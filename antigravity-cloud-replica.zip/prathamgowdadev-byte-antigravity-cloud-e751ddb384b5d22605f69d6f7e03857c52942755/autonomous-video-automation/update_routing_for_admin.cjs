const fs = require('fs');

// 1. Update api/serve_project.js
const servePath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system\\api\\serve_project.js';
let serveCode = fs.readFileSync(servePath, 'utf8');

const targetPaths = `  // 1. Try local disk first or fetch pre-compiled prototype from GitHub
  const paths = [
    \`projects/\${slug}/index.html\`,
    \`prototypes/\${slug}/index.html\`
  ];`;

const newPaths = `  // 1. Try local disk first or fetch pre-compiled prototype from GitHub
  const isAdmin = (req.query && (req.query.admin === 'true' || req.query.admin === '1')) || slug.includes('admin');
  const cleanSlug = slug.replace(/\\/(admin|index)(\\.html)?$/, '').replace(/-admin$/, '');

  const paths = isAdmin ? [
    \`projects/\${cleanSlug}/admin.html\`,
    \`projects/\${slug}/admin.html\`,
    \`projects/\${slug}/index.html\`,
    \`prototypes/\${slug}/index.html\`
  ] : [
    \`projects/\${slug}/index.html\`,
    \`prototypes/\${slug}/index.html\`
  ];`;

serveCode = serveCode.replace(targetPaths, () => newPaths);
fs.writeFileSync(servePath, serveCode, 'utf8');
console.log('Updated api/serve_project.js for admin routing.');

// 2. Update vercel.json
const vercelPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system\\vercel.json';
const vercelConfig = {
  "crons": [
    {
      "path": "/api/cron_hunt",
      "schedule": "*/30 * * * *"
    }
  ],
  "rewrites": [
    {
      "source": "/projects/:slug/admin.html",
      "destination": "/api/serve_project?slug=:slug&admin=true"
    },
    {
      "source": "/projects/:slug/admin",
      "destination": "/api/serve_project?slug=:slug&admin=true"
    },
    {
      "source": "/projects/:slug/index.html",
      "destination": "/api/serve_project?slug=:slug"
    },
    {
      "source": "/projects/:slug",
      "destination": "/api/serve_project?slug=:slug"
    }
  ]
};

fs.writeFileSync(vercelPath, JSON.stringify(vercelConfig, null, 2), 'utf8');
console.log('Updated vercel.json with admin rewrite rules.');
