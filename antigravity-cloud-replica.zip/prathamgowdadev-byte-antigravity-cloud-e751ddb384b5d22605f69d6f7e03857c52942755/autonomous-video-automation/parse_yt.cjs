const fs = require('fs');

const path = 'C:/Users/WINDOWS/.gemini/antigravity/brain/89cf8d98-dd47-4e89-be0a-1ca403d809e8/.system_generated/steps/1539/content.md';
const content = fs.readFileSync(path, 'utf8');

// Title
const titleMatch = content.match(/<title>([^<]+)<\/title>/);
console.log('Title:', titleMatch ? titleMatch[1] : 'N/A');

// og:title
const ogTitleMatch = content.match(/property="og:title" content="([^"]+)"/);
console.log('OG Title:', ogTitleMatch ? ogTitleMatch[1] : 'N/A');

// og:description
const ogDescMatch = content.match(/property="og:description" content="([^"]+)"/);
console.log('OG Description:', ogDescMatch ? ogDescMatch[1] : 'N/A');

// video details in ytInitialPlayerResponse or ytInitialData
const vDetails = content.match(/"shortDescription":"([^"]+)"/);
if (vDetails) {
  console.log('Short Description:', vDetails[1].replace(/\\n/g, '\n').slice(0, 800));
}

const channelMatch = content.match(/"ownerChannelName":"([^"]+)"/);
console.log('Channel:', channelMatch ? channelMatch[1] : 'N/A');
