const fs = require('fs');

async function checkVideo() {
  try {
    const res = await fetch('https://www.youtube.com/watch?v=rJC6iwozKEE', {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
      }
    });
    const html = await res.text();
    const captionMatch = html.match(/"captionTracks":\s*(\[.*?\])/);
    if (captionMatch) {
      const tracks = JSON.parse(captionMatch[1]);
      console.log('Tracks found:', tracks.length);
      const enTrack = tracks.find(t => t.languageCode === 'en') || tracks[0];
      if (enTrack && enTrack.baseUrl) {
        const capRes = await fetch(enTrack.baseUrl);
        const capXml = await capRes.text();
        const text = capXml.replace(/<[^>]+>/g, ' ').replace(/\s+/g, ' ');
        console.log('Transcript sample (first 1000 chars):');
        console.log(text.slice(0, 1000));
        fs.writeFileSync('C:/Users/WINDOWS/.gemini/antigravity/brain/89cf8d98-dd47-4e89-be0a-1ca403d809e8/scratch/yt_transcript.txt', text);
      }
    } else {
      console.log('No caption tracks found in HTML');
    }
  } catch (e) {
    console.error('Error:', e.message);
  }
}

checkVideo();
