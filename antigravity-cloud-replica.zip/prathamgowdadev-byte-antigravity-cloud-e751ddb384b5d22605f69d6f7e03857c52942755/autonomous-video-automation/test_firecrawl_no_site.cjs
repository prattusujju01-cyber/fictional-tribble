const FIRECRAWL_KEY = "fc-9580658b488a4455850b07c92bd7ed59";

async function searchNoWebsite(niche, city) {
  // Businesses with social media / directory presence but no dedicated website
  const queries = [
    `"${niche}" "${city}" site:facebook.com "call now" OR "phone" -site:instagram.com`,
    `"${niche}" "${city}" site:yellowpages.com "Phone"`,
    `"${niche}" in "${city}" "call" "hours" "address" "no website"`
  ];

  for (const q of queries) {
    console.log(`\nQuerying: ${q}...`);
    try {
      const res = await fetch("https://api.firecrawl.dev/v1/search", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${FIRECRAWL_KEY}`,
          "Content-Type": "application/json"
        },
        body: JSON.stringify({
          query: q,
          limit: 3
        })
      });
      const data = await res.json();
      if (data.data) {
        console.log(`Found ${data.data.length} results.`);
        for (const item of data.data) {
          console.log(`Title: ${item.title}`);
          console.log(`URL: ${item.url}`);
          // Extract phone regex
          const desc = item.description || "";
          const phoneMatch = desc.match(/(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
          console.log(`Phone: ${phoneMatch ? phoneMatch[0] : 'None detected'}`);
        }
      }
    } catch (e) {
      console.error(e.message);
    }
  }
}

searchNoWebsite("roofer", "Austin");
