const { PALETTE_MATRIX_100, generateLuxuryHTML } = require('./brand_engine.cjs');

console.log('Total Palettes:', PALETTE_MATRIX_100.length);

const carLead = {
  slug: 'architectural-exports-in-sion-west',
  name: 'Architectural Exports In Sion West',
  niche: 'Car Detailing & Ceramic Studio',
  city: 'Mumbai, Maharashtra',
  address: 'Sion West, Mumbai 400022',
  phone: '+91 93723 17501',
  cleanPhone: '9372317501',
  rating: '4.7',
  reviews: '104'
};

const carHtml = generateLuxuryHTML(carLead);
console.log('\n--- CAR DETAILING RESULT ---');
console.log('HTML Length:', carHtml.length);
console.log('H1:', (carHtml.match(/<h1[\s\S]*?<\/h1>/) || [''])[0].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim());
console.log('Has Pinwrap (Full Screen Hero):', carHtml.includes('class="pinwrap"'));
console.log('Has Photo Chapters:', (carHtml.match(/class="ch"/g) || []).length);
console.log('Has 0+ or 0k+ slop:', carHtml.includes('0k+') || carHtml.includes('0+ YEARS'));
console.log('Has RERA in Auto Detailing:', carHtml.includes('RERA'));
console.log('Has 9H Graphene Ceramic:', carHtml.includes('9H'));

const dentalLead = {
  slug: 'all-smiles-dental-clinic-bangalore',
  name: 'All Smiles Dental Clinic',
  niche: 'Dental Clinic & Implantology Center',
  city: 'Bangalore, Karnataka',
  address: '100 Feet Road, Indiranagar, Bangalore 560038',
  phone: '+91 79751 92509',
  cleanPhone: '7975192509',
  rating: '4.9',
  reviews: '184'
};

const dentalHtml = generateLuxuryHTML(dentalLead);
console.log('\n--- DENTAL RESULT ---');
console.log('HTML Length:', dentalHtml.length);
console.log('H1:', (dentalHtml.match(/<h1[\s\S]*?<\/h1>/) || [''])[0].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim());
console.log('Has 0+ or 0k+ slop:', dentalHtml.includes('0k+') || dentalHtml.includes('0+ YEARS'));
console.log('Has Neo-Clinic traces:', dentalHtml.includes('neo-clinic') || dentalHtml.includes('Surgical Ice Cyan'));
