async function testModels() {
  console.log("1. Testing Open-Source Qwen 2.5...");
  try {
    const res = await fetch("https://text.pollinations.ai/", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: [
          { role: "system", content: "You are an elite documentary screenwriter for high-retention YouTube essays." },
          { role: "user", content: "Write a 2-sentence hook for: What Did Ancient Humans Do at Night?" }
        ],
        model: "qwen"
      })
    });
    const text = await res.text();
    console.log("Qwen Response:\n", text);
  } catch (e) {
    console.error("Qwen Error:", e.message);
  }

  console.log("\n2. Testing Open-Source FLUX.1 Visual Generation...");
  try {
    const prompt = encodeURIComponent("minimalist 2D hand-drawn line art illustration, expressive stickman caveman lying inside prehistoric cave, glowing campfire, crescent moon in dark night sky, atmospheric textured paper, style of Zenn animation");
    const imgUrl = `https://image.pollinations.ai/prompt/${prompt}?width=1280&height=720&model=flux&nologo=true`;
    console.log("FLUX Image URL:", imgUrl);
    const imgRes = await fetch(imgUrl);
    console.log("FLUX Image Status:", imgRes.status, "Content-Type:", imgRes.headers.get("content-type"), "Length:", imgRes.headers.get("content-length"));
  } catch (e) {
    console.error("FLUX Error:", e.message);
  }
}

testModels();
