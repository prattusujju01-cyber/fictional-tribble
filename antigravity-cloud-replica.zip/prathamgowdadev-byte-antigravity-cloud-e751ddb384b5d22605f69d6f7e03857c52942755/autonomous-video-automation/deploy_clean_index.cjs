const fs = require('fs');
const path = require('path');

const srcPath = path.join(__dirname, 'clean_index.html');
const destIndex = path.join('C:', 'Users', 'WINDOWS', '.gemini', 'antigravity', 'scratch', 'asura-system', 'index.html');
const destDist = path.join('C:', 'Users', 'WINDOWS', '.gemini', 'antigravity', 'scratch', 'asura-system', 'dist', 'index.html');

const content = fs.readFileSync(srcPath, 'utf8');

// Validate script syntax
const scriptMatch = content.match(/<script>([\s\S]*?)<\/script>/);
if (!scriptMatch) {
  console.error('ERROR: Could not find main script block!');
  process.exit(1);
}

try {
  new Function(scriptMatch[1]);
  console.log('[VALIDATION OK] Main JavaScript block has 0 syntax errors!');
} catch (e) {
  console.error('[VALIDATION FAILED] Syntax error in script block:', e);
  process.exit(1);
}

// Copy to targets
fs.writeFileSync(destIndex, content, 'utf8');
console.log('[COPY OK] Wrote to:', destIndex);

fs.writeFileSync(destDist, content, 'utf8');
console.log('[COPY OK] Wrote to:', destDist);
