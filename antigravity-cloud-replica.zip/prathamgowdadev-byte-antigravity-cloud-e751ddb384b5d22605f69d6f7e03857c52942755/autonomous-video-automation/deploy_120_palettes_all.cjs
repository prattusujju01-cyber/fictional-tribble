const fs = require('fs');
const path = require('path');
const { PALETTE_MATRIX_100, generateLuxuryHTML, selectPalette } = require('./brand_engine.cjs');

const GITHUB_TOKEN = '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';
const REPO = 'prathamgowda194-pixel/asura-system';

async function api(endpoint, method = 'GET', body = null) {
  const opts = {
    method,
    headers: {
      'Authorization': `Bearer ${GITHUB_TOKEN}`,
      'User-Agent': 'ASURA-Deployer',
      'Accept': 'application/vnd.github.v3+json'
    }
  };
  if (body) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(`https://api.github.com/repos/${REPO}${endpoint}`, opts);
  return await res.json();
}

async function run() {
  console.log('⚡ COMMITTING 120 LUXURY PALETTES, AUTO-DETAILING ENGINE & PURGING NEO-CLINIC...');

  const leadsPath = path.join(__dirname, 'data', 'hunter_leads.json');
  let leads = JSON.parse(fs.readFileSync(leadsPath, 'utf8'));

  const carLead = {
    slug: 'architectural-exports-in-sion-west',
    name: 'Architectural Exports In Sion West',
    niche: 'Car Detailing & Ceramic Studio',
    city: 'Mumbai, Maharashtra',
    address: 'Sion West, Mumbai 400022',
    phone: '+91 93723 17501',
    cleanPhone: '9372317501',
    rating: '4.7',
    reviews: '104',
    hasWebsite: false,
    prototypeUrl: 'https://asura-system.vercel.app/projects/architectural-exports-in-sion-west/index.html',
    vercelUrl: 'https://asura-system.vercel.app/projects/architectural-exports-in-sion-west/index.html',
    status: 'PROTOTYPE_DEPLOYED'
  };

  // Add carLead if not present
  leads = leads.filter(l => l.slug !== carLead.slug);
  leads.unshift(carLead);

  // Update archetypes with 120 palette names
  leads.forEach(l => {
    const pal = selectPalette(l.slug, l.name);
    l.archetype = pal.name;
    l.updatedAt = new Date().toISOString();
  });

  fs.writeFileSync(leadsPath, JSON.stringify(leads, null, 2), 'utf8');
  console.log(`✅ Leads updated with 120-palette assignments. Total leads: ${leads.length}`);

  // Update cron_hunt.js
  const cronPath = path.join(__dirname, 'api', 'cron_hunt.js');
  let cronCode = fs.readFileSync(cronPath, 'utf8');
  if (!cronCode.includes('architectural-exports-in-sion-west')) {
    const snippet = `  {\n    name: "Architectural Exports In Sion West",\n    niche: "Car Detailing & Ceramic Studio",\n    city: "Mumbai, Maharashtra",\n    address: "Sion West, Mumbai 400022",\n    phone: "+91 93723 17501",\n    cleanPhone: "9372317501",\n    rating: "4.7",\n    reviews: "104",\n    slug: "architectural-exports-in-sion-west",\n    archetype: "${selectPalette('architectural-exports-in-sion-west', 'Architectural Exports In Sion West').name}"\n  },\n`;
    cronCode = cronCode.replace('const CLIENT_PORTFOLIO = [\n', 'const CLIENT_PORTFOLIO = [\n' + snippet);
    fs.writeFileSync(cronPath, cronCode, 'utf8');
    console.log('✅ Added Architectural Exports to api/cron_hunt.js');
  }

  // Generate HTML for all leads and create blobs
  const treeEntries = [];

  for (const lead of leads) {
    const html = generateLuxuryHTML(lead);

    // Verify zero 0-start counter slop
    if (html.includes('0k+') || html.includes('0+ YEARS') || html.includes('class="counter"')) {
      throw new Error(`CRITICAL: Found 0-start counter slop in ${lead.slug}!`);
    }

    // Save locally
    const localDir = path.join(__dirname, 'projects', lead.slug);
    if (!fs.existsSync(localDir)) fs.mkdirSync(localDir, { recursive: true });
    fs.writeFileSync(path.join(localDir, 'index.html'), html, 'utf8');

    // Create blob
    const blob = await api('/git/blobs', 'POST', {
      content: Buffer.from(html, 'utf8').toString('base64'),
      encoding: 'base64'
    });

    treeEntries.push({ path: `projects/${lead.slug}/index.html`, mode: '100644', type: 'blob', sha: blob.sha });
    treeEntries.push({ path: `prototypes/${lead.slug}/index.html`, mode: '100644', type: 'blob', sha: blob.sha });
    console.log(`✅ Synced: ${lead.name} -> ${lead.archetype}`);
  }

  // Upload core files
  const brandContent = fs.readFileSync(path.join(__dirname, 'brand_engine.cjs'), 'utf8');
  const brandBlob = await api('/git/blobs', 'POST', {
    content: Buffer.from(brandContent, 'utf8').toString('base64'),
    encoding: 'base64'
  });
  treeEntries.push({ path: 'brand_engine.cjs', mode: '100644', type: 'blob', sha: brandBlob.sha });

  const serveContent = fs.readFileSync(path.join(__dirname, 'api', 'serve_project.js'), 'utf8');
  const serveBlob = await api('/git/blobs', 'POST', {
    content: Buffer.from(serveContent, 'utf8').toString('base64'),
    encoding: 'base64'
  });
  treeEntries.push({ path: 'api/serve_project.js', mode: '100644', type: 'blob', sha: serveBlob.sha });

  const cronContent = fs.readFileSync(cronPath, 'utf8');
  const cronBlob = await api('/git/blobs', 'POST', {
    content: Buffer.from(cronContent, 'utf8').toString('base64'),
    encoding: 'base64'
  });
  treeEntries.push({ path: 'api/cron_hunt.js', mode: '100644', type: 'blob', sha: cronBlob.sha });

  const leadsBlob = await api('/git/blobs', 'POST', {
    content: Buffer.from(JSON.stringify(leads, null, 2), 'utf8').toString('base64'),
    encoding: 'base64'
  });
  treeEntries.push({ path: 'data/hunter_leads.json', mode: '100644', type: 'blob', sha: leadsBlob.sha });

  console.log(`🌳 Assembling git tree with ${treeEntries.length} entries...`);
  const ref = await api('/git/ref/heads/main');
  const parentSha = ref.object.sha;
  const parentCommit = await api(`/git/commits/${parentSha}`);

  const tree = await api('/git/trees', 'POST', {
    base_tree: parentCommit.tree.sha,
    tree: treeEntries
  });

  console.log('✍️ Signing atomic commit...');
  const commit = await api('/git/commits', 'POST', {
    message: 'feat(brand-engine): 120 luxury palettes, autodetailing niche, purge neo-clinic, and zero-slop solid stats',
    tree: tree.sha,
    parents: [parentSha]
  });

  console.log('🚀 Pushing to main branch...');
  const updatedRef = await api('/git/refs/heads/main', 'PATCH', {
    sha: commit.sha,
    force: false
  });

  console.log('🎉 120-PALETTE ENGINE DEPLOYED SUCCESSFULLY! Commit SHA:', updatedRef.object.sha);
}

run().catch(err => {
  console.error('❌ Error during deployment:', err);
  process.exit(1);
});
