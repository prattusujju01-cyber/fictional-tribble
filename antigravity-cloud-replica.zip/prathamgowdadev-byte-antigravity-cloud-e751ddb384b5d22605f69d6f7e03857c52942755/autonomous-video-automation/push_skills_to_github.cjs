const fs = require('fs');
const path = require('path');

const CONFIG = {
  GITHUB_TOKEN: process.env.GITHUB_TOKEN || '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',
  REPO_OWNER: 'prathamgowda194-pixel',
  REPO_NAME: 'asura-system'
};

const FILES = [
  'index.html',
  'dist/index.html',
  'projects/studio/index.html',
  'api/generate_website.js',
  'lib/asura_skills_orchestrator.cjs',
  'mcp_config.json',
  'docs/SKILLS_AND_MCP_MANUAL.md',
  'skills/frontend-design/SKILL.md',
  'skills/ui-ux-pro-max/SKILL.md',
  'skills/design-taste-frontend/SKILL.md',
  'skills/shadcn-ui-mcp/SKILL.md',
  'skills/magic-mcp-21st/SKILL.md',
  'skills/vercel-react-best-practices/SKILL.md',
  'skills/vercel-react-native-skills/SKILL.md',
  'skills/gsap-master/SKILL.md',
  'skills/motion-framer/SKILL.md',
  'skills/convex-create-component/SKILL.md'
];

async function getFileSha(remotePath) {
  const url = `https://api.github.com/repos/${CONFIG.REPO_OWNER}/${CONFIG.REPO_NAME}/contents/${remotePath}`;
  try {
    const res = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${CONFIG.GITHUB_TOKEN}`,
        'User-Agent': 'Node.js/GitHub-Sync'
      }
    });
    if (res.status === 200) {
      const data = await res.json();
      return data.sha;
    }
  } catch (e) {}
  return null;
}

async function uploadFile(localPath) {
  const fullPath = path.join('C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system', localPath);
  if (!fs.existsSync(fullPath)) {
    console.error(`File missing: ${fullPath}`);
    return;
  }

  const content = fs.readFileSync(fullPath).toString('base64');
  const remotePath = localPath.replace(/\\/g, '/');
  const sha = await getFileSha(remotePath);

  const payload = {
    message: `feat(skills): integrate 10 frontend design skills, gsap, framer & mcp servers [${remotePath}]`,
    content,
    branch: 'main'
  };
  if (sha) payload.sha = sha;

  const url = `https://api.github.com/repos/${CONFIG.REPO_OWNER}/${CONFIG.REPO_NAME}/contents/${remotePath}`;
  const res = await fetch(url, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${CONFIG.GITHUB_TOKEN}`,
      'Content-Type': 'application/json',
      'User-Agent': 'Node.js/GitHub-Sync'
    },
    body: JSON.stringify(payload)
  });

  if (res.status === 200 || res.status === 201) {
    console.log(`[SYNC OK] Pushed ${remotePath} to GitHub main.`);
  } else {
    const text = await res.text();
    console.error(`[SYNC FAIL] ${remotePath}: ${res.status} - ${text}`);
  }
}

async function main() {
  for (const f of FILES) {
    await uploadFile(f);
  }
  console.log('Finished pushing all Asura 10-Skill files to GitHub.');
}

main().catch(console.error);
