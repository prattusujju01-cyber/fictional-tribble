const fs = require('fs');
const path = require('path');

const targetServe = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system\\api\\serve_project.js';
const targetVercel = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system\\vercel.json';

const serveCode = `/**
 * ASURA EDGE PROJECT SERVICER // INSTANT ZERO-RATE-LIMIT GATEWAY
 * Dynamically serves live client prototypes directly from GitHub storage.
 * Eliminates Vercel 100-deployment/day rate limits forever.
 */

const GITHUB_TOKEN = process.env.GITHUB_TOKEN || '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';
const REPO = 'prathamgowda194-pixel/asura-system';

export default async function handler(req, res) {
  const slug = (req.query.slug || '').replace(/[^a-z0-9-]/gi, '');
  if (!slug) {
    return res.status(400).send("<h1>Missing project slug</h1>");
  }

  const fileUrl = \`https://raw.githubusercontent.com/\${REPO}/main/projects/\${slug}/index.html?t=\${Date.now()}\`;

  try {
    const rawRes = await fetch(fileUrl, {
      headers: {
        'Authorization': \`Bearer \${GITHUB_TOKEN}\`,
        'Accept': 'text/plain'
      }
    });

    if (rawRes.status === 200) {
      const html = await rawRes.text();
      res.setHeader('Content-Type', 'text/html; charset=utf-8');
      res.setHeader('Cache-Control', 'public, max-age=60, s-maxage=300');
      return res.status(200).send(html);
    } else {
      // Fallback: try GitHub Contents API
      const apiEndpoint = \`https://api.github.com/repos/\${REPO}/contents/projects/\${slug}/index.html\`;
      const apiRes = await fetch(apiEndpoint, {
        headers: {
          'Authorization': \`Bearer \${GITHUB_TOKEN}\`,
          'User-Agent': 'ASURA-Edge'
        }
      });
      if (apiRes.status === 200) {
        const data = await apiRes.json();
        const decoded = Buffer.from(data.content, 'base64').toString('utf8');
        res.setHeader('Content-Type', 'text/html; charset=utf-8');
        res.setHeader('Cache-Control', 'public, max-age=60, s-maxage=300');
        return res.status(200).send(decoded);
      }
      return res.status(404).send(\`<h1>Project "\${slug}" is still compiling or not found.</h1>\`);
    }
  } catch (err) {
    return res.status(500).send("<h1>Internal gateway error retrieving prototype.</h1>");
  }
}
`;

const vercelConfig = {
  "rewrites": [
    {
      "source": "/projects/:slug/index.html",
      "destination": "/api/serve_project?slug=:slug"
    },
    {
      "source": "/projects/:slug",
      "destination": "/api/serve_project?slug=:slug"
    }
  ]
};

fs.writeFileSync(targetServe, serveCode, 'utf8');
fs.writeFileSync(targetVercel, JSON.stringify(vercelConfig, null, 2), 'utf8');
console.log('Successfully created api/serve_project.js and vercel.json');
