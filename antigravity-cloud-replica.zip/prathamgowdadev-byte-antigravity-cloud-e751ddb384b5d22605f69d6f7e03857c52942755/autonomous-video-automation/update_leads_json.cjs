const fs = require('fs');
const path = require('path');

const leadsPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system\\data\\hunter_leads.json';

const CLIENTS = [
  {
    slug: "bridge-property-consultants-mumbai",
    name: "Bridge Property Consultants",
    niche: "Luxury Real Estate & Villa Developers",
    city: "Mumbai, Maharashtra",
    phone: "+91 93202 93840",
    cleanPhone: "9320293840",
    address: "Below Flyover, Sanyas Ashram Chowk, Vile Parle West, Mumbai 400056",
    rating: "4.9",
    reviews: "129",
    archetype: "The Atelier Noir (Champagne Brass & Obsidian)"
  },
  {
    slug: "gkb-gkb-construction-llp-building",
    name: "GKB Construction LLP",
    niche: "Civil Construction & Turnkey High-Rises",
    city: "Jaipur, Rajasthan",
    phone: "+91 93529 81701",
    cleanPhone: "9352981701",
    address: "C-Scheme & Tonk Road, Jaipur 302001",
    rating: "4.9",
    reviews: "114",
    archetype: "The Cocoon Sanctuary (Terracotta & Alabaster)"
  },
  {
    slug: "skin-secrets-in-edappally-cochin-kochi",
    name: "Skin Secrets Aesthetic Clinic",
    niche: "Dermatology & Aesthetic Clinic",
    city: "Kochi, Kerala",
    phone: "+91 75609 07255",
    cleanPhone: "7560907255",
    address: "Metro Pillar 482, Edappally, Cochin 682024",
    rating: "4.8",
    reviews: "168",
    archetype: "The Architectural Brutalist (Signal Amber & Carbon)"
  },
  {
    slug: "bhoomiputra-real-estate-developers",
    name: "Bhoomiputra Real Estate Developers",
    niche: "Luxury Real Estate & Land Promoters",
    city: "Bangalore, Karnataka",
    phone: "+91 63632 73458",
    cleanPhone: "6363273458",
    address: "Nagadevanahalli & Kengeri, Bangalore, Karnataka 560060",
    rating: "4.8",
    reviews: "145",
    archetype: "The Emerald Estate (Forest Green & Antique Gold)"
  },
  {
    slug: "all-smiles-dental-clinic-bangalore",
    name: "All Smiles Dental Clinic",
    niche: "Dental Clinic & Implantology Center",
    city: "Bangalore, Karnataka",
    phone: "+91 79751 92509",
    cleanPhone: "7975192509",
    address: "100 Feet Road, Indiranagar, Bangalore, Karnataka 560038",
    rating: "4.9",
    reviews: "184",
    archetype: "The Neo-Clinic Avant-Garde (Surgical Cyan & Ice)"
  },
  {
    slug: "impact-fitness-center-bangalore",
    name: "Impact Fitness Center",
    niche: "Premium Fitness & Crossfit Studio",
    city: "Bangalore, Karnataka",
    phone: "+91 87920 38282",
    cleanPhone: "8792038282",
    address: "Electronics City Phase 1, Bangalore, Karnataka 560100",
    rating: "4.8",
    reviews: "96",
    archetype: "The Scandinavian Craft (Sandstone & Paper White)"
  },
  {
    slug: "s-m-corporation-interiors-bangalore",
    name: "S M Corporation Interiors",
    niche: "Interior Architecture & Modular Living",
    city: "Bangalore, Karnataka",
    phone: "+91 99808 15604",
    cleanPhone: "9980815604",
    address: "27th Main Rd, HSR Layout Sector 2, Bangalore 560102",
    rating: "4.8",
    reviews: "72",
    archetype: "The Industrial Kinetic (Crimson Flare & Matte Gunmetal)"
  },
  {
    slug: "xanadu-bangalore",
    name: "Xanadu Realty Estates",
    niche: "Luxury Real Estate & Villa Developers",
    city: "Bangalore, Karnataka",
    phone: "+91 76192 54435",
    cleanPhone: "7619254435",
    address: "Lavelle Road, Bangalore 560001",
    rating: "4.9",
    reviews: "88",
    archetype: "The Minimalist Monolith (Chanel Editorial White & Black)"
  },
  {
    slug: "mumbai-real-estate-professionals",
    name: "Mumbai Real Estate Professionals",
    niche: "Luxury Real Estate & Villa Developers",
    city: "Mumbai, Maharashtra",
    phone: "+91 84596 14982",
    cleanPhone: "8459614982",
    address: "BKC, Mumbai 400051",
    rating: "4.8",
    reviews: "75",
    archetype: "The Atelier Noir (Champagne Brass & Obsidian)"
  },
  {
    slug: "blr-properties-in-kammanahalli-main",
    name: "BLR Properties Consultants",
    niche: "Luxury Real Estate & Villa Developers",
    city: "Bangalore, Karnataka",
    phone: "+91 84602 46249",
    cleanPhone: "8460246249",
    address: "Kammanahalli Main Road, Bangalore 560084",
    rating: "4.8",
    reviews: "101",
    archetype: "The Cocoon Sanctuary (Terracotta & Alabaster)"
  },
  {
    slug: "shankar-real-estate-agency-bangalore",
    name: "Shankar Real Estate Agency",
    niche: "Real Estate Consultancy & Commercial Brokerage",
    city: "Bangalore, Karnataka",
    phone: "+91 70411 24398",
    cleanPhone: "7041124398",
    address: "Sanjay Nagar, Bangalore 560094",
    rating: "4.8",
    reviews: "166",
    archetype: "The Architectural Brutalist (Signal Amber & Carbon)"
  },
  {
    slug: "kdc-dental-clinic-bangalore",
    name: "KDC Dental & Implantology",
    niche: "Dental Clinic & Implantology Center",
    city: "Bangalore, Karnataka",
    phone: "+91 80501 03103",
    cleanPhone: "8050103103",
    address: "Koramangala 4th Block, Bangalore 560034",
    rating: "4.8",
    reviews: "81",
    archetype: "The Emerald Estate (Forest Green & Antique Gold)"
  },
  {
    slug: "sp-interior-design-studio-in",
    name: "SP Interior Design Studio",
    niche: "Interior Architecture & Modular Living",
    city: "Bangalore, Karnataka",
    phone: "+91 99805 45562",
    cleanPhone: "9980545562",
    address: "Gattahalli & Sarjapur Road, Bangalore 560099",
    rating: "4.9",
    reviews: "54",
    archetype: "The Neo-Clinic Avant-Garde (Surgical Cyan & Ice)"
  },
  {
    slug: "karnataka-elite-nri-property-expo",
    name: "Karnataka Elite NRI Real Estate",
    niche: "Luxury Real Estate & Villa Developers",
    city: "Bangalore, Karnataka",
    phone: "+91 96860 40864",
    cleanPhone: "9686040864",
    address: "MG Road, Bangalore 560001",
    rating: "5.0",
    reviews: "60",
    archetype: "The Scandinavian Craft (Sandstone & Paper White)"
  },
  {
    slug: "dental-clinic-best-dentist-clinic",
    name: "Ridgetop Dental International",
    niche: "Dental Clinic & Implantology Center",
    city: "Bangalore, Karnataka",
    phone: "+91 80476 77564",
    cleanPhone: "8047677564",
    address: "Indiranagar, Bangalore 560038",
    rating: "4.8",
    reviews: "102",
    archetype: "The Industrial Kinetic (Crimson Flare & Matte Gunmetal)"
  },
  {
    slug: "bangalore-real-estate-help-bangalore",
    name: "Prime Bengaluru Realty",
    niche: "Luxury Real Estate & Villa Developers",
    city: "Bangalore, Karnataka",
    phone: "+91 95850 22037",
    cleanPhone: "9585022037",
    address: "Whitefield, Bangalore 560066",
    rating: "4.9",
    reviews: "59",
    archetype: "The Minimalist Monolith (Chanel Editorial White & Black)"
  }
];

const leads = CLIENTS.map(c => ({
  ...c,
  id: `ind_lead_${c.slug}`,
  hasWebsite: false,
  prototypeUrl: `https://asura-system.vercel.app/projects/${c.slug}/index.html`,
  vercelUrl: `https://asura-system.vercel.app/projects/${c.slug}/index.html`,
  status: "PROTOTYPE_DEPLOYED",
  updatedAt: new Date().toISOString()
}));

fs.writeFileSync(leadsPath, JSON.stringify(leads, null, 2), 'utf8');
console.log('Successfully updated hunter_leads.json with', leads.length, 'clients');
