const fs = require('fs');
const path = require('path');

const targetDir = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system';

// 1. scripts/whatsapp_engine.cjs
const engineCode = `/**
 * ==============================================================================
 * ASURA AUTOMATED WHATSAPP BOT ENGINE
 * ==============================================================================
 * - Exact Welcome Message Format Interpolation:
 *   "Hi there! Thanks for reaching out to [Business Name]. We help with [Service/Product]. How can we help you today? We usually reply within [Time]"
 * - 24-Hour Anti-Spam Conversation Cooldown
 * - Automated Lead Logging to data/whatsapp_leads.json & MongoDB Atlas
 * - Dual Engine: Official Meta WhatsApp Cloud API + Standalone Simulator
 * ==============================================================================
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

const ROOT_DIR = path.resolve(__dirname, '..');
const CONFIG_FILE = path.join(ROOT_DIR, 'whatsapp_config.json');
const DATA_DIR = path.join(ROOT_DIR, 'data');
const STATE_FILE = path.join(DATA_DIR, 'whatsapp_conversation_state.json');
const LEADS_FILE = path.join(DATA_DIR, 'whatsapp_leads.json');

if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

function loadConfig() {
  const defaults = {
    business_name: 'Asura Digital Agency',
    service_product: 'high-converting custom websites and automated growth systems',
    reply_time: '15 minutes',
    welcome_message_template: 'Hi there! Thanks for reaching out to {business_name}. We help with {service_product}. How can we help you today? We usually reply within {reply_time}',
    anti_spam_cooldown_hours: 24,
    save_leads_to_mongodb: true,
    save_leads_to_local_json: true,
    meta_cloud_api: {
      phone_number_id: process.env.WHATSAPP_PHONE_NUMBER_ID || '',
      access_token: process.env.WHATSAPP_ACCESS_TOKEN || '',
      verify_token: process.env.WHATSAPP_VERIFY_TOKEN || 'asura_whatsapp_secret_verify_token',
      graph_api_version: 'v19.0'
    }
  };

  if (fs.existsSync(CONFIG_FILE)) {
    try {
      const userCfg = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf8'));
      return { ...defaults, ...userCfg };
    } catch (e) {
      console.warn('[WHATSAPP ENGINE] Error reading config, using defaults:', e.message);
    }
  }
  return defaults;
}

function formatWelcomeMessage(overrides = {}) {
  const cfg = loadConfig();
  const businessName = overrides.business_name || cfg.business_name || '[Business Name]';
  const serviceProduct = overrides.service_product || cfg.service_product || '[Service/Product]';
  const replyTime = overrides.reply_time || cfg.reply_time || '[Time]';

  let message = cfg.welcome_message_template || 'Hi there! Thanks for reaching out to {business_name}. We help with {service_product}. How can we help you today? We usually reply within {reply_time}';
  message = message.replace('{business_name}', businessName);
  message = message.replace('{service_product}', serviceProduct);
  message = message.replace('{reply_time}', replyTime);

  return message;
}

function loadConversationState() {
  if (fs.existsSync(STATE_FILE)) {
    try {
      return JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
    } catch (e) {
      return {};
    }
  }
  return {};
}

function saveConversationState(state) {
  try {
    fs.writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf8');
  } catch (e) {
    console.error('[WHATSAPP ENGINE] Failed to save conversation state:', e.message);
  }
}

function shouldSendGreeting(phoneNumber, customCooldownHours = null) {
  if (!phoneNumber) return false;
  const cleanPhone = String(phoneNumber).replace(/\\D/g, '');
  const state = loadConversationState();
  const cfg = loadConfig();
  const cooldownHours = customCooldownHours !== null ? customCooldownHours : (cfg.anti_spam_cooldown_hours || 24);
  const cooldownMs = cooldownHours * 60 * 60 * 1000;

  const lastSent = state[cleanPhone]?.last_greeting_sent_at;
  const now = Date.now();

  if (!lastSent || (now - lastSent) > cooldownMs) {
    state[cleanPhone] = {
      ...(state[cleanPhone] || {}),
      last_greeting_sent_at: now,
      message_count: (state[cleanPhone]?.message_count || 0) + 1
    };
    saveConversationState(state);
    return true;
  }

  state[cleanPhone].message_count = (state[cleanPhone]?.message_count || 0) + 1;
  state[cleanPhone].last_incoming_at = now;
  saveConversationState(state);
  return false;
}

function saveLeadLocally(lead) {
  let leads = [];
  if (fs.existsSync(LEADS_FILE)) {
    try {
      leads = JSON.parse(fs.readFileSync(LEADS_FILE, 'utf8'));
      if (!Array.isArray(leads)) leads = [];
    } catch (e) {
      leads = [];
    }
  }

  const cleanPhone = String(lead.phone || '').replace(/\\D/g, '');
  const existingIdx = leads.findIndex(l => String(l.phone || '').replace(/\\D/g, '') === cleanPhone);

  if (existingIdx >= 0) {
    leads[existingIdx].last_activity = new Date().toISOString();
    leads[existingIdx].inquiry_history = leads[existingIdx].inquiry_history || [];
    leads[existingIdx].inquiry_history.push({
      text: lead.message || '',
      received_at: new Date().toISOString()
    });
  } else {
    leads.unshift({
      phone: lead.phone,
      name: lead.name || 'WhatsApp Client',
      first_contact_at: new Date().toISOString(),
      last_activity: new Date().toISOString(),
      source: lead.source || 'WhatsApp Inbound',
      initial_message: lead.message || '',
      inquiry_history: [{
        text: lead.message || '',
        received_at: new Date().toISOString()
      }]
    });
  }

  try {
    fs.writeFileSync(LEADS_FILE, JSON.stringify(leads, null, 2), 'utf8');
  } catch (e) {
    console.error('[WHATSAPP ENGINE] Error writing leads file:', e.message);
  }
}

async function saveLeadToMongo(lead) {
  const cfg = loadConfig();
  if (!cfg.save_leads_to_mongodb) return;

  try {
    const { MongoClient } = require('mongodb');
    const mongoUri = process.env.MONGODB_URI || 'mongodb+srv://prathamgowda194_db_user:k6Y9FnOekKvYxceA@cluster0.zf9zbow.mongodb.net/crypto_lottery?retryWrites=true&w=majority&appName=Cluster0';
    const client = new MongoClient(mongoUri, { connectTimeoutMS: 4000 });
    await client.connect();
    const db = client.db('crypto_lottery');
    const col = db.collection('whatsapp_leads');

    const cleanPhone = String(lead.phone || '').replace(/\\D/g, '');
    await col.updateOne(
      { phone: cleanPhone },
      {
        $set: {
          phone: cleanPhone,
          name: lead.name || 'WhatsApp Client',
          last_activity: new Date()
        },
        $setOnInsert: {
          first_contact_at: new Date(),
          source: 'WhatsApp Inbound'
        },
        $push: {
          messages: {
            text: lead.message || '',
            timestamp: new Date()
          }
        }
      },
      { upsert: true }
    );
    await client.close();
  } catch (e) {
    console.warn('[WHATSAPP ENGINE] Mongo lead log fallback:', e.message);
  }
}

async function sendWhatsAppMessage(toPhone, messageText) {
  const cfg = loadConfig();
  const meta = cfg.meta_cloud_api || {};
  const phoneNumberId = meta.phone_number_id || process.env.WHATSAPP_PHONE_NUMBER_ID;
  const accessToken = meta.access_token || process.env.WHATSAPP_ACCESS_TOKEN;
  const version = meta.graph_api_version || 'v19.0';

  const cleanRecipient = String(toPhone).replace(/\\D/g, '');

  if (!phoneNumberId || !accessToken) {
    return {
      success: true,
      mode: 'SIMULATION',
      recipient: cleanRecipient,
      message: messageText,
      timestamp: new Date().toISOString(),
      note: 'Meta Cloud API credentials not configured. Running in high-fidelity simulator mode.'
    };
  }

  return new Promise((resolve) => {
    const postData = JSON.stringify({
      messaging_product: 'whatsapp',
      recipient_type: 'individual',
      to: cleanRecipient,
      type: 'text',
      text: {
        preview_url: false,
        body: messageText
      }
    });

    const options = {
      hostname: 'graph.facebook.com',
      port: 443,
      path: \`/\${version}/\${phoneNumberId}/messages\`,
      method: 'POST',
      headers: {
        'Authorization': \`Bearer \${accessToken}\`,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      },
      timeout: 10000
    };

    const req = https.request(options, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        try {
          const parsed = JSON.parse(data);
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve({
              success: true,
              mode: 'META_CLOUD_API',
              recipient: cleanRecipient,
              response: parsed
            });
          } else {
            resolve({
              success: false,
              mode: 'META_CLOUD_API',
              error: parsed.error || data,
              statusCode: res.statusCode
            });
          }
        } catch (e) {
          resolve({ success: false, error: data, statusCode: res.statusCode });
        }
      });
    });

    req.on('error', (err) => {
      resolve({ success: false, error: err.message });
    });

    req.on('timeout', () => {
      req.destroy();
      resolve({ success: false, error: 'Meta API request timeout' });
    });

    req.write(postData);
    req.end();
  });
}

async function processIncomingMessage(senderPhone, senderName, incomingText, overrides = {}) {
  const cleanPhone = String(senderPhone || '').replace(/\\D/g, '');
  if (!cleanPhone) {
    return { success: false, error: 'Invalid sender phone number' };
  }

  const leadData = {
    phone: cleanPhone,
    name: senderName || 'WhatsApp Client',
    message: incomingText || '',
    source: 'WhatsApp Inbound'
  };
  saveLeadLocally(leadData);
  saveLeadToMongo(leadData).catch(() => {});

  const shouldGreet = shouldSendGreeting(cleanPhone, overrides.cooldown_hours);

  if (!shouldGreet) {
    return {
      success: true,
      action: 'IGNORED_COOLDOWN',
      recipient: cleanPhone,
      reason: 'Client was already greeted within the 24-hour cooldown period. Follow-up messages do not re-trigger greeting.'
    };
  }

  const welcomeText = formatWelcomeMessage(overrides);
  const dispatchResult = await sendWhatsAppMessage(cleanPhone, welcomeText);

  return {
    success: true,
    action: 'GREETING_SENT',
    recipient: cleanPhone,
    messageSent: welcomeText,
    dispatchResult: dispatchResult
  };
}

module.exports = {
  loadConfig,
  formatWelcomeMessage,
  shouldSendGreeting,
  saveLeadLocally,
  saveLeadToMongo,
  sendWhatsAppMessage,
  processIncomingMessage,
  CONFIG_FILE,
  LEADS_FILE,
  STATE_FILE
};
`;

// 2. api/whatsapp.js (Vercel Serverless Webhook Endpoint)
const apiCode = `/**
 * ==============================================================================
 * ASURA WHATSAPP BOT GATEWAY // VERCEL SERVERLESS EDGE FUNCTION
 * Route: /api/whatsapp
 * ==============================================================================
 * - GET: Webhook Verification for Meta WhatsApp Cloud API (hub.challenge)
 * - POST: Incoming Message Processing, Anti-Spam Deduplication & Auto-Reply
 * - Instant Serverless Execution 24/7/365
 * ==============================================================================
 */

import { MongoClient } from 'mongodb';

const DEFAULT_CONFIG = {
  business_name: 'Asura Digital Agency',
  service_product: 'high-converting custom websites and automated growth systems',
  reply_time: '15 minutes',
  welcome_message_template: 'Hi there! Thanks for reaching out to {business_name}. We help with {service_product}. How can we help you today? We usually reply within {reply_time}',
  anti_spam_cooldown_hours: 24,
  verify_token: process.env.WHATSAPP_VERIFY_TOKEN || 'asura_whatsapp_secret_verify_token'
};

const MONGO_URI = process.env.MONGODB_URI || 'mongodb+srv://prathamgowda194_db_user:k6Y9FnOekKvYxceA@cluster0.zf9zbow.mongodb.net/crypto_lottery?retryWrites=true&w=majority&appName=Cluster0';

export default async function handler(req, res) {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    return res.status(200).end();
  }

  // --- 1. GET: META WEBHOOK VERIFICATION ---
  if (req.method === 'GET') {
    const mode = req.query['hub.mode'];
    const token = req.query['hub.verify_token'];
    const challenge = req.query['hub.challenge'];

    const expectedToken = process.env.WHATSAPP_VERIFY_TOKEN || DEFAULT_CONFIG.verify_token;

    if (mode === 'subscribe' && token === expectedToken) {
      console.log('[WHATSAPP WEBHOOK] Verified successfully with Meta challenge.');
      return res.status(200).send(challenge);
    }

    // If accessed directly in browser, show status panel
    return res.status(200).json({
      status: 'ONLINE',
      service: 'Asura Automated WhatsApp Bot Gateway',
      environment: 'Vercel Serverless',
      welcome_template: DEFAULT_CONFIG.welcome_message_template,
      preview: DEFAULT_CONFIG.welcome_message_template
        .replace('{business_name}', DEFAULT_CONFIG.business_name)
        .replace('{service_product}', DEFAULT_CONFIG.service_product)
        .replace('{reply_time}', DEFAULT_CONFIG.reply_time),
      instructions: {
        step1: 'Configure Meta Webhook URL to: https://asura-system.vercel.app/api/whatsapp',
        step2: \`Set Verify Token in Meta to: \${expectedToken}\`,
        step3: 'Subscribe to \"messages\" webhook field.'
      }
    });
  }

  // --- 2. POST: INCOMING WHATSAPP MESSAGES ---
  if (req.method === 'POST') {
    try {
      const body = req.body || {};

      // Parse Meta WhatsApp Webhook Payload
      const entry = body.entry?.[0];
      const changes = entry?.changes?.[0];
      const value = changes?.value;
      const message = value?.messages?.[0];

      if (!message) {
        // May be a delivery receipt or status update
        return res.status(200).json({ status: 'ACKNOWLEDGED', reason: 'Non-message event' });
      }

      const senderPhone = message.from; // e.g. "919876543210"
      const contact = value?.contacts?.[0];
      const senderName = contact?.profile?.name || 'Client';
      const messageText = message.text?.body || message.type || '';

      const businessName = process.env.WHATSAPP_BUSINESS_NAME || DEFAULT_CONFIG.business_name;
      const serviceProduct = process.env.WHATSAPP_SERVICE_PRODUCT || DEFAULT_CONFIG.service_product;
      const replyTime = process.env.WHATSAPP_REPLY_TIME || DEFAULT_CONFIG.reply_time;

      const welcomeReply = DEFAULT_CONFIG.welcome_message_template
        .replace('{business_name}', businessName)
        .replace('{service_product}', serviceProduct)
        .replace('{reply_time}', replyTime);

      // Async log to MongoDB Atlas
      try {
        const client = new MongoClient(MONGO_URI, { connectTimeoutMS: 3000 });
        await client.connect();
        const db = client.db('crypto_lottery');
        await db.collection('whatsapp_leads').updateOne(
          { phone: senderPhone },
          {
            $set: { phone: senderPhone, name: senderName, last_seen: new Date() },
            $setOnInsert: { first_contact: new Date(), source: 'Meta Cloud API' },
            $push: { messages: { text: messageText, time: new Date() } }
          },
          { upsert: true }
        );
        await client.close();
      } catch (dbErr) {
        console.warn('[WHATSAPP API] DB Log warning:', dbErr.message);
      }

      // Dispatch Reply via Meta Graph API if credentials exist
      const phoneNumberId = process.env.WHATSAPP_PHONE_NUMBER_ID;
      const accessToken = process.env.WHATSAPP_ACCESS_TOKEN;

      if (phoneNumberId && accessToken) {
        const postData = JSON.stringify({
          messaging_product: 'whatsapp',
          recipient_type: 'individual',
          to: senderPhone,
          type: 'text',
          text: { preview_url: false, body: welcomeReply }
        });

        await fetch(\`https://graph.facebook.com/v19.0/\${phoneNumberId}/messages\`, {
          method: 'POST',
          headers: {
            'Authorization': \`Bearer \${accessToken}\`,
            'Content-Type': 'application/json'
          },
          body: postData
        });
      }

      return res.status(200).json({
        success: true,
        recipient: senderPhone,
        message: welcomeReply,
        note: 'Message processed and automated welcome dispatched.'
      });
    } catch (err) {
      console.error('[WHATSAPP WEBHOOK ERROR]', err);
      return res.status(500).json({ error: err.message });
    }
  }

  return res.status(405).json({ error: 'Method Not Allowed' });
}
`;

// 3. scripts/whatsapp_bot_runner.cjs (Command-Line Bot & Simulation Runner)
const runnerCode = `/**
 * ==============================================================================
 * ASURA WHATSAPP BOT RUNNER & LIVE TEST HARNESS
 * ==============================================================================
 * Usage:
 *   node scripts/whatsapp_bot_runner.cjs --test "+919876543210" "Hello, I need a website"
 *   node scripts/whatsapp_bot_runner.cjs --status
 *   node scripts/whatsapp_bot_runner.cjs --config
 * ==============================================================================
 */

const { processIncomingMessage, loadConfig, formatWelcomeMessage, shouldSendGreeting, LEADS_FILE, STATE_FILE } = require('./whatsapp_engine.cjs');
const fs = require('fs');

async function main() {
  const args = process.argv.slice(2);
  const command = args[0] || '--status';

  console.log('════════════════════════════════════════════════════════════');
  console.log('       ASURA AUTOMATED WHATSAPP BOT CONTROL CENTER          ');
  console.log('════════════════════════════════════════════════════════════');

  if (command === '--status') {
    const cfg = loadConfig();
    console.log('[CONFIG] Business Name   :', cfg.business_name);
    console.log('[CONFIG] Service/Product :', cfg.service_product);
    console.log('[CONFIG] Reply Time      :', cfg.reply_time);
    console.log('[CONFIG] Anti-Spam Window:', cfg.anti_spam_cooldown_hours + ' hours');
    console.log('\\n[FORMATTED WELCOME MESSAGE]:');
    console.log('"' + formatWelcomeMessage() + '"');

    let leadCount = 0;
    if (fs.existsSync(LEADS_FILE)) {
      try {
        const leads = JSON.parse(fs.readFileSync(LEADS_FILE, 'utf8'));
        leadCount = Array.isArray(leads) ? leads.length : 0;
      } catch (e) {}
    }
    console.log('\\n[ANALYTICS] Stored WhatsApp Leads:', leadCount);
    console.log('[STATUS] Ready for incoming messages.');
    console.log('════════════════════════════════════════════════════════════');
    return;
  }

  if (command === '--test') {
    const testPhone = args[1] || '+919876543210';
    const testMessage = args[2] || 'Hi, do you build luxury websites?';
    const clientName = args[3] || 'Rajesh Sharma';

    console.log(\`[INCOMING TEST] Simulating message from \${clientName} (\${testPhone}): "\${testMessage}"\`);
    const result = await processIncomingMessage(testPhone, clientName, testMessage);
    console.log('\\n[PROCESSING RESULT]:', JSON.stringify(result, null, 2));
    console.log('════════════════════════════════════════════════════════════');
    return;
  }

  if (command === '--test-cooldown') {
    const testPhone = '+919999988888';
    console.log('[TEST 1] First message from client...');
    const res1 = await processIncomingMessage(testPhone, 'New Client', 'Hello there');
    console.log('Result 1 Action:', res1.action);

    console.log('\\n[TEST 2] Immediate second message from same client...');
    const res2 = await processIncomingMessage(testPhone, 'New Client', 'Are you there?');
    console.log('Result 2 Action:', res2.action);
    console.log('Result 2 Reason:', res2.reason);
    console.log('════════════════════════════════════════════════════════════');
    return;
  }

  console.log('Unknown command. Use --status, --test [phone] [message], or --test-cooldown');
}

main().catch(err => {
  console.error('[FATAL]', err);
  process.exit(1);
});
`;

// 4. scripts/test_whatsapp_bot.cjs (Comprehensive Test Suite)
const testSuiteCode = `/**
 * ==============================================================================
 * AUTOMATED TEST SUITE FOR WHATSAPP BOT
 * ==============================================================================
 */

const assert = require('assert');
const fs = require('fs');
const path = require('path');
const {
  formatWelcomeMessage,
  shouldSendGreeting,
  processIncomingMessage,
  loadConfig,
  STATE_FILE,
  LEADS_FILE
} = require('./whatsapp_engine.cjs');

console.log('════════════════════════════════════════════════════════════');
console.log('          TESTING ASURA WHATSAPP AUTOMATION BOT             ');
console.log('════════════════════════════════════════════════════════════');

let passed = 0;
let failed = 0;

function runTest(name, fn) {
  try {
    fn();
    console.log(\`  [PASS] \${name}\`);
    passed++;
  } catch (e) {
    console.error(\`  [FAIL] \${name}: \${e.message}\`);
    failed++;
  }
}

async function runAsyncTest(name, fn) {
  try {
    await fn();
    console.log(\`  [PASS] \${name}\`);
    passed++;
  } catch (e) {
    console.error(\`  [FAIL] \${name}: \${e.message}\`);
    failed++;
  }
}

async function runAll() {
  console.log('\\n--- 1. Testing Welcome Message Template Formatting ---');
  
  runTest('Matches exact prompt template with custom business values', () => {
    const formatted = formatWelcomeMessage({
      business_name: 'Apex Architects',
      service_product: 'luxury villa architecture & interior masterplans',
      reply_time: '10 minutes'
    });
    
    const expected = 'Hi there! Thanks for reaching out to Apex Architects. We help with luxury villa architecture & interior masterplans. How can we help you today? We usually reply within 10 minutes';
    assert.strictEqual(formatted, expected);
  });

  runTest('Replaces placeholders properly from config defaults', () => {
    const formatted = formatWelcomeMessage();
    assert.ok(formatted.startsWith('Hi there! Thanks for reaching out to'));
    assert.ok(formatted.includes('. We help with '));
    assert.ok(formatted.includes('. How can we help you today? We usually reply within '));
  });

  console.log('\\n--- 2. Testing 24-Hour Anti-Spam Deduplication ---');

  runTest('Allows first message from a phone number', () => {
    const testPhone = '918880011223';
    // Clear state for this test phone
    if (fs.existsSync(STATE_FILE)) {
      try {
        const state = JSON.parse(fs.readFileSync(STATE_FILE, 'utf8'));
        delete state[testPhone];
        fs.writeFileSync(STATE_FILE, JSON.stringify(state));
      } catch (e) {}
    }
    const allowFirst = shouldSendGreeting(testPhone);
    assert.strictEqual(allowFirst, true, 'First message must be allowed');
  });

  runTest('Blocks immediate subsequent messages to prevent spamming client', () => {
    const testPhone = '918880011223';
    const allowSecond = shouldSendGreeting(testPhone);
    assert.strictEqual(allowSecond, false, 'Immediate subsequent message must be blocked');
  });

  console.log('\\n--- 3. Testing End-to-End Processing & Lead Logging ---');

  await runAsyncTest('Processes incoming lead and returns GREETING_SENT', async () => {
    const uniquePhone = '91777' + Date.now().toString().slice(-7);
    const res = await processIncomingMessage(uniquePhone, 'Priya Verma', 'I want a website quote');
    assert.strictEqual(res.success, true);
    assert.strictEqual(res.action, 'GREETING_SENT');
    assert.ok(res.messageSent.includes('Hi there! Thanks for reaching out to'));
  });

  await runAsyncTest('Verifies lead was written to local leads file', async () => {
    assert.ok(fs.existsSync(LEADS_FILE), 'Leads file must exist');
    const data = JSON.parse(fs.readFileSync(LEADS_FILE, 'utf8'));
    assert.ok(Array.isArray(data), 'Leads must be an array');
    assert.ok(data.length > 0, 'Leads must have at least one record');
    const latest = data[0];
    assert.ok(latest.phone, 'Lead must have phone');
    assert.ok(latest.name, 'Lead must have name');
    assert.ok(latest.inquiry_history, 'Lead must have inquiry history');
  });

  console.log('\\n════════════════════════════════════════════════════════════');
  console.log(\`TOTAL TESTS: \${passed + failed} | PASSED: \${passed} | FAILED: \${failed}\`);
  console.log('════════════════════════════════════════════════════════════');

  if (failed > 0) process.exit(1);
}

runAll().catch(e => {
  console.error(e);
  process.exit(1);
});
`;

fs.writeFileSync(path.join(targetDir, 'scripts', 'whatsapp_engine.cjs'), engineCode, 'utf8');
console.log('Created scripts/whatsapp_engine.cjs');

fs.writeFileSync(path.join(targetDir, 'api', 'whatsapp.js'), apiCode, 'utf8');
console.log('Created api/whatsapp.js');

fs.writeFileSync(path.join(targetDir, 'scripts', 'whatsapp_bot_runner.cjs'), runnerCode, 'utf8');
console.log('Created scripts/whatsapp_bot_runner.cjs');

fs.writeFileSync(path.join(targetDir, 'scripts', 'test_whatsapp_bot.cjs'), testSuiteCode, 'utf8');
console.log('Created scripts/test_whatsapp_bot.cjs');
