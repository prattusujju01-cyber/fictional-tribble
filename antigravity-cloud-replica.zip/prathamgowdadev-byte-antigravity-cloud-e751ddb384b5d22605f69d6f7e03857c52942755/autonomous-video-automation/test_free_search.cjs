const https = require('https');

async function testDuckDuckGo(query) {
  console.log(`Testing DuckDuckGo search for: "${query}"...`);
  const url = `https://html.duckduckgo.com/html/?q=${encodeURIComponent(query)}`;
  
  const res = await fetch(url, {
    headers: {
      'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
      'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
      'Accept-Language': 'en-US,en;q=0.9'
    }
  });

  console.log('Response status:', res.status);
  const html = await res.text();
  console.log('HTML size:', html.length, 'bytes');

  // Extract results using regex
  const results = [];
  const parts = html.split('<div class="result results_links');
  
  for (let i = 1; i < parts.length && results.length < 5; i++) {
    const block = parts[i];
    
    // Extract title & URL
    const titleMatch = block.match(/<a[^>]+class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)<\/a>/i);
    // Extract snippet
    const snippetMatch = block.match(/<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)<\/a>/i);

    if (titleMatch) {
      let rawUrl = titleMatch[1];
      // Decode uddg param if duckduckgo redirect
      const uddgMatch = rawUrl.match(/uddg=([^&]+)/);
      if (uddgMatch) {
        rawUrl = decodeURIComponent(uddgMatch[1]);
      }

      const title = titleMatch[2].replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&#x27;/g, "'").trim();
      const description = snippetMatch ? snippetMatch[1].replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').trim() : '';

      results.push({ title, description, url: rawUrl });
    }
  }

  return results;
}

async function run() {
  const query = 'dental clinic bangalore phone contact justdial';
  const results = await testDuckDuckGo(query);
  console.log(`\nFound ${results.length} results from DuckDuckGo:`);
  results.forEach((r, idx) => {
    console.log(`\n[${idx + 1}] ${r.title}`);
    console.log(`    URL: ${r.url}`);
    console.log(`    Desc: ${r.description.slice(0, 100)}...`);
  });
}

run().catch(console.error);
