const fs = require('fs');
const path = require('path');
const key = 'AQ.Ab8RN6LQTcBVg27285xhxo4j7NrFIsXGY9tKv96nGlh6e6rlDQ';
const user_input = 'A luxury premium dark-mode landing page for a high-end corporate consulting firm called Apex Strategy';

const prompt = `You are the world's leading UI/UX architect and frontend engineer. The client has provided this specific mission directive: '${user_input}'.
Generate an absolute masterpiece, production-ready, single-file HTML website matching this EXACT niche and business instruction.
CRITICAL:
1. Tailor all branding, headlines, copy, navigation links, services, features, stats, pricing, and testimonials STRICTLY to '${user_input}'.
2. Use modern HTML5 with Tailwind CSS CDN: <script src="https://cdn.tailwindcss.com"></script>.
3. Visual style: Ultra-sleek, premium dark mode.
4. Include interactive UI elements via vanilla JavaScript: navigation drawer, animated review/testimonial slider, interactive modal/lead capture form.
5. Absolutely NO generic lorem ipsum, NO placeholder text, and NO emojis.
6. Output ONLY raw HTML starting with <!DOCTYPE html> and closing with </html>. Do not wrap in markdown codeblocks.`;

async function main() {
  console.log('Sending request to gemini-3.6-flash...');
  const res = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-3.6-flash:generateContent?key=${key}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      contents: [{ parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.3 }
    })
  });
  const data = await res.json();
  if (data.error) {
    console.error('API Error:', data.error);
    return;
  }
  let html = data.candidates[0].content.parts[0].text.trim();
  if (html.includes('```html')) {
    html = html.split('```html')[1].split('```')[0].trim();
  } else if (html.includes('```')) {
    html = html.split('```')[1].split('```')[0].trim();
  }
  const targetPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system\\index.html';
  fs.writeFileSync(targetPath, html, 'utf8');
  console.log('Successfully written index.html! Length:', html.length);
  const title = html.match(/<title>(.*?)<\/title>/i)?.[1];
  console.log('Website title:', title);
}

main();
