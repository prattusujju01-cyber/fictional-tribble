const GITHUB_TOKEN = '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';
const REPO = 'prathamgowda194-pixel/asura-system';

const KEEP_PROJECTS = [
  'blr-properties-in-kammanahalli-main',
  'mumbai-real-estate-professionals',
  'xanadu-bangalore',
  'shankar-real-estate-agency-bangalore'
];

async function api(endpoint, method = 'GET', body = null) {
  const opts = {
    method,
    headers: {
      'Authorization': `Bearer ${GITHUB_TOKEN}`,
      'User-Agent': 'ASURA-Engine',
      'Accept': 'application/vnd.github.v3+json'
    }
  };
  if (body) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(`https://api.github.com/repos/${REPO}${endpoint}`, opts);
  return await res.json();
}

async function run() {
  console.log('Fetching projects directory from GitHub...');
  const contents = await api('/contents/projects');
  if (!Array.isArray(contents)) {
    console.log('Error fetching contents:', contents);
    return;
  }

  const toDelete = contents.filter(item => !KEEP_PROJECTS.includes(item.name));
  console.log(`Found ${toDelete.length} dummy projects to purge.`);

  // 1. Get current commit on main
  const ref = await api('/git/ref/heads/main');
  const latestCommitSha = ref.object.sha;
  console.log('Latest commit SHA:', latestCommitSha);

  // 2. Get tree of current commit recursively
  const commit = await api(`/git/commits/${latestCommitSha}`);
  const treeSha = commit.tree.sha;
  const fullTree = await api(`/git/trees/${treeSha}?recursive=1`);

  // Find all file paths inside projects/<dummy_folder>/
  const deleteTreeEntries = [];
  for (const item of fullTree.tree) {
    if (item.path.startsWith('projects/')) {
      const parts = item.path.split('/');
      const projName = parts[1];
      if (!KEEP_PROJECTS.includes(projName)) {
        // Mark for deletion
        deleteTreeEntries.push({
          path: item.path,
          mode: item.mode,
          type: item.type,
          sha: null
        });
      }
    }
  }

  console.log(`Identified ${deleteTreeEntries.length} files to delete across dummy projects.`);

  if (deleteTreeEntries.length === 0) {
    console.log('No files to delete.');
    return;
  }

  // 3. Create new tree
  const newTree = await api('/git/trees', 'POST', {
    base_tree: treeSha,
    tree: deleteTreeEntries
  });
  console.log('New tree created:', newTree.sha);

  // 4. Create commit with [skip ci]
  const newCommit = await api('/git/commits', 'POST', {
    message: 'chore: take down all dummy test projects and reset for live Indian clients [skip ci]',
    tree: newTree.sha,
    parents: [latestCommitSha]
  });
  console.log('New commit created:', newCommit.sha);

  // 5. Update ref
  const updatedRef = await api('/git/refs/heads/main', 'PATCH', {
    sha: newCommit.sha,
    force: false
  });
  console.log('Successfully updated main branch! Dummy servers taken down.');
}

run().catch(console.error);
