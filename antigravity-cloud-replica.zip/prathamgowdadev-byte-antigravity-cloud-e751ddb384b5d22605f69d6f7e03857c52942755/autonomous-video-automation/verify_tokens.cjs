const tokens = [
  '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',
  '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',
  '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',
  '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',
  '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',
  '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',
  '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',
  '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',
  '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'
];

async function verifyAll() {
  console.log('Verifying all 9 Hugging Face tokens...');
  for (let i = 0; i < tokens.length; i++) {
    const t = tokens[i].trim();
    try {
      const res = await fetch('https://huggingface.co/api/whoami-v2', {
        headers: { Authorization: 'Bearer ' + t }
      });
      const d = await res.json();
      console.log(`[Token ${i + 1}/${tokens.length}] Status: ${res.status}, User: ${d.name || d.type || 'OK'}`);
    } catch (e) {
      console.log(`[Token ${i + 1}] Error:`, e.message);
    }
  }
}
verifyAll();
