const fs = require('fs');
const path = require('path');

const targetPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\dashboard\\hermes-story-dashboard.html';

const htmlContent = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hermes Autonomous Studio — Zenn Anthropology Engine</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@600;700;900&family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg-void: #070913;
      --bg-card: #0E1222;
      --bg-card-hover: #151C33;
      --border-subtle: #1C2442;
      --border-accent: #FF7A00;
      --campfire-orange: #FF7A00;
      --campfire-gold: #F39C12;
      --amber-glow: rgba(255, 122, 0, 0.25);
      --text-main: #E2E8F0;
      --text-muted: #94A3B8;
      --text-dim: #64748B;
      --cyan-tech: #38BDF8;
      --emerald-success: #10B981;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      background: var(--bg-void);
      color: var(--text-main);
      font-family: 'Plus Jakarta Sans', -apple-system, sans-serif;
      min-height: 100vh;
      overflow-x: hidden;
      background-image: 
        radial-gradient(circle at 15% 20%, rgba(255, 122, 0, 0.08) 0%, transparent 40%),
        radial-gradient(circle at 85% 80%, rgba(56, 189, 248, 0.05) 0%, transparent 45%);
    }

    /* Ambient Ember Canvas */
    #emberCanvas {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      pointer-events: none;
      z-index: 0;
      opacity: 0.6;
    }

    .container {
      position: relative;
      z-index: 10;
      max-width: 1520px;
      margin: 0 auto;
      padding: 24px 28px 80px 28px;
    }

    /* Header & Navigation */
    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-bottom: 24px;
      border-bottom: 1px solid var(--border-subtle);
      margin-bottom: 28px;
      flex-wrap: wrap;
      gap: 16px;
    }

    .brand-group {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .logo-badge {
      width: 52px;
      height: 52px;
      background: linear-gradient(135deg, #FF7A00, #B45309);
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 26px;
      box-shadow: 0 0 24px var(--amber-glow);
      border: 1px solid rgba(255, 255, 255, 0.15);
    }

    .brand-meta h1 {
      font-family: 'Cinzel', serif;
      font-size: 24px;
      font-weight: 700;
      letter-spacing: 0.5px;
      background: linear-gradient(90deg, #FFFFFF, #F39C12);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .brand-meta p {
      font-size: 13px;
      color: var(--text-muted);
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .badge-open-source {
      background: rgba(16, 185, 129, 0.15);
      color: var(--emerald-success);
      padding: 3px 8px;
      border-radius: 6px;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      font-weight: 600;
      border: 1px solid rgba(16, 185, 129, 0.3);
    }

    .badge-zero-gemini {
      background: rgba(255, 122, 0, 0.15);
      color: var(--campfire-orange);
      padding: 3px 8px;
      border-radius: 6px;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      font-weight: 600;
      border: 1px solid rgba(255, 122, 0, 0.3);
    }

    .header-actions {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .btn {
      padding: 10px 18px;
      border-radius: 10px;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      border: none;
      font-family: inherit;
    }

    .btn-primary {
      background: linear-gradient(135deg, #FF7A00, #EA580C);
      color: #FFFFFF;
      box-shadow: 0 4px 16px rgba(255, 122, 0, 0.3);
    }

    .btn-primary:hover {
      transform: translateY(-2px);
      box-shadow: 0 6px 22px rgba(255, 122, 0, 0.45);
    }

    .btn-secondary {
      background: var(--bg-card);
      color: var(--text-main);
      border: 1px solid var(--border-subtle);
    }

    .btn-secondary:hover {
      background: var(--bg-card-hover);
      border-color: var(--text-dim);
    }

    /* Video Player & Main Stage Grid */
    .hero-grid {
      display: grid;
      grid-template-columns: 1.65fr 1fr;
      gap: 28px;
      margin-bottom: 36px;
    }

    @media (max-width: 1100px) {
      .hero-grid { grid-template-columns: 1fr; }
    }

    .player-card {
      background: var(--bg-card);
      border-radius: 18px;
      border: 1px solid var(--border-subtle);
      overflow: hidden;
      box-shadow: 0 16px 40px rgba(0, 0, 0, 0.5);
      position: relative;
    }

    .cinema-screen {
      position: relative;
      width: 100%;
      padding-top: 56.25%; /* 16:9 Aspect Ratio */
      background: #000000;
      overflow: hidden;
    }

    #videoCanvas {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      display: block;
      object-fit: cover;
    }

    /* Subtitle Banner Overlay */
    .subtitle-banner {
      position: absolute;
      bottom: 24px;
      left: 6%;
      right: 6%;
      text-align: center;
      background: rgba(7, 9, 19, 0.85);
      backdrop-filter: blur(8px);
      padding: 12px 20px;
      border-radius: 10px;
      border: 1px solid rgba(255, 122, 0, 0.3);
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.6);
      transition: all 0.3s ease;
      z-index: 20;
    }

    .subtitle-text {
      font-size: 15px;
      line-height: 1.5;
      font-weight: 500;
      color: #FFFFFF;
      text-shadow: 0 2px 4px rgba(0, 0, 0, 0.8);
    }

    .subtitle-act-badge {
      font-size: 11px;
      font-weight: 700;
      color: var(--campfire-orange);
      text-transform: uppercase;
      letter-spacing: 1px;
      margin-bottom: 4px;
      display: inline-block;
    }

    /* Player Controls Bar */
    .player-controls {
      padding: 18px 24px;
      background: #0A0D18;
      border-top: 1px solid var(--border-subtle);
      display: flex;
      flex-direction: column;
      gap: 14px;
    }

    .scrub-row {
      display: flex;
      align-items: center;
      gap: 14px;
    }

    .progress-bar-container {
      flex: 1;
      height: 8px;
      background: #1E293B;
      border-radius: 4px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }

    .progress-bar-fill {
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg, #FF7A00, #F39C12);
      border-radius: 4px;
      transition: width 0.1s linear;
    }

    .time-readout {
      font-family: 'JetBrains Mono', monospace;
      font-size: 12px;
      color: var(--text-muted);
      min-width: 90px;
    }

    .action-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 12px;
    }

    .control-buttons-left {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .btn-circle {
      width: 42px;
      height: 42px;
      border-radius: 50%;
      background: var(--bg-card-hover);
      border: 1px solid var(--border-subtle);
      color: var(--text-main);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 16px;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .btn-circle:hover {
      background: var(--campfire-orange);
      color: #FFFFFF;
      border-color: var(--campfire-orange);
      transform: scale(1.05);
    }

    .btn-circle.play-btn {
      width: 48px;
      height: 48px;
      background: linear-gradient(135deg, #FF7A00, #D97706);
      color: #FFFFFF;
      font-size: 20px;
    }

    .pill-selector {
      display: flex;
      background: #11162A;
      border-radius: 8px;
      padding: 3px;
      border: 1px solid var(--border-subtle);
    }

    .pill-opt {
      padding: 4px 10px;
      font-size: 11px;
      font-weight: 600;
      color: var(--text-muted);
      border-radius: 6px;
      cursor: pointer;
      transition: all 0.2s ease;
    }

    .pill-opt.active {
      background: var(--campfire-orange);
      color: #FFFFFF;
    }

    /* Right Column: Scene Director & Audio HUD */
    .sidebar-panel {
      display: flex;
      flex-direction: column;
      gap: 20px;
    }

    .hud-box {
      background: var(--bg-card);
      border: 1px solid var(--border-subtle);
      border-radius: 16px;
      padding: 22px;
    }

    .hud-title {
      font-size: 14px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: var(--text-muted);
      margin-bottom: 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .active-scene-details {
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .active-scene-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .active-scene-badge {
      font-family: 'JetBrains Mono', monospace;
      font-size: 12px;
      color: var(--campfire-orange);
      background: rgba(255, 122, 0, 0.12);
      padding: 4px 10px;
      border-radius: 6px;
      border: 1px solid rgba(255, 122, 0, 0.25);
    }

    .active-scene-timing {
      font-family: 'JetBrains Mono', monospace;
      font-size: 12px;
      color: var(--cyan-tech);
    }

    .prompt-box {
      background: #080B14;
      border-radius: 10px;
      padding: 12px 14px;
      border: 1px solid #161D33;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      color: #CBD5E1;
      line-height: 1.6;
      max-height: 100px;
      overflow-y: auto;
    }

    .prompt-box-label {
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.8px;
      color: var(--campfire-gold);
      margin-bottom: 4px;
    }

    /* Ambient Audio Generator Toggle */
    .ambient-card {
      background: linear-gradient(135deg, rgba(255, 122, 0, 0.08), rgba(243, 156, 18, 0.03));
      border: 1px solid rgba(255, 122, 0, 0.2);
      border-radius: 14px;
      padding: 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .ambient-info h4 {
      font-size: 13px;
      font-weight: 700;
      color: #FFFFFF;
      display: flex;
      align-items: center;
      gap: 6px;
    }

    .ambient-info p {
      font-size: 11px;
      color: var(--text-muted);
      margin-top: 2px;
    }

    /* Toggle Switch */
    .switch {
      position: relative;
      display: inline-block;
      width: 44px;
      height: 24px;
    }

    .switch input { opacity: 0; width: 0; height: 0; }

    .slider {
      position: absolute;
      cursor: pointer;
      top: 0; left: 0; right: 0; bottom: 0;
      background-color: #1E293B;
      transition: .3s;
      border-radius: 24px;
      border: 1px solid var(--border-subtle);
    }

    .slider:before {
      position: absolute;
      content: "";
      height: 16px;
      width: 16px;
      left: 3px;
      bottom: 3px;
      background-color: #FFFFFF;
      transition: .3s;
      border-radius: 50%;
    }

    input:checked + .slider {
      background-color: var(--campfire-orange);
    }

    input:checked + .slider:before {
      transform: translateX(20px);
    }

    /* Hermes Agent Fleet Grid */
    .fleet-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 16px;
      margin-bottom: 36px;
    }

    .agent-card {
      background: var(--bg-card);
      border: 1px solid var(--border-subtle);
      border-radius: 14px;
      padding: 18px;
      transition: all 0.2s ease;
      position: relative;
      overflow: hidden;
    }

    .agent-card:hover {
      border-color: rgba(255, 122, 0, 0.4);
      transform: translateY(-2px);
    }

    .agent-card-top {
      display: flex;
      align-items: center;
      justify-content: space-between;
      margin-bottom: 10px;
    }

    .agent-icon {
      width: 36px;
      height: 36px;
      border-radius: 10px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 18px;
      background: #131A30;
      border: 1px solid var(--border-subtle);
    }

    .agent-status-dot {
      width: 8px;
      height: 8px;
      border-radius: 50%;
      background: var(--emerald-success);
      box-shadow: 0 0 8px var(--emerald-success);
    }

    .agent-name {
      font-size: 14px;
      font-weight: 700;
      color: #FFFFFF;
      margin-bottom: 4px;
    }

    .agent-role {
      font-size: 12px;
      color: var(--text-muted);
      margin-bottom: 8px;
    }

    .agent-model-tag {
      font-family: 'JetBrains Mono', monospace;
      font-size: 10px;
      color: var(--cyan-tech);
      background: rgba(56, 189, 248, 0.1);
      padding: 2px 6px;
      border-radius: 4px;
      display: inline-block;
    }

    /* Scene Storyboard Grid */
    .section-title {
      font-family: 'Cinzel', serif;
      font-size: 20px;
      font-weight: 700;
      margin-bottom: 20px;
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .section-title::after {
      content: '';
      flex: 1;
      height: 1px;
      background: var(--border-subtle);
    }

    .storyboard-scroll {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(260px, 1fr));
      gap: 20px;
      margin-bottom: 40px;
    }

    .scene-tile {
      background: var(--bg-card);
      border: 1px solid var(--border-subtle);
      border-radius: 14px;
      overflow: hidden;
      cursor: pointer;
      transition: all 0.25s ease;
      position: relative;
    }

    .scene-tile:hover {
      border-color: var(--campfire-orange);
      transform: translateY(-3px);
      box-shadow: 0 8px 24px rgba(255, 122, 0, 0.2);
    }

    .scene-tile.active-tile {
      border: 2px solid var(--campfire-orange);
      box-shadow: 0 0 20px var(--amber-glow);
    }

    .scene-thumb-wrap {
      position: relative;
      width: 100%;
      padding-top: 56.25%;
      background: #000000;
      overflow: hidden;
    }

    .scene-thumb-img {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
      transition: transform 0.3s ease;
    }

    .scene-tile:hover .scene-thumb-img {
      transform: scale(1.05);
    }

    .scene-badge-corner {
      position: absolute;
      top: 8px;
      left: 8px;
      background: rgba(7, 9, 19, 0.85);
      border: 1px solid rgba(255, 255, 255, 0.15);
      padding: 3px 8px;
      border-radius: 6px;
      font-family: 'JetBrains Mono', monospace;
      font-size: 10px;
      font-weight: 700;
      color: #FFFFFF;
    }

    .scene-tile-body {
      padding: 14px;
    }

    .scene-tile-timing {
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      color: var(--campfire-orange);
      font-weight: 600;
      margin-bottom: 6px;
    }

    .scene-tile-narrative {
      font-size: 12px;
      color: var(--text-muted);
      line-height: 1.45;
      display: -webkit-box;
      -webkit-line-clamp: 3;
      -webkit-box-orient: vertical;
      overflow: hidden;
    }

    /* Screenplay Reader Tab */
    .screenplay-panel {
      background: var(--bg-card);
      border: 1px solid var(--border-subtle);
      border-radius: 16px;
      padding: 28px;
      margin-bottom: 40px;
    }

    .act-accordion {
      border-bottom: 1px solid var(--border-subtle);
      padding: 18px 0;
    }

    .act-accordion:last-child {
      border-bottom: none;
    }

    .act-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      cursor: pointer;
      user-select: none;
    }

    .act-title-wrap {
      display: flex;
      align-items: center;
      gap: 14px;
    }

    .act-num {
      font-family: 'Cinzel', serif;
      font-size: 18px;
      color: var(--campfire-orange);
      font-weight: 700;
      width: 60px;
    }

    .act-title-text {
      font-size: 16px;
      font-weight: 700;
      color: #FFFFFF;
    }

    .act-stats {
      font-family: 'JetBrains Mono', monospace;
      font-size: 12px;
      color: var(--text-muted);
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .act-body {
      padding: 16px 0 8px 74px;
      font-size: 14px;
      line-height: 1.7;
      color: #CBD5E1;
    }

    .citation-highlight {
      background: rgba(255, 122, 0, 0.12);
      color: var(--campfire-gold);
      padding: 2px 6px;
      border-radius: 4px;
      font-weight: 600;
      border-bottom: 1px dashed var(--campfire-orange);
    }

    /* Hidden Native Audio Element */
    #nativeAudio {
      display: none;
    }
  </style>
</head>
<body>
  <canvas id="emberCanvas"></canvas>
  <audio id="nativeAudio" preload="auto"></audio>

  <div class="container">
    <!-- Header -->
    <header>
      <div class="brand-group">
        <div class="logo-badge">🔥</div>
        <div class="brand-meta">
          <h1>HERMES AUTONOMOUS STUDIO</h1>
          <p>
            Channel: <strong>Zenn Anthropology</strong> 
            <span class="badge-open-source">Open-Source AI Suite</span>
            <span class="badge-zero-gemini">Zero Gemini Policy</span>
          </p>
        </div>
      </div>
      <div class="header-actions">
        <button class="btn btn-secondary" onclick="exportFullPackage()">
          📦 Download Video Package
        </button>
        <button class="btn btn-primary" onclick="togglePlay()">
          ▶ Play Master Video
        </button>
      </div>
    </header>

    <!-- Main Stage: Cinema Player & HUD -->
    <div class="hero-grid">
      <!-- Left: Player -->
      <div class="player-card">
        <div class="cinema-screen" id="cinemaScreen">
          <canvas id="videoCanvas" width="1280" height="720"></canvas>
          <div class="subtitle-banner" id="subBanner">
            <span class="subtitle-act-badge" id="subAct">ACT 1: THE DISCONNECT</span>
            <p class="subtitle-text" id="subText">Loading narration...</p>
          </div>
        </div>
        <div class="player-controls">
          <div class="scrub-row">
            <div class="progress-bar-container" id="progressBar" onclick="seekTimeline(event)">
              <div class="progress-bar-fill" id="progressFill"></div>
            </div>
            <span class="time-readout" id="timeDisplay">0:00 / 12:45</span>
          </div>
          <div class="action-row">
            <div class="control-buttons-left">
              <button class="btn-circle" onclick="prevScene()" title="Previous Scene">⏮</button>
              <button class="btn-circle play-btn" id="playBtn" onclick="togglePlay()" title="Play / Pause">▶</button>
              <button class="btn-circle" onclick="nextScene()" title="Next Scene">⏭</button>
              <div class="pill-selector">
                <div class="pill-opt active" onclick="setSpeed(1.0, this)">1.0x</div>
                <div class="pill-opt" onclick="setSpeed(1.25, this)">1.25x</div>
                <div class="pill-opt" onclick="setSpeed(1.5, this)">1.5x</div>
              </div>
            </div>
            <div class="control-buttons-right">
              <button class="btn btn-secondary" onclick="toggleFullscreen()" style="padding: 8px 12px; font-size: 12px;">
                ⛶ Fullscreen
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Right: Director HUD -->
      <div class="sidebar-panel">
        <div class="hud-box">
          <div class="hud-title">
            <span>🎬 Scene Director HUD</span>
            <span class="badge-open-source" id="activeModelTag">FLUX.1-schnell</span>
          </div>
          <div class="active-scene-details">
            <div class="active-scene-header">
              <span class="active-scene-badge" id="hudSceneId">SCENE 001</span>
              <span class="active-scene-timing" id="hudTiming">0:00 - 0:45</span>
            </div>
            <div class="prompt-box-label">FLUX.1 Minimalist Stickman Visual Prompt:</div>
            <div class="prompt-box" id="hudPrompt">Loading visual prompt...</div>
            <div class="prompt-box-label" style="margin-top: 8px;">Narration Cue:</div>
            <div class="prompt-box" id="hudNarration" style="color: #94A3B8;">Loading narration cue...</div>
          </div>
        </div>

        <div class="ambient-card">
          <div class="ambient-info">
            <h4>🔥 Prehistoric Campfire Audio</h4>
            <p>WebAudio crackling embers & night wind generator</p>
          </div>
          <label class="switch">
            <input type="checkbox" id="ambientToggle" onchange="toggleCampfireAudio(this.checked)" checked>
            <span class="slider"></span>
          </label>
        </div>

        <div class="hud-box">
          <div class="hud-title">
            <span>📊 Video Metrics</span>
          </div>
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 12px;">
            <div style="background: #090C16; padding: 10px; border-radius: 8px; border: 1px solid var(--border-subtle);">
              <div style="font-size: 10px; color: var(--text-dim); text-transform: uppercase;">Duration</div>
              <div style="font-size: 16px; font-weight: 700; color: #FFFFFF;" id="metaDuration">12-14 Min</div>
            </div>
            <div style="background: #090C16; padding: 10px; border-radius: 8px; border: 1px solid var(--border-subtle);">
              <div style="font-size: 10px; color: var(--text-dim); text-transform: uppercase;">Total Words</div>
              <div style="font-size: 16px; font-weight: 700; color: var(--campfire-orange);" id="metaWords">1,980 W</div>
            </div>
            <div style="background: #090C16; padding: 10px; border-radius: 8px; border: 1px solid var(--border-subtle);">
              <div style="font-size: 10px; color: var(--text-dim); text-transform: uppercase;">Scenes</div>
              <div style="font-size: 16px; font-weight: 700; color: var(--cyan-tech);" id="metaScenes">14 Scenes</div>
            </div>
            <div style="background: #090C16; padding: 10px; border-radius: 8px; border: 1px solid var(--border-subtle);">
              <div style="font-size: 10px; color: var(--text-dim); text-transform: uppercase;">Pacing</div>
              <div style="font-size: 16px; font-weight: 700; color: var(--emerald-success);">140 WPM</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- Hermes Agent Fleet Status -->
    <h2 class="section-title">Hermes Autonomous Agent Fleet</h2>
    <div class="fleet-grid">
      <div class="agent-card">
        <div class="agent-card-top">
          <div class="agent-icon">🧠</div>
          <div class="agent-status-dot"></div>
        </div>
        <div class="agent-name">Hermes-Anthropologist</div>
        <div class="agent-role">Topic Radar & Curiosity Hook Engineer</div>
        <span class="agent-model-tag">Validated 7.9M Hook</span>
      </div>

      <div class="agent-card">
        <div class="agent-card-top">
          <div class="agent-icon">✍️</div>
          <div class="agent-status-dot"></div>
        </div>
        <div class="agent-name">Hermes-Screenwriter</div>
        <div class="agent-role">10-15 Min Screenplay Architecture</div>
        <span class="agent-model-tag">Qwen 2.5 72B Blueprint</span>
      </div>

      <div class="agent-card">
        <div class="agent-card-top">
          <div class="agent-icon">🎨</div>
          <div class="agent-status-dot"></div>
        </div>
        <div class="agent-name">Hermes-VisualDirector</div>
        <div class="agent-role">2D Stickman Scene Synthesizer</div>
        <span class="agent-model-tag">FLUX.1-schnell 16:9</span>
      </div>

      <div class="agent-card">
        <div class="agent-card-top">
          <div class="agent-icon">🎙️</div>
          <div class="agent-status-dot"></div>
        </div>
        <div class="agent-name">Hermes-VoiceStudio</div>
        <div class="agent-role">Intellectual Documentary Voiceover</div>
        <span class="agent-model-tag">Neural Audio Engine</span>
      </div>

      <div class="agent-card">
        <div class="agent-card-top">
          <div class="agent-icon">🎞️</div>
          <div class="agent-status-dot"></div>
        </div>
        <div class="agent-name">Hermes-TimelineEditor</div>
        <div class="agent-role">Ken Burns Motion & Timeline Assembler</div>
        <span class="agent-model-tag">Timeline Engine v2.1</span>
      </div>
    </div>

    <!-- Storyboard Grid -->
    <h2 class="section-title">Visual Storyboard & Scene Timeline (14 Scenes)</h2>
    <div class="storyboard-scroll" id="storyboardGrid">
      <!-- Dynamically Populated -->
    </div>

    <!-- Screenplay Reader -->
    <h2 class="section-title">Master Screenplay Reader (1,980 Words // 5 Acts)</h2>
    <div class="screenplay-panel" id="screenplayPanel">
      <!-- Dynamically Populated -->
    </div>
  </div>

  <script>
    // Global State
    let timelineData = null;
    let screenplayData = null;
    let currentSceneIdx = 0;
    let isPlaying = false;
    let playbackSpeed = 1.0;
    let animationFrameId = null;
    let sceneStartTime = 0;
    let sceneDuration = 15;
    let campfireAudioActive = true;
    let audioCtx = null;
    let fireNoiseNode = null;

    // Load Data
    async function initDashboard() {
      try {
        const [tlRes, spRes] = await Promise.all([
          fetch('../assets/timeline.json').catch(() => null),
          fetch('../assets/screenplay.json').catch(() => null)
        ]);

        if (tlRes && tlRes.ok) timelineData = await tlRes.json();
        if (spRes && spRes.ok) screenplayData = await spRes.json();

        if (!timelineData || !screenplayData) {
          console.warn('Assets loading fallback, generating local fallback state');
          generateFallbackData();
        }

        renderStoryboard();
        renderScreenplay();
        loadScene(0);
        initCampfireWebAudio();
        initEmberParticles();
      } catch (err) {
        console.error('Init error:', err);
      }
    }

    function generateFallbackData() {
      // Direct in-memory manifest matching open-source-ai.js
      screenplayData = {
        meta: {
          title: "What Did Ancient Humans Do at Night?",
          targetDuration: "12-14 Minutes",
          totalWordCount: 1980
        },
        acts: [
          { act: 1, title: "The Modern Disconnect & The 99.9% Reality Hook", wordCount: 385 },
          { act: 2, title: "The Campfire Revolution & The Birth of the Social Brain", wordCount: 440 },
          { act: 3, title: "The Lost History of Sleep: First Sleep, Second Sleep & The Watch", wordCount: 520 },
          { act: 4, title: "The Circadian Trap: How Light Bulbs Killed the Night", wordCount: 425 },
          { act: 5, title: "The Biological Echo: Your Body Isn't Broken, It's Remembering", wordCount: 210 }
        ]
      };
    }

    // Storyboard Render
    function renderStoryboard() {
      const grid = document.getElementById('storyboardGrid');
      grid.innerHTML = '';

      const scenes = timelineData?.scenes || [];
      scenes.forEach((s, idx) => {
        const tile = document.createElement('div');
        tile.className = 'scene-tile' + (idx === 0 ? ' active-tile' : '');
        tile.id = 'tile_' + idx;
        tile.onclick = () => { loadScene(idx); if (isPlaying) playScene(idx); };

        tile.innerHTML = \`
          <div class="scene-thumb-wrap">
            <img class="scene-thumb-img" src="../\${s.imagePath}" onerror="this.src='https://images.unsplash.com/photo-1518709268805-4e9042af9f23?w=600&auto=format&fit=crop&q=60'" alt="Scene \${idx+1}">
            <div class="scene-badge-corner">#\${idx + 1} \${s.sceneId.toUpperCase()}</div>
          </div>
          <div class="scene-tile-body">
            <div class="scene-tile-timing">⏱ \${s.timing} (~ \${s.durationSec}s)</div>
            <div class="scene-tile-narrative">\${s.narration}</div>
          </div>
        \`;
        grid.appendChild(tile);
      });
    }

    // Screenplay Reader Render
    function renderScreenplay() {
      const panel = document.getElementById('screenplayPanel');
      panel.innerHTML = '';

      if (!screenplayData?.acts) return;

      screenplayData.acts.forEach(act => {
        const acc = document.createElement('div');
        acc.className = 'act-accordion';

        let scenesHtml = '';
        if (act.scenes) {
          scenesHtml = act.scenes.map(s => \`
            <div style="margin-bottom: 14px; padding-left: 12px; border-left: 2px solid var(--border-subtle);">
              <div style="font-family: 'JetBrains Mono', monospace; font-size: 11px; color: var(--campfire-orange); margin-bottom: 4px;">\${s.sceneId.toUpperCase()} (\${s.timing})</div>
              <div>\${s.narration.replace(/(Roger Ekirch|Thomas Wehr|Polly Wiessner|Wonderwerk Cave|first sleep|second sleep)/gi, '<span class="citation-highlight">$1</span>')}</div>
            </div>
          \`).join('');
        }

        acc.innerHTML = \`
          <div class="act-header" onclick="this.nextElementSibling.style.display = this.nextElementSibling.style.display === 'none' ? 'block' : 'none'">
            <div class="act-title-wrap">
              <span class="act-num">ACT \${act.act}</span>
              <span class="act-title-text">\${act.title}</span>
            </div>
            <div class="act-stats">
              <span>\${act.wordCount} words</span>
              <span>\${act.timestamp || ''}</span>
              <span>▼</span>
            </div>
          </div>
          <div class="act-body">
            \${scenesHtml}
          </div>
        \`;
        panel.appendChild(acc);
      });
    }

    // Cinema Canvas & Ken Burns Render
    const canvas = document.getElementById('videoCanvas');
    const ctx = canvas.getContext('2d');
    const currentImg = new Image();

    function loadScene(idx) {
      currentSceneIdx = idx;
      document.querySelectorAll('.scene-tile').forEach((t, i) => {
        t.classList.toggle('active-tile', i === idx);
      });

      const scenes = timelineData?.scenes || [];
      const s = scenes[idx];
      if (!s) return;

      // Update HUD
      document.getElementById('hudSceneId').innerText = s.sceneId.toUpperCase();
      document.getElementById('hudTiming').innerText = s.timing;
      document.getElementById('hudNarration').innerText = s.narration;

      // Subtitles
      document.getElementById('subAct').innerText = 'SCENE ' + (idx + 1) + ' // ' + s.timing;
      document.getElementById('subText').innerText = s.narration;

      // Load Image
      currentImg.src = '../' + s.imagePath;
      currentImg.onload = () => {
        renderFrame(0);
      };

      // Native Audio Track
      const audio = document.getElementById('nativeAudio');
      audio.src = '../assets/audio/' + s.sceneId + '.mp3';
      audio.playbackRate = playbackSpeed;

      sceneStartTime = Date.now();
      sceneDuration = s.durationSec || 15;
    }

    function renderFrame(progress) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      if (!currentImg.complete) return;

      // Ken Burns Slow Pan & Zoom
      const scale = 1.0 + 0.12 * progress;
      const panX = Math.sin(progress * Math.PI) * 25;
      const panY = Math.cos(progress * Math.PI) * 15;

      ctx.save();
      ctx.translate(canvas.width / 2 + panX, canvas.height / 2 + panY);
      ctx.scale(scale, scale);
      ctx.drawImage(currentImg, -canvas.width / 2, -canvas.height / 2, canvas.width, canvas.height);
      ctx.restore();

      // Atmospheric Vignette & Film Grain Overlay
      const grad = ctx.createRadialGradient(
        canvas.width / 2, canvas.height / 2, canvas.width * 0.25,
        canvas.width / 2, canvas.height / 2, canvas.width * 0.75
      );
      grad.addColorStop(0, 'rgba(0,0,0,0)');
      grad.addColorStop(1, 'rgba(7,9,19,0.7)');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Warm Campfire Amber Edge Tint
      const fireGlow = ctx.createRadialGradient(
        canvas.width * 0.5, canvas.height, 50,
        canvas.width * 0.5, canvas.height, canvas.height * 0.8
      );
      fireGlow.addColorStop(0, 'rgba(255, 122, 0, 0.15)');
      fireGlow.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = fireGlow;
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }

    function animationLoop() {
      if (!isPlaying) return;

      const audio = document.getElementById('nativeAudio');
      const progress = audio.duration ? (audio.currentTime / audio.duration) : Math.min(1, (Date.now() - sceneStartTime) / (sceneDuration * 1000));

      renderFrame(progress);

      // Update progress bar
      document.getElementById('progressFill').style.width = (progress * 100) + '%';
      const cur = Math.round(audio.currentTime || (progress * sceneDuration));
      const tot = Math.round(audio.duration || sceneDuration);
      document.getElementById('timeDisplay').innerText = formatTime(cur) + ' / ' + formatTime(tot);

      if (progress >= 1 || audio.ended) {
        nextScene();
      } else {
        animationFrameId = requestAnimationFrame(animationLoop);
      }
    }

    function formatTime(sec) {
      const m = Math.floor(sec / 60);
      const s = Math.floor(sec % 60);
      return m + ':' + (s < 10 ? '0' : '') + s;
    }

    function togglePlay() {
      const audio = document.getElementById('nativeAudio');
      const btn = document.getElementById('playBtn');

      if (isPlaying) {
        isPlaying = false;
        audio.pause();
        btn.innerText = '▶';
        if (animationFrameId) cancelAnimationFrame(animationFrameId);
      } else {
        isPlaying = true;
        audio.play().catch(e => console.log('Audio autoplay policy:', e));
        btn.innerText = '⏸';
        sceneStartTime = Date.now();
        animationLoop();
      }
    }

    function nextScene() {
      const scenes = timelineData?.scenes || [];
      if (currentSceneIdx < scenes.length - 1) {
        loadScene(currentSceneIdx + 1);
        if (isPlaying) {
          const audio = document.getElementById('nativeAudio');
          audio.play().catch(e => {});
        }
      } else {
        // Loop back to start
        loadScene(0);
        togglePlay();
      }
    }

    function prevScene() {
      if (currentSceneIdx > 0) {
        loadScene(currentSceneIdx - 1);
        if (isPlaying) {
          const audio = document.getElementById('nativeAudio');
          audio.play().catch(e => {});
        }
      }
    }

    function setSpeed(rate, el) {
      playbackSpeed = rate;
      document.querySelectorAll('.pill-opt').forEach(p => p.classList.remove('active'));
      el.classList.add('active');
      const audio = document.getElementById('nativeAudio');
      audio.playbackRate = rate;
    }

    function seekTimeline(e) {
      const bar = document.getElementById('progressBar');
      const rect = bar.getBoundingClientRect();
      const pct = (e.clientX - rect.left) / rect.width;
      const audio = document.getElementById('nativeAudio');
      if (audio.duration) {
        audio.currentTime = pct * audio.duration;
      }
      renderFrame(pct);
    }

    function toggleFullscreen() {
      const screen = document.getElementById('cinemaScreen');
      if (!document.fullscreenElement) {
        screen.requestFullscreen().catch(err => alert(err.message));
      } else {
        document.exitFullscreen();
      }
    }

    // WebAudio Prehistoric Campfire Synthesis (Crackling embers & wind)
    function initCampfireWebAudio() {
      try {
        const AudioContext = window.AudioContext || window.webkitAudioContext;
        audioCtx = new AudioContext();

        // White noise buffer for crackles
        const bufferSize = audioCtx.sampleRate * 2;
        const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          // Sparse randomized crackle spikes
          output[i] = (Math.random() < 0.008 ? (Math.random() * 2 - 1) : (Math.random() * 0.08 - 0.04));
        }

        const whiteNoise = audioCtx.createBufferSource();
        whiteNoise.buffer = noiseBuffer;
        whiteNoise.loop = true;

        const filter = audioCtx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 1200;
        filter.Q.value = 1.2;

        const gainNode = audioCtx.createGain();
        gainNode.gain.value = 0.12; // Gentle warm background volume

        whiteNoise.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        whiteNoise.start();
        fireNoiseNode = gainNode;
      } catch (err) {
        console.warn('WebAudio campfire init skipped:', err);
      }
    }

    function toggleCampfireAudio(active) {
      if (!fireNoiseNode) return;
      fireNoiseNode.gain.value = active ? 0.12 : 0;
    }

    // Ambient Ember Canvas Animation
    function initEmberParticles() {
      const c = document.getElementById('emberCanvas');
      const ctxE = c.getContext('2d');
      let w = c.width = window.innerWidth;
      let h = c.height = window.innerHeight;

      window.onresize = () => { w = c.width = window.innerWidth; h = c.height = window.innerHeight; };

      const embers = Array.from({ length: 45 }, () => ({
        x: Math.random() * w,
        y: Math.random() * h + h * 0.2,
        size: Math.random() * 2.5 + 0.8,
        speedY: Math.random() * 1.2 + 0.4,
        speedX: (Math.random() - 0.5) * 0.6,
        alpha: Math.random() * 0.7 + 0.3
      }));

      function drawEmbers() {
        ctxE.clearRect(0, 0, w, h);
        embers.forEach(e => {
          e.y -= e.speedY;
          e.x += e.speedX;
          e.alpha -= 0.002;
          if (e.y < 0 || e.alpha <= 0) {
            e.y = h + 10;
            e.x = Math.random() * w;
            e.alpha = Math.random() * 0.7 + 0.3;
          }
          ctxE.fillStyle = \`rgba(255, 122, 0, \${e.alpha})\`;
          ctxE.beginPath();
          ctxE.arc(e.x, e.y, e.size, 0, Math.PI * 2);
          ctxE.fill();
        });
        requestAnimationFrame(drawEmbers);
      }
      drawEmbers();
    }

    function exportFullPackage() {
      alert("📦 Complete Video Package ready in:\\nC:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\assets\\n\\nContains:\\n- 14 FLUX.1 Line-Art Scenes\\n- Full Master Narration MP3\\n- Subtitles JSON & Timeline Manifest\\n- 1,980-word Qwen 2.5 Screenplay");
    }

    window.onload = initDashboard;
  </script>
</body>
</html>
`;

fs.writeFileSync(targetPath, htmlContent, 'utf8');
console.log('✅ Interactive Hermes Storyboard & Video Dashboard written to:', targetPath);
