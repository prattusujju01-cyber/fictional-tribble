const { MsEdgeTTS, OUTPUT_FORMAT } = require('../../../scratch/node_modules/msedge-tts');
const fs = require('fs');
const path = require('path');

async function testTTS() {
  const tts = new MsEdgeTTS();
  await tts.setMetadata("en-US-ChristopherNeural", OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);

  const outPath = path.join(__dirname, 'test_christopher_male.mp3');
  const stream = tts.toStream("For over two thousand years, Egypt lived under the shadow of a thousand gods. But one pharaoh dared to delete them all.");

  const writeStream = fs.createWriteStream(outPath);
  stream.pipe(writeStream);

  return new Promise((resolve, reject) => {
    writeStream.on('finish', () => {
      console.log('✅ Generated male voiceover successfully:', outPath, 'Bytes:', fs.statSync(outPath).size);
      resolve(outPath);
    });
    writeStream.on('error', reject);
    stream.on('error', reject);
  });
}

testTTS().catch(err => console.error('TTS test failed:', err));
