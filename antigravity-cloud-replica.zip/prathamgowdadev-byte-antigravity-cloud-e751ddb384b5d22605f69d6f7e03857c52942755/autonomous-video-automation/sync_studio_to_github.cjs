/**
 * sync_studio_to_github.cjs
 * Syncs overhauled files to GitHub repo prathamgowda194-pixel/asura-system
 */

const fs = require('fs');
const path = require('path');
const https = require('https');

const BASE_DIR = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system';
const TOKEN = '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';
const REPO = 'prathamgowda194-pixel/asura-system';

const FILES_TO_SYNC = [
  'projects/studio/index.html',
  'projects/pixnova/index.html',
  'dist/index.html',
  'api/generate_website.js'
];

async function getSha(remotePath) {
  return new Promise((resolve) => {
    const req = https.request({
      hostname: 'api.github.com',
      path: \`/repos/\${REPO}/contents/\${remotePath}\`,
      method: 'GET',
      headers: {
        'User-Agent': 'ASURA-Sync-Client',
        'Authorization': \`Bearer \${TOKEN}\`,
        'Accept': 'application/vnd.github.v3+json'
      }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode === 200) {
          try {
            const parsed = JSON.parse(data);
            resolve(parsed.sha);
          } catch(e) { resolve(null); }
        } else {
          resolve(null);
        }
      });
    });
    req.on('error', () => resolve(null));
    req.end();
  });
}

async function uploadFile(relPath) {
  const localPath = path.join(BASE_DIR, relPath);
  if (!fs.existsSync(localPath)) {
    console.log('File not found locally:', localPath);
    return;
  }

  const content = fs.readFileSync(localPath, 'utf8');
  const base64Content = Buffer.from(content, 'utf8').toString('base64');
  const sha = await getSha(relPath);

  const payload = JSON.stringify({
    message: \`ASURA System Overhaul: Complete Studio, Pixnova showpiece & API sync (\${relPath})\`,
    content: base64Content,
    branch: 'main',
    ...(sha ? { sha } : {})
  });

  return new Promise((resolve, reject) => {
    const req = https.request({
      hostname: 'api.github.com',
      path: \`/repos/\${REPO}/contents/\${relPath}\`,
      method: 'PUT',
      headers: {
        'User-Agent': 'ASURA-Sync-Client',
        'Authorization': \`Bearer \${TOKEN}\`,
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(payload),
        'Accept': 'application/vnd.github.v3+json'
      }
    }, (res) => {
      let data = '';
      res.on('data', chunk => data += chunk);
      res.on('end', () => {
        if (res.statusCode === 200 || res.statusCode === 201) {
          console.log(\`✓ Successfully uploaded \${relPath} (HTTP \${res.statusCode})\`);
          resolve(true);
        } else {
          console.error(\`✗ Failed to upload \${relPath}: HTTP \${res.statusCode}\`, data);
          resolve(false);
        }
      });
    });
    req.on('error', err => {
      console.error(\`✗ Network error uploading \${relPath}:\`, err.message);
      resolve(false);
    });
    req.write(payload);
    req.end();
  });
}

async function main() {
  console.log('--- SYNCING OVERHAULED FILES TO GITHUB & VERCEL ---');
  for (const f of FILES_TO_SYNC) {
    console.log(\`Syncing \${f}...\`);
    await uploadFile(f);
    // 1s throttle between commits
    await new Promise(r => setTimeout(r, 1000));
  }
  console.log('--- ALL FILES SYNCED TO GITHUB SUCCESSFULLY ---');
}

main().catch(console.error);
