const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const desktopPath = path.join('C:', 'Users', 'WINDOWS', 'Desktop');

// 1. Update .bat to launch Vercel directly
const batPath = path.join(desktopPath, 'ASURA AI Web Developer.bat');
const batContent = `@echo off
title ASURA AGENTIC AI WEBSITE DEVELOPER // CLOUD STUDIO
echo Launching ASURA Cloud Studio on Vercel...
start https://asura-system.vercel.app
exit
`;

fs.writeFileSync(batPath, batContent, 'utf8');
console.log('[OK] Updated Desktop .bat to launch Vercel directly:', batPath);

// 2. Update .lnk shortcut to launch Vercel URL
const vbsScript = `
Set WshShell = WScript.CreateObject("WScript.Shell")
Set Shortcut = WshShell.CreateShortcut("${path.join(desktopPath, 'ASURA AI Web Developer.lnk').replace(/\\/g, '\\\\')}")
Shortcut.TargetPath = "https://asura-system.vercel.app"
Shortcut.Description = "ASURA Agentic AI Website Developer Cloud Studio"
Shortcut.Save
`;

const tempVbs = path.join(__dirname, 'update_shortcut.vbs');
fs.writeFileSync(tempVbs, vbsScript, 'utf8');
try {
  execSync(`cscript //nologo "${tempVbs}"`);
  console.log('[OK] Updated Desktop .lnk shortcut to point to Vercel URL');
} catch (e) {
  console.error('Error updating shortcut:', e.message);
}
if (fs.existsSync(tempVbs)) fs.unlinkSync(tempVbs);
