const fs = require('fs');
const path = require('path');

const baseDir = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent';

// 1. Create channel config
const channelConfig = {
  id: "global_history_documentary",
  name: "Genius History // 2D Epic Documentaries",
  niche: "Historical Documentaries (2D Hand-Drawn Animated Format)",
  targetAudience: "History enthusiasts, documentary viewers, educational animation fans",
  artStyle: {
    format: "2D Hand-Drawn Comic Line Art",
    aspectRatio: "16:9 (1920x1080)",
    lineArt: "Thick crisp black ink outlines, rounded joints, hand-drawn wiggles",
    colorFills: "Flat matte vector fills, zero photorealism, subtle paper/parchment grain texture",
    characters: "Minimalist expressive stickman/comic figures with authentic historical markers (Roman togas, samurai kabuto/armor, feathered Aztec crowns, medieval plate armor, Spartan hoplite helmets)",
    pacing: "100+ static visual cuts (~5s per cut), instant static cuts, zero camera zoom drift, zero on-screen captions"
  },
  audioProfile: {
    voiceType: "Male Explanatory Documentary Narrator",
    tone: "Authoritative, dramatic, compelling, fast-paced",
    recommendedVoices: [
      "ElevenLabs Marcus (Anthropologist/History)",
      "ElevenLabs Adam (Deep Documentary Baritone)",
      "ElevenLabs Antoni (Dramatic Storyteller)",
      "Kokoro-82M Adam (Warm Resonant Baritone)",
      "Natural Christopher (Broadcast Narrator)"
    ]
  },
  chapterStructure: [
    "Chapter 1: The Spark & Humble Origins (Scenes 1-4)",
    "Chapter 2: The Crucible of War & Expansion (Scenes 5-9)",
    "Chapter 3: The Golden Zenith & Peak Civilization (Scenes 10-14)",
    "Chapter 4: Corruption, Betrayal & Rot (Scenes 15-19)",
    "Chapter 5: Collapse & Enduring Legacy (Scenes 20-24)"
  ]
};

fs.writeFileSync(path.join(baseDir, 'config/channels/global_history_documentary.json'), JSON.stringify(channelConfig, null, 2), 'utf8');

// Remove old zenn channel config if exists
const oldZennConfig = path.join(baseDir, 'config/channels/zenn_anthropology.json');
if (fs.existsSync(oldZennConfig)) {
  fs.unlinkSync(oldZennConfig);
}

// 2. Create Hermes Historical Researcher Agent
const researcherCode = `/**
 * ══════════════════════════════════════════════════════════════════════════════
 * HERMES HISTORICAL RESEARCHER AGENT // VIRAL DOCUMENTARY RADAR
 * ══════════════════════════════════════════════════════════════════════════════
 * Analyzes global civilizations, high-stakes turning points, and viral demand:
 * - Rome, Sparta, Feudal Japan, Ancient Egypt, Mongols, Aztecs, Byzantium, etc.
 * - Identifies psychological hooks, betrayal arcs, and epic structural collapses.
 */

const fs = require('fs');
const path = require('path');

class HermesHistoricalResearcher {
  constructor() {
    this.name = 'Hermes-HistoricalResearcher';
    this.version = '4.5.0';
  }

  async getTopTrendingConcepts() {
    return [
      {
        id: 1,
        civilization: "Roman Empire (44 BC)",
        title: "The 23 Cuts: How Rome Murdered Its Savior",
        hook: "A republic terrified of kings created an emperor by trying to prevent one.",
        arc: "Julius Caesar's hubris, the Senate conspiracy, bloody Ides of March, and civil war.",
        palette: "Imperial Tyrian purple, marble white, terracotta red, blood crimson"
      },
      {
        id: 2,
        civilization: "Sengoku Japan (1582)",
        title: "The Fire of Honno-ji: The Fall of the Demon King",
        hook: "He conquered sixty provinces only to be trapped inside a burning temple by his general.",
        arc: "Oda Nobunaga's ruthless unification, Akechi Mitsuhide's betrayal, final blaze.",
        palette: "Samurai lacquer black, crimson fire orange, bamboo green, gold leaf"
      },
      {
        id: 3,
        civilization: "Ancient Egypt (1330 BC)",
        title: "Akhenaten: The Pharaoh Who Deleted The Gods",
        hook: "One man outlawed two thousand years of religion overnight to build a sun city in the sand.",
        arc: "Religious fanaticism, desert capital construction, mass starvation, complete erasure.",
        palette: "Lapis lazuli blue, desert sun gold, papyrus sand, turquoise"
      },
      {
        id: 4,
        civilization: "Spartan Hegemony (404 BC)",
        title: "Sparta’s Fatal Mistake: How Victory Destroyed Them",
        hook: "They conquered Athens, accumulated gold, and forgot the one law that kept them invincible.",
        arc: "Peloponnesian victory, introduction of private silver, social decay, Leuctra wipeout.",
        palette: "Bronze shield, Spartan crimson cloak, olive grove green, stone gray"
      },
      {
        id: 5,
        civilization: "Mongol Empire (1221)",
        title: "The Wrath of Genghis: When Khwarazm Killed the Caravan",
        hook: "A single governor shaved the beards of Mongol envoys and doomed five million people.",
        arc: "Insult of the silk envoys, unstoppable desert crossing, siege of Samarkand, devastation.",
        palette: "Steppe grassland green, horsehair brown, horse archer cyan, dust ochre"
      },
      {
        id: 6,
        civilization: "Aztec Empire (1520)",
        title: "The Night of Tears: The Aztec Empire’s Final Stand",
        hook: "Tenochtitlan was a floating paradise of 200,000 until Spanish steel and smallpox met.",
        arc: "Moctezuma's palace hostage, temple massacre, the bloody causeway escape, the siege.",
        palette: "Quetzal jade green, obsidian black, volcanic lake blue, blood ochre"
      },
      {
        id: 7,
        civilization: "Byzantine Empire (1453)",
        title: "The Last Emperor: The Fall of Constantinople",
        hook: "A 1,000-year Roman citadel defended by 7,000 men against 100,000 Ottoman cannons.",
        arc: "Super-cannon bombardment, Golden Horn naval bypass, breach at the St. Romanus gate.",
        palette: "Byzantine gold mosaic, deep imperial navy, cannon smoke gray, blood sunset"
      },
      {
        id: 8,
        civilization: "Kingdom of Mali (1324)",
        title: "Mansa Musa: The Man Who Crashed World Gold",
        hook: "He gave away so much gold on pilgrimage that Egypt's economy did not recover for twelve years.",
        arc: "Trans-Saharan gold monopoly, 60,000-person caravan, inflation wave, Timbuktu zenith.",
        palette: "Desert dune gold, rich saffron yellow, desert clay brown, royal indigo"
      },
      {
        id: 9,
        civilization: "Viking Scandinavia (878)",
        title: "The Great Heathen Army: When England Shivering In Fear",
        hook: "Three brothers sailed four hundred longships to avenge their father's pit of vipers.",
        arc: "Ragnar Lodbrok's death, bloody invasion, fall of York, battle against King Alfred.",
        palette: "North sea slate blue, blood raven black, bone white, muddy brown"
      },
      {
        id: 10,
        civilization: "French Revolution (1793)",
        title: "The Terror: When Reason Invented the Guillotine",
        hook: "The philosophers promised liberty, but within four years, Parisian gutters ran red.",
        arc: "Fall of Bastille, Jacobin radicalization, public executions, Robespierre's own demise.",
        palette: "Revolutionary tricolor red/white/blue, cold guillotine steel, cobblestone wet gray"
      }
    ];
  }
}

module.exports = new HermesHistoricalResearcher();
`;

fs.writeFileSync(path.join(baseDir, 'agents/hermes-historical-researcher.js'), researcherCode, 'utf8');

// Update hermes-voice-studio default to male explanatory voice
const voiceConfig = {
  selectedVoice: "elevenlabs_marcus",
  voiceInfo: {
    id: "elevenlabs_marcus",
    provider: "ElevenLabs",
    name: "Marcus (Authoritative Male Explanatory Documentary)",
    voiceId: "IdqgP8kC041nL0hZ4p7c",
    gender: "Male",
    accent: "American",
    style: "Deep, compelling, authoritative male documentary narrator with dramatic pacing.",
    sampleText: "In the year 44 BC, the most powerful civilization on Earth was about to tear itself apart."
  },
  updatedAt: new Date().toISOString()
};
fs.writeFileSync(path.join(baseDir, 'config/voice_selection.json'), JSON.stringify(voiceConfig, null, 2), 'utf8');

console.log('✅ Global 2D Historical Documentary niche deployed successfully!');
