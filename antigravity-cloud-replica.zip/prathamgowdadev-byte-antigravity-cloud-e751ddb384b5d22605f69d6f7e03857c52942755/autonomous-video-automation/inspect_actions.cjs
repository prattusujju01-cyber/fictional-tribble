const GITHUB_TOKEN = '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';
const REPO = 'prathamgowda194-pixel/asura-system';

async function checkActions() {
  const url = 'https://api.github.com/repos/' + REPO + '/actions/runs';
  const res = await fetch(url, {
    headers: {
      'Authorization': 'Bearer ' + GITHUB_TOKEN,
      'User-Agent': 'ASURA-Debugger',
      'Accept': 'application/vnd.github.v3+json'
    }
  });
  const data = await res.json();
  if (data.message) {
    console.error('GitHub API error:', data.message);
    return;
  }
  console.log('Total runs:', data.total_count);
  for (const run of (data.workflow_runs || []).slice(0, 3)) {
    console.log('--- Run ID:', run.id, '---');
    console.log('Name:', run.name);
    console.log('Status:', run.status, '| Conclusion:', run.conclusion);
    console.log('Event:', run.event);
    console.log('Commit:', run.head_commit?.id?.slice(0,7), '| Msg:', run.head_commit?.message);

    // Fetch jobs for this run
    const jobsRes = await fetch(run.jobs_url, {
      headers: {
        'Authorization': 'Bearer ' + GITHUB_TOKEN,
        'User-Agent': 'ASURA-Debugger',
        'Accept': 'application/vnd.github.v3+json'
      }
    });
    const jobsData = await jobsRes.json();
    for (const job of (jobsData.jobs || [])) {
      console.log('  Job:', job.name, '| Status:', job.status, '| Conclusion:', job.conclusion);
      for (const step of (job.steps || [])) {
        if (step.conclusion === 'failure') {
          console.log('    FAILED STEP:', step.name, '| Conclusion:', step.conclusion);
        }
      }
    }
  }
}

checkActions();
