const fs = require('fs');
const path = require('path');

const GITHUB_TOKEN = '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';
const REPO = 'prathamgowda194-pixel/asura-system';

async function api(endpoint, method = 'GET', body = null) {
  const opts = {
    method,
    headers: {
      'Authorization': `Bearer ${GITHUB_TOKEN}`,
      'User-Agent': 'ASURA-Migration',
      'Accept': 'application/vnd.github.v3+json'
    }
  };
  if (body) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(`https://api.github.com/repos/${REPO}${endpoint}`, opts);
  return await res.json();
}

async function run() {
  console.log('⚡ MIGRATING PROTOTYPES TO PROTOTYPES/ TO BYPASS VERCEL STATIC CACHE...');

  // 1. Get latest commit on main
  const ref = await api('/git/ref/heads/main');
  const parentSha = ref.object.sha;
  const parentCommit = await api(`/git/commits/${parentSha}`);

  // 2. Fetch current tree recursively
  const treeData = await api(`/git/trees/${parentCommit.tree.sha}?recursive=1`);
  const currentTree = treeData.tree || [];

  // 3. Find all projects/:slug/index.html blobs
  const projectBlobs = currentTree.filter(item => item.path.startsWith('projects/') && item.type === 'blob');
  console.log(`Found ${projectBlobs.length} project files to migrate.`);

  // 4. Create new tree entries:
  // - Add to prototypes/:slug/index.html
  // - Remove from projects/ (by not including them in a new base tree, or deleting them)
  const newEntries = [];

  // Copy all project blobs to prototypes/
  for (const blob of projectBlobs) {
    const newPath = blob.path.replace(/^projects\//, 'prototypes/');
    newEntries.push({
      path: newPath,
      mode: blob.mode,
      type: 'blob',
      sha: blob.sha
    });
  }

  // To completely remove the static projects/ directory from Vercel's build output,
  // we rebuild the tree with all non-projects files + the new prototypes files.
  const nonProjectFiles = currentTree.filter(item => !item.path.startsWith('projects/') && item.type === 'blob');

  const fullTreeEntries = [
    ...nonProjectFiles.map(item => ({
      path: item.path,
      mode: item.mode,
      type: 'blob',
      sha: item.sha
    })),
    ...newEntries
  ];

  console.log(`Creating fresh tree without static projects/ (${fullTreeEntries.length} total files)...`);
  const createdTree = await api('/git/trees', 'POST', {
    tree: fullTreeEntries
  });

  // 5. Create commit
  const newCommit = await api('/git/commits', 'POST', {
    message: 'feat(infra): move prototypes to prototypes/ to eliminate Vercel static cache collisions',
    tree: createdTree.sha,
    parents: [parentSha]
  });

  // 6. Update main branch
  await api('/git/refs/heads/main', 'PATCH', {
    sha: newCommit.sha,
    force: false
  });

  console.log(`🎉 SUCCESS! Migrated all prototypes to prototypes/ in commit: ${newCommit.sha.slice(0, 7)}`);
}

run().catch(console.error);
