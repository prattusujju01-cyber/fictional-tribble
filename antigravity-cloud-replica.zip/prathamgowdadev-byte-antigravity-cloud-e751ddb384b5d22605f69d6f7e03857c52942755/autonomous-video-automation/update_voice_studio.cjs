const fs = require('fs');
const path = require('path');

const target = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\agents\\hermes-voice-studio.js';
const code = `/**
 * Hermes Voice Studio Agent
 * Intellectual Neural Documentary Voiceover & Audio Engine
 * Scene-by-Scene High-Prosody Neural Synthesis + Master Audio Assembly
 */
const fs = require('fs');
const path = require('path');
const openSourceAI = require('../utils/open-source-ai.js');

class HermesVoiceStudio {
  constructor() {
    this.name = 'Hermes-VoiceStudio';
    this.version = '2.1.0';
  }

  async synthesizeNarration(screenplay) {
    const audioDir = path.join(__dirname, '../assets/audio');
    if (!fs.existsSync(audioDir)) fs.mkdirSync(audioDir, { recursive: true });

    const masterAudioPath = path.join(audioDir, 'narration.mp3');
    console.log(\`[\${this.name}] 🎙️ Commencing scene-by-scene neural audio synthesis for: "\${screenplay.meta.title}"...\`);

    const allScenes = screenplay.acts.flatMap(act => act.scenes);
    const sceneBuffers = [];
    const subtitleManifest = [];
    let currentSeconds = 0;

    for (let i = 0; i < allScenes.length; i++) {
      const s = allScenes[i];
      const sceneAudioFile = \`\${s.sceneId}.mp3\`;
      const sceneAudioPath = path.join(audioDir, sceneAudioFile);

      console.log(\`[\${this.name}] 🎙️ Synthesizing Scene [\${i + 1}/\${allScenes.length}]: \${s.sceneId}...\`);

      try {
        const res = await openSourceAI.generateVoiceover(s.narration, sceneAudioPath);
        const buf = fs.readFileSync(sceneAudioPath);
        sceneBuffers.push(buf);

        const wordCount = s.narration.split(/\\s+/).length;
        // ~140 words per minute => ~2.33 words/sec
        const durationSeconds = Math.max(7, Math.round(wordCount / 2.33));
        const start = currentSeconds;
        const end = currentSeconds + durationSeconds;
        currentSeconds = end;

        subtitleManifest.push({
          sceneId: s.sceneId,
          sceneIndex: i + 1,
          startTimeSec: start,
          endTimeSec: end,
          durationSec: durationSeconds,
          wordCount,
          audioFile: \`assets/audio/\${sceneAudioFile}\`,
          text: s.narration
        });

        console.log(\`[\${this.name}] ✅ \${s.sceneId}.mp3 ready (\${Math.round(buf.length / 1024)} KB, ~\${durationSeconds}s)\`);
      } catch (err) {
        console.warn(\`[\${this.name}] ⚠️ Scene \${s.sceneId} audio fallback: \${err.message}\`);
      }

      // Small delay between scenes
      if (i < allScenes.length - 1) {
        await new Promise(r => setTimeout(r, 400));
      }
    }

    // Concatenate all scene buffers into master narration.mp3
    const masterBuffer = Buffer.concat(sceneBuffers);
    fs.writeFileSync(masterAudioPath, masterBuffer);
    const totalKB = Math.round(masterBuffer.length / 1024);

    console.log(\`[\${this.name}] 🎵 Master narration concatenated: \${totalKB} KB (~\${Math.round(currentSeconds / 60)} mins) at \${masterAudioPath}\`);

    const subPath = path.join(__dirname, '../assets/subtitles.json');
    fs.writeFileSync(subPath, JSON.stringify(subtitleManifest, null, 2), 'utf8');

    return {
      audioPath: masterAudioPath,
      relativePath: 'assets/audio/narration.mp3',
      totalEstimatedSeconds: currentSeconds,
      subtitles: subtitleManifest,
      sizeKB: totalKB
    };
  }
}

module.exports = new HermesVoiceStudio();
`;

fs.writeFileSync(target, code, 'utf8');
console.log('Updated Hermes Voice Studio at', target);
