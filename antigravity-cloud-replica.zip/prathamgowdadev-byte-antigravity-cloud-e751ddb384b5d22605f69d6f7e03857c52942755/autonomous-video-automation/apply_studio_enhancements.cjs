const fs = require('fs');
const path = require('path');

const asuraDir = path.join('C:', 'Users', 'WINDOWS', '.gemini', 'antigravity', 'scratch', 'asura-system');
const indexPath = path.join(asuraDir, 'index.html');
const distPath = path.join(asuraDir, 'dist', 'index.html');
const studioPath = path.join(asuraDir, 'projects', 'studio', 'index.html');

let content = fs.readFileSync(indexPath, 'utf8');

// 1. Update quick action pills around the orb
const oldPills = '<button onclick="prefillPrompt(\'Create a luxury real estate website with dark obsidian theme, 3D villa parallax, and interactive inquiry form\')" class="px-3 py-1.5 rounded-lg bg-obsidian-100 hover:bg-obsidian-50 border border-obsidian-border text-zinc-300 hover:text-white hover:border-white/40 transition">\n' +
'              ✦ Luxury Real Estate\n' +
'            </button>\n' +
'            <button onclick="prefillPrompt(\'Create an ultra-modern crypto fintech website with dynamic 3D globe and interactive wallet connection\')" class="px-3 py-1.5 rounded-lg bg-obsidian-100 hover:bg-obsidian-50 border border-obsidian-border text-zinc-300 hover:text-white hover:border-white/40 transition">\n' +
'              ✦ FinTech Crypto Portal\n' +
'            </button>\n' +
'            <button onclick="prefillPrompt(\'Create a high-converting aesthetic dental clinic landing page with before-after slider and booking wizard\')" class="px-3 py-1.5 rounded-lg bg-obsidian-100 hover:bg-obsidian-50 border border-obsidian-border text-zinc-300 hover:text-white hover:border-white/40 transition">\n' +
'              ✦ Aesthetic Medical Clinic\n' +
'            </button>\n' +
'            <button onclick="switchMainView(\'radar\')" class="px-3 py-1.5 rounded-lg bg-obsidian-100 hover:bg-obsidian-50 border border-emerald-500/30 text-emerald-400 transition">\n' +
'              ✦ Live Vercel Radar\n' +
'            </button>';

const newPills = '<button onclick="prefillPrompt(\'Build a 21st.dev Magic interactive Bento Grid website for an enterprise AI accelerator with GSAP scroll physics\')" class="px-3 py-1.5 rounded-lg bg-obsidian-100 hover:bg-obsidian-50 border border-obsidian-border text-zinc-300 hover:text-white hover:border-white/40 transition">\n' +
'              ✦ 21st.dev Magic Bento\n' +
'            </button>\n' +
'            <button onclick="prefillPrompt(\'Build a high-performance FinTech portal with Shadcn UI cards, dynamic charts, and Convex real-time state\')" class="px-3 py-1.5 rounded-lg bg-obsidian-100 hover:bg-obsidian-50 border border-obsidian-border text-zinc-300 hover:text-white hover:border-white/40 transition">\n' +
'              ✦ Shadcn & Convex FinTech\n' +
'            </button>\n' +
'            <button onclick="prefillPrompt(\'Build a luxury architectural estate website with GSAP ScrollTrigger parallax and tactile hover micro-physics\')" class="px-3 py-1.5 rounded-lg bg-obsidian-100 hover:bg-obsidian-50 border border-obsidian-border text-zinc-300 hover:text-white hover:border-white/40 transition">\n' +
'              ✦ GSAP ScrollTrigger Luxury\n' +
'            </button>\n' +
'            <button onclick="switchMainView(\'radar\')" class="px-3 py-1.5 rounded-lg bg-obsidian-100 hover:bg-obsidian-50 border border-emerald-500/30 text-emerald-400 transition">\n' +
'              ✦ Live Vercel Radar\n' +
'            </button>';

if (content.indexOf('✦ Luxury Real Estate') !== -1) {
  content = content.replace(oldPills, newPills);
  console.log('[OK] Replaced quick action pills with 10-skill presets');
}

// 2. Update Model Selector dropdown
const oldSelect = '<option value="Asura 3.5 Flash High">Gemini 2.0 Flash High</option>';
const newSelect = '<option value="Gemini 3.6 Flash High">Gemini 3.6 Flash High (10 Skills Master)</option>\n' +
'                    <option value="OpenAI Form (Structured JSON)">OpenAI Form (Structured Schema)</option>';

if (content.indexOf(oldSelect) !== -1) {
  content = content.replace(oldSelect, newSelect);
  console.log('[OK] Updated model selector with Gemini 3.6 Flash & OpenAI Form');
}

// 3. Update Reasoning Trajectory Step Progress
const oldProg = '<div class="flex items-center gap-2"><span class="text-emerald-400 font-bold">✓</span> Requirement Decomposition & Archetype Blueprinting</div>\n' +
'            <div class="flex items-center gap-2"><span class="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></span> Synthesizing Responsive UI, Kinetic Shaders, & Motion Physics...</div>';

const newProg = '<div class="flex items-center gap-2"><span class="text-emerald-400 font-bold">✓</span> [frontend-design & ui-ux-pro-max]: Anti-Slop Archetype & Bento Grid Tokens</div>\n' +
'            <div class="flex items-center gap-2"><span class="text-emerald-400 font-bold">✓</span> [shadcn-ui & 21st.dev Magic MCP]: Synthesized Modular Accessible Primitives</div>\n' +
'            <div class="flex items-center gap-2"><span class="text-emerald-400 font-bold">✓</span> [gsap-master & motion-framer]: Injected ScrollTrigger Parallax & Spring Curves</div>\n' +
'            <div class="flex items-center gap-2"><span class="text-emerald-400 font-bold">✓</span> [vercel-react-best-practices]: Zero-Waterfall Pipeline & Fluid Touch Targets</div>\n' +
'            <div class="flex items-center gap-2"><span class="w-1.5 h-1.5 rounded-full bg-white animate-pulse"></span> [convex-create-component]: Compiling Real-Time Reactive Lead Schema...</div>';

if (content.indexOf(oldProg) !== -1) {
  content = content.replace(oldProg, newProg);
  console.log('[OK] Updated reasoning trajectory with 10-skill progress steps');
}

// Write to all target HTML files
fs.writeFileSync(indexPath, content, 'utf8');
console.log('[OK] Updated:', indexPath);

fs.writeFileSync(distPath, content, 'utf8');
console.log('[OK] Updated:', distPath);

fs.writeFileSync(studioPath, content, 'utf8');
console.log('[OK] Updated:', studioPath);

fs.writeFileSync(path.join(__dirname, 'clean_index.html'), content, 'utf8');
console.log('[OK] Updated artifact clean_index.html');
