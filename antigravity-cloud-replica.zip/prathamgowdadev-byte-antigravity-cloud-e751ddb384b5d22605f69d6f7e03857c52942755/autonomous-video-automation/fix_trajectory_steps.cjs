const fs = require('fs');
const path = require('path');

const asuraDir = path.join('C:', 'Users', 'WINDOWS', '.gemini', 'antigravity', 'scratch', 'asura-system');
const files = [
  path.join(asuraDir, 'index.html'),
  path.join(asuraDir, 'dist', 'index.html'),
  path.join(asuraDir, 'projects', 'studio', 'index.html'),
  path.join(__dirname, 'clean_index.html')
];

const oldSnippet = "'<div id=\"stepProgress\" class=\"space-y-2 text-[11px] text-zinc-400\">' +\n" +
"            '<div class=\"flex items-center gap-2\"><span class=\"text-emerald-400 font-bold\">✓</span> Requirement Decomposition & Archetype Blueprinting</div>' +\n" +
"            '<div class=\"flex items-center gap-2\"><span class=\"w-1.5 h-1.5 rounded-full bg-white animate-pulse\"></span> Synthesizing Responsive UI, Kinetic Shaders, & Motion Physics...</div>' +\n" +
"          '</div>'";

const newSnippet = "'<div id=\"stepProgress\" class=\"space-y-2 text-[11px] text-zinc-400\">' +\n" +
"            '<div class=\"flex items-center gap-2\"><span class=\"text-emerald-400 font-bold\">✓</span> [frontend-design & ui-ux-pro-max]: Anti-Slop Archetype & Bento Grid Tokens</div>' +\n" +
"            '<div class=\"flex items-center gap-2\"><span class=\"text-emerald-400 font-bold\">✓</span> [shadcn-ui & 21st.dev Magic MCP]: Synthesized Modular Accessible Primitives</div>' +\n" +
"            '<div class=\"flex items-center gap-2\"><span class=\"text-emerald-400 font-bold\">✓</span> [gsap-master & motion-framer]: Injected ScrollTrigger Parallax & Spring Curves</div>' +\n" +
"            '<div class=\"flex items-center gap-2\"><span class=\"text-emerald-400 font-bold\">✓</span> [vercel-react-best-practices]: Zero-Waterfall Pipeline & Fluid Touch Targets</div>' +\n" +
"            '<div class=\"flex items-center gap-2\"><span class=\"w-1.5 h-1.5 rounded-full bg-white animate-pulse\"></span> [convex-create-component]: Compiling Real-Time Reactive Lead Schema...</div>' +\n" +
"          '</div>'";

for (const f of files) {
  let c = fs.readFileSync(f, 'utf8');
  if (c.includes(oldSnippet)) {
    c = c.replace(oldSnippet, newSnippet);
    fs.writeFileSync(f, c, 'utf8');
    console.log('[OK] Replaced trajectory steps in:', f);
  } else {
    console.log('[WARN] Snippet not found in:', f);
  }
}
