const FIRECRAWL_KEY = "fc-9580658b488a4455850b07c92bd7ed59";

async function testFirecrawl() {
  try {
    console.log("Testing Firecrawl search API...");
    const res = await fetch("https://api.firecrawl.dev/v1/search", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${FIRECRAWL_KEY}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify({
        query: "dentist Miami phone contact -site:yelp.com -site:zocdoc.com",
        limit: 5
      })
    });
    console.log("Status:", res.status);
    const data = await res.json();
    console.log("Firecrawl Result:", JSON.stringify(data, null, 2).slice(0, 1000));
  } catch (e) {
    console.error("Firecrawl Error:", e.message);
  }
}

testFirecrawl();
