const fs = require('fs');
const crypto = require('crypto');

function synthesizeEdgeTTS(text, voice = 'en-US-ChristopherNeural') {
  return new Promise((resolve, reject) => {
    const connectionId = crypto.randomUUID().replace(/-/g, '');
    const wsUrl = `wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1?TrustedClientToken=6A5AA1D4EA6540818367A688880D7F55&ConnectionId=${connectionId}`;
    
    const ws = new WebSocket(wsUrl);
    const audioBuffers = [];

    ws.onopen = () => {
      // 1. Send speech.config
      const configMessage = `Content-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n{"context":{"synthesis":{"audio":{"metadataoptions":{"sentenceBoundaryEnabled":"false","wordBoundaryEnabled":"true"},"outputFormat":"audio-24khz-48kbitrate-mono-mp3"}}}}`;
      ws.send(configMessage);

      // 2. Send SSML
      const requestId = crypto.randomUUID().replace(/-/g, '');
      const ssml = `<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'>
        <voice name='${voice}'>
          <prosody rate='-5%' pitch='-2Hz'>${text}</prosody>
        </voice>
      </speak>`;
      const ssmlMessage = `X-RequestId:${requestId}\r\nContent-Type:application/ssml+xml\r\nPath:ssml\r\n\r\n${ssml}`;
      ws.send(ssmlMessage);
    };

    ws.onmessage = async (event) => {
      if (typeof event.data === 'string') {
        if (event.data.includes('Path:turn.end')) {
          ws.close();
          const finalBuffer = Buffer.concat(audioBuffers);
          resolve(finalBuffer);
        }
      } else if (event.data instanceof Blob) {
        const arrayBuffer = await event.data.arrayBuffer();
        const buffer = Buffer.from(arrayBuffer);
        // Header is binary delimited by \r\n\r\n (Path:audio)
        const headerEnd = buffer.indexOf(Buffer.from('\r\n\r\n'));
        if (headerEnd !== -1) {
          const audioChunk = buffer.subarray(headerEnd + 4);
          audioBuffers.push(audioChunk);
        }
      }
    };

    ws.onerror = (err) => reject(err);
    ws.onclose = () => {
      if (audioBuffers.length > 0) {
        resolve(Buffer.concat(audioBuffers));
      }
    };
  });
}

async function run() {
  console.log('Testing Edge-TTS with ChristopherNeural...');
  try {
    const text = "Tonight, when you flip a light switch, you probably won’t think twice about it. But for ninety-nine point nine percent of human history, that switch didn’t exist.";
    const audio = await synthesizeEdgeTTS(text);
    console.log('Audio received, bytes:', audio.length);
    fs.writeFileSync('test_edge_tts.mp3', audio);
    console.log('Saved to test_edge_tts.mp3 successfully!');
  } catch (e) {
    console.error('Error:', e);
  }
}

run();
