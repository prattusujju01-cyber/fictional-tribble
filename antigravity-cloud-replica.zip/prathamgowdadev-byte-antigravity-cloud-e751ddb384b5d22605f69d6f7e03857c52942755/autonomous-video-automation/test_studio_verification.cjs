/**
 * test_studio_verification.cjs
 * Verifies all fixes applied to Asura Studio
 */

const fs = require('fs');
const path = require('path');
const assert = require('assert');

console.log('--- RUNNING ASURA OVERHAUL VERIFICATION TESTS ---');

const BASE_DIR = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system';
const STUDIO_PATH = path.join(BASE_DIR, 'projects', 'studio', 'index.html');
const PIXNOVA_PATH = path.join(BASE_DIR, 'projects', 'pixnova', 'index.html');

// Test 1: Pixnova Showpiece Inspection
const pixnova = fs.readFileSync(PIXNOVA_PATH, 'utf8');
assert(pixnova.includes('background-color: #FFFFFF'), 'Pixnova MUST have pure white background (#FFFFFF)');
assert(pixnova.includes('color: #050D24'), 'Pixnova MUST have dark midnight blue text (#050D24)');
assert(pixnova.includes('Plus Jakarta Sans'), 'Pixnova must include Plus Jakarta Sans font');
assert(pixnova.includes('Syne'), 'Pixnova must include Syne font');
assert(pixnova.includes('ScrollTrigger'), 'Pixnova must include GSAP ScrollTrigger');
assert(pixnova.includes('VORTEX AI CLOUD'), 'Pixnova must include multi-niche portfolio cards');
assert(pixnova.includes('Growth Architecture ($9,800)'), 'Pixnova must include interactive pricing calculator');
assert(pixnova.includes('mandateForm'), 'Pixnova must include interactive mandate terminal');
console.log('✓ Test 1 Passed: Pixnova Showpiece verified with white background, dark blue text, and full interactive architecture.');

// Test 2: Studio Code Inspection
const studio = fs.readFileSync(STUDIO_PATH, 'utf8');
assert(studio.includes('deleteConversation'), 'Studio MUST have individual delete conversation function');
assert(studio.includes('asura_studio_conversations_v6'), 'Studio MUST use upgraded storage key v6');
assert(studio.includes('Pristine White & Midnight Navy Blue'), 'Studio MUST support Pristine White & Midnight Navy Blue palette');
assert(studio.includes('jarvisAnimationSpeed = 0.055'), 'Studio MUST speed up Jarvis Orb during reasoning');
assert(studio.includes('openSavedConversation'), 'Studio MUST have openSavedConversation');
assert(!studio.includes('prefillPrompt(found.prompt);\n      submitPrompt();'), 'Studio MUST NOT re-call submitPrompt on opening saved conversation');
console.log('✓ Test 2 Passed: Studio script verified with non-duplicating session loader, individual delete buttons, and authentic reasoning trajectory.');

console.log('--- ALL VERIFICATION TESTS PASSED (2/2) ---');
