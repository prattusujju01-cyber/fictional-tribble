const BOT_TOKEN = '8909145509:AAF8UhbWxPR5JGt8ddcAd9D1gqZ3L13ZuAo';

async function run() {
  // Test 1: Simple plain text message
  console.log('Test 1: Simple plain text...');
  const r1 = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: '7025916840',
      text: 'ASURA HUNTER 24/7 // Cloud cron is now LIVE. This is your 30-minute auto-sweep working from Vercel cloud. No laptop needed!'
    })
  });
  const d1 = await r1.json();
  console.log('Status:', r1.status, '| OK:', d1.ok, '| Error:', d1.description || 'none');

  if (!d1.ok) return;

  // Test 2: HTML message with buttons
  await new Promise(r => setTimeout(r, 1000));
  console.log('\nTest 2: HTML + inline buttons...');
  const protoUrl = 'https://asura-system.vercel.app/projects/bridge-property-consultants-mumbai/index.html';
  const r2 = await fetch(`https://api.telegram.org/bot${BOT_TOKEN}/sendMessage`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      chat_id: '7025916840',
      parse_mode: 'HTML',
      text: '<b>NEW CLIENT LEAD</b>\nBusiness: Bridge Property Consultants\nPhone: +91 93202 93840\nCity: Mumbai\nWebsite Status: NO WEBSITE\n\nLive Prototype: ' + protoUrl,
      reply_markup: {
        inline_keyboard: [
          [{ text: 'Open Live Website', url: protoUrl }],
          [{ text: 'WhatsApp Pitch', url: 'https://wa.me/919320293840' }, { text: 'Call +91', url: 'tel:+919320293840' }]
        ]
      }
    })
  });
  const d2 = await r2.json();
  console.log('Status:', r2.status, '| OK:', d2.ok, '| MsgID:', d2.result && d2.result.message_id, '| Error:', d2.description || 'none');
}

run().catch(console.error);
