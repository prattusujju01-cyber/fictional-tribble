const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const targetCloudUrl = 'https://asura-system.vercel.app/projects/studio';
const desktopPath = path.join('C:', 'Users', 'WINDOWS', 'Desktop');

// 1. Update .bat
const batPath = path.join(desktopPath, 'ASURA AI Web Developer.bat');
const batContent = `@echo off
title ASURA AGENTIC AI WEBSITE DEVELOPER // 24/7 CLOUD STUDIO
echo ======================================================================
echo Launching ASURA Agentic AI Studio 24/7 Cloud on Vercel...
echo URL: ${targetCloudUrl}
echo ======================================================================
start "" "${targetCloudUrl}"
exit
`;
fs.writeFileSync(batPath, batContent, 'utf8');
console.log('[OK] Updated Desktop .bat launcher to open:', targetCloudUrl);

// 2. Update .lnk shortcut via VBScript
const vbsScript = `
Set WshShell = WScript.CreateObject("WScript.Shell")
Set Shortcut = WshShell.CreateShortcut("${path.join(desktopPath, 'ASURA AI Web Developer.lnk').replace(/\\/g, '\\\\')}")
Shortcut.TargetPath = "${targetCloudUrl}"
Shortcut.Description = "ASURA Agentic AI Website Developer (24/7 Vercel Cloud Studio)"
Shortcut.Save
`;

const tempVbs = path.join(__dirname, 'update_cloud_shortcut.vbs');
fs.writeFileSync(tempVbs, vbsScript, 'utf8');
try {
  execSync(`cscript //nologo "${tempVbs}"`);
  console.log('[OK] Updated Desktop .lnk shortcut to open:', targetCloudUrl);
} catch (e) {
  console.error('Error updating shortcut:', e.message);
}
if (fs.existsSync(tempVbs)) fs.unlinkSync(tempVbs);
