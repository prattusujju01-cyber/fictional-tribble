const fs = require('fs');
const path = require('path');

const targetPath = path.join('C:', 'Users', 'WINDOWS', '.gemini', 'antigravity', 'scratch', 'youtube-automation-agent', 'config', 'channels', 'zenn_anthropology.json');

const config = {
  channelId: "zenn_anthropology_curiosity",
  channelName: "Zenn Curiosity / Human History",
  niche: "Anthropological, Evolutionary & Historical Curiosity",
  subNiches: [
    "Prehistoric Human Lifestyle",
    "Lost Human Biological Rhythms",
    "Evolution of Human Sleep & Diet",
    "Ancient Psychology vs Modern Society",
    "Paleoanthropology Mysteries"
  ],
  targetAudience: {
    demographic: "Intellectually curious adults (20-45) interested in history, evolution, philosophy, and neuroscience",
    emotionalHook: "Existential perspective shifts, re-contextualizing modern struggles (insomnia, anxiety, loneliness) as ancient biological adaptations"
  },
  videoFormat: {
    targetDurationMinutes: "10-15 minutes",
    targetWordCount: "1,800 - 2,200 words",
    averagePacingWPM: 140,
    aspectRatio: "16:9",
    resolution: "1920x1080 Full HD",
    cutFrequencySeconds: "6-10 seconds per visual scene (60-90 scenes per 12-minute video)"
  },
  visualDNA: {
    style: "Minimalist 2D hand-drawn line-art stickman illustration",
    aesthetic: "Dark cave ambience, warm glowing campfire (#FF7A00, #F39C12), deep charcoal stone textures (#1A1A24, #0D0F18), crescent moonlight highlights (#E0E6ED), subtle paper grain, cinematic vignette",
    characterSpecs: {
      protagonist: "Expressive stickman human ancestor with clean circular head, wide curious white eyes, minimalist black line body, organic handwritten linework",
      expressions: ["curious wondering", "shivering in cold darkness", "peaceful meditative slumber", "alarmed predator alert", "philosophical gaze at stars"]
    },
    masterVisualPromptPrefix: "minimalist 2D hand-drawn line art illustration, expressive stickman caveman, style of Zenn animation, atmospheric textured cave backdrop, warm campfire ember glow, deep nocturnal void, cinematic lighting, 8k resolution 16:9, clean vector composition"
  },
  audioDNA: {
    voiceProfile: {
      tone: "Calm, contemplative, articulate, intimate documentary narrator",
      speedRate: "-5%",
      pitchShift: "-2Hz",
      preferredVoices: ["en-US-ChristopherNeural", "en-US-GuyNeural", "en-GB-RyanNeural"]
    },
    soundscapeLayers: [
      "Layer 1: Continuous low-volume crackling wood embers and cave wind",
      "Layer 2: Subtle sub-bass drone and atmospheric ambient cello synth",
      "Layer 3: Foley hits on key transition beats (soft match strike, book page turn, heartbeat pulse, water drip)"
    ]
  },
  narrativeStructure: {
    totalActs: 5,
    acts: [
      {
        actNumber: 1,
        title: "The Modern Disconnect & The 99.9% Reality Hook",
        duration: "0:00 - 2:30",
        targetWords: 350,
        objective: "Shatter modern assumptions using an everyday sensory trigger (flipping a light switch, staring at a phone at 2 AM). Reveal that for 99.9% of human existence, total darkness ruled half of every 24-hour cycle.",
        retentionMechanic: "Pattern interrupt at second 45: pose the central question that creates an irresistible knowledge gap."
      },
      {
        actNumber: 2,
        title: "The Campfire Revolution & The Social Brain",
        duration: "2:30 - 5:30",
        targetWords: 450,
        objective: "Explore how controlling fire (Wonderwerk Cave, 1M years ago) extended human day by 4-5 hours. Explain Polly Wiessner's study on how daytime talk was economic, but firelight talk became mythology, singing, and bonding.",
        retentionMechanic: "Contrast dynamic: from brutal survival predator tension to the warm sanctuary of the fire circle."
      },
      {
        actNumber: 3,
        title: "The Lost History of Sleep: First & Second Sleep",
        duration: "5:30 - 9:00",
        targetWords: 500,
        objective: "Unveil Roger Ekirch's groundbreaking archival discovery of biphasic sleep across centuries of literature, and Thomas Wehr's NIH darkness experiment proving humans naturally sleep in two 4-hour shifts separated by a 1-hour midnight 'Watch'.",
        retentionMechanic: "Scientific epiphany: explain that 2 AM insomnia isn't a medical defect—it is human biology functioning as designed."
      },
      {
        actNumber: 4,
        title: "The Circadian Trap & The Industrial Invention of 8 Hours",
        duration: "9:00 - 12:00",
        targetWords: 450,
        objective: "Track how 17th-century streetlights (Paris under Louis XIV), gas lamps, and the Industrial Revolution compressed sleep into a single mechanical block to maximize factory labor.",
        retentionMechanic: "Historical irony: our modern sleep anxiety is a 150-year-old byproduct of factory work shifts and Edison's bulb."
      },
      {
        actNumber: 5,
        title: "The Biological Echo & The Philosophical Resolution",
        duration: "12:00 - 14:30",
        targetWords: 350,
        objective: "Synthesize the biological and emotional lesson. When you sit awake in the dark tonight, you are not alone; you are standing the ancient midnight watch of your ancestors. Conclude with a resonant, poetic sign-off.",
        retentionMechanic: "Deep catharsis and high re-watch/share value."
      }
    ]
  },
  scientificCitations: [
    "Roger Ekirch (2001, American Historical Review) - 'Sleep We Have Lost: Pre-Industrial Slumber in the British Isles'",
    "Thomas Wehr (1992, Journal of Sleep Research) - 'In short photoperiods, human sleep is biphasic'",
    "Polly Wiessner (2014, PNAS) - 'Embers of society: Firelight talk among the Ju/'hoansi Bushmen'",
    "Francesco Berna et al. (2012, PNAS) - 'Microstratigraphic evidence of in situ fire in Wonderwerk Cave'",
    "Kenneth Wright et al. (2013, Current Biology) - 'Entrainment of the Human Circadian Clock to the Natural Light-Dark Cycle'"
  ]
};

fs.writeFileSync(targetPath, JSON.stringify(config, null, 2), 'utf8');
console.log('✅ Zenn Anthropology Niche Blueprint written successfully to:', targetPath);
