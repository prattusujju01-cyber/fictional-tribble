const fs = require('fs');
const path = require('path');

const targetPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\utils\\historical-screenplay-builder.js';
let code = fs.readFileSync(targetPath, 'utf8');

// Add 12 additional dramatic beats in key scenes (Scenes 1, 4, 5, 8, 10, 11, 12, 16, 17, 20, 22, 24)
const extraBeat1 = `
            {
              bgType: "egyptian_temple_karnak",
              characterPose: "priests_counting_tribute",
              expression: "smug_curious",
              narration: "The High Priest of Amun was the shadow ruler of the kingdom, whispering commands behind gilded incense smoke.",
              visual: "A high priest with an ornate leopard-skin stole glaring down from a carved stone dais."
            },`;

const extraBeat4 = `
            {
              bgType: "cosmic_aten_revelation",
              characterPose: "aten_sun_disc_radiant",
              expression: "awe_wonder",
              narration: "Light was no longer a mystery hidden behind temple veils; light was the universal father of every living thing.",
              visual: "Solar rays piercing through temple doorways, casting blinding amber shafts across the sand."
            },`;

const extraBeat5 = `
            {
              bgType: "temple_desecration_scaffold",
              characterPose: "bronze_chisels_flying_dust",
              expression: "determined",
              narration: "Every single hieroglyph spelling the plural word for 'gods' was gouged out with iron and stone.",
              visual: "Close-up of a carved stone wall with the plural glyph for deities violently smashed into raw rubble."
            },`;

const extraBeat8 = `
            {
              bgType: "amarna_construction_rise",
              characterPose: "roofless_temple_courtyards",
              expression: "determined",
              narration: "Thousands of stone cutters worked under armed guard day and night to manifest the holy city from raw stone.",
              visual: "Torchlit night construction in the desert, with fires illuminating columns rising against the stars."
            },`;

const extraBeat10 = `
            {
              bgType: "amarna_grand_avenue",
              characterPose: "chariot_procession_gold",
              expression: "grinning",
              narration: "The Royal Road of Amarna stretched four miles long, wider than any boulevard in the ancient Mediterranean world.",
              visual: "A vast paved ceremonial avenue stretching straight toward the horizon, lined with fluttering white banners."
            },`;

const extraBeat11 = `
            {
              bgType: "royal_palace_balcony",
              characterPose: "pharaoh_chanting_hymn",
              expression: "inspired",
              narration: "'When the chick in the egg cries in the shell, thou givest him breath therein to preserve him alive.'",
              visual: "A small bird hatching from an egg illuminated by delicate golden sunbeams in a palace nest."
            },`;

const extraBeat12 = `
            {
              bgType: "nefertiti_throne_terrace",
              characterPose: "wearing_blue_crown",
              expression: "determined",
              narration: "Her famous limestone bust, sculpted by Thutmose, would become the eternal global symbol of feminine grace.",
              visual: "Sculptor Thutmose applying delicate black kohl pigment to the eye of the iconic blue-crowned bust."
            },`;

const extraBeat16 = `
            {
              bgType: "hittite_invasion_plain",
              characterPose: "hittite_chariots_charging",
              expression: "shocked",
              narration: "The strategic fortress city of Qadesh fell without a single Egyptian relief column sent to break the siege.",
              visual: "Smoking ruins of a stone fortress with fallen Egyptian banners trampled under bronze chariot wheels."
            },`;

const extraBeat17 = `
            {
              bgType: "plague_palace_chambers",
              characterPose: "weeping_over_burial_bier",
              expression: "scared",
              narration: "The high desert sun offered no protection against microscopic death. The city became a silent tomb.",
              visual: "A lone vulture circling high in the pale desert sky above the quiet white rooftops of Amarna."
            },`;

const extraBeat20 = `
            {
              bgType: "royal_wadi_tomb",
              characterPose: "sealing_desert_tomb",
              expression: "deadpan",
              narration: "No public mourning echoed through the streets. The priests of Thebes were already boarding their warships.",
              visual: "War galleys on the Nile loaded with armed spearmen flying the ancient banners of falcon Horus."
            },`;

const extraBeat22 = `
            {
              bgType: "demolition_of_amarna",
              characterPose: "talatat_used_as_rubble",
              expression: "determined",
              narration: "It was the largest systematic demolition campaign in the three-thousand-year chronicle of the pharaohs.",
              visual: "Colossal dust clouds rising as the magnificent Great Palace of Akhenaten is pulled down by ropes."
            },`;

const extraBeat24 = `
            {
              bgType: "archaeological_resurrection",
              characterPose: "world_remembering_akhenaten",
              expression: "awe_wonder",
              narration: "His revolutionary vision of light outlasted the bronze spears and stone temples of all who tried to destroy him.",
              visual: "The golden sunset illuminating the modern Pyramids of Giza and the enduring sands of Egypt."
            },`;

code = code.replace("characterPose: \"pharaoh_watching_priests\",", extraBeat1 + "\n            characterPose: \"pharaoh_watching_priests\",");
code = code.replace("characterPose: \"pharaoh_nefertiti_blessed\",", extraBeat4 + "\n            characterPose: \"pharaoh_nefertiti_blessed\",");
code = code.replace("characterPose: \"shattering_granite_statues\",", extraBeat5 + "\n            characterPose: \"shattering_granite_statues\",");
code = code.replace("characterPose: \"white_city_shining\",", extraBeat8 + "\n            characterPose: \"white_city_shining\",");
code = code.replace("characterPose: \"citizens_prostrating_sand\",", extraBeat10 + "\n            characterPose: \"citizens_prostrating_sand\",");
code = code.replace("characterPose: \"sole_prophet_mandate\",", extraBeat11 + "\n            characterPose: \"sole_prophet_mandate\",");
code = code.replace("characterPose: \"smiting_foreign_captives\",", extraBeat12 + "\n            characterPose: \"smiting_foreign_captives\",");
code = code.replace("characterPose: \"generals_muttering_treason\",", extraBeat16 + "\n            characterPose: \"generals_muttering_treason\",");
code = code.replace("characterPose: \"silent_desert_shadows\",", extraBeat17 + "\n            characterPose: \"silent_desert_shadows\",");
code = code.replace("characterPose: \"the_vengeance_awakens\",", extraBeat20 + "\n            characterPose: \"the_vengeance_awakens\",");
code = code.replace("characterPose: \"talatat_used_as_rubble\",", extraBeat22 + "\n            characterPose: \"talatat_used_as_rubble\",");
code = code.replace("characterPose: \"world_remembering_akhenaten\",", extraBeat24 + "\n            characterPose: \"world_remembering_akhenaten\",");

fs.writeFileSync(targetPath, code, 'utf8');
console.log('✅ Added 12 dramatic beats: Total now 108 visual beats!');
