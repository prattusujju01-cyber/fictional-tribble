const fs = require('fs');
const path = require('path');
const { ARCHETYPES, generateLuxuryHTML } = require('./brand_engine.cjs');

const GITHUB_TOKEN = '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';
const REPO = 'prathamgowda194-pixel/asura-system';

async function api(endpoint, method = 'GET', body = null) {
  const opts = {
    method,
    headers: {
      'Authorization': `Bearer ${GITHUB_TOKEN}`,
      'User-Agent': 'ASURA-Deployer',
      'Accept': 'application/vnd.github.v3+json'
    }
  };
  if (body) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(`https://api.github.com/repos/${REPO}${endpoint}`, opts);
  return await res.json();
}

async function run() {
  console.log('⚡ COMMITTING ZERO-404 SYSTEM & HYDERABAD REAL ESTATE PROTOTYPE...');

  const hyderabadLead = {
    name: "Hyderabad Real Estate",
    niche: "Luxury Real Estate & Villa Developers",
    city: "Hyderabad, Telangana",
    address: "Road No. 36, Jubilee Hills, Hyderabad 500033",
    phone: "+91 73375 26868",
    cleanPhone: "7337526868",
    rating: "4.7",
    reviews: "53",
    slug: "hyderabad-real-estate-hyderabad"
  };

  // Find The Imperial Citadel archetype (Royal Burgundy)
  const citadelArch = ARCHETYPES.find(a => a.id === "imperial-citadel") || ARCHETYPES[2];
  const hyderabadHtml = generateLuxuryHTML(hyderabadLead, citadelArch);

  // Write locally
  const localProtoDir = path.join(__dirname, 'projects', hyderabadLead.slug);
  if (!fs.existsSync(localProtoDir)) fs.mkdirSync(localProtoDir, { recursive: true });
  fs.writeFileSync(path.join(localProtoDir, 'index.html'), hyderabadHtml, 'utf8');

  // Create GitHub blobs
  const hydBlob = await api('/git/blobs', 'POST', {
    content: Buffer.from(hyderabadHtml, 'utf8').toString('base64'),
    encoding: 'base64'
  });

  const serveProjectContent = fs.readFileSync('C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system\\api\\serve_project.js', 'utf8');
  const serveBlob = await api('/git/blobs', 'POST', {
    content: Buffer.from(serveProjectContent, 'utf8').toString('base64'),
    encoding: 'base64'
  });

  const brandEngineContent = fs.readFileSync('C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system\\brand_engine.cjs', 'utf8');
  const brandBlob = await api('/git/blobs', 'POST', {
    content: Buffer.from(brandEngineContent, 'utf8').toString('base64'),
    encoding: 'base64'
  });

  // Update hunter_leads.json locally and create blob
  const leadsPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system\\data\\hunter_leads.json';
  let leads = [];
  try { leads = JSON.parse(fs.readFileSync(leadsPath, 'utf8')); } catch (e) {}
  // Add or update hyderabad
  leads = leads.filter(l => l.slug !== hyderabadLead.slug);
  leads.unshift({
    ...hyderabadLead,
    id: `ind_lead_${hyderabadLead.slug}`,
    hasWebsite: false,
    prototypeUrl: `https://asura-system.vercel.app/projects/${hyderabadLead.slug}/index.html`,
    vercelUrl: `https://asura-system.vercel.app/projects/${hyderabadLead.slug}/index.html`,
    status: "PROTOTYPE_DEPLOYED",
    archetype: "The Imperial Citadel (Royal Burgundy & Regal Amber)"
  });
  fs.writeFileSync(leadsPath, JSON.stringify(leads, null, 2), 'utf8');

  const leadsBlob = await api('/git/blobs', 'POST', {
    content: Buffer.from(JSON.stringify(leads, null, 2), 'utf8').toString('base64'),
    encoding: 'base64'
  });

  // Assemble atomic tree
  const treeEntries = [
    { path: `projects/${hyderabadLead.slug}/index.html`, mode: '100644', type: 'blob', sha: hydBlob.sha },
    { path: `prototypes/${hyderabadLead.slug}/index.html`, mode: '100644', type: 'blob', sha: hydBlob.sha },
    { path: 'api/serve_project.js', mode: '100644', type: 'blob', sha: serveBlob.sha },
    { path: 'brand_engine.cjs', mode: '100644', type: 'blob', sha: brandBlob.sha },
    { path: 'data/hunter_leads.json', mode: '100644', type: 'blob', sha: leadsBlob.sha }
  ];

  const ref = await api('/git/ref/heads/main');
  const parentSha = ref.object.sha;
  const parentCommit = await api(`/git/commits/${parentSha}`);

  const newTree = await api('/git/trees', 'POST', {
    base_tree: parentCommit.tree.sha,
    tree: treeEntries
  });

  const newCommit = await api('/git/commits', 'POST', {
    message: 'feat: zero-404 fallback engine, verified image URLs, and Hyderabad Real Estate luxury prototype',
    tree: newTree.sha,
    parents: [parentSha]
  });

  await api('/git/refs/heads/main', 'PATCH', {
    sha: newCommit.sha,
    force: false
  });

  console.log(`🎉 SUCCESS! Deployed all fixes in commit: ${newCommit.sha.slice(0, 7)}`);
}

run().catch(console.error);
