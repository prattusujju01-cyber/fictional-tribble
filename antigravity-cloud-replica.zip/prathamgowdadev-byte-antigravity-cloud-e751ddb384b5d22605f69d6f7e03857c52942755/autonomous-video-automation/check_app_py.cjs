const fs = require('fs');
const path = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system\\app.py';
const content = fs.readFileSync(path, 'utf8');
const lines = content.split('\n');
console.log('Total lines in app.py:', lines.length);

lines.forEach((line, idx) => {
  if (line.includes('f"""') || line.includes("f'''")) {
    console.log(`Line ${idx + 1}: ${line.trim()}`);
  }
});
