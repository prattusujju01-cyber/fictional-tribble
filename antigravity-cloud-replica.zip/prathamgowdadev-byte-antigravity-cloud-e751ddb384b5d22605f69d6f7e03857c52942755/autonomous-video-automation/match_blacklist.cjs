const fs = require('fs');
const path = require('path');

const token = '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';
const userList = [
  'Bridge property consultants',
  'All smiles dental clinic',
  'S9 Luxury Hair studio',
  'Hyderabad Real Estate',
  'Byob restaurant',
  'Architectural Exports insion west Mumbai',
  'Lee Space Interior Design',
  'Taaam Fine dining private limited',
  'Indus dental clinic',
  'Dev interior design work inLgb Nagar',
  'Sri prathyangiridevi real estate',
  'Lawyer advocates at 1000/ person',
  'India sotheby\'s international reality',
  'Mr&mrs Detailing studio',
  'Ravi construction in mohali',
  'S K Sahil civil contractor in mapusa goa',
  'Eternal fitness centre',
  'Contractor for bathroom',
  'Rahul real estate vijaynagar indore',
  'Hair treatment in pune',
  'If they wont we will call',
  '22 photos of naik real estate in santa cruz goa',
  'Building construction qamsham infra developers',
  'Interior designer vendors in ahemadabadh'
];

async function main() {
  const res = await fetch('https://api.github.com/repos/prathamgowda194-pixel/asura-system/contents/projects', {
    headers: { 'Authorization': 'Bearer ' + token, 'User-Agent': 'ASURA', 'Accept': 'application/vnd.github.v3+json' }
  });
  const items = await res.json();
  const slugs = items.map(i => i.name);
  console.log('Total GitHub project folders:', slugs.length);

  const leadsFile = path.join('C:/Users/WINDOWS/.gemini/antigravity/scratch/asura-system/data/hunter_leads.json');
  const leads = JSON.parse(fs.readFileSync(leadsFile, 'utf8'));
  console.log('Total leads in hunter_leads.json:', leads.length);

  const localProjectsDir = path.join('C:/Users/WINDOWS/.gemini/antigravity/scratch/asura-system/projects');
  const localDirs = fs.readdirSync(localProjectsDir);
  console.log('Total local project dirs:', localDirs.length);

  const matchedSlugs = new Set();
  const matchedLeads = [];

  userList.forEach(biz => {
    const cleanBiz = biz.toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
    const words = cleanBiz.split(' ').filter(w => w.length > 2);
    
    // Check in GitHub slugs
    const mSlugs = slugs.filter(s => {
      const sWords = s.split('-');
      const score = words.filter(w => sWords.some(sw => sw.includes(w) || w.includes(sw))).length;
      return score >= 2 || (words.length === 1 && s.includes(words[0]));
    });

    // Check in leads
    const mLeads = leads.filter(l => {
      const lName = (l.name || '').toLowerCase();
      const lSlug = (l.slug || '').toLowerCase();
      const score = words.filter(w => lName.includes(w) || lSlug.includes(w)).length;
      return score >= 2 || words.some(w => lSlug.includes(w));
    });

    console.log(`\n🔍 Search for: "${biz}"`);
    console.log(`   GitHub Slugs: ${mSlugs.join(', ') || 'None'}`);
    console.log(`   Lead Names: ${mLeads.map(l => l.name + ' (' + l.slug + ')').join(' | ') || 'None'}`);

    mSlugs.forEach(s => matchedSlugs.add(s));
    mLeads.forEach(l => {
      if (l.slug) matchedSlugs.add(l.slug);
      matchedLeads.push(l);
    });
  });

  console.log('\n======================================================');
  console.log('TOTAL DISTINCT SLUGS TO DELETE & BLACKLIST:', matchedSlugs.size);
  console.log(Array.from(matchedSlugs).sort());
  console.log('======================================================');
}

main().catch(console.error);
