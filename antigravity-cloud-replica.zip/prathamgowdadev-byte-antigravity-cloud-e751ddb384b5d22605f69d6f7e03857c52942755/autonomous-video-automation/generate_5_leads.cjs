const fs = require('fs');
const path = require('path');
const { 
  generatePrototypeWithGemini, 
  pushPrototypeToGitHub, 
  broadcastLeadCard,
  saveLead
} = require('./hunter_engine.cjs');

const LEADS = [
  {
    id: `ind_lead_${Date.now()}_101`,
    name: "Bridge Property Consultants",
    niche: "Luxury Real Estate & Villa Developers",
    city: "Mumbai, Maharashtra",
    phone: "+91 93202 93840",
    cleanPhone: "9320293840",
    address: "Below Flyover, Sanyas Ashram Chowk, Vile Parle West, Mumbai, Maharashtra 400056",
    rating: "4.9",
    reviews: "129",
    hasWebsite: false
  },
  {
    id: `ind_lead_${Date.now()}_102`,
    name: "Bhoomiputra Real Estate Developers",
    niche: "Luxury Real Estate & Land Promoters",
    city: "Bangalore, Karnataka",
    phone: "+91 63632 73458",
    cleanPhone: "6363273458",
    address: "Hootagalli & Nagadevanahalli, Bangalore, Karnataka 560060",
    rating: "4.8",
    reviews: "145",
    hasWebsite: false
  },
  {
    id: `ind_lead_${Date.now()}_103`,
    name: "All Smiles Dental Clinic",
    niche: "Dental Clinic & Implantology Center",
    city: "Bangalore, Karnataka",
    phone: "+91 79751 92509",
    cleanPhone: "7975192509",
    address: "100 Feet Road, Indiranagar, Bangalore, Karnataka 560038",
    rating: "4.9",
    reviews: "184",
    hasWebsite: false
  },
  {
    id: `ind_lead_${Date.now()}_104`,
    name: "Impact Fitness Center",
    niche: "Premium Fitness & Crossfit Studio",
    city: "Bangalore, Karnataka",
    phone: "+91 87920 38282",
    cleanPhone: "8792038282",
    address: "Electronics City Phase 1, Bangalore, Karnataka 560100",
    rating: "4.8",
    reviews: "96",
    hasWebsite: false
  },
  {
    id: `ind_lead_${Date.now()}_105`,
    name: "S M Corporation Interiors",
    niche: "Interior Architecture & Modular Living",
    city: "Bangalore, Karnataka",
    phone: "+91 99808 15604",
    cleanPhone: "9980815604",
    address: "27th Main Rd, HSR Layout Sector 2, Bangalore, Karnataka 560102",
    rating: "4.8",
    reviews: "72",
    hasWebsite: false
  }
];

function generateSlug(name, city) {
  const combined = `${name} ${city.split(',')[0]}`;
  let slug = combined
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
  if (slug.length > 38) slug = slug.substring(0, 38).replace(/-[^-]*$/, '');
  return slug || 'indian-client';
}

function persistLead(lead) {
  const file = path.join(__dirname, 'data', 'hunter_leads.json');
  let list = [];
  try {
    if (fs.existsSync(file)) {
      list = JSON.parse(fs.readFileSync(file, 'utf8'));
    }
  } catch (e) {}
  const idx = list.findIndex(l => l.cleanPhone === lead.cleanPhone || l.slug === lead.slug);
  if (idx >= 0) {
    list[idx] = { ...list[idx], ...lead };
  } else {
    list.unshift(lead);
  }
  fs.writeFileSync(file, JSON.stringify(list, null, 2), 'utf8');
}

async function run() {
  console.log(`⚡ GENERATING & DEPLOYING 5 BESPOKE INDIAN PROTOTYPES TO VERCEL...`);

  for (let i = 0; i < LEADS.length; i++) {
    const lead = LEADS[i];
    console.log(`\n━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`[${i + 1}/5] Processing: ${lead.name} (${lead.city})`);
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);

    const slug = generateSlug(lead.name, lead.city);
    lead.slug = slug;
    lead.createdAt = new Date().toISOString();

    // 1. Generate bespoke Gemini prototype
    console.log(`Synthesizing Gemini 3.6 Flash prototype for ${lead.name}...`);
    const html = await generatePrototypeWithGemini(lead.name, lead.niche, lead.city, lead.phone);

    // 2. Deploy to GitHub & Vercel
    console.log(`Deploying to GitHub repository...`);
    const vercelUrl = await pushPrototypeToGitHub(slug, html);

    lead.prototypeUrl = vercelUrl;
    lead.vercelUrl = vercelUrl;
    lead.status = "PROTOTYPE_DEPLOYED";

    // 3. Save to database
    persistLead(lead);

    // 4. Dispatch alert card to Telegram
    console.log(`Broadcasting lead card to Telegram...`);
    await broadcastLeadCard(lead, vercelUrl);

    console.log(`✅ [SUCCESS] Deployed & Dispatched: ${lead.name}`);
    console.log(`   Live URL: ${vercelUrl}`);

    // Small delay between calls
    await new Promise(r => setTimeout(r, 4000));
  }

  console.log(`\n🎉 ALL 5 GENUINE INDIAN LEADS PROCESSED & DISPATCHED TO TELEGRAM!`);
}

run().catch(console.error);
