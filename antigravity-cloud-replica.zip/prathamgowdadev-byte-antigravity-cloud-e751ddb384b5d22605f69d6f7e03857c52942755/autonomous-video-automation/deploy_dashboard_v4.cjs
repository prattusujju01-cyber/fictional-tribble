const fs = require('fs');
const path = require('path');

const targetPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\dashboard\\hermes-story-dashboard.html';

const html = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Hermes 2D Studio // Zenn Anti-AI-Slop Pipeline & Voice Studio</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@700&family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg-void: #090D1A;
      --bg-card: #0F1629;
      --bg-card-hover: #17223D;
      --border-subtle: #1E2B4D;
      --zenn-orange: #FF7A00;
      --zenn-gold: #F59E0B;
      --zenn-blue: #38BDF8;
      --zenn-green: #10B981;
      --zenn-purple: #A855F7;
      --text-main: #F1F5F9;
      --text-muted: #94A3B8;
      --text-dim: #64748B;
    }

    * { box-sizing: border-box; margin: 0; padding: 0; }

    body {
      background: var(--bg-void);
      color: var(--text-main);
      font-family: 'Plus Jakarta Sans', -apple-system, sans-serif;
      min-height: 100vh;
      overflow-x: hidden;
      background-image: 
        radial-gradient(circle at 10% 15%, rgba(255, 122, 0, 0.08) 0%, transparent 40%),
        radial-gradient(circle at 90% 85%, rgba(56, 189, 248, 0.06) 0%, transparent 45%);
    }

    .container {
      max-width: 1600px;
      margin: 0 auto;
      padding: 24px 28px 80px 28px;
    }

    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding-bottom: 22px;
      border-bottom: 1px solid var(--border-subtle);
      margin-bottom: 24px;
      flex-wrap: wrap;
      gap: 16px;
    }

    .brand-group {
      display: flex;
      align-items: center;
      gap: 16px;
    }

    .logo-badge {
      width: 52px;
      height: 52px;
      background: linear-gradient(135deg, #FF7A00, #EA580C);
      border-radius: 14px;
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 26px;
      box-shadow: 0 0 24px rgba(255, 122, 0, 0.3);
      border: 1px solid rgba(255, 255, 255, 0.2);
    }

    .brand-meta h1 {
      font-family: 'Cinzel', serif;
      font-size: 22px;
      font-weight: 700;
      letter-spacing: 0.5px;
      background: linear-gradient(90deg, #FFFFFF, #F59E0B);
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .brand-meta p {
      font-size: 13px;
      color: var(--text-muted);
      display: flex;
      align-items: center;
      gap: 8px;
      margin-top: 2px;
      flex-wrap: wrap;
    }

    .badge-tag {
      padding: 3px 8px;
      border-radius: 6px;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      font-weight: 600;
    }
    .badge-vector { background: rgba(16, 185, 129, 0.15); color: var(--zenn-green); border: 1px solid rgba(16, 185, 129, 0.3); }
    .badge-rapid { background: rgba(255, 122, 0, 0.15); color: var(--zenn-orange); border: 1px solid rgba(255, 122, 0, 0.3); }
    .badge-static { background: rgba(56, 189, 248, 0.15); color: var(--zenn-blue); border: 1px solid rgba(56, 189, 248, 0.3); }
    .badge-voice { background: rgba(168, 85, 247, 0.15); color: var(--zenn-purple); border: 1px solid rgba(168, 85, 247, 0.3); }

    .header-actions {
      display: flex;
      gap: 12px;
    }

    .btn {
      padding: 10px 18px;
      border-radius: 10px;
      font-weight: 600;
      font-size: 13px;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 8px;
      transition: all 0.2s ease;
      border: none;
    }
    .btn-primary {
      background: linear-gradient(135deg, #FF7A00, #EA580C);
      color: #FFF;
      box-shadow: 0 4px 14px rgba(255, 122, 0, 0.3);
    }
    .btn-primary:hover {
      transform: translateY(-1px);
      box-shadow: 0 6px 20px rgba(255, 122, 0, 0.45);
    }
    .btn-secondary {
      background: var(--bg-card);
      border: 1px solid var(--border-subtle);
      color: var(--text-main);
    }
    .btn-secondary:hover {
      background: var(--bg-card-hover);
      border-color: #2E3E6B;
    }

    /* Voiceover Switcher Section */
    .voice-studio-card {
      background: var(--bg-card);
      border: 1px solid var(--border-subtle);
      border-radius: 18px;
      padding: 22px;
      margin-bottom: 24px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
    }

    .voice-studio-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 16px;
      flex-wrap: wrap;
      gap: 12px;
    }

    .voice-title-group {
      display: flex;
      align-items: center;
      gap: 12px;
    }
    .voice-title-group h3 {
      font-size: 16px;
      font-weight: 700;
      letter-spacing: 0.5px;
      color: #FFF;
    }

    .voice-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 14px;
    }

    .voice-card {
      background: #111827;
      border: 1px solid var(--border-subtle);
      border-radius: 12px;
      padding: 14px 16px;
      cursor: pointer;
      transition: all 0.2s ease;
      position: relative;
    }
    .voice-card:hover {
      border-color: var(--zenn-purple);
      background: #161F33;
    }
    .voice-card.selected {
      border-color: var(--zenn-purple);
      background: rgba(168, 85, 247, 0.08);
      box-shadow: 0 0 16px rgba(168, 85, 247, 0.2);
    }

    .voice-card-top {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 6px;
    }
    .voice-name {
      font-weight: 700;
      font-size: 14px;
      color: #FFF;
    }
    .voice-provider {
      font-size: 10px;
      font-family: 'JetBrains Mono', monospace;
      padding: 2px 6px;
      border-radius: 4px;
      font-weight: 600;
    }
    .prov-elevenlabs { background: rgba(168, 85, 247, 0.2); color: #C084FC; }
    .prov-kokoro { background: rgba(56, 189, 248, 0.2); color: #38BDF8; }
    .prov-natural { background: rgba(16, 185, 129, 0.2); color: #34D399; }

    .voice-style-text {
      font-size: 12px;
      color: var(--text-muted);
      line-height: 1.4;
      margin-bottom: 10px;
    }

    .voice-card-actions {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .btn-sample {
      background: #1F2937;
      border: 1px solid #374151;
      color: #E5E7EB;
      padding: 4px 10px;
      border-radius: 6px;
      font-size: 11px;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 5px;
    }
    .btn-sample:hover {
      background: #374151;
      color: #FFF;
    }
    .selected-tag {
      font-size: 11px;
      font-weight: 700;
      color: var(--zenn-purple);
      display: none;
    }
    .voice-card.selected .selected-tag {
      display: inline;
    }

    /* Main Stage: Cinema Player & HUD */
    .hero-grid {
      display: grid;
      grid-template-columns: 2.3fr 1fr;
      gap: 24px;
      margin-bottom: 36px;
    }

    @media (max-width: 1180px) {
      .hero-grid { grid-template-columns: 1fr; }
    }

    .player-card {
      background: var(--bg-card);
      border: 1px solid var(--border-subtle);
      border-radius: 20px;
      padding: 20px;
      box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
    }

    /* 16:9 Canvas (Zero on-screen subtitles, zero zoom drift) */
    .cinema-screen {
      position: relative;
      width: 100%;
      aspect-ratio: 16 / 9;
      background: #000;
      border-radius: 14px;
      overflow: hidden;
      box-shadow: inset 0 0 40px rgba(0, 0, 0, 0.9);
      border: 1px solid #1E293B;
    }

    #videoCanvas {
      width: 100%;
      height: 100%;
      display: block;
      /* Zero zoom drift CSS */
      object-fit: contain;
    }

    .beat-watermark {
      position: absolute;
      top: 14px;
      left: 14px;
      background: rgba(9, 13, 26, 0.85);
      backdrop-filter: blur(8px);
      padding: 4px 10px;
      border-radius: 6px;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      font-weight: 600;
      color: var(--zenn-orange);
      border: 1px solid rgba(255, 122, 0, 0.3);
      letter-spacing: 0.5px;
      pointer-events: none;
    }

    .static-indicator {
      position: absolute;
      top: 14px;
      right: 14px;
      background: rgba(9, 13, 26, 0.85);
      backdrop-filter: blur(8px);
      padding: 4px 10px;
      border-radius: 6px;
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      font-weight: 600;
      color: var(--zenn-blue);
      border: 1px solid rgba(56, 189, 248, 0.3);
      pointer-events: none;
    }

    .player-controls {
      margin-top: 16px;
      display: flex;
      flex-direction: column;
      gap: 12px;
    }

    .scrub-row {
      display: flex;
      align-items: center;
      gap: 14px;
    }

    .progress-bar-container {
      flex: 1;
      height: 8px;
      background: #1E293B;
      border-radius: 4px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }

    .progress-bar-fill {
      height: 100%;
      width: 0%;
      background: linear-gradient(90deg, #FF7A00, #F59E0B);
      border-radius: 4px;
      transition: width 0.1s linear;
    }

    .time-readout {
      font-family: 'JetBrains Mono', monospace;
      font-size: 12px;
      color: var(--text-muted);
      min-width: 100px;
    }

    .action-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      flex-wrap: wrap;
      gap: 12px;
    }

    .control-buttons-left {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .btn-circle {
      width: 40px;
      height: 40px;
      border-radius: 50%;
      background: var(--bg-card-hover);
      border: 1px solid var(--border-subtle);
      color: var(--text-main);
      display: flex;
      align-items: center;
      justify-content: center;
      font-size: 16px;
      cursor: pointer;
      transition: all 0.2s ease;
    }
    .btn-circle:hover {
      background: var(--zenn-orange);
      color: #FFF;
      border-color: var(--zenn-orange);
    }
    .btn-circle.play-btn {
      width: 46px;
      height: 46px;
      background: linear-gradient(135deg, #FF7A00, #EA580C);
      color: #FFF;
      font-size: 20px;
    }

    .pill-selector {
      display: flex;
      background: #131A30;
      border-radius: 8px;
      padding: 3px;
      border: 1px solid var(--border-subtle);
    }
    .pill-opt {
      padding: 4px 10px;
      font-size: 11px;
      font-weight: 600;
      color: var(--text-muted);
      border-radius: 6px;
      cursor: pointer;
    }
    .pill-opt.active {
      background: var(--zenn-orange);
      color: #FFF;
    }

    /* Right Sidebar HUD */
    .sidebar-panel {
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    .hud-box {
      background: var(--bg-card);
      border: 1px solid var(--border-subtle);
      border-radius: 16px;
      padding: 20px;
    }

    .hud-title {
      font-size: 13px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 1px;
      color: var(--text-muted);
      margin-bottom: 14px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }

    .active-beat-details {
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .gag-label {
      font-size: 11px;
      font-weight: 600;
      color: var(--text-dim);
      text-transform: uppercase;
      letter-spacing: 0.5px;
    }

    .gag-box {
      background: #131A30;
      border-left: 3px solid var(--zenn-orange);
      padding: 10px 14px;
      border-radius: 6px;
      font-size: 13px;
      color: #F8FAFC;
      line-height: 1.5;
    }

    .narration-box {
      background: #131A30;
      border-left: 3px solid var(--zenn-gold);
      padding: 10px 14px;
      border-radius: 6px;
      font-size: 13px;
      color: #FDE047;
      line-height: 1.5;
      font-style: italic;
    }

    .ambient-card {
      background: linear-gradient(135deg, rgba(255, 122, 0, 0.08), rgba(245, 158, 11, 0.04));
      border: 1px solid rgba(255, 122, 0, 0.2);
      border-radius: 14px;
      padding: 16px;
      display: flex;
      align-items: center;
      justify-content: space-between;
    }
    .ambient-info h4 { font-size: 13px; font-weight: 700; color: #FFF; margin-bottom: 2px; }
    .ambient-info p { font-size: 11px; color: var(--text-muted); }

    .switch {
      position: relative;
      display: inline-block;
      width: 44px;
      height: 24px;
    }
    .switch input { opacity: 0; width: 0; height: 0; }
    .slider {
      position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0;
      background-color: #1E293B;
      transition: .3s;
      border-radius: 24px;
      border: 1px solid var(--border-subtle);
    }
    .slider:before {
      position: absolute; content: ""; height: 16px; width: 16px; left: 3px; bottom: 3px;
      background-color: white;
      transition: .3s;
      border-radius: 50%;
    }
    input:checked + .slider { background-color: var(--zenn-orange); }
    input:checked + .slider:before { transform: translateX(20px); }

    /* Storyboard Grid */
    .section-title {
      font-size: 18px;
      font-weight: 700;
      color: #FFF;
      margin: 36px 0 16px 0;
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .storyboard-scroll {
      display: grid;
      grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
      gap: 16px;
      max-height: 480px;
      overflow-y: auto;
      padding-right: 8px;
    }

    .beat-card {
      background: var(--bg-card);
      border: 1px solid var(--border-subtle);
      border-radius: 12px;
      overflow: hidden;
      cursor: pointer;
      transition: all 0.2s ease;
    }
    .beat-card:hover {
      border-color: var(--zenn-orange);
      transform: translateY(-2px);
    }
    .beat-card.active-beat {
      border-color: var(--zenn-orange);
      box-shadow: 0 0 16px rgba(255, 122, 0, 0.4);
    }

    .beat-thumb-wrap {
      position: relative;
      aspect-ratio: 16 / 9;
      background: #000;
      overflow: hidden;
    }
    .beat-thumb-img {
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
    .beat-badge-corner {
      position: absolute;
      top: 6px;
      left: 6px;
      background: rgba(0, 0, 0, 0.8);
      color: #FFF;
      font-family: 'JetBrains Mono', monospace;
      font-size: 10px;
      font-weight: 700;
      padding: 2px 6px;
      border-radius: 4px;
    }
    .beat-timing-corner {
      position: absolute;
      bottom: 6px;
      right: 6px;
      background: rgba(0, 0, 0, 0.8);
      color: var(--zenn-orange);
      font-family: 'JetBrains Mono', monospace;
      font-size: 10px;
      padding: 2px 6px;
      border-radius: 4px;
    }

    .beat-card-body {
      padding: 10px;
    }
    .beat-gag-text {
      font-size: 12px;
      font-weight: 600;
      color: #FFF;
      line-height: 1.3;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .beat-narrative-sub {
      font-size: 11px;
      color: var(--text-dim);
      margin-top: 4px;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }

    /* Screenplay View */
    .screenplay-panel {
      background: var(--bg-card);
      border: 1px solid var(--border-subtle);
      border-radius: 16px;
      padding: 20px;
      max-height: 380px;
      overflow-y: auto;
      margin-bottom: 40px;
    }
    .screenplay-beat-row {
      display: flex;
      align-items: flex-start;
      gap: 14px;
      padding: 10px 0;
      border-bottom: 1px solid rgba(30, 43, 77, 0.6);
      font-size: 13px;
      line-height: 1.6;
    }
    .screenplay-beat-time {
      font-family: 'JetBrains Mono', monospace;
      font-size: 11px;
      color: var(--zenn-orange);
      min-width: 65px;
      padding-top: 2px;
    }
    .screenplay-beat-gag {
      color: var(--zenn-gold);
      font-weight: 600;
      min-width: 220px;
    }
    .screenplay-beat-voice {
      color: #CBD5E1;
      flex: 1;
    }

    #nativeAudio { display: none; }
  </style>
</head>
<body>
  <audio id="nativeAudio" preload="auto"></audio>

  <div class="container">
    <header>
      <div class="brand-group">
        <div class="logo-badge">🔥</div>
        <div class="brand-meta">
          <h1>HERMES 2D STUDIO // ZENN ENGINE</h1>
          <p>
            Channel: <strong>Zenn Anthropology</strong> 
            <span class="badge-tag badge-vector">100% Hand-Drawn 2D Comic</span>
            <span class="badge-tag badge-rapid">112+ Dedicated Scene Cuts</span>
            <span class="badge-tag badge-static">Zero Zoom Drift // Instant Static Cuts</span>
            <span class="badge-tag badge-voice">ElevenLabs Voice Switcher</span>
          </p>
        </div>
      </div>
      <div class="header-actions">
        <button class="btn btn-secondary" onclick="exportPackage()">
          📦 Export Video Assets
        </button>
        <button class="btn btn-primary" onclick="togglePlay()">
          ▶ Play Master Video
        </button>
      </div>
    </header>

    <!-- VOICE STUDIO SWITCHER BAR -->
    <div class="voice-studio-card">
      <div class="voice-studio-header">
        <div class="voice-title-group">
          <span style="font-size: 22px;">🎙️</span>
          <div>
            <h3>Voiceover Switcher Studio (ElevenLabs & GitHub Alternatives)</h3>
            <p style="font-size: 12px; color: var(--text-muted); margin-top: 2px;">
              Select your preferred voice persona for the video essay narration. Test voice preview samples below.
            </p>
          </div>
        </div>
        <div style="display: flex; gap: 8px; align-items: center;">
          <span style="font-size: 12px; color: var(--text-dim);">Active Voice:</span>
          <span class="badge-tag badge-voice" id="activeVoiceBadge">Marcus (Anthropologist)</span>
        </div>
      </div>

      <div class="voice-grid" id="voiceGrid">
        <!-- Voice Card: ElevenLabs Marcus -->
        <div class="voice-card selected" onclick="selectVoice('elevenlabs_marcus', this)">
          <div class="voice-card-top">
            <span class="voice-name">Marcus (Anthropologist)</span>
            <span class="voice-provider prov-elevenlabs">ElevenLabs</span>
          </div>
          <div class="voice-style-text">Authoritative, natural conversational intellectual. Perfect for Zenn evolutionary essays.</div>
          <div class="voice-card-actions">
            <button class="btn-sample" onclick="playVoiceSample('Tonight, when you flip a light switch, you do not think twice about it.', 'marcus', event)">🔊 Test Sample</button>
            <span class="selected-tag">✓ ACTIVE</span>
          </div>
        </div>

        <!-- Voice Card: ElevenLabs Adam -->
        <div class="voice-card" onclick="selectVoice('elevenlabs_adam', this)">
          <div class="voice-card-top">
            <span class="voice-name">Adam (Deep Narrator)</span>
            <span class="voice-provider prov-elevenlabs">ElevenLabs</span>
          </div>
          <div class="voice-style-text">Deep, calm, resonant documentary baritone with deliberate human pacing.</div>
          <div class="voice-card-actions">
            <button class="btn-sample" onclick="playVoiceSample('For over three hundred thousand years, darkness was complete and terrifying.', 'adam', event)">🔊 Test Sample</button>
            <span class="selected-tag">✓ ACTIVE</span>
          </div>
        </div>

        <!-- Voice Card: ElevenLabs Antoni -->
        <div class="voice-card" onclick="selectVoice('elevenlabs_antoni', this)">
          <div class="voice-card-top">
            <span class="voice-name">Antoni (Expressive Storyteller)</span>
            <span class="voice-provider prov-elevenlabs">ElevenLabs</span>
          </div>
          <div class="voice-style-text">Dynamic, animated storytelling with emotional inflection and rising tension.</div>
          <div class="voice-card-actions">
            <button class="btn-sample" onclick="playVoiceSample('If an early human was caught on open ground after sunset, their life was measured in minutes.', 'antoni', event)">🔊 Test Sample</button>
            <span class="selected-tag">✓ ACTIVE</span>
          </div>
        </div>

        <!-- Voice Card: ElevenLabs Brian -->
        <div class="voice-card" onclick="selectVoice('elevenlabs_brian', this)">
          <div class="voice-card-top">
            <span class="voice-name">Brian (Conversational Explainer)</span>
            <span class="voice-provider prov-elevenlabs">ElevenLabs</span>
          </div>
          <div class="voice-style-text">Witty, punchy, relatable conversational delivery. Great for modern takeaways.</div>
          <div class="voice-card-actions">
            <button class="btn-sample" onclick="playVoiceSample('You can scroll on your phone at 2 AM and completely forget darkness exists.', 'brian', event)">🔊 Test Sample</button>
            <span class="selected-tag">✓ ACTIVE</span>
          </div>
        </div>

        <!-- Voice Card: Kokoro-82M Michael -->
        <div class="voice-card" onclick="selectVoice('kokoro_michael', this)">
          <div class="voice-card-top">
            <span class="voice-name">Michael (Kokoro-82M)</span>
            <span class="voice-provider prov-kokoro">GitHub Open-Weights</span>
          </div>
          <div class="voice-style-text">#1 ranked lightweight open model. Natural breath cadence, youthful & engaging.</div>
          <div class="voice-card-actions">
            <button class="btn-sample" onclick="playVoiceSample('Fire was not just light. It was an invisible fortress wall.', 'michael', event)">🔊 Test Sample</button>
            <span class="selected-tag">✓ ACTIVE</span>
          </div>
        </div>

        <!-- Voice Card: Kokoro-82M George -->
        <div class="voice-card" onclick="selectVoice('kokoro_george', this)">
          <div class="voice-card-top">
            <span class="voice-name">George (Kokoro-82M BBC)</span>
            <span class="voice-provider prov-kokoro">GitHub Open-Weights</span>
          </div>
          <div class="voice-style-text">Sophisticated British documentary style with impeccable articulation.</div>
          <div class="voice-card-actions">
            <button class="btn-sample" onclick="playVoiceSample('The pineal gland flooded the bloodstream with natural restorative melatonin.', 'george', event)">🔊 Test Sample</button>
            <span class="selected-tag">✓ ACTIVE</span>
          </div>
        </div>

        <!-- Voice Card: Natural Christopher -->
        <div class="voice-card" onclick="selectVoice('natural_christopher', this)">
          <div class="voice-card-top">
            <span class="voice-name">Christopher Neural</span>
            <span class="voice-provider prov-natural">Natural Neural</span>
          </div>
          <div class="voice-style-text">Smooth, articulate broadcast narrator with balanced neutral timbre.</div>
          <div class="voice-card-actions">
            <button class="btn-sample" onclick="playVoiceSample('Dr. Thomas Wehr proved biphasic sleep is hardwired into human DNA.', 'christopher', event)">🔊 Test Sample</button>
            <span class="selected-tag">✓ ACTIVE</span>
          </div>
        </div>

        <!-- Voice Card: Natural Guy -->
        <div class="voice-card" onclick="selectVoice('natural_guy', this)">
          <div class="voice-card-top">
            <span class="voice-name">Guy Neural</span>
            <span class="voice-provider prov-natural">Natural Neural</span>
          </div>
          <div class="voice-style-text">Relaxed, friendly everyday storyteller with warm conversational cadence.</div>
          <div class="voice-card-actions">
            <button class="btn-sample" onclick="playVoiceSample('When you wake up at 3:14 AM, smile. Your biology is working perfectly.', 'guy', event)">🔊 Test Sample</button>
            <span class="selected-tag">✓ ACTIVE</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Main Stage: Cinema Player & HUD -->
    <div class="hero-grid">
      <div class="player-card">
        <!-- 16:9 Canvas (Zero on-screen subtitles, zero zoom drift) -->
        <div class="cinema-screen" id="cinemaScreen">
          <canvas id="videoCanvas" width="1280" height="720"></canvas>
          <div class="beat-watermark" id="beatTag">BEAT 001 // ACT 1</div>
          <div class="static-indicator">STATIC CUT // NO ZOOM</div>
        </div>
        <div class="player-controls">
          <div class="scrub-row">
            <div class="progress-bar-container" id="progressBar" onclick="seekTimeline(event)">
              <div class="progress-bar-fill" id="progressFill"></div>
            </div>
            <span class="time-readout" id="timeDisplay">0:00 / 10:00</span>
          </div>
          <div class="action-row">
            <div class="control-buttons-left">
              <button class="btn-circle" onclick="prevBeat()" title="Previous Beat">⏮</button>
              <button class="btn-circle play-btn" id="playBtn" onclick="togglePlay()" title="Play / Pause">▶</button>
              <button class="btn-circle" onclick="nextBeat()" title="Next Beat">⏭</button>
              <div class="pill-selector">
                <div class="pill-opt active" onclick="setSpeed(1.0, this)">1.0x</div>
                <div class="pill-opt" onclick="setSpeed(1.25, this)">1.25x</div>
                <div class="pill-opt" onclick="setSpeed(1.5, this)">1.5x</div>
              </div>
            </div>
            <div class="control-buttons-right">
              <button class="btn btn-secondary" onclick="readActiveBeatAloud()" style="padding: 8px 12px; font-size: 12px;">
                🗣️ Speak This Beat
              </button>
              <button class="btn btn-secondary" onclick="toggleFullscreen()" style="padding: 8px 12px; font-size: 12px;">
                ⛶ Fullscreen
              </button>
            </div>
          </div>
        </div>
      </div>

      <!-- Right: Scene HUD -->
      <div class="sidebar-panel">
        <div class="hud-box">
          <div class="hud-title">
            <span>🎬 Visual Beat HUD</span>
            <span class="badge-tag badge-vector">Hand-Drawn Comic</span>
          </div>
          <div class="active-beat-details">
            <div class="gag-label">Current Scene Illustration:</div>
            <div class="gag-box" id="hudGag">Loading visual beat...</div>
            <div class="gag-label" style="margin-top: 6px;">Voiceover Dialogue (Matches Visual):</div>
            <div class="narration-box" id="hudVoice">Loading narration cue...</div>
          </div>
        </div>

        <div class="ambient-card">
          <div class="ambient-info">
            <h4>🔥 Prehistoric Campfire & Savanna Ambience</h4>
            <p>Procedural WebAudio crackling embers & night wind</p>
          </div>
          <label class="switch">
            <input type="checkbox" id="ambientToggle" onchange="toggleCampfire(this.checked)" checked>
            <span class="slider"></span>
          </label>
        </div>

        <div class="hud-box">
          <div class="hud-title"><span>📊 Video Specifications</span></div>
          <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
            <div style="background: #0B1020; padding: 10px; border-radius: 8px; border: 1px solid var(--border-subtle);">
              <div style="font-size: 10px; color: var(--text-dim); text-transform: uppercase;">Duration</div>
              <div style="font-size: 16px; font-weight: 700; color: #FFF;" id="specDuration">10:00 Min</div>
            </div>
            <div style="background: #0B1020; padding: 10px; border-radius: 8px; border: 1px solid var(--border-subtle);">
              <div style="font-size: 10px; color: var(--text-dim); text-transform: uppercase;">Total Cuts</div>
              <div style="font-size: 16px; font-weight: 700; color: var(--zenn-orange);" id="specBeats">112+ Beats</div>
            </div>
            <div style="background: #0B1020; padding: 10px; border-radius: 8px; border: 1px solid var(--border-subtle);">
              <div style="font-size: 10px; color: var(--text-dim); text-transform: uppercase;">Camera Motion</div>
              <div style="font-size: 14px; font-weight: 700; color: var(--zenn-blue);">Zero Zoom (Static)</div>
            </div>
            <div style="background: #0B1020; padding: 10px; border-radius: 8px; border: 1px solid var(--border-subtle);">
              <div style="font-size: 10px; color: var(--text-dim); text-transform: uppercase;">Canvas Art</div>
              <div style="font-size: 14px; font-weight: 700; color: var(--zenn-green);">Zero On-Screen Caps</div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- 112-Beat Storyboard Grid -->
    <h2 class="section-title">Visual Beat Storyboard (112+ Dedicated Hand-Drawn Scenes)</h2>
    <div class="storyboard-scroll" id="storyboardGrid"></div>

    <!-- Screenplay Reader -->
    <h2 class="section-title">Master Evolutionary Screenplay & Timed Dialogue</h2>
    <div class="screenplay-panel" id="screenplayPanel"></div>
  </div>

  <script>
    let timelineData = null;
    let currentBeatIdx = 0;
    let isPlaying = false;
    let playbackSpeed = 1.0;
    let animFrame = null;
    let currentImg = new Image();
    let audioCtx = null;
    let fireNoiseNode = null;
    let selectedVoiceId = 'elevenlabs_marcus';

    async function initDashboard() {
      try {
        const tlRes = await fetch('../assets/timeline.json');
        if (tlRes.ok) {
          timelineData = await tlRes.json();
          document.getElementById('specBeats').innerText = timelineData.beats.length + ' Beats';
          document.getElementById('specDuration').innerText = (timelineData.meta.formattedDuration || '10:00') + ' Min';
        }
        
        renderStoryboard();
        renderScreenplay();
        loadBeat(0);
        initCampfire();
      } catch (err) {
        console.error('Init error:', err);
      }
    }

    function selectVoice(voiceId, el) {
      selectedVoiceId = voiceId;
      document.querySelectorAll('.voice-card').forEach(c => c.classList.remove('selected'));
      el.classList.add('selected');
      const name = el.querySelector('.voice-name').innerText;
      document.getElementById('activeVoiceBadge').innerText = name;
      console.log('Selected voice:', voiceId);
    }

    function playVoiceSample(text, persona, e) {
      if (e) e.stopPropagation();
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
        const utter = new SpeechSynthesisUtterance(text);
        const voices = window.speechSynthesis.getVoices();
        
        if (persona === 'george') {
          const uk = voices.find(v => v.lang.includes('GB') || v.name.includes('UK') || v.name.includes('George'));
          if (uk) utter.voice = uk;
          utter.pitch = 0.95;
          utter.rate = 0.95;
        } else if (persona === 'adam') {
          const male = voices.find(v => v.name.includes('David') || v.name.includes('Male') || v.name.includes('Natural'));
          if (male) utter.voice = male;
          utter.pitch = 0.85;
          utter.rate = 0.95;
        } else {
          const us = voices.find(v => v.lang.includes('US') && (v.name.includes('Guy') || v.name.includes('Natural') || v.name.includes('English')));
          if (us) utter.voice = us;
          utter.pitch = 1.0;
          utter.rate = 1.0;
        }
        window.speechSynthesis.speak(utter);
      }
    }

    function readActiveBeatAloud() {
      const beats = timelineData?.beats || [];
      const b = beats[currentBeatIdx];
      if (b && b.narration) {
        playVoiceSample(b.narration, selectedVoiceId.split('_')[1] || 'marcus');
      }
    }

    function renderStoryboard() {
      const grid = document.getElementById('storyboardGrid');
      grid.innerHTML = '';
      const beats = timelineData?.beats || [];

      beats.forEach((b, idx) => {
        const card = document.createElement('div');
        card.className = 'beat-card' + (idx === 0 ? ' active-beat' : '');
        card.id = 'beat_card_' + idx;
        card.onclick = () => { loadBeat(idx); };

        card.innerHTML = \`
          <div class="beat-thumb-wrap">
            <img class="beat-thumb-img" src="../\${b.svgPath}" alt="\${b.beatId}">
            <div class="beat-badge-corner">#\${idx + 1}</div>
            <div class="beat-timing-corner">\${formatTime(b.startSec)}</div>
          </div>
          <div class="beat-card-body">
            <div class="beat-gag-text">\${b.gag || 'Visual Cut'}</div>
            <div class="beat-narrative-sub">\${b.narration || 'Scene Beat'}</div>
          </div>
        \`;
        grid.appendChild(card);
      });
    }

    function renderScreenplay() {
      const panel = document.getElementById('screenplayPanel');
      panel.innerHTML = '';
      const beats = timelineData?.beats || [];

      beats.forEach(b => {
        const row = document.createElement('div');
        row.className = 'screenplay-beat-row';
        row.innerHTML = \`
          <span class="screenplay-beat-time">\${formatTime(b.startSec)}</span>
          <span class="screenplay-beat-gag">[ACT \${b.act}] \${b.gag}</span>
          <span class="screenplay-beat-voice">\${b.narration ? '"' + b.narration + '"' : '— (Visual Transition) —'}</span>
        \`;
        panel.appendChild(row);
      });
    }

    const canvas = document.getElementById('videoCanvas');
    const ctx = canvas.getContext('2d');

    function loadBeat(idx) {
      currentBeatIdx = idx;
      document.querySelectorAll('.beat-card').forEach((c, i) => {
        c.classList.toggle('active-beat', i === idx);
      });

      const beats = timelineData?.beats || [];
      const b = beats[idx];
      if (!b) return;

      document.getElementById('beatTag').innerText = b.beatId.toUpperCase() + ' // ACT ' + b.act;
      document.getElementById('hudGag').innerText = b.gag || 'Hand-Drawn Comic Scene';
      document.getElementById('hudVoice').innerText = b.narration || '(Visual Scene)';

      currentImg.src = '../' + b.svgPath;
      currentImg.onload = () => {
        renderFrame();
      };
    }

    // STRICT ANTI-AI-SLOP: ZERO ZOOM IN / ZOOM OUT -> CLEAN INSTANT STATIC CUT
    function renderFrame() {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      if (!currentImg.complete) return;
      // Instant static cut: perfectly framed 1280x720 canvas, zero zoom/pan distortion
      ctx.drawImage(currentImg, 0, 0, canvas.width, canvas.height);
    }

    function animationLoop() {
      if (!isPlaying) return;

      const audio = document.getElementById('nativeAudio');
      const totalDur = timelineData?.meta?.totalDurationSeconds || 600;
      const curTime = audio.currentTime || 0;

      // Find current beat based on audio currentTime
      const beats = timelineData?.beats || [];
      const matchedIdx = beats.findIndex(b => curTime >= b.startSec && curTime < b.endSec);

      if (matchedIdx !== -1 && matchedIdx !== currentBeatIdx) {
        loadBeat(matchedIdx);
      }

      const progress = Math.min(1, curTime / totalDur);
      document.getElementById('progressFill').style.width = (progress * 100) + '%';
      document.getElementById('timeDisplay').innerText = formatTime(Math.floor(curTime)) + ' / ' + formatTime(totalDur);

      renderFrame();

      if (progress >= 1 || audio.ended) {
        togglePlay();
      } else {
        animFrame = requestAnimationFrame(animationLoop);
      }
    }

    function togglePlay() {
      const audio = document.getElementById('nativeAudio');
      const btn = document.getElementById('playBtn');

      if (isPlaying) {
        isPlaying = false;
        audio.pause();
        btn.innerText = '▶';
        if (animFrame) cancelAnimationFrame(animFrame);
      } else {
        isPlaying = true;
        audio.src = '../assets/audio/narration.mp3';
        audio.play().catch(e => console.log('Autoplay:', e));
        btn.innerText = '⏸';
        animationLoop();
      }
    }

    function nextBeat() {
      const beats = timelineData?.beats || [];
      if (currentBeatIdx < beats.length - 1) {
        loadBeat(currentBeatIdx + 1);
        const audio = document.getElementById('nativeAudio');
        if (isPlaying && audio.duration) {
          audio.currentTime = beats[currentBeatIdx].startSec;
        }
      }
    }

    function prevBeat() {
      if (currentBeatIdx > 0) {
        loadBeat(currentBeatIdx - 1);
        const audio = document.getElementById('nativeAudio');
        if (isPlaying && audio.duration) {
          audio.currentTime = timelineData.beats[currentBeatIdx].startSec;
        }
      }
    }

    function setSpeed(rate, el) {
      playbackSpeed = rate;
      document.querySelectorAll('.pill-opt').forEach(p => p.classList.remove('active'));
      el.classList.add('active');
      const audio = document.getElementById('nativeAudio');
      audio.playbackRate = rate;
    }

    function seekTimeline(e) {
      const bar = document.getElementById('progressBar');
      const rect = bar.getBoundingClientRect();
      const pct = (e.clientX - rect.left) / rect.width;
      const audio = document.getElementById('nativeAudio');
      const totalDur = timelineData?.meta?.totalDurationSeconds || 600;
      const seekSec = pct * totalDur;

      if (audio.duration) {
        audio.currentTime = seekSec;
      }
      const beats = timelineData?.beats || [];
      const matchedIdx = beats.findIndex(b => seekSec >= b.startSec && seekSec < b.endSec);
      if (matchedIdx !== -1) loadBeat(matchedIdx);
    }

    function toggleFullscreen() {
      const screen = document.getElementById('cinemaScreen');
      if (!document.fullscreenElement) {
        screen.requestFullscreen().catch(err => console.log(err));
      } else {
        document.exitFullscreen();
      }
    }

    function initCampfire() {
      try {
        audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        const bufferSize = audioCtx.sampleRate * 2;
        const noiseBuffer = audioCtx.createBuffer(1, bufferSize, audioCtx.sampleRate);
        const output = noiseBuffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          output[i] = Math.random() * 2 - 1;
        }

        const whiteNoise = audioCtx.createBufferSource();
        whiteNoise.buffer = noiseBuffer;
        whiteNoise.loop = true;

        const filter = audioCtx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.value = 800;
        filter.Q.value = 3.0;

        const gainNode = audioCtx.createGain();
        gainNode.gain.value = 0.04;

        whiteNoise.connect(filter);
        filter.connect(gainNode);
        gainNode.connect(audioCtx.destination);
        whiteNoise.start(0);
        fireNoiseNode = gainNode;
      } catch (e) {
        console.log('WebAudio not allowed before user interaction');
      }
    }

    function toggleCampfire(enabled) {
      if (!audioCtx) initCampfire();
      if (audioCtx && audioCtx.state === 'suspended') audioCtx.resume();
      if (fireNoiseNode) {
        fireNoiseNode.gain.value = enabled ? 0.04 : 0.0;
      }
    }

    function formatTime(sec) {
      const m = Math.floor(sec / 60);
      const s = Math.floor(sec % 60);
      return m + ':' + String(s).padStart(2, '0');
    }

    function exportPackage() {
      alert('🎉 100% Anti-AI-Slop Video Package Ready!\\n\\n• 112+ Hand-Drawn 2D Comic Scenes (assets/scenes)\\n• Full 10-Minute Voiceover (assets/audio/narration.mp3)\\n• Clean Timeline with Zero Zoom & Zero Captions (assets/timeline.json)\\n• Ready for YouTube Publishing!');
    }

    window.addEventListener('DOMContentLoaded', initDashboard);
  </script>
</body>
</html>
`;

fs.writeFileSync(targetPath, html, 'utf8');
console.log('✅ Hermes Story Dashboard V4 written to:', targetPath);
