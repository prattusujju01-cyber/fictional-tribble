const fs = require('fs');
const path = require('path');

const scenesDir = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\assets\\scenes';
const screenplayPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\assets\\screenplay.json';

async function fetchImageWithRetry(prompt, outputPath, retries = 3) {
  const cleanPrompt = prompt.trim();
  const encoded = encodeURIComponent(cleanPrompt);
  
  // Try flux, fallback to turbo if flux queue is congested
  const models = ['flux', 'flux', 'turbo'];

  for (let attempt = 0; attempt < retries; attempt++) {
    const model = models[attempt];
    const url = `https://image.pollinations.ai/prompt/${encoded}?width=1280&height=720&model=${model}&nologo=true&seed=${Math.floor(Math.random() * 999999)}`;
    
    console.log(`[Retry Engine] Fetching (attempt ${attempt + 1}/${retries}, model=${model}): ${outputPath}...`);
    try {
      const res = await fetch(url, {
        headers: { 'User-Agent': 'Mozilla/5.0' },
        signal: AbortSignal.timeout(90000)
      });
      if (res.status === 200) {
        const buf = Buffer.from(await res.arrayBuffer());
        if (buf.length > 5000) {
          fs.writeFileSync(outputPath, buf);
          console.log(`[Retry Engine] ✅ Saved: ${path.basename(outputPath)} (${Math.round(buf.length / 1024)} KB, model=${model})`);
          return true;
        }
      }
    } catch (err) {
      console.warn(`[Retry Engine] ⚠️ Attempt ${attempt + 1} failed: ${err.message}`);
    }
    await new Promise(r => setTimeout(r, 2500));
  }
  return false;
}

async function run() {
  if (!fs.existsSync(screenplayPath)) {
    console.error('Screenplay not found');
    return;
  }
  const screenplay = JSON.parse(fs.readFileSync(screenplayPath, 'utf8'));
  const allScenes = screenplay.acts.flatMap(a => a.scenes);

  for (const scene of allScenes) {
    const file = path.join(scenesDir, `${scene.sceneId}.jpg`);
    const exists = fs.existsSync(file) && fs.statSync(file).size > 5000;
    if (!exists) {
      console.log(`[Retry Engine] Missing or invalid: ${scene.sceneId}`);
      await fetchImageWithRetry(scene.fluxPrompt, file);
      await new Promise(r => setTimeout(r, 2000));
    } else {
      console.log(`[Retry Engine] Already exists: ${scene.sceneId} (${Math.round(fs.statSync(file).size / 1024)} KB)`);
    }
  }

  // Update visual manifest
  const manifest = allScenes.map(s => {
    const file = path.join(scenesDir, `${s.sceneId}.jpg`);
    const exists = fs.existsSync(file) && fs.statSync(file).size > 5000;
    return {
      sceneId: s.sceneId,
      filePath: file,
      relativePath: `assets/scenes/${s.sceneId}.jpg`,
      prompt: s.fluxPrompt,
      status: exists ? 'rendered' : 'missing',
      sizeKB: exists ? Math.round(fs.statSync(file).size / 1024) : 0
    };
  });
  fs.writeFileSync('C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\assets\\visual-manifest.json', JSON.stringify(manifest, null, 2), 'utf8');
  console.log('✅ Visual manifest updated with all 14 scenes!');
}

run();
