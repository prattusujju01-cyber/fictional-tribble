const fs = require('fs');
const path = require('path');

const GITHUB_TOKEN = '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';
const REPO = 'prathamgowda194-pixel/asura-system';

async function commitFile(relPath, localFilePath, msg) {
  const url = `https://api.github.com/repos/${REPO}/contents/${relPath}`;
  let sha = null;
  try {
    const res = await fetch(url, { headers: { 'Authorization': `Bearer ${GITHUB_TOKEN}`, 'User-Agent': 'Node' } });
    if (res.status === 200) sha = (await res.json()).sha;
  } catch (e) {}

  const content = fs.readFileSync(localFilePath, 'utf8');
  const base64 = Buffer.from(content, 'utf8').toString('base64');
  const body = { message: msg, content: base64, branch: 'main' };
  if (sha) body.sha = sha;

  const putRes = await fetch(url, {
    method: 'PUT',
    headers: { 'Authorization': `Bearer ${GITHUB_TOKEN}`, 'Content-Type': 'application/json', 'User-Agent': 'Node' },
    body: JSON.stringify(body)
  });
  const d = await putRes.json();
  console.log(`${relPath}: HTTP ${putRes.status}${d.commit ? ' | Commit: ' + d.commit.sha.slice(0, 7) : ' | ' + JSON.stringify(d).slice(0, 100)}`);
}

async function run() {
  const root = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system';

  console.log('Committing core engine files to GitHub...');
  await commitFile(
    'api/serve_project.js',
    path.join(root, 'api', 'serve_project.js'),
    'feat(edge): zero-cache GitHub Contents API primary fetch for instant prototype updates'
  );

  await commitFile(
    'api/cron_hunt.js',
    path.join(root, 'api', 'cron_hunt.js'),
    'feat(cron): dispatch batch of 5 verified clients every 30 mins with non-repeating archetypes'
  );

  await commitFile(
    'data/hunter_leads.json',
    path.join(root, 'data', 'hunter_leads.json'),
    'data: update 16 verified Indian clients with luxury archetypes and live prototype links'
  );

  console.log('All files committed successfully!');
}

run().catch(console.error);
