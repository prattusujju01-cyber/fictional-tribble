import urllib.parse
import re
import requests

def free_search_duckduckgo(query, limit=5):
    url = f"https://html.duckduckgo.com/html/?q={urllib.parse.quote(query)}"
    headers = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-IN,en-US;q=0.9,en;q=0.8"
    }
    try:
        r = requests.get(url, headers=headers, timeout=10)
        if r.status_code == 200:
            results = []
            parts = r.text.split('<div class="result results_links')
            for p in parts[1:limit+1]:
                t_m = re.search(r'<a[^>]+class="result__a"[^>]*href="([^"]+)"[^>]*>([\s\S]*?)</a>', p, re.I)
                s_m = re.search(r'<a[^>]+class="result__snippet"[^>]*>([\s\S]*?)</a>', p, re.I)
                if t_m:
                    raw_url = t_m.group(1)
                    if "uddg=" in raw_url:
                        raw_url = urllib.parse.unquote(raw_url.split("uddg=")[1].split("&")[0])
                    title = re.sub(r'<[^>]+>', '', t_m.group(2)).strip()
                    desc = re.sub(r'<[^>]+>', '', s_m.group(1)).strip() if s_m else ""
                    results.append({"title": title, "description": desc, "url": raw_url})
            return results
    except Exception as e:
        print(f"[FREE CRAWLER PYTHON ERROR] {e}")
    return []

def unified_search(query, limit=5, firecrawl_key=None, force_free=False):
    if not force_free and firecrawl_key:
        try:
            res = requests.post(
                "https://api.firecrawl.dev/v1/search",
                headers={"Authorization": f"Bearer {firecrawl_key}", "Content-Type": "application/json"},
                json={"query": query, "limit": limit},
                timeout=10
            )
            if res.status_code == 200:
                data = res.json()
                if data.get("data"):
                    return data.get("data", [])
            elif res.status_code in (402, 429):
                print(f"⚠️ [FIRECRAWL QUOTA EXHAUSTED {res.status_code}] Falling back to Free Open-Source Crawler...")
        except Exception as e:
            print(f"⚠️ [FIRECRAWL EXCEPTION {e}] Falling back to Free Crawler...")
    
    return free_search_duckduckgo(query, limit)
