async function test() {
  const url = 'https://asura-system.vercel.app/api/serve_project?slug=byob-restaurant-experience-in-gurgaon';
  console.log('Testing live URL:', url);
  const res = await fetch(url + '&_t=' + Date.now());
  console.log('HTTP Status:', res.status);
  const text = await res.text();
  console.log('Response Length:', text.length);
  console.log('Contains 0k+ slop:', text.includes('0k+'));
  console.log('Contains 0+ BOTTLES slop:', text.includes('0+ BOTTLES'));
  console.log('Contains counter class:', text.includes('class="counter"'));
  console.log('Contains Fraunces typography:', text.includes('Fraunces'));
  console.log('Contains 100% BYOB:', text.includes('100% BYOB'));
  console.log('Contains Chef tasting platter:', text.includes("Chef's Wood-Fired Tasting Platter"));
  console.log('Contains WhatsApp 9654120004:', text.includes('9654120004'));
  console.log('Title tag:', (text.match(/<title>(.*?)<\/title>/) || [])[1]);
  console.log('H1 tag:', (text.match(/<h1[\s\S]*?>(.*?)<\/h1>/) || [])[1]?.replace(/\s+/g, ' ').trim());

  // Also test direct project URL
  console.log('\n--- Direct Static Project Test ---');
  const staticUrl = 'https://asura-system.vercel.app/projects/byob-restaurant-experience-in-gurgaon/index.html';
  const res2 = await fetch(staticUrl + '?_t=' + Date.now());
  console.log('Static URL Status:', res2.status);
  const text2 = await res2.text();
  console.log('Static Length:', text2.length);
  console.log('Static Contains 0k+:', text2.includes('0k+'));
  console.log('Static Contains Fraunces:', text2.includes('Fraunces'));
}
test().catch(console.error);
