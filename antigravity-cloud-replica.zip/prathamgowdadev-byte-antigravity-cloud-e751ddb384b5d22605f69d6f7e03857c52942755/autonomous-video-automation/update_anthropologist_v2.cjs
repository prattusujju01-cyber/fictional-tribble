const fs = require('fs');
const path = require('path');

const target = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\agents\\hermes-anthropologist.js';
const code = `/**
 * Hermes Anthropologist Agent // Retrained for Zenn Curiosity Niches
 * Viral Curiosity Radar, Evolutionary Gags & Relatable Human Quirk Research
 */
const fs = require('fs');
const path = require('path');

class HermesAnthropologist {
  constructor() {
    this.name = 'Hermes-Anthropologist';
    this.version = '3.0.0';
  }

  getCuriosityNiches() {
    return [
      {
        id: 'ancient-humans-night',
        title: 'What Did Ancient Humans Do at Night?',
        viewsBenchmark: '7.9M',
        scientificCitations: [
          "A. Roger Ekirch - At Day's Close: Night in Times Past (Biphasic Sleep)",
          "Dr. Thomas Wehr - NIH Darkness Study (Natural Circadian Rhythms & Prolactin)",
          "Polly Wiessner (2014) - PNAS Embers of Society: Firelight Storytelling",
          "Berna et al. (2012) - Wonderwerk Cave 1-million-year-old Acheulean campfire evidence"
        ],
        visualGagHooks: [
          'Stickman clinging to tree branch looking down terrified (Image 1 style)',
          'Stickman walking with deadpan face while pairs of predator eyes watch in darkness (Image 2 style)',
          'Stickman cornered by two cute spotted leopards (Image 3 style)',
          'Stickman standing behind monkeys in evolution march (Image 4 style)',
          'Modern stickman on couch getting blasted by ceiling sun lamp (Image 5 style)'
        ],
        coreEvolutionaryInsight: 'Your 3:00 AM wakefulness is not broken insomnia—it is an ancient biological echo of first and second sleep.'
      },
      {
        id: 'why-humans-lost-fur',
        title: 'The Real Reason Humans Lost All Their Fur',
        viewsBenchmark: '5.4M',
        scientificCitations: [
          "Nina Jablonski - Skin: A Natural History",
          "David Carrier - Endurance Running Hypothesis"
        ],
        visualGagHooks: [
          'Stickman sweating profusely while furry chimps pass out from heat',
          'Stickman picking ticks off a giant furry mammoth',
          'Stickman proudly jogging past exhausted gazelles at high noon'
        ],
        coreEvolutionaryInsight: 'We became naked apes so we could sweat and run until every furry animal collapsed from heatstroke.'
      },
      {
        id: 'silent-forest-fear',
        title: 'Why Do We Get Terrified When Forests Go Dead Silent?',
        viewsBenchmark: '6.2M',
        scientificCitations: [
          "Gordon Orians - Savanna Hypothesis & Evolutionary Aesthetics",
          "David Quammen - Monster of God: Predator Echoes"
        ],
        visualGagHooks: [
          'Stickman hearing sudden dead silence and hair standing straight up on head',
          'Birds abruptly flying away leaving stickman alone in shadows',
          'Stickman creeping backward very slowly while eyes peer from bushes'
        ],
        coreEvolutionaryInsight: 'A silent forest meant a silent apex predator was actively hunting.'
      }
    ];
  }

  async researchTopic(topicName) {
    console.log(\`[\${this.name}] 🧠 Analyzing viral curiosity hook & visual gags for: "\${topicName}"\`);
    const niches = this.getCuriosityNiches();
    const matched = niches.find(n => n.title.toLowerCase().includes(topicName.toLowerCase()) || topicName.toLowerCase().includes(n.title.toLowerCase())) || niches[0];

    const dossier = {
      selectedTopic: matched.title,
      benchmarkViews: matched.viewsBenchmark,
      scientificCitations: matched.scientificCitations,
      visualGagHooks: matched.visualGagHooks,
      coreEvolutionaryInsight: matched.coreEvolutionaryInsight,
      recommendedVisualEngine: 'Zenn 2D Webcomic Vector Stickman Engine',
      pacingProfile: '82 Rapid Visual Cuts (3-5s per beat, Zero On-Screen Subtitles)'
    };

    console.log(\`[\${this.name}] 📜 Topic Dossier ready: "\${matched.title}" with \${matched.visualGagHooks.length} visual gags\`);
    return dossier;
  }
}

module.exports = new HermesAnthropologist();
`;

fs.writeFileSync(target, code, 'utf8');
console.log('✅ Retrained Hermes Anthropologist at', target);
