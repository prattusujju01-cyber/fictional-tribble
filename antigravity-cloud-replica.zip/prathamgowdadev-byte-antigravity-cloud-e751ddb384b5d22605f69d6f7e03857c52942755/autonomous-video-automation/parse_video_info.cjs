const fs = require('fs');
const content = fs.readFileSync('C:\\Users\\WINDOWS\\.gemini\\antigravity\\brain\\89cf8d98-dd47-4e89-be0a-1ca403d809e8\\.system_generated\\steps\\3956\\content.md', 'utf8');

const idx = content.indexOf('"videoDetails"');
if (idx !== -1) {
  const slice = content.slice(idx, idx + 2000);
  console.log(slice);
} else {
  console.log('No videoDetails found');
  const titleTag = content.match(/<title>([^<]+)<\/title>/);
  if (titleTag) console.log('Title tag:', titleTag[1]);
}
