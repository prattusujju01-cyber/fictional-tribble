const fs = require('fs');
const path = require('path');

async function synthesizeEdgeNeural(text, voice = 'en-US-ChristopherNeural', outputPath = './assets/audio/test_edge.mp3') {
  const connectionId = Array.from({length: 32}, () => Math.floor(Math.random()*16).toString(16)).join('');
  const url = `wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1?TrustedClientToken=6A5AA1D4EAFF4E9FB37E23D68491D6F4&ConnectionId=${connectionId}`;

  const dir = path.dirname(outputPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  return new Promise((resolve, reject) => {
    const ws = new WebSocket(url, {
      headers: {
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0',
        'Origin': 'chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold'
      }
    });

    const audioChunks = [];

    ws.onopen = () => {
      // 1. Send speech.config
      const configMsg = "X-Timestamp: " + new Date().toISOString() + "\\r\\n" +
        "Content-Type: application/json; charset=utf-8\\r\\n" +
        "Path: speech.config\\r\\n\\r\\n" +
        JSON.stringify({
          context: {
            synthesis: {
              audio: {
                metadataoptions: { sentenceBoundaryEnabled: "false", wordBoundaryEnabled: "false" },
                outputFormat: "audio-24khz-48kbitrate-mono-mp3"
              }
            }
          }
        });
      ws.send(configMsg);

      // 2. Send SSML request with emotional rate/pitch
      const requestId = Array.from({length: 32}, () => Math.floor(Math.random()*16).toString(16)).join('');
      const ssml = `<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'>` +
        `<voice name='${voice}'>` +
        `<prosody rate='+0%' pitch='+0Hz'>${text}</prosody>` +
        `</voice></speak>`;

      const ssmlMsg = `X-RequestId: ${requestId}\\r\\n` +
        `Content-Type: application/ssml+xml\\r\\n` +
        `X-Timestamp: ${new Date().toISOString()}Z\\r\\n` +
        `Path: ssml\\r\\n\\r\\n` +
        ssml;

      ws.send(ssmlMsg);
    };

    ws.onmessage = async (event) => {
      if (typeof event.data === 'string') {
        if (event.data.includes('Path:turn.end')) {
          ws.close();
          const finalBuffer = Buffer.concat(audioChunks);
          fs.writeFileSync(outputPath, finalBuffer);
          resolve({
            outputPath,
            bytes: finalBuffer.length,
            voice
          });
        }
      } else {
        // Binary audio chunk (first 2 bytes = header length)
        const arrayBuf = await event.data.arrayBuffer();
        const buf = Buffer.from(arrayBuf);
        const headerLen = buf.readUInt16BE(0);
        const audioData = buf.subarray(headerLen + 2);
        audioChunks.push(audioData);
      }
    };

    ws.onerror = (err) => {
      reject(err);
    };

    setTimeout(() => {
      ws.close();
      if (audioChunks.length > 0) {
        const finalBuffer = Buffer.concat(audioChunks);
        fs.writeFileSync(outputPath, finalBuffer);
        resolve({ outputPath, bytes: finalBuffer.length, voice });
      } else {
        reject(new Error('TTS Timeout'));
      }
    }, 15000);
  });
}

synthesizeEdgeNeural("Tonight, when you flip a light switch in your bedroom, you literally don't think twice about it.", "en-US-ChristopherNeural")
  .then(res => console.log("✅ Christopher Neural Voice OK! Bytes:", res.bytes))
  .catch(err => console.error("Edge TTS test failed:", err.message));
