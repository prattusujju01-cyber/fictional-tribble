const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { execSync } = require('child_process');

const WORKSPACE = 'C:/Users/WINDOWS/.gemini/antigravity/scratch/youtube-automation-agent';
const SCENES_DIR = path.join(WORKSPACE, 'assets/scenes');
const AUDIO_DIR = path.join(WORKSPACE, 'assets/audio');
const SCREENPLAY_PATH = path.join(WORKSPACE, 'assets/screenplay.json');
const DURATIONS_PATH = path.join(WORKSPACE, 'assets/scene_durations.json');
const FFMPEG_PATH = path.join(WORKSPACE, 'node_modules/ffmpeg-static/ffmpeg.exe');
const { MsEdgeTTS, OUTPUT_FORMAT } = require('C:/Users/WINDOWS/.gemini/antigravity/scratch/node_modules/msedge-tts');

const TOKENS = [
  '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',
  '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',
  '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',
  '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',
  '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',
  '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',
  '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',
  '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',
  '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'
];

let tokenIdx = 0;
function getNextToken() {
  const t = TOKENS[tokenIdx];
  tokenIdx = (tokenIdx + 1) % TOKENS.length;
  return t;
}

const DUPLICATE_SCENES = [79, 80, 81, 82, 83, 85, 86, 87, 88, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99];

async function generateSingleImage(prompt) {
  for (let attempt = 0; attempt < TOKENS.length * 2; attempt++) {
    const token = getNextToken();
    try {
      const res = await fetch('https://router.huggingface.co/hf-inference/models/stabilityai/stable-diffusion-3-medium-diffusers', {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer ' + token,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ inputs: prompt })
      });

      if (res.status === 200) {
        const buf = Buffer.from(await res.arrayBuffer());
        if (buf.length > 5000) return buf;
      } else {
        const errText = await res.text().catch(() => '');
        console.warn(`   ⚠️ Status ${res.status}: ${errText.slice(0, 100)} - rotating token...`);
      }
    } catch (err) {
      console.warn(`   ⚠️ Fetch error: ${err.message} - rotating token...`);
    }
    await new Promise(r => setTimeout(r, 2000));
  }
  throw new Error('Failed to generate image after cycling through all tokens');
}

async function runVisualGeneration() {
  console.log('================================================================');
  console.log('🎨 PHASE 1: GENERATING REMAINING 19 UNIQUE SCENE VISUALS');
  console.log('================================================================\n');

  const screenplay = JSON.parse(fs.readFileSync(SCREENPLAY_PATH, 'utf8'));

  for (const sceneNum of DUPLICATE_SCENES) {
    const padNum = String(sceneNum).padStart(3, '0');
    const targetFile = path.join(SCENES_DIR, `scene_${padNum}.jpg`);
    const scene = screenplay.scenes.find(s => s.sceneNumber === sceneNum);

    const prompt = `Minimalist 2D hand-drawn comic art, bold black ink outlines, flat vector colors, simple expressive comic aesthetic, clean cinematic lighting, ${scene.subPrompt}, 16:9 widescreen`;
    console.log(`🖼️ [Scene ${padNum}/100] "${scene.sceneTitle}"...`);

    try {
      const imgBuf = await generateSingleImage(prompt);
      fs.writeFileSync(targetFile, imgBuf);
      console.log(`   ✅ Saved scene_${padNum}.jpg (${(imgBuf.length / 1024).toFixed(0)} KB)`);
      await new Promise(r => setTimeout(r, 1500));
    } catch (err) {
      console.error(`   ❌ Failed scene_${padNum}:`, err.message);
    }
  }

  // Verify all 100 scenes are unique
  const files = fs.readdirSync(SCENES_DIR).filter(f => /^scene_\d{3}\.jpg$/.test(f)).sort();
  const hashes = new Map();
  const dups = [];
  files.forEach(f => {
    const buf = fs.readFileSync(path.join(SCENES_DIR, f));
    const hash = crypto.createHash('md5').update(buf).digest('hex');
    if (hashes.has(hash)) {
      dups.push(f);
    } else {
      hashes.set(hash, f);
    }
  });

  console.log(`\n🎉 Total unique scene files: ${hashes.size} / 100`);
  if (dups.length > 0) {
    console.warn(`⚠️ Warning: ${dups.length} duplicate files remaining:`, dups);
  } else {
    console.log('🌟 ZERO DUPLICATES! Every single one of the 100 scenes is 100% unique!\n');
  }
}

function getAudioDuration(filePath) {
  try {
    execSync(`"${FFMPEG_PATH}" -i "${filePath}"`, { stdio: 'pipe' });
  } catch (err) {
    const out = (err.stdout ? err.stdout.toString() : '') + (err.stderr ? err.stderr.toString() : '');
    const m = out.match(/Duration:\s*(\d+):(\d+):(\d+\.\d+)/);
    if (m) {
      const h = parseFloat(m[1]);
      const min = parseFloat(m[2]);
      const s = parseFloat(m[3]);
      return Math.round((h * 3600 + min * 60 + s) * 10) / 10;
    }
  }
  return 5.5;
}

async function runAudioSynthesis() {
  console.log('================================================================');
  console.log('🎙️ PHASE 2: SYNTHESIZING 100% NATURAL 1.0X CHRISTOPHER NEURAL AUDIO');
  console.log('   (NO 2X Speedup | NO Chipmunk Pitch | Natural Historical Pace)');
  console.log('================================================================\n');

  const screenplay = JSON.parse(fs.readFileSync(SCREENPLAY_PATH, 'utf8'));
  const scenes = screenplay.scenes;

  const sceneAudioDir = path.join(AUDIO_DIR, 'scenes');
  if (!fs.existsSync(sceneAudioDir)) fs.mkdirSync(sceneAudioDir, { recursive: true });

  const tts = new MsEdgeTTS();
  await tts.setMetadata('en-US-ChristopherNeural', OUTPUT_FORMAT.AUDIO_24KHZ_48KBITRATE_MONO_MP3);

  const sceneDurations = [];
  let cumulativeTime = 0.0;

  for (let i = 0; i < scenes.length; i++) {
    const s = scenes[i];
    const padNum = String(s.sceneNumber).padStart(3, '0');
    const tempDir = path.join(sceneAudioDir, `scene_${padNum}`);
    if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

    const sceneAudioPath = path.join(tempDir, 'audio.mp3');

    // Synthesize if not already done
    let retries = 3;
    while (retries > 0) {
      try {
        await tts.toFile(tempDir, s.narration);
        break;
      } catch (e) {
        retries--;
        console.warn(`   ⚠️ TTS retry ${3 - retries} for Scene ${padNum}: ${e.message}`);
        await new Promise(r => setTimeout(r, 1500));
      }
    }

    // Measure exact audio duration
    let durSec = getAudioDuration(sceneAudioPath);

    // Add a natural 0.3s breathing gap between scenes
    durSec = Math.round((durSec + 0.3) * 10) / 10;

    const startSec = Math.round(cumulativeTime * 10) / 10;
    const endSec = Math.round((cumulativeTime + durSec) * 10) / 10;
    cumulativeTime += durSec;

    sceneDurations.push({
      sceneNumber: s.sceneNumber,
      sceneId: `scene_${padNum}`,
      startSec: startSec,
      durationSec: durSec,
      endSec: endSec,
      bytes: fs.existsSync(sceneAudioPath) ? fs.statSync(sceneAudioPath).size : 0
    });

    if ((i + 1) % 10 === 0 || i === scenes.length - 1) {
      console.log(`🎙️ [${i + 1}/100] Synthesized through Scene ${padNum} (${endSec}s cumulative)`);
    }

    // Brief pause to avoid flooding TTS server
    await new Promise(r => setTimeout(r, 200));
  }

  fs.writeFileSync(DURATIONS_PATH, JSON.stringify(sceneDurations, null, 2), 'utf8');

  const totalSec = sceneDurations[sceneDurations.length - 1].endSec;
  const totalMins = Math.floor(totalSec / 60);
  const totalSecs = Math.round(totalSec % 60);
  console.log(`\n✅ All 100 scenes synthesized at 1.0x natural speed!`);
  console.log(`⏱️ Total documentary duration: ${totalMins}:${String(totalSecs).padStart(2, '0')} (${totalSec} seconds)`);

  // Concatenate all 100 audio files into master narration.mp3
  console.log('\n🎵 Merging into master narration track: assets/audio/narration.mp3...');
  const concatList = path.join(AUDIO_DIR, 'audio_concat_list.txt');
  let listContent = '';
  for (let i = 0; i < scenes.length; i++) {
    const padNum = String(scenes[i].sceneNumber).padStart(3, '0');
    const p = path.join(sceneAudioDir, `scene_${padNum}`, 'audio.mp3').replace(/\\/g, '/');
    listContent += `file '${p}'\n`;
  }
  fs.writeFileSync(concatList, listContent, 'utf8');

  const masterAudio = path.join(AUDIO_DIR, 'narration.mp3');
  execSync(`"${FFMPEG_PATH}" -y -f concat -safe 0 -i "${concatList}" -c:a libmp3lame -b:a 192k "${masterAudio}"`, { stdio: 'inherit' });
  console.log(`✅ Master narration track compiled (${(fs.statSync(masterAudio).size / 1024).toFixed(0)} KB)\n`);
}

async function runVideoCompilation() {
  console.log('================================================================');
  console.log('🎬 PHASE 3: COMPILING FINAL 1080P MASTER DOCUMENTARY VIDEO');
  console.log('================================================================\n');

  const screenplay = JSON.parse(fs.readFileSync(SCREENPLAY_PATH, 'utf8'));
  const scenes = screenplay.scenes;
  const durations = JSON.parse(fs.readFileSync(DURATIONS_PATH, 'utf8'));

  const concatListPath = path.join(WORKSPACE, 'assets/concat_list.txt');
  const masterAudioPath = path.join(AUDIO_DIR, 'narration.mp3');
  const exportsDir = path.join(WORKSPACE, 'assets/exports');
  if (!fs.existsSync(exportsDir)) fs.mkdirSync(exportsDir, { recursive: true });
  const outputVideoPath = path.join(exportsDir, 'egypt_documentary_master.mp4');

  let concatContent = '';
  for (let i = 0; i < scenes.length; i++) {
    const padNum = String(scenes[i].sceneNumber).padStart(3, '0');
    const imgPath = path.join(SCENES_DIR, `scene_${padNum}.jpg`).replace(/\\/g, '/');
    const dur = durations[i] ? durations[i].durationSec : 5.7;
    concatContent += `file '${imgPath}'\nduration ${dur}\n`;
  }
  const lastPad = String(scenes[scenes.length - 1].sceneNumber).padStart(3, '0');
  concatContent += `file '${path.join(SCENES_DIR, `scene_${lastPad}.jpg`).replace(/\\/g, '/')}'\n`;

  fs.writeFileSync(concatListPath, concatContent, 'utf8');

  const ffmpegCmd = `"${FFMPEG_PATH}" -y -f concat -safe 0 -i "${concatListPath}" -i "${masterAudioPath}" -c:v libx264 -pix_fmt yuv420p -preset medium -crf 20 -c:a aac -b:a 192k -shortest "${outputVideoPath}"`;
  console.log('Executing FFmpeg encode...');
  execSync(ffmpegCmd, { stdio: 'inherit' });

  const finalVideoKB = Math.round(fs.statSync(outputVideoPath).size / 1024);
  console.log('\n================================================================');
  console.log('🏆 COMPLETE 100-SCENE DOCUMENTARY MASTER VIDEO READY!');
  console.log(`📁 Video Path: ${outputVideoPath}`);
  console.log(`📊 File Size: ${(finalVideoKB / 1024).toFixed(1)} MB (${finalVideoKB} KB)`);
  console.log(`⏱️ Duration: ${Math.floor(durations[durations.length - 1].endSec / 60)}:${String(Math.round(durations[durations.length - 1].endSec % 60)).padStart(2, '0')}`);
  console.log('================================================================\n');

  // Update timeline.json
  const totalSec = durations[durations.length - 1].endSec;
  const beats = scenes.map((s, idx) => {
    const dur = durations[idx];
    const padNum = String(s.sceneNumber).padStart(3, '0');
    return {
      beatId: `scene_${padNum}`,
      sceneNumber: s.sceneNumber,
      act: s.act,
      actTitle: s.actTitle,
      title: s.sceneTitle,
      startSec: dur.startSec,
      endSec: dur.endSec,
      duration: dur.durationSec,
      narration: s.narration,
      masterPrompt: s.masterPrompt,
      subPrompt: s.subPrompt,
      imagePrompt: s.fullPrompt,
      motion: { name: 'instant_static_cut', scale: 1.0, panX: 0, panY: 0 },
      visualPath: `assets/scenes/scene_${padNum}.jpg`
    };
  });

  const timeline = {
    meta: {
      title: screenplay.meta.title,
      totalScenes: 100,
      totalActs: 4,
      totalDurationSeconds: totalSec,
      formattedDuration: `${Math.floor(totalSec / 60)}:${String(Math.round(totalSec % 60)).padStart(2, '0')}`,
      audioTrack: 'assets/audio/narration.mp3',
      voice: 'en-US-ChristopherNeural',
      speed: '1.0x Natural Speed (Zero Fast-Forward)',
      style: 'Genius History 2D Flat Cartoon Comic Illustration',
      aspectRatio: '16:9',
      resolution: '1920x1080',
      cameraFraming: '100% Stable Static Framing',
      renderedAt: new Date().toISOString()
    },
    acts: screenplay.acts,
    beats: beats,
    thumbnails: screenplay.thumbnailConcepts
  };

  fs.writeFileSync(path.join(WORKSPACE, 'assets/timeline.json'), JSON.stringify(timeline, null, 2), 'utf8');
  console.log('✅ assets/timeline.json updated successfully!');
}

async function main() {
  await runVisualGeneration();
  await runAudioSynthesis();
  await runVideoCompilation();
}

main().catch(err => {
  console.error('Fatal Pipeline Error:', err);
  process.exit(1);
});
