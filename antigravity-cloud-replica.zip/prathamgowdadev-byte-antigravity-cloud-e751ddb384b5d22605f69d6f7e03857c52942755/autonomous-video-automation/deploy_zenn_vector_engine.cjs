const fs = require('fs');
const path = require('path');

const targetPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\utils\\zenn-vector-engine.js';

const code = `/**
 * ══════════════════════════════════════════════════════════════════════════════
 * ZENN 2D VECTOR ART ENGINE // TRUE COMIC STICKMAN GENERATOR
 * ══════════════════════════════════════════════════════════════════════════════
 * Replicates the authentic visual DNA of Zenn (7.9M views):
 * - Simple expressive stickman (round white head, bold black outline, deadpan/scared/annoyed expressions)
 * - Flat vibrant colorblocked backgrounds (Navy night #1B2E58, Savanna earth #7A4B24, Lush green #22C55E)
 * - Cartoon creatures: Floating yellow predator eyes, spotted yellow leopards, brown monkeys
 * - Props & Gags: Trees, purple sofas, blazing ceiling sun lamps, campfires, clocks, flint stones
 * - Generates 100+ SVG visual beats in milliseconds with zero queue delays
 */

const fs = require('fs');
const path = require('path');

class ZennVectorEngine {
  constructor() {
    this.width = 1280;
    this.height = 720;
  }

  // ── HEAD & FACIAL EXPRESSIONS ──────────────────────────────────────────────
  renderHead(cx, cy, radius = 70, expression = 'deadpan') {
    let eyesHtml = '';
    let mouthHtml = '';
    let browsHtml = '';
    let extraHtml = '';

    switch (expression) {
      case 'scared':
        // Tilted worried eyebrows, wide eyes, curved mouth, sweat drop
        browsHtml = \`
          <path d="M \${cx - 45} \${cy - 30} Q \${cx - 28} \${cy - 48} \${cx - 10} \${cy - 32}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 10} \${cy - 32} Q \${cx + 28} \${cy - 48} \${cx + 45} \${cy - 30}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <ellipse cx="\${cx - 26}" cy="\${cy - 10}" rx="15" ry="18" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx - 24}" cy="\${cy - 7}" r="6" fill="#000"/>
          <ellipse cx="\${cx + 26}" cy="\${cy - 10}" rx="15" ry="18" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx + 24}" cy="\${cy - 7}" r="6" fill="#000"/>
        \`;
        mouthHtml = \`<path d="M \${cx - 24} \${cy + 30} Q \${cx} \${cy + 18} \${cx + 24} \${cy + 30}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>\`;
        extraHtml = \`<path d="M \${cx + 48} \${cy - 20} C \${cx + 45} \${cy - 32}, \${cx + 58} \${cy - 28}, \${cx + 52} \${cy - 14} Z" fill="#60A5FA"/>\`; // Sweat drop
        break;

      case 'annoyed':
        // Angled frown eyebrows, sideways glare, wavy flat mouth
        browsHtml = \`
          <line x1="\${cx - 44}" y1="\${cy - 34}" x2="\${cx - 10}" y2="\${cy - 24}" stroke="#000" stroke-width="4.5" stroke-linecap="round"/>
          <line x1="\${cx + 10}" y1="\${cy - 24}" x2="\${cx + 44}" y2="\${cy - 34}" stroke="#000" stroke-width="4.5" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <ellipse cx="\${cx - 24}" cy="\${cy - 8}" rx="14" ry="16" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx - 19}" cy="\${cy - 8}" r="5.5" fill="#000"/>
          <ellipse cx="\${cx + 24}" cy="\${cy - 8}" rx="14" ry="16" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx + 29}" cy="\${cy - 8}" r="5.5" fill="#000"/>
        \`;
        mouthHtml = \`<path d="M \${cx - 22} \${cy + 28} Q \${cx} \${cy + 22} \${cx + 22} \${cy + 26}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>\`;
        break;

      case 'shocked':
        // High arched brows, giant round eyes with tiny pupils, open O mouth
        browsHtml = \`
          <path d="M \${cx - 44} \${cy - 40} Q \${cx - 26} \${cy - 52} \${cx - 8} \${cy - 40}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 8} \${cy - 40} Q \${cx + 26} \${cy - 52} \${cx + 44} \${cy - 40}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <circle cx="\${cx - 26}" cy="\${cy - 12}" r="18" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx - 26}" cy="\${cy - 12}" r="4" fill="#000"/>
          <circle cx="\${cx + 26}" cy="\${cy - 12}" r="18" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx + 26}" cy="\${cy - 12}" r="4" fill="#000"/>
        \`;
        mouthHtml = \`<ellipse cx="\${cx}" cy="\${cy + 30}" rx="12" ry="16" fill="#000"/>\`;
        break;

      case 'sleeping':
        // Gentle curved closed eyes, relaxed horizontal brows
        browsHtml = \`
          <line x1="\${cx - 40}" y1="\${cy - 24}" x2="\${cx - 12}" y2="\${cy - 24}" stroke="#000" stroke-width="3.5" stroke-linecap="round"/>
          <line x1="\${cx + 12}" y1="\${cy - 24}" x2="\${cx + 40}" y2="\${cy - 24}" stroke="#000" stroke-width="3.5" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <path d="M \${cx - 38} \${cy - 4} Q \${cx - 25} \${cy + 8} \${cx - 12} \${cy - 4}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 12} \${cy - 4} Q \${cx + 25} \${cy + 8} \${cx + 38} \${cy - 4}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
        \`;
        mouthHtml = \`<line x1="\${cx - 16}" y1="\${cy + 26}" x2="\${cx + 16}" y2="\${cy + 26}" stroke="#000" stroke-width="3.5" stroke-linecap="round"/>\`;
        extraHtml = \`
          <text x="\${cx + 55}" y="\${cy - 40}" font-family="sans-serif" font-weight="bold" font-size="28" fill="#93C5FD">Z</text>
          <text x="\${cx + 75}" y="\${cy - 65}" font-family="sans-serif" font-weight="bold" font-size="22" fill="#93C5FD">z</text>
        \`;
        break;

      case 'deadpan':
      default:
        // Classic horizontal brows, wide blank unblinking eyes, flat mouth
        browsHtml = \`
          <line x1="\${cx - 42}" y1="\${cy - 28}" x2="\${cx - 12}" y2="\${cy - 28}" stroke="#000" stroke-width="4" stroke-linecap="round"/>
          <line x1="\${cx + 12}" y1="\${cy - 28}" x2="\${cx + 42}" y2="\${cy - 28}" stroke="#000" stroke-width="4" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <ellipse cx="\${cx - 26}" cy="\${cy - 6}" rx="15" ry="17" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx - 22}" cy="\${cy - 6}" r="6" fill="#000"/>
          <ellipse cx="\${cx + 26}" cy="\${cy - 6}" rx="15" ry="17" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx + 30}" cy="\${cy - 6}" r="6" fill="#000"/>
        \`;
        mouthHtml = \`<line x1="\${cx - 26}" y1="\${cy + 26}" x2="\${cx + 26}" y2="\${cy + 26}" stroke="#000" stroke-width="4.5" stroke-linecap="round"/>\`;
        break;
    }

    return \`
      <!-- Head Circle -->
      <circle cx="\${cx}" cy="\${cy}" r="\${radius}" fill="#FFFFFF" stroke="#000000" stroke-width="6"/>
      \${browsHtml}
      \${eyesHtml}
      \${mouthHtml}
      \${extraHtml}
    \`;
  }

  // ── BODY POSES ────────────────────────────────────────────────────────────
  renderStickman(x, y, pose = 'walking', expression = 'deadpan', scale = 1.0) {
    const headRadius = 65 * scale;
    const bodyLength = 160 * scale;
    const limbWidth = 5.5 * scale;
    const headY = y - bodyLength;

    let limbsHtml = '';

    switch (pose) {
      case 'walking':
        limbsHtml = \`
          <!-- Torso -->
          <line x1="\${x}" y1="\${headY + headRadius}" x2="\${x}" y2="\${y}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <!-- Arms -->
          <line x1="\${x}" y1="\${headY + headRadius + 35*scale}" x2="\${x - 45*scale}" y2="\${y - 65*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <line x1="\${x - 45*scale}" y1="\${y - 65*scale}" x2="\${x - 65*scale}" y2="\${y - 10*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <line x1="\${x}" y1="\${headY + headRadius + 35*scale}" x2="\${x + 40*scale}" y2="\${y - 60*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <line x1="\${x + 40*scale}" y1="\${y - 60*scale}" x2="\${x + 60*scale}" y2="\${y - 15*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <!-- Legs -->
          <line x1="\${x}" y1="\${y}" x2="\${x - 55*scale}" y2="\${y + 70*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <line x1="\${x - 55*scale}" y1="\${y + 70*scale}" x2="\${x - 75*scale}" y2="\${y + 130*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <line x1="\${x}" y1="\${y}" x2="\${x + 45*scale}" y2="\${y + 65*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <line x1="\${x + 45*scale}" y1="\${y + 65*scale}" x2="\${x + 75*scale}" y2="\${y + 130*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
        \`;
        break;

      case 'climbing_tree':
        // Clinging to tree branch (Image 1 style)
        limbsHtml = \`
          <!-- Torso angled -->
          <line x1="\${x}" y1="\${headY + headRadius}" x2="\${x + 35*scale}" y2="\${y}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <!-- Left Arm holding lower branch -->
          <line x1="\${x + 10*scale}" y1="\${headY + headRadius + 30*scale}" x2="\${x - 40*scale}" y2="\${headY + headRadius + 50*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <!-- Right Arm reaching up to trunk -->
          <line x1="\${x + 10*scale}" y1="\${headY + headRadius + 30*scale}" x2="\${x + 70*scale}" y2="\${headY - 20*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <!-- Bent legs holding onto tree trunk -->
          <line x1="\${x + 35*scale}" y1="\${y}" x2="\${x + 15*scale}" y2="\${y + 40*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <line x1="\${x + 15*scale}" y1="\${y + 40*scale}" x2="\${x + 65*scale}" y2="\${y + 75*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <line x1="\${x + 35*scale}" y1="\${y}" x2="\${x + 50*scale}" y2="\${y + 50*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <line x1="\${x + 50*scale}" y1="\${y + 50*scale}" x2="\${x + 80*scale}" y2="\${y + 100*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
        \`;
        break;

      case 'sitting_couch':
        // Legs crossed, arms resting on sofa back (Image 5 style)
        limbsHtml = \`
          <!-- Torso -->
          <line x1="\${x}" y1="\${headY + headRadius}" x2="\${x}" y2="\${y + 30*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <!-- Left Arm resting on couch -->
          <path d="M \${x} \${headY + headRadius + 25*scale} L \${x - 90*scale} \${headY + headRadius + 20*scale} L \${x - 70*scale} \${headY + headRadius + 75*scale}" stroke="#000" stroke-width="\${limbWidth}" fill="none" stroke-linecap="round"/>
          <!-- Right Arm resting on couch -->
          <path d="M \${x} \${headY + headRadius + 25*scale} L \${x + 90*scale} \${headY + headRadius + 20*scale} L \${x + 70*scale} \${headY + headRadius + 75*scale}" stroke="#000" stroke-width="\${limbWidth}" fill="none" stroke-linecap="round"/>
          <!-- Crossed Legs -->
          <path d="M \${x} \${y + 30*scale} L \${x - 60*scale} \${y + 10*scale} L \${x - 40*scale} \${y + 90*scale}" stroke="#000" stroke-width="\${limbWidth}" fill="none" stroke-linecap="round"/>
          <path d="M \${x} \${y + 30*scale} L \${x + 30*scale} \${y + 50*scale} L \${x + 25*scale} \${y + 110*scale}" stroke="#000" stroke-width="\${limbWidth}" fill="none" stroke-linecap="round"/>
        \`;
        break;

      case 'cornered_defensive':
        // Hands up defensively, legs braced (Image 3 style)
        limbsHtml = \`
          <!-- Torso -->
          <line x1="\${x}" y1="\${headY + headRadius}" x2="\${x}" y2="\${y}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <!-- Arms raised defensively -->
          <path d="M \${x} \${headY + headRadius + 30*scale} L \${x - 80*scale} \${headY + headRadius - 10*scale} L \${x - 110*scale} \${headY + headRadius - 20*scale}" stroke="#000" stroke-width="\${limbWidth}" fill="none" stroke-linecap="round"/>
          <path d="M \${x} \${headY + headRadius + 30*scale} L \${x - 70*scale} \${headY + headRadius + 35*scale} L \${x - 100*scale} \${headY + headRadius + 40*scale}" stroke="#000" stroke-width="\${limbWidth}" fill="none" stroke-linecap="round"/>
          <!-- Legs braced -->
          <line x1="\${x}" y1="\${y}" x2="\${x - 25*scale}" y2="\${y + 60*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <line x1="\${x - 25*scale}" y1="\${y + 60*scale}" x2="\${x - 30*scale}" y2="\${y + 120*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <line x1="\${x}" y1="\${y}" x2="\${x + 20*scale}" y2="\${y + 60*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <line x1="\${x + 20*scale}" y1="\${y + 60*scale}" x2="\${x + 25*scale}" y2="\${y + 120*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
        \`;
        break;

      case 'campfire_crouch':
        // Sitting near fire, hands warming
        limbsHtml = \`
          <!-- Torso hunched -->
          <line x1="\${x}" y1="\${headY + headRadius}" x2="\${x - 20*scale}" y2="\${y + 20*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <!-- Arms stretched towards fire -->
          <path d="M \${x - 5*scale} \${headY + headRadius + 25*scale} L \${x + 50*scale} \${headY + headRadius + 40*scale} L \${x + 85*scale} \${headY + headRadius + 35*scale}" stroke="#000" stroke-width="\${limbWidth}" fill="none" stroke-linecap="round"/>
          <!-- Legs folded/crouched -->
          <path d="M \${x - 20*scale} \${y + 20*scale} L \${x + 30*scale} \${y + 30*scale} L \${x + 45*scale} \${y + 80*scale}" stroke="#000" stroke-width="\${limbWidth}" fill="none" stroke-linecap="round"/>
          <path d="M \${x - 20*scale} \${y + 20*scale} L \${x - 50*scale} \${y + 40*scale} L \${x - 30*scale} \${y + 80*scale}" stroke="#000" stroke-width="\${limbWidth}" fill="none" stroke-linecap="round"/>
        \`;
        break;

      case 'lying_bed':
        // Stickman lying down horizontally on bed
        limbsHtml = \`
          <!-- Torso horizontal -->
          <line x1="\${x}" y1="\${headY}" x2="\${x + 140*scale}" y2="\${headY}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <!-- Arms tucked under pillow/blanket -->
          <line x1="\${x + 20*scale}" y1="\${headY}" x2="\${x + 50*scale}" y2="\${headY + 30*scale}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
          <!-- Legs straight -->
          <line x1="\${x + 140*scale}" y1="\${headY}" x2="\${x + 230*scale}" y2="\${headY}" stroke="#000" stroke-width="\${limbWidth}" stroke-linecap="round"/>
        \`;
        break;
    }

    return \`
      <g>
        \${limbsHtml}
        \${this.renderHead(x, headY, headRadius, expression)}
      </g>
    \`;
  }

  // ── CREATURES & CHARACTERS ────────────────────────────────────────────────
  renderPredatorEyes(x, y, scale = 1.0) {
    const rx = 18 * scale;
    const ry = 21 * scale;
    const rPupil = 6.5 * scale;
    const gap = 48 * scale;

    return \`
      <g transform="translate(\${x}, \${y})">
        <ellipse cx="0" cy="0" rx="\${rx}" ry="\${ry}" fill="#FCD34D" stroke="#000000" stroke-width="3"/>
        <circle cx="-2" cy="0" r="\${rPupil}" fill="#000000"/>
        <ellipse cx="\${gap}" cy="0" rx="\${rx}" ry="\${ry}" fill="#FCD34D" stroke="#000000" stroke-width="3"/>
        <circle cx="\${gap - 2}" cy="0" r="\${rPupil}" fill="#000000"/>
      </g>
    \`;
  }

  renderCartoonLeopard(x, y, scale = 1.0, facing = 'left') {
    // Exact cartoon yellow spotted leopard from Image 3
    const flip = facing === 'right' ? -1 : 1;
    return \`
      <g transform="translate(\${x}, \${y}) scale(\${scale * flip}, \${scale})">
        <!-- Body -->
        <path d="M 0 0 C -40 -40 -120 -30 -160 30 C -180 80 -160 140 -120 160 L -110 240 L -80 240 L -70 170 L 40 170 L 50 240 L 80 240 L 80 120 C 80 40 40 0 0 0 Z" fill="#FBBF24" stroke="#000" stroke-width="4"/>
        <!-- Head -->
        <circle cx="-30" cy="-40" r="50" fill="#FBBF24" stroke="#000" stroke-width="4"/>
        <!-- Ears -->
        <path d="M -75 -65 Q -85 -100 -55 -80 Z" fill="#FBBF24" stroke="#000" stroke-width="3"/>
        <path d="M -5 -65 Q 5 -100 -25 -80 Z" fill="#FBBF24" stroke="#000" stroke-width="3"/>
        <!-- Eyes (Green with black pupils) -->
        <ellipse cx="-50" cy="-40" rx="14" ry="16" fill="#10B981" stroke="#000" stroke-width="3"/>
        <circle cx="-50" cy="-40" r="6" fill="#000"/>
        <ellipse cx="-10" cy="-40" rx="14" ry="16" fill="#10B981" stroke="#000" stroke-width="3"/>
        <circle cx="-10" cy="-40" r="6" fill="#000"/>
        <!-- Snout & Nose -->
        <path d="M -30 -18 L -36 -28 L -24 -28 Z" fill="#000"/>
        <line x1="-30" y1="-18" x2="-30" y2="-8" stroke="#000" stroke-width="3"/>
        <path d="M -40 -8 Q -30 -2 -20 -8" stroke="#000" stroke-width="3" fill="none"/>
        <!-- Tail -->
        <path d="M 80 120 Q 150 130 140 70 Q 130 30 110 50" stroke="#000" stroke-width="12" fill="none" stroke-linecap="round"/>
        <path d="M 80 120 Q 150 130 140 70 Q 130 30 110 50" stroke="#FBBF24" stroke-width="6" fill="none" stroke-linecap="round"/>
        <!-- Black Spots -->
        <circle cx="-90" cy="50" r="8" fill="#000"/>
        <circle cx="-50" cy="70" r="10" fill="#000"/>
        <circle cx="-20" cy="30" r="7" fill="#000"/>
        <circle cx="-70" cy="110" r="9" fill="#000"/>
        <circle cx="20" cy="80" r="11" fill="#000"/>
        <circle cx="50" cy="120" r="8" fill="#000"/>
        <circle cx="-110" cy="120" r="7" fill="#000"/>
        <circle cx="-30" cy="130" r="9" fill="#000"/>
      </g>
    \`;
  }

  renderCartoonMonkey(x, y, scale = 1.0) {
    // Exact brown cartoon monkey in row from Image 4
    return \`
      <g transform="translate(\${x}, \${y}) scale(\${scale})">
        <!-- Body (brown rounded) -->
        <path d="M 0 0 C -40 20 -50 80 -40 140 C -30 190 20 200 50 160 C 70 120 60 50 40 10 Z" fill="#8B5A2B" stroke="#000" stroke-width="4"/>
        <!-- Head -->
        <circle cx="20" cy="-25" r="42" fill="#8B5A2B" stroke="#000" stroke-width="4"/>
        <!-- Muzzle / Face Plate -->
        <ellipse cx="32" cy="-18" rx="26" ry="24" fill="#CD853F" stroke="#000" stroke-width="3"/>
        <!-- Eyes (white cartoon with black pupils looking left) -->
        <circle cx="22" cy="-28" r="11" fill="#FFF" stroke="#000" stroke-width="3"/>
        <circle cx="24" cy="-28" r="5" fill="#000"/>
        <circle cx="42" cy="-28" r="11" fill="#FFF" stroke="#000" stroke-width="3"/>
        <circle cx="44" cy="-28" r="5" fill="#000"/>
        <!-- Deadpan mouth line -->
        <line x1="24" y1="-8" x2="42" y2="-8" stroke="#000" stroke-width="3.5" stroke-linecap="round"/>
        <!-- Tail curling up -->
        <path d="M -40 120 Q -90 120 -80 60 Q -70 20 -50 40" stroke="#8B5A2B" stroke-width="12" fill="none" stroke-linecap="round"/>
        <path d="M -40 120 Q -90 120 -80 60 Q -70 20 -50 40" stroke="#000" stroke-width="3" fill="none" stroke-linecap="round"/>
        <!-- Arms and Feet -->
        <path d="M 10 70 L 25 150 L 15 175" stroke="#000" stroke-width="6" fill="none" stroke-linecap="round"/>
        <path d="M -20 150 L -25 195 L 5 195" stroke="#000" stroke-width="6" fill="none" stroke-linecap="round"/>
      </g>
    \`;
  }

  // ── PROPS & ENVIRONMENTS ──────────────────────────────────────────────────
  renderTree(x, y, scale = 1.0) {
    // Tree from Image 1
    return \`
      <g transform="translate(\${x}, \${y}) scale(\${scale})">
        <!-- Foliage (Lush Green with black outline) -->
        <path d="M -250 -350 C -320 -400 -380 -320 -380 -250 C -420 -150 -350 -100 -300 -120 C -220 -80 -180 -150 -120 -180 C -50 -150 50 -180 120 -240 C 180 -300 120 -380 50 -380 C -20 -420 -150 -420 -250 -350 Z" fill="#22C55E" stroke="#000" stroke-width="5"/>
        <!-- Trunk & Branches -->
        <path d="M 0 350 L -40 -120 L -180 -220 L -160 -240 L -20 -150 L -10 -300 L 20 -300 L 20 -140 L 100 -240 L 120 -220 L 40 -100 L 80 350 Z" fill="#92400E" stroke="#000" stroke-width="5"/>
      </g>
    \`;
  }

  renderModernLivingRoom(stickmanX = 640, stickmanY = 480) {
    // Modern room from Image 5 (Purple sofa, blazing ceiling sun lamp)
    return \`
      <!-- Wall: Off-white cream -->
      <rect width="1280" height="720" fill="#FDFBF7"/>
      <!-- Floor: Cream wood line -->
      <line x1="0" y1="580" x2="1280" y2="580" stroke="#000" stroke-width="4"/>

      <!-- Window with clouds and blue sky -->
      <rect x="760" y="160" width="140" height="200" fill="#BAE6FD" stroke="#000" stroke-width="4"/>
      <path d="M 800 240 Q 820 220 850 230 Q 880 220 890 240 Z" fill="#FFF"/>
      <line x1="760" y1="260" x2="900" y2="260" stroke="#000" stroke-width="3"/>

      <!-- Bookshelf on Right -->
      <rect x="940" y="260" width="120" height="320" fill="#1E3A8A" stroke="#000" stroke-width="4"/>
      <rect x="960" y="320" width="20" height="60" fill="#EF4444" stroke="#000" stroke-width="2"/>
      <rect x="985" y="310" width="25" height="70" fill="#10B981" stroke="#000" stroke-width="2"/>
      <rect x="1015" y="330" width="20" height="50" fill="#F59E0B" stroke="#000" stroke-width="2"/>

      <!-- Small Table with Lamp on Left -->
      <path d="M 120 440 L 260 440 L 250 580 L 230 580 L 240 460 L 140 460 L 150 580 L 130 580 Z" fill="#78350F" stroke="#000" stroke-width="3"/>
      <polygon points="190,340 160,400 220,400" fill="#10B981" stroke="#000" stroke-width="3"/>
      <line x1="190" y1="400" x2="190" y2="440" stroke="#000" stroke-width="3"/>

      <!-- Blazing Ceiling Sun Lamp (Image 5) -->
      <!-- Giant Sun Ray Burst -->
      <g>
        <line x1="640" y1="80" x2="200" y2="60" stroke="#FBBF24" stroke-width="7" stroke-linecap="round"/>
        <line x1="640" y1="80" x2="380" y2="15" stroke="#FBBF24" stroke-width="7" stroke-linecap="round"/>
        <line x1="640" y1="80" x2="520" y2="5" stroke="#FBBF24" stroke-width="7" stroke-linecap="round"/>
        <line x1="640" y1="80" x2="760" y2="5" stroke="#FBBF24" stroke-width="7" stroke-linecap="round"/>
        <line x1="640" y1="80" x2="900" y2="15" stroke="#FBBF24" stroke-width="7" stroke-linecap="round"/>
        <line x1="640" y1="80" x2="1080" y2="60" stroke="#FBBF24" stroke-width="7" stroke-linecap="round"/>
        <line x1="640" y1="80" x2="180" y2="150" stroke="#FBBF24" stroke-width="7" stroke-linecap="round"/>
        <line x1="640" y1="80" x2="1100" y2="150" stroke="#FBBF24" stroke-width="7" stroke-linecap="round"/>
        <line x1="640" y1="80" x2="320" y2="280" stroke="#FBBF24" stroke-width="7" stroke-linecap="round"/>
        <line x1="640" y1="80" x2="960" y2="280" stroke="#FBBF24" stroke-width="7" stroke-linecap="round"/>
        <line x1="640" y1="80" x2="480" y2="340" stroke="#FBBF24" stroke-width="7" stroke-linecap="round"/>
        <line x1="640" y1="80" x2="800" y2="340" stroke="#FBBF24" stroke-width="7" stroke-linecap="round"/>
      </g>
      <!-- Circular Ceiling Fixture -->
      <ellipse cx="640" cy="85" rx="140" ry="28" fill="#F59E0B" stroke="#000" stroke-width="5"/>
      <ellipse cx="640" cy="80" rx="130" ry="24" fill="#FEF08A" stroke="#000" stroke-width="4"/>

      <!-- Purple Sofa (Image 5) -->
      <g transform="translate(360, 380)">
        <!-- Backrest -->
        <rect x="0" y="0" width="560" height="180" rx="20" fill="#6366F1" stroke="#000" stroke-width="5"/>
        <!-- Seat Cushion -->
        <rect x="-20" y="110" width="600" height="90" rx="16" fill="#4F46E5" stroke="#000" stroke-width="5"/>
        <!-- Armrests -->
        <rect x="-40" y="70" width="50" height="130" rx="14" fill="#4338CA" stroke="#000" stroke-width="5"/>
        <rect x="550" y="70" width="50" height="130" rx="14" fill="#4338CA" stroke="#000" stroke-width="5"/>
      </g>
    \`;
  }

  renderCampfire(x, y, scale = 1.0) {
    return \`
      <g transform="translate(\${x}, \${y}) scale(\${scale})">
        <!-- Stones ring -->
        <ellipse cx="0" cy="20" rx="90" ry="30" fill="#334155" stroke="#000" stroke-width="4"/>
        <circle cx="-70" cy="18" r="16" fill="#475569" stroke="#000" stroke-width="3"/>
        <circle cx="-35" cy="28" r="18" fill="#64748B" stroke="#000" stroke-width="3"/>
        <circle cx="0" cy="32" r="19" fill="#475569" stroke="#000" stroke-width="3"/>
        <circle cx="35" cy="28" r="18" fill="#64748B" stroke="#000" stroke-width="3"/>
        <circle cx="70" cy="18" r="16" fill="#475569" stroke="#000" stroke-width="3"/>
        <!-- Fire logs -->
        <line x1="-50" y1="15" x2="50" y2="0" stroke="#78350F" stroke-width="12" stroke-linecap="round"/>
        <line x1="-40" y1="0" x2="45" y2="15" stroke="#78350F" stroke-width="12" stroke-linecap="round"/>
        <!-- Large Orange Flame -->
        <path d="M 0 10 Q -60 -40 -30 -90 Q 0 -60 0 -130 Q 20 -70 40 -80 Q 60 -30 0 10 Z" fill="#EA580C" stroke="#000" stroke-width="4"/>
        <!-- Inner Yellow Flame -->
        <path d="M 0 10 Q -35 -20 -15 -60 Q 0 -40 0 -90 Q 15 -45 25 -50 Q 35 -20 0 10 Z" fill="#FBBF24"/>
        <!-- Floating Embers -->
        <circle cx="-25" cy="-110" r="4" fill="#F97316"/>
        <circle cx="15" cy="-135" r="5" fill="#FBBF24"/>
        <circle cx="-10" cy="-160" r="3.5" fill="#F97316"/>
        <circle cx="30" cy="-105" r="4" fill="#FBBF24"/>
      </g>
    \`;
  }

  // ── MASTER BEAT SCENE BUILDER ──────────────────────────────────────────────
  buildSceneSVG(beat) {
    let backgroundHtml = '';
    let foregroundHtml = '';

    const bgType = beat.bgType || 'night_savanna';

    switch (bgType) {
      case 'night_savanna':
        // Image 2 style: Deep Navy Sky + Brown Earth
        backgroundHtml = \`
          <rect width="1280" height="720" fill="#1B2E58"/>
          <rect y="560" width="1280" height="160" fill="#7A4B24"/>
          <line x1="0" y1="560" x2="1280" y2="560" stroke="#000" stroke-width="4.5"/>
        \`;
        break;

      case 'tree_canopy':
        // Image 1 style: Dark blue sky, flat green grass, big cartoon tree
        backgroundHtml = \`
          <rect width="1280" height="720" fill="#1B2E58"/>
          <rect y="500" width="1280" height="220" fill="#16A34A"/>
          <line x1="0" y1="500" x2="1280" y2="500" stroke="#000" stroke-width="4.5"/>
          \${this.renderTree(820, 480, 1.25)}
        \`;
        break;

      case 'modern_room':
        // Image 5 style: Cream walls, giant ceiling sun lamp, purple sofa
        backgroundHtml = this.renderModernLivingRoom();
        break;

      case 'cave_interior':
        // Cave wall dark background with rocky arch
        backgroundHtml = \`
          <rect width="1280" height="720" fill="#0F172A"/>
          <!-- Cave mouth opening with star dots -->
          <path d="M 0 0 L 1280 0 L 1280 720 L 0 720 Z" fill="#1E293B"/>
          <path d="M 200 720 Q 250 180 640 160 Q 1050 180 1100 720 Z" fill="#090D16"/>
          <!-- Starry sky outside cave -->
          <circle cx="500" cy="260" r="2.5" fill="#FFF"/>
          <circle cx="680" cy="220" r="3" fill="#FFF"/>
          <circle cx="780" cy="300" r="2" fill="#FFF"/>
          <circle cx="420" cy="340" r="2.5" fill="#FFF"/>
          <!-- Cave floor -->
          <rect y="560" width="1280" height="160" fill="#334155"/>
          <line x1="0" y1="560" x2="1280" y2="560" stroke="#000" stroke-width="4.5"/>
        \`;
        break;

      case 'evolution_plain':
        // Image 4 style: Clean white minimalist background, bright green ground
        backgroundHtml = \`
          <rect width="1280" height="720" fill="#FFFFFF"/>
          <rect y="540" width="1280" height="180" fill="#22C55E"/>
          <line x1="0" y1="540" x2="1280" y2="540" stroke="#000" stroke-width="4.5"/>
        \`;
        break;

      case 'milky_way_void':
        // Pure dark blue with starry sky and full moon
        backgroundHtml = \`
          <rect width="1280" height="720" fill="#0A1128"/>
          <!-- Full Moon -->
          <circle cx="340" cy="180" r="60" fill="#FEF08A" stroke="#000" stroke-width="4"/>
          <!-- Stars -->
          <circle cx="120" cy="120" r="2.5" fill="#FFF"/><circle cx="200" cy="280" r="2" fill="#FFF"/>
          <circle cx="650" cy="90" r="3" fill="#FFF"/><circle cx="820" cy="160" r="2" fill="#FFF"/>
          <circle cx="950" cy="80" r="3.5" fill="#FFF"/><circle cx="1120" cy="220" r="2.5" fill="#FFF"/>
          <rect y="560" width="1280" height="160" fill="#1C1917"/>
          <line x1="0" y1="560" x2="1280" y2="560" stroke="#000" stroke-width="4.5"/>
        \`;
        break;
    }

    // ── FOREGROUND ACTORS & PROPS ──
    const sceneType = beat.sceneType || 'stickman_walking';

    switch (sceneType) {
      case 'stickman_tree_scared':
        // Image 1: Scared stickman in tree
        foregroundHtml = this.renderStickman(710, 240, 'climbing_tree', 'scared', 0.95);
        break;

      case 'predator_eyes_stalking':
        // Image 2: Deadpan walking stickman surrounded by 4 pairs of predator eyes
        foregroundHtml = \`
          \${this.renderPredatorEyes(360, 160, 0.95)}
          \${this.renderPredatorEyes(210, 310, 1.05)}
          \${this.renderPredatorEyes(840, 150, 0.95)}
          \${this.renderPredatorEyes(970, 300, 1.0)}
          \${this.renderStickman(640, 430, 'walking', 'deadpan', 1.05)}
        \`;
        break;

      case 'cornered_by_leopards':
        // Image 3: Stickman cornered by two spotted cartoon leopards
        foregroundHtml = \`
          \${this.renderCartoonLeopard(720, 280, 1.25, 'left')}
          \${this.renderStickman(640, 430, 'cornered_defensive', 'annoyed', 1.0)}
          \${this.renderCartoonLeopard(780, 410, 1.1, 'left')}
        \`;
        break;

      case 'monkey_evolution_line':
        // Image 4: Stickman walking behind 3 identical monkeys
        foregroundHtml = \`
          \${this.renderStickman(310, 410, 'walking', 'deadpan', 0.98)}
          \${this.renderCartoonMonkey(560, 340, 1.05)}
          \${this.renderCartoonMonkey(780, 340, 1.05)}
          \${this.renderCartoonMonkey(1000, 340, 1.05)}
        \`;
        break;

      case 'living_room_sun_lamp':
        // Image 5: Deadpan stickman sitting on sofa under blazing sun lamp
        foregroundHtml = this.renderStickman(640, 430, 'sitting_couch', 'deadpan', 1.05);
        break;

      case 'campfire_gathering':
        // Hunter gatherers around campfire
        foregroundHtml = \`
          \${this.renderStickman(420, 440, 'campfire_crouch', 'deadpan', 0.95)}
          \${this.renderCampfire(640, 500, 1.15)}
          <g transform="translate(860, 440) scale(-1, 1)">
            \${this.renderStickman(0, 0, 'campfire_crouch', 'deadpan', 0.95)}
          </g>
        \`;
        break;

      case 'sleeping_biphasic':
        // Stickman asleep on bed (first/second sleep)
        foregroundHtml = \`
          <!-- Bed frame & Straw mat -->
          <rect x="360" y="460" width="560" height="90" rx="10" fill="#B45309" stroke="#000" stroke-width="4"/>
          <rect x="380" y="440" width="520" height="40" rx="6" fill="#FEF08A" stroke="#000" stroke-width="3"/>
          <ellipse cx="440" cy="420" rx="55" ry="30" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          \${this.renderStickman(460, 460, 'lying_bed', 'sleeping', 1.0)}
          <!-- Blanket covering lower body -->
          <path d="M 520 420 L 890 420 L 890 490 L 520 490 Z" fill="#CBD5E1" stroke="#000" stroke-width="4"/>
        \`;
        break;

      case 'midnight_watch_awake':
        // Stickman sitting up in the dark, looking out at the stars
        foregroundHtml = \`
          <!-- Bed -->
          <rect x="300" y="480" width="500" height="80" rx="10" fill="#B45309" stroke="#000" stroke-width="4"/>
          \${this.renderStickman(520, 390, 'campfire_crouch', 'deadpan', 1.0)}
          <!-- Candle / small oil lamp -->
          <circle cx="750" cy="460" r="16" fill="#F59E0B"/>
          <path d="M 750 460 Q 740 435 750 420 Q 760 435 750 460 Z" fill="#FBBF24" stroke="#000" stroke-width="2"/>
          <text x="820" y="430" font-family="sans-serif" font-weight="bold" font-size="28" fill="#FCD34D">2:00 AM</text>
        \`;
        break;

      case 'lightswitch_flip':
        // Modern stickman with finger on light switch
        foregroundHtml = \`
          <!-- Wall -->
          <rect x="750" y="260" width="90" height="150" rx="10" fill="#F1F5F9" stroke="#000" stroke-width="4"/>
          <rect x="785" y="320" width="20" height="35" fill="#000"/>
          \${this.renderStickman(580, 430, 'walking', 'deadpan', 1.0)}
          <line x1="580" y1="360" x2="795" y2="335" stroke="#000" stroke-width="5" stroke-linecap="round"/>
        \`;
        break;

      default:
        foregroundHtml = this.renderStickman(640, 430, 'walking', 'deadpan', 1.05);
        break;
    }

    // Wrap in standard 1280x720 16:9 SVG
    return \`<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720" width="1280" height="720">
  <defs>
    <style>
      text { font-family: 'Plus Jakarta Sans', system-ui, -apple-system, sans-serif; }
    </style>
  </defs>
  <!-- Background Layer -->
  \${backgroundHtml}
  <!-- Foreground Actors & Props -->
  \${foregroundHtml}
</svg>
\`;
  }
}

module.exports = new ZennVectorEngine();
`;

fs.writeFileSync(targetPath, code, 'utf8');
console.log('✅ Zenn Vector Engine written to:', targetPath);
