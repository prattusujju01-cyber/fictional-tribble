const testUrls = [
  'https://asura-system.vercel.app/api/serve_project?slug=architectural-exports-in-sion-west',
  'https://asura-system.vercel.app/projects/architectural-exports-in-sion-west/index.html',
  'https://asura-system.vercel.app/api/serve_project?slug=all-smiles-dental-clinic-bangalore',
  'https://asura-system.vercel.app/projects/all-smiles-dental-clinic-bangalore/index.html',
  'https://asura-system.vercel.app/api/serve_project?slug=byob-restaurant-experience-in-gurgaon'
];

async function verify() {
  for (const u of testUrls) {
    console.log('\n--- VERIFYING ---');
    console.log('URL:', u);
    const separator = u.includes('?') ? '&' : '?';
    const res = await fetch(u + separator + '_t=' + Date.now());
    console.log('Status:', res.status);
    const html = await res.text();
    console.log('Length:', html.length);
    console.log('Has Pinwrap (Full Screen Hero):', html.includes('class="pinwrap"'));
    console.log('Photo chapters count:', (html.match(/class="ch"/g) || []).length);
    console.log('Has 0+ or 0k+ slop:', html.includes('0k+') || html.includes('0+ YEARS') || html.includes('0+ SMILES'));
    console.log('Has Neo-Clinic traces:', html.includes('neo-clinic') || html.includes('Surgical Ice Cyan'));
    console.log('Has RERA in Auto Detailing:', u.includes('architectural') && html.includes('RERA'));
    const h1 = (html.match(/<h1[\s\S]*?<\/h1>/) || [''])[0].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
    console.log('H1:', h1);
  }
}
verify().catch(console.error);
