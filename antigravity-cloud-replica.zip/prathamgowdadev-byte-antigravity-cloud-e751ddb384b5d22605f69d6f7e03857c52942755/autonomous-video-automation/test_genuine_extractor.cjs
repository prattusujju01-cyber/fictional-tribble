const FIRECRAWL_KEY = "fc-9580658b488a4455850b07c92bd7ed59";

function cleanBusinessName(rawTitle, niche, city) {
  if (!rawTitle) return null;

  let name = rawTitle
    .replace(/\s*[-|:]\s*(Yellow Pages|Facebook|Yelp|HomeAdvisor|Angi|BBB|MapQuest|Foursquare|Instagram|LinkedIn).*$/i, '')
    .replace(/\s*[-|:]\s*(Dentist|Dental Clinic|Roofer|Roofing|Plumber|Gym|Fitness|Lawyer|Attorney|Salon|Barbershop|Med Spa|Restaurant).*$/i, '')
    .replace(/\s*[-|:]\s*[A-Za-z\s,]+(?:TX|FL|CA|NY|IL|GA|AZ|CO|NV|NC|TN|WA)\s*(?:\d{5})?.*$/i, '')
    .replace(/\.{2,}/g, '')
    .trim();

  // Banned phrases
  const lower = name.toLowerCase();
  const banned = ['best 30', 'top 10', 'reviews for', 'recommendation', 'when a homeowner', 'how to', 'directory', 'discussion', 'near me', 'forum', 'classified', 'what are', 'has anyone'];
  for (const b of banned) {
    if (lower.includes(b)) return null;
  }

  if (name.length < 3 || name.length > 50) return null;
  return name;
}

async function testExtraction() {
  const query = `"Roofer" "Austin, TX" site:yellowpages.com "Phone"`;
  console.log("Searching Firecrawl for genuine businesses...");
  const res = await fetch("https://api.firecrawl.dev/v1/search", {
    method: "POST",
    headers: {
      "Authorization": `Bearer ${FIRECRAWL_KEY}`,
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ query: query, limit: 5 })
  });
  const data = await res.json();
  console.log("Results count:", data.data?.length);

  for (const item of data.data || []) {
    const rawTitle = item.title || "";
    const desc = item.description || "";
    const phoneMatch = desc.match(/(?:\+?1[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}/);
    
    // Address extraction regex
    const addrMatch = desc.match(/\d+\s+[A-Za-z0-9\s,.]+(?:St|Street|Ave|Avenue|Rd|Road|Blvd|Boulevard|Dr|Drive|Way|Hwy|Highway)[A-Za-z0-9\s,.]*(?:TX|FL|CA|NY|IL|GA|AZ|CO|NV|NC|TN|WA)\s*(?:\d{5})?/i);

    const cleanedName = cleanBusinessName(rawTitle, "Roofing", "Austin, TX");
    if (!cleanedName || !phoneMatch) continue;

    console.log("════════════════════════════════════════");
    console.log("GENUINE BUSINESS DETECTED:");
    console.log("Raw Title:   ", rawTitle);
    console.log("Clean Name:  ", cleanedName);
    console.log("Phone:       ", phoneMatch[0]);
    console.log("Address:     ", addrMatch ? addrMatch[0] : "Austin, TX");
    console.log("URL:         ", item.url);
  }
}

testExtraction();
