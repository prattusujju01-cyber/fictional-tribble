/**
 * ══════════════════════════════════════════════════════════════════════════════
 * GLOBAL 2D HISTORICAL DOCUMENTARY VISUAL ENGINE
 * ══════════════════════════════════════════════════════════════════════════════
 * Implements strict hand-drawn comic visual generation (Genius History Style):
 * - Aspect Ratio: 16:9 Landscape (1920x1080)
 * - Aesthetic: 2D hand-drawn line art, thick crisp ink outlines, flat color fills,
 *   clean ambient lighting, zero photorealism, subtle paper/parchment grain texture.
 * - 2D Image Prompt Formula:
 *   [Minimalist 2D hand-drawn art, bold black ink outlines, flat vector colors, simple expressive comic aesthetic, clean lighting] + [Exact Historical Subject & Action] + [Environment & Background] + [Wide-angle / Macro / Isometric View] + [--ar 16:9]
 * - Thumbnail Prompt Formula:
 *   [Detailed 2D architectural comic illustration, bold clean ink lines, flat matte color palette, dramatic perspective] + [Massive Historical Landmark/Hero Subject] + [Typography placeholder space with big bold serif text: "YOUR TEXT"] + [--ar 16:9]
 */

const fs = require('fs');
const path = require('path');

class HistoricalVisualEngine {
  constructor() {
    this.name = 'Hermes-HistoricalVisualEngine';
    this.version = '6.0.0';
    this.width = 1920;
    this.height = 1080;
  }

  generate2DImagePrompt(subjectAction, environment, view = 'Wide-angle panoramic view') {
    return `Minimalist 2D hand-drawn art, bold black ink outlines, flat vector colors, simple expressive comic aesthetic, clean lighting, ${subjectAction}, ${environment}, ${view}, --ar 16:9`;
  }

  generateThumbnailPrompt(landmarkSubject, titleText, perspective = 'Dramatic low-angle perspective') {
    return `Detailed 2D architectural comic illustration, bold clean ink lines, flat matte color palette, ${perspective}, ${landmarkSubject}, typography placeholder space with big bold serif text: "${titleText}", --ar 16:9`;
  }

  renderSceneVisual(beat, scenesDir) {
    const filenameJpg = `${beat.beatId}.jpg`;
    const filenameSvg = `${beat.beatId}.svg`;
    const jpgPath = path.join(scenesDir, filenameJpg);
    const svgPath = path.join(scenesDir, filenameSvg);

    // If a high-res 2D comic art JPG already exists, prioritize it
    if (fs.existsSync(jpgPath)) {
      return {
        filePath: jpgPath,
        relativePath: `assets/scenes/${filenameJpg}`,
        type: 'jpg'
      };
    }

    // Generate high-fidelity 2D comic vector artwork (Genius History aesthetic)
    const svgContent = this.buildHighFidelityComicSVG(beat);
    fs.writeFileSync(svgPath, svgContent, 'utf8');

    return {
      filePath: svgPath,
      relativePath: `assets/scenes/${filenameSvg}`,
      type: 'svg'
    };
  }

  buildHighFidelityComicSVG(beat) {
    const title = beat.sceneTitle || 'Ancient Egypt';
    const desc = beat.visualDescription || beat.narration || '';
    const prompt = beat.imagePrompt || this.generate2DImagePrompt(desc, 'Ancient Egypt', 'Wide-angle view');
    const beatNum = beat.beatIndex || 1;

    let skyColor = '#0F172A';
    let groundColor = '#D97706';

    if (beat.bgType && (beat.bgType.includes('karnak') || beat.bgType.includes('temple'))) {
      skyColor = '#FEF3C7';
      groundColor = '#B45309';
    } else if (beat.bgType && (beat.bgType.includes('aten') || beat.bgType.includes('sun_disc'))) {
      skyColor = '#0284C7';
      groundColor = '#EA580C';
    } else if (beat.bgType && (beat.bgType.includes('nile') || beat.bgType.includes('exodus'))) {
      skyColor = '#38BDF8';
      groundColor = '#0369A1';
    } else if (beat.bgType && (beat.bgType.includes('hittite') || beat.bgType.includes('war'))) {
      skyColor = '#450A0A';
      groundColor = '#7F1D1D';
    } else if (beat.bgType && (beat.bgType.includes('demolition') || beat.bgType.includes('tomb'))) {
      skyColor = '#1C1917';
      groundColor = '#78350F';
    }

    return `<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1920 1080" width="1920" height="1080">
  <defs>
    <filter id="parchmentTexture" x="0%" y="0%" width="100%" height="100%">
      <feTurbulence type="fractalNoise" baseFrequency="0.04" numOctaves="3" result="noise"/>
      <feColorMatrix type="matrix" values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 0.08 0"/>
      <feBlend in="SourceGraphic" in2="noise" mode="multiply"/>
    </filter>
    <linearGradient id="skyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
      <stop offset="0%" stop-color="${skyColor}"/>
      <stop offset="100%" stop-color="${groundColor}" stop-opacity="0.7"/>
    </linearGradient>
    <linearGradient id="atenSun" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#FEF08A"/>
      <stop offset="50%" stop-color="#FBBF24"/>
      <stop offset="100%" stop-color="#EA580C"/>
    </linearGradient>
  </defs>

  <rect width="1920" height="1080" fill="url(#skyGrad)"/>
  <rect width="1920" height="1080" fill="#FFFBEB" opacity="0.04" filter="url(#parchmentTexture)"/>

  <g stroke="#000000" stroke-width="6" stroke-linecap="round" stroke-linejoin="round">
    <path d="M 0 740 Q 480 680 960 720 Q 1440 660 1920 730 L 1920 1080 L 0 1080 Z" fill="#D97706"/>
    
    <rect x="180" y="240" width="260" height="600" fill="#B45309"/>
    <rect x="1480" y="240" width="260" height="600" fill="#B45309"/>
    <path d="M 140 240 Q 310 160 480 240 L 440 300 L 180 300 Z" fill="#92400E"/>
    <path d="M 1440 240 Q 1610 160 1780 240 L 1740 300 L 1480 300 Z" fill="#92400E"/>

    <g stroke="#78350F" stroke-width="4" fill="none">
      <circle cx="280" cy="400" r="28"/>
      <line x1="280" y1="428" x2="280" y2="480"/>
      <path d="M 250 450 L 310 450"/>
      <circle cx="1600" cy="400" r="28"/>
      <line x1="1600" y1="428" x2="1600" y2="480"/>
      <path d="M 1570 450 L 1630 450"/>
    </g>

    <g transform="translate(960, 320)">
      <circle cx="0" cy="0" r="140" fill="url(#atenSun)" stroke="#000" stroke-width="7"/>
      <g stroke="#FBBF24" stroke-width="5">
        <line x1="0" y1="140" x2="0" y2="340"/>
        <circle cx="0" cy="345" r="10" fill="#EA580C"/>
        <line x1="-100" y1="100" x2="-260" y2="280"/>
        <circle cx="-265" cy="285" r="10" fill="#EA580C"/>
        <line x1="100" y1="100" x2="260" y2="280"/>
        <circle cx="265" cy="285" r="10" fill="#EA580C"/>
        <line x1="-140" y1="0" x2="-360" y2="120"/>
        <circle cx="-365" cy="125" r="10" fill="#EA580C"/>
        <line x1="140" y1="0" x2="360" y2="120"/>
        <circle cx="365" cy="125" r="10" fill="#EA580C"/>
      </g>
    </g>

    <path d="M 520 1080 L 820 740 L 1100 740 L 1400 1080 Z" fill="#0284C7"/>
    <line x1="520" y1="1080" x2="820" y2="740" stroke="#000" stroke-width="6"/>
    <line x1="1400" y1="1080" x2="1100" y2="740" stroke="#000" stroke-width="6"/>

    <g transform="translate(960, 720)">
      <rect x="-180" y="80" width="360" height="60" fill="#F59E0B" stroke="#000" stroke-width="5"/>
      <path d="M -35 -40 Q 0 -130 35 -40 Z" fill="#2563EB" stroke="#000" stroke-width="5"/>
      <circle cx="0" cy="-20" r="32" fill="#FEF3C7" stroke="#000" stroke-width="4.5"/>
      <path d="M -30 20 L -45 110 L 45 110 L 30 20 Z" fill="#FFFFFF" stroke="#000" stroke-width="5"/>
      <path d="M -20 20 L 0 80 L 20 20 Z" fill="#F59E0B"/>
      <path d="M -25 20 Q -90 -30 -110 -80" stroke="#000" stroke-width="6" fill="none"/>
      <path d="M 25 20 Q 90 -30 110 -80" stroke="#000" stroke-width="6" fill="none"/>
    </g>
  </g>

  <g font-family="'Plus Jakarta Sans', sans-serif">
    <rect x="60" y="50" width="520" height="64" rx="10" fill="rgba(15, 23, 42, 0.85)" stroke="#334155" stroke-width="2"/>
    <text x="80" y="88" fill="#F59E0B" font-size="18" font-weight="700" letter-spacing="1">SCENE #${beatNum} // 2D COMIC TIMELINE</text>
    <text x="80" y="104" fill="#94A3B8" font-size="13">${title.toUpperCase()}</text>
  </g>
</svg>`;
  }
}

module.exports = new HistoricalVisualEngine();
