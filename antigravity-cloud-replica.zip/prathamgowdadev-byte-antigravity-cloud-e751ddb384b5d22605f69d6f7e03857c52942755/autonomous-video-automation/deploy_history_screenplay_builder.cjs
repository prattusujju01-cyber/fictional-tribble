const fs = require('fs');
const path = require('path');

const targetPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\utils\\historical-screenplay-builder.js';

const code = `/**
 * ══════════════════════════════════════════════════════════════════════════════
 * HISTORICAL SCREENPLAY BUILDER // 108 DEDICATED STATIC VISUAL BEATS (10+ MIN)
 * ══════════════════════════════════════════════════════════════════════════════
 * Topic: "Akhenaten: The Pharaoh Who Deleted The Gods"
 * Architecture:
 * - 24 Core Historical Narrative Scenes expanded into 108 micro-visual cuts (~5.5s each)
 * - 5 Full Chronological Chapters
 * - Authoritative, dramatic Male Explanatory Documentary Voiceover
 * - Instant static cuts (Zero zoom drift, Zero on-screen captions)
 */

function buildHistoricalDocumentaryScreenplay() {
  const chapters = [
    {
      chapterNumber: 1,
      chapterTitle: "The Spark & Humble Origins",
      scenes: [
        {
          sceneNumber: 1,
          sceneTitle: "The City of a Thousand Idols",
          beats: [
            {
              bgType: "egyptian_temple_karnak",
              characterPose: "priests_weighing_gold",
              expression: "smug_curious",
              narration: "For two thousand years, ancient Egypt lived under the shadow of a thousand gods.",
              visual: "Towering sandstone temple pylons at Karnak with golden statues of falcon Horus and jackal Anubis."
            },
            {
              bgType: "egyptian_temple_karnak",
              characterPose: "priests_counting_tribute",
              expression: "smug_curious",
              narration: "Jackal-headed Anubis weighed the souls of the dead. But above them all stood Amun-Ra: King of the Gods.",
              visual: "Bald Egyptian high priests in white pleated linen kilts weighing piles of gold ingots on bronze scales."
            },
            {
              bgType: "egyptian_temple_karnak",
              characterPose: "priests_counting_tribute",
              expression: "deadpan",
              narration: "And behind Amun stood a corrupt priesthood that owned more land, more cattle, and more gold than the crown.",
              visual: "Lines of priests inspecting tribute carts overflowing with grain, wine amphorae, and silver bullion."
            },
            {
              bgType: "egyptian_temple_karnak",
              characterPose: "pharaoh_watching_priests",
              expression: "annoyed",
              narration: "Until one sickly young prince decided that eternity had lasted long enough.",
              visual: "Young Amenhotep IV standing in the shadow of a giant column, watching the arrogant priests with cold fury."
            }
          ]
        },
        {
          sceneNumber: 2,
          sceneTitle: "The Prince in the Shadows",
          beats: [
            {
              bgType: "royal_palace_garden",
              characterPose: "prince_thutmose_chariot",
              expression: "grinning",
              narration: "His birth name was Amenhotep IV. He was never intended to inherit the Double Crown of Egypt.",
              visual: "The muscular older brother Prince Thutmose galloping on a golden chariot, celebrated by cheering crowds."
            },
            {
              bgType: "royal_palace_garden",
              characterPose: "tomb_elder_prince",
              expression: "shocked",
              narration: "His older brother Thutmose was the golden heir—until he abruptly died of a mysterious childhood illness.",
              visual: "A royal funeral sarcophagus being closed as funeral incense curls upward in the dark tomb."
            },
            {
              bgType: "royal_palace_garden",
              characterPose: "isolated_prince_lotus",
              expression: "deadpan",
              narration: "That left Amenhotep: an unusual, brooding prince with an elongated face, narrow chest, and spindly limbs.",
              visual: "Amenhotep standing alone beside a palace lotus pond, frail and introspective, shunned by the military elites."
            },
            {
              bgType: "royal_palace_garden",
              characterPose: "staring_at_sun_solitary",
              expression: "awe_wonder",
              narration: "While courtiers worshipped sacred bulls, the prince retreated into solitude, staring unblinkingly at the desert sun.",
              visual: "Close-up of the young prince's kohl-rimmed eyes reflecting the blinding yellow radiance of the noonday sun."
            }
          ]
        },
        {
          sceneNumber: 3,
          sceneTitle: "Coronation and the Quiet Heresy",
          beats: [
            {
              bgType: "coronation_terrace_thebes",
              characterPose: "crowned_pharaoh_refusing",
              expression: "deadpan",
              narration: "In 1353 BC, his father passed away, and the crown of Upper and Lower Egypt was placed upon his head.",
              visual: "Grand coronation on the stone terrace of Thebes; the blue Khepresh crown lowered onto Amenhotep IV."
            },
            {
              bgType: "coronation_terrace_thebes",
              characterPose: "turning_back_on_altar",
              expression: "determined",
              narration: "The high priests gathered at Karnak expecting lavish sacrifices. But the new Pharaoh did not bow.",
              visual: "The new Pharaoh turning his back completely on the statue of Amun, walking out of the dark sanctuary."
            },
            {
              bgType: "coronation_terrace_thebes",
              characterPose: "pointing_to_sky_proclamation",
              expression: "determined",
              narration: "He announced an edict that terrified the court: Amun is not the creator. The old beast-gods are dead stone.",
              visual: "Akhenaten pointing his golden staff straight up toward the sun as bald priests drop their offerings in horror."
            },
            {
              bgType: "coronation_terrace_thebes",
              characterPose: "pointing_to_sky_proclamation",
              expression: "awe_wonder",
              narration: "There is only one true life-giver in the cosmos: the Aten—the blinding light of the solar disc.",
              visual: "A brilliant golden halo breaking over the temple roof, casting long dramatic shadows across the panicked priests."
            }
          ]
        },
        {
          sceneNumber: 4,
          sceneTitle: "The Revelation of the Aten",
          beats: [
            {
              bgType: "cosmic_aten_revelation",
              characterPose: "aten_sun_disc_radiant",
              expression: "awe_wonder",
              narration: "The god he declared was unlike anything the ancient world had ever conceived.",
              visual: "A colossal golden sun disc suspended in a deep cosmic blue sky, radiating dozens of geometric light beams."
            },
            {
              bgType: "cosmic_aten_revelation",
              characterPose: "aten_hands_ankh",
              expression: "awe_wonder",
              narration: "Not a man with a falcon head or an animal idol, but the physical disc of the sun itself.",
              visual: "Close-up of golden solar rays terminating in tiny delicate human hands holding the ankh breath-of-life cross."
            },
            {
              bgType: "cosmic_aten_revelation",
              characterPose: "pharaoh_nefertiti_blessed",
              expression: "peaceful",
              narration: "Each ray ended in a hand touching the lips of Pharaoh and Queen Nefertiti.",
              visual: "The royal couple standing hand-in-hand as divine hands gently place ankh crosses against their mouths."
            },
            {
              bgType: "cosmic_aten_revelation",
              characterPose: "pharaoh_nefertiti_blessed",
              expression: "smug_curious",
              narration: "The political message was absolute: you no longer need priests or temples. You only need me.",
              visual: "Akhenaten standing supreme between heaven and earth while the entire kingdom kneels beneath the light."
            }
          ]
        }
      ]
    },
    {
      chapterNumber: 2,
      chapterTitle: "The Crucible of War & Expansion",
      scenes: [
        {
          sceneNumber: 5,
          sceneTitle: "The Chisel of Damnation",
          beats: [
            {
              bgType: "temple_desecration_scaffold",
              characterPose: "masons_hacking_names",
              expression: "determined",
              narration: "The Pharaoh cast off his birth name and became Akhenaten: 'Effective for the Sun Disc.'",
              visual: "Akhenaten signing his new cartouche in red ink on royal papyrus scrolls surrounded by guards."
            },
            {
              bgType: "temple_desecration_scaffold",
              characterPose: "bronze_chisels_flying_dust",
              expression: "determined",
              narration: "Then, he unleashed a cultural blitzkrieg across Egypt. Royal chisel squads were dispatched to every city.",
              visual: "Teams of stonemasons on tall wooden scaffolds furiously hammering bronze chisels into carved temple pylons."
            },
            {
              bgType: "temple_desecration_scaffold",
              characterPose: "shattering_granite_statues",
              expression: "shocked",
              narration: "They smashed the name of Amun off obelisks, hacked down ancient shrines, and looted sacred treasures.",
              visual: "Giant granite statues of ram-headed Amun toppling from stone pedestals, shattering into flying debris."
            },
            {
              bgType: "temple_desecration_scaffold",
              characterPose: "shattering_granite_statues",
              expression: "scared",
              narration: "Even private family tombs were invaded. Two thousand years of sacred Egyptian heritage were obliterated.",
              visual: "Soldiers scraping hieroglyphic names off family tomb stelae by torchlight as weeping relatives watch helplessly."
            }
          ]
        },
        {
          sceneNumber: 6,
          sceneTitle: "Exodus into the Barren Waste",
          beats: [
            {
              bgType: "nile_exodus_flotilla",
              characterPose: "pharaoh_chariot_barge",
              expression: "determined",
              narration: "The old capital of Thebes was tainted by false gods. Akhenaten declared he would never look upon it again.",
              visual: "The Pharaoh standing at the gilded prow of a royal barge sailing away from the smoking temples of Thebes."
            },
            {
              bgType: "nile_exodus_flotilla",
              characterPose: "thousands_marching_barges",
              expression: "deadpan",
              narration: "In the fifth year of his reign, he ordered thirty thousand soldiers, architects, and artisans into exile.",
              visual: "A colossal flotilla of hundreds of wooden Nile barges carrying families, cattle, and building stones north."
            },
            {
              bgType: "nile_exodus_flotilla",
              characterPose: "unloading_desert_cliffs",
              expression: "exhausted",
              narration: "They sailed two hundred miles north into an uninhabited desert plain flanked by towering limestone cliffs.",
              visual: "Laborers hauling wooden sleds loaded with supplies off barges onto raw orange desert mudbanks."
            },
            {
              bgType: "nile_exodus_flotilla",
              characterPose: "unloading_desert_cliffs",
              expression: "awe_wonder",
              narration: "A clean slate in the desert sand, belonging to no existing deity, tribe, or faction.",
              visual: "Vast empty desert gap framed by white bluffs, with the blazing yellow sun rising over the eastern horizon."
            }
          ]
        },
        {
          sceneNumber: 7,
          sceneTitle: "The Four Boundary Stelae",
          beats: [
            {
              bgType: "limestone_boundary_cliff",
              characterPose: "carving_boundary_stele",
              expression: "determined",
              narration: "Here, in the desert of modern Amarna, Akhenaten marked his holy perimeter.",
              visual: "Artisans carving massive thirty-foot boundary tablets directly into the vertical limestone cliff faces."
            },
            {
              bgType: "limestone_boundary_cliff",
              characterPose: "pharaoh_swearing_oath",
              expression: "determined",
              narration: "Sixteen colossal boundary stelae were chiseled into the rock, enclosing fifty square miles of sand.",
              visual: "Akhenaten raising his golden spear before a giant carved monument, surrounded by his royal bodyguard."
            },
            {
              bgType: "limestone_boundary_cliff",
              characterPose: "pharaoh_swearing_oath",
              expression: "determined",
              narration: "On these stones, he swore an unbreakable vow: he would build Akhetaten, the 'Horizon of the Sun Disc.'",
              visual: "Close-up of hieroglyphic text being carved into limestone: 'I shall not pass beyond the southern boundary.'."
            },
            {
              bgType: "limestone_boundary_cliff",
              characterPose: "pharaoh_swearing_oath",
              expression: "smug_curious",
              narration: "And no matter what crisis struck Egypt, he swore he would never cross those boundaries until he died.",
              visual: "Akhenaten looking out over the desert valley from the cliff precipice, sealing his own geographical prison."
            }
          ]
        },
        {
          sceneNumber: 8,
          sceneTitle: "The Miracle of Amarna (Akhetaten)",
          beats: [
            {
              bgType: "amarna_construction_rise",
              characterPose: "laying_talatat_blocks",
              expression: "determined",
              narration: "To build a capital overnight, his architects invented rapid modular construction: the Talatat blocks.",
              visual: "Masons quickly stacking standardized two-foot limestone blocks with mortar, erecting walls at record speed."
            },
            {
              bgType: "amarna_construction_rise",
              characterPose: "roofless_temple_courtyards",
              expression: "awe_wonder",
              narration: "Traditional temples were dark stone caves. Akhenaten did the unthinkable: he built his temples completely roofless.",
              visual: "Vast white limestone temples with open blue skies above, revealing hundreds of open-air offering altars."
            },
            {
              bgType: "amarna_construction_rise",
              characterPose: "roofless_temple_courtyards",
              expression: "awe_wonder",
              narration: "Every slab of meat, every pomegranate, and every loaf of bread baked directly under the raw heat of the sun.",
              visual: "Hundreds of stone tables heaped with roasted ducks, grapes, and honeycomb roasting in blinding sunlight."
            },
            {
              bgType: "amarna_construction_rise",
              characterPose: "white_city_shining",
              expression: "peaceful",
              narration: "Within just two years, a glittering white city arose from the barren sands like a mirage.",
              visual: "Panoramic vista of the gleaming whitewashed desert metropolis with royal avenues and swaying green palms."
            }
          ]
        },
        {
          sceneNumber: 9,
          sceneTitle: "The Art Revolution: Distorted Flesh",
          beats: [
            {
              bgType: "amarna_art_studio",
              characterPose: "carving_elongated_skull",
              expression: "inspired",
              narration: "Inside the royal workshops, Akhenaten demolished fifteen hundred years of artistic dogma.",
              visual: "Sculptors carving limestone statues with strange curved silhouettes instead of rigid boxy figures."
            },
            {
              bgType: "amarna_art_studio",
              characterPose: "carving_elongated_skull",
              expression: "smug_curious",
              narration: "Pharaohs had always been depicted as flawless muscle-bound gods. Akhenaten ordered brutal, bizarre honesty.",
              visual: "Relief carving showing the Pharaoh with a sagging potbelly, thick thighs, spindly arms, and a long alien skull."
            },
            {
              bgType: "amarna_art_studio",
              characterPose: "intimate_family_carving",
              expression: "peaceful",
              narration: "He had himself carved kissing Queen Nefertiti and bouncing his giggling infant daughters on his knee.",
              visual: "A tender royal family relief showing Akhenaten and Nefertiti laughing together under the benevolent sun rays."
            },
            {
              bgType: "amarna_art_studio",
              characterPose: "intimate_family_carving",
              expression: "awe_wonder",
              narration: "For the first time in human history, royal power was portrayed not with cold terror, but with intimate warmth.",
              visual: "Close-up of the delicate limestone carving of Nefertiti smiling softly as rays of Aten touch her crown."
            }
          ]
        }
      ]
    },
    {
      chapterNumber: 3,
      chapterTitle: "The Golden Zenith & Peak Civilization",
      scenes: [
        {
          sceneNumber: 10,
          sceneTitle: "The Sun-Drenched Paradise",
          beats: [
            {
              bgType: "amarna_grand_avenue",
              characterPose: "morning_trumpets_dawn",
              expression: "awe_wonder",
              narration: "By the tenth year of his reign, Akhetaten had swelled to fifty thousand residents.",
              visual: "Bronze trumpeters in white linen sounding horns from the city gate towers at the first crimson blush of dawn."
            },
            {
              bgType: "amarna_grand_avenue",
              characterPose: "incense_clouds_rising",
              expression: "peaceful",
              narration: "Every single morning, three hundred open-air cauldrons ignited frankincense across the royal boulevard.",
              visual: "Columns of fragrant white incense smoke rising into a cloudless turquoise Egyptian sky."
            },
            {
              bgType: "amarna_grand_avenue",
              characterPose: "chariot_procession_gold",
              expression: "grinning",
              narration: "The Pharaoh and his queen rode side-by-side in matching chariots of electrum, escorted by Nubian runners.",
              visual: "Akhenaten and Nefertiti racing gleaming gold chariots down the broad avenue, wheels kicking up golden dust."
            },
            {
              bgType: "amarna_grand_avenue",
              characterPose: "citizens_prostrating_sand",
              expression: "awe_wonder",
              narration: "To those who walked its gleaming stone paths, it truly felt like a heaven on Earth had arrived.",
              visual: "Crowds of citizens with upraised hands prostrating in joy as the royal procession passes under the blazing sun."
            }
          ]
        },
        {
          sceneNumber: 11,
          sceneTitle: "The Great Hymn to the Aten",
          beats: [
            {
              bgType: "royal_palace_balcony",
              characterPose: "pharaoh_chanting_hymn",
              expression: "inspired",
              narration: "From the palace balcony, Akhenaten sang his literary masterpiece: The Great Hymn to the Sun.",
              visual: "The Pharaoh standing in flowing linen robes with outstretched arms, reciting poetry from the gilded balcony."
            },
            {
              bgType: "royal_palace_balcony",
              characterPose: "pharaoh_chanting_hymn",
              expression: "inspired",
              narration: "'When thou settest in the western horizon, the Earth is in darkness as if in death.'",
              visual: "The burning orange sun dipping below desert dunes while wild beasts stir in the darkness."
            },
            {
              bgType: "royal_palace_balcony",
              characterPose: "tossing_gold_collars",
              expression: "grinning",
              narration: "Scholars recognize these verses as the intellectual predecessor to Psalm 104 in the Hebrew Bible.",
              visual: "Akhenaten smiling triumphantly, showering golden necklaces and carnelian beads down on his loyal viziers."
            },
            {
              bgType: "royal_palace_balcony",
              characterPose: "sole_prophet_mandate",
              expression: "smug_curious",
              narration: "Yet the hymn carried a ruthless warning: 'None knoweth Thee save Thy son, Akhenaten.'",
              visual: "The Pharaoh's silhouette dominating the sky, claiming an absolute spiritual monopoly over all mankind."
            }
          ]
        },
        {
          sceneNumber: 12,
          sceneTitle: "Queen Nefertiti: Power Behind the Disc",
          beats: [
            {
              bgType: "nefertiti_throne_terrace",
              characterPose: "wearing_blue_crown",
              expression: "determined",
              narration: "Beside the Pharaoh stood the most formidable woman in antiquity: Queen Nefertiti.",
              visual: "Nefertiti in her iconic tall flat-topped blue crown and heavy gold collar, standing on the palace dais."
            },
            {
              bgType: "nefertiti_throne_terrace",
              characterPose: "steering_war_chariot",
              expression: "determined",
              narration: "She was no quiet queen. Amarna's reliefs depict her driving her own war chariot through the city streets.",
              visual: "Nefertiti gripping leather reins, hair ribbons fluttering behind her as her chariot charges forward."
            },
            {
              bgType: "nefertiti_throne_terrace",
              characterPose: "smiting_foreign_captives",
              expression: "determined",
              narration: "Temple carvings even show her raising a mace to smite foreign prisoners—a privilege reserved solely for Kings.",
              visual: "Carved temple wall showing Nefertiti holding a captured enemy by the hair with raised royal mace."
            },
            {
              bgType: "nefertiti_throne_terrace",
              characterPose: "smiting_foreign_captives",
              expression: "smug_curious",
              narration: "Some historians believe she co-ruled Egypt as an equal, pulling the strings of the entire empire.",
              visual: "Nefertiti and Akhenaten seated on dual golden thrones, their crowns level with one another."
            }
          ]
        },
        {
          sceneNumber: 13,
          sceneTitle: "A World of Gold and Glass",
          beats: [
            {
              bgType: "glass_faience_workshop",
              characterPose: "blowing_cobalt_glass",
              expression: "focused",
              narration: "Amarna became the glittering creative heart of the eastern Mediterranean world.",
              visual: "Egyptian glassblowers shaping molten cobalt blue and turquoise glass bottles over roaring charcoal furnaces."
            },
            {
              bgType: "glass_faience_workshop",
              characterPose: "painting_palace_floor",
              expression: "focused",
              narration: "Artisans painted palace floors with hyper-realistic murals of calves leaping through papyrus reeds.",
              visual: "Painter kneeling with fine horsehair brush painting vibrant swimming carp and flying ducks on wet plaster."
            },
            {
              bgType: "glass_faience_workshop",
              characterPose: "sculptor_thutmose_studio",
              expression: "inspired",
              narration: "Master sculptor Thutmose carved portrait busts so lifelike they looked ready to whisper from the stone.",
              visual: "The famous polychrome bust of Nefertiti sitting on Thutmose's workbench bathed in soft window sunlight."
            },
            {
              bgType: "glass_faience_workshop",
              characterPose: "sculptor_thutmose_studio",
              expression: "awe_wonder",
              narration: "It was an explosion of color, poetry, and beauty that seemed destined to conquer the future.",
              visual: "Glittering faience tiles, gold bracelets, and painted pottery jars displayed in an open market stall."
            }
          ]
        },
        {
          sceneNumber: 14,
          sceneTitle: "The Mirage of Perfection",
          beats: [
            {
              bgType: "desert_quarry_laborers",
              characterPose: "laborers_crushed_blocks",
              expression: "exhausted",
              narration: "Yet the golden paradise of Amarna was a rotting mirage built on human sacrifice.",
              visual: "Sunken quarry trench where emaciated workers with hunched spines pull colossal limestone blocks."
            },
            {
              bgType: "desert_quarry_laborers",
              characterPose: "laborers_crushed_blocks",
              expression: "scared",
              narration: "While the royal court drank wine in perfumed villas, the common laborers lived behind barbed mud enclosures.",
              visual: "Barren mudbrick worker village enclosed by high walls, armed sentries watching from stone posts."
            },
            {
              bgType: "desert_quarry_laborers",
              characterPose: "forensic_skeletons_anemia",
              expression: "shocked",
              narration: "Modern forensic digs revealed that 75% of teenager skeletons at Amarna suffered from severe spinal fractures and anemia.",
              visual: "A shallow sand grave revealing fractured juvenile bones covered in rough woven reed mats."
            },
            {
              bgType: "desert_quarry_laborers",
              characterPose: "forensic_skeletons_anemia",
              expression: "annoyed",
              narration: "The Sun God's city was drinking the blood of its children—and outside the cliffs, the storm was breaking.",
              visual: "A dark dust storm gathering on the jagged cliff horizon as exhausted workers look up in weary despair."
            }
          ]
        }
      ]
    },
    {
      chapterNumber: 4,
      chapterTitle: "Corruption, Betrayal & Rot",
      scenes: [
        {
          sceneNumber: 15,
          sceneTitle: "The Unopened Diplomatic Tablets",
          beats: [
            {
              bgType: "cuneiform_archive_dust",
              characterPose: "messenger_collapsing_scrolls",
              expression: "scared",
              narration: "While the Pharaoh worshipped the sun, Egypt's vast international empire was rapidly collapsing.",
              visual: "A bloodied messenger on exhausted horse collapsing onto the stone threshold of the Amarna archive."
            },
            {
              bgType: "cuneiform_archive_dust",
              characterPose: "cuneiform_tablets_dusty",
              expression: "deadpan",
              narration: "Inside the royal records room sat nearly four hundred clay cuneiform tablets: the famous Amarna Letters.",
              visual: "Wooden cedar racks stacked with rows of baked clay tablets etched with dense Akkadian cuneiform."
            },
            {
              bgType: "cuneiform_archive_dust",
              characterPose: "cuneiform_tablets_dusty",
              expression: "scared",
              narration: "Vassal kings in Canaan and Syria screamed for help: 'War is upon us! Send archers, or the kingdom is lost!'",
              visual: "Close-up of a cracked clay tablet showing desperate inscriptions: 'The desert raiders are taking our cities!'."
            },
            {
              bgType: "cuneiform_archive_dust",
              characterPose: "tablets_abandoned_cobwebs",
              expression: "annoyed",
              narration: "Akhenaten never replied. He never sent a single chariot. The letters were simply filed away to rot in the dust.",
              visual: "Cobwebs stretching across the unopened diplomatic tablets as sand blows across the archive floor."
            }
          ]
        },
        {
          sceneNumber: 16,
          sceneTitle: "The Hittite Wolf at the Border",
          beats: [
            {
              bgType: "hittite_invasion_plain",
              characterPose: "hittite_chariots_charging",
              expression: "determined",
              narration: "Sensing the Pharaoh's complete military detachment, Egypt's fiercest rival struck without mercy.",
              visual: "King Suppiluliuma of the Hittites in bronze armor commanding armies of heavy battle chariots."
            },
            {
              bgType: "hittite_invasion_plain",
              characterPose: "egyptian_garrisons_burning",
              expression: "shocked",
              narration: "The Hittite war machine marched through northern Syria, overrunning Egyptian outposts and burning fortresses.",
              visual: "Egyptian garrisons in flames as Hittite three-man chariots crush spearmen under galloping horses."
            },
            {
              bgType: "hittite_invasion_plain",
              characterPose: "generals_muttering_treason",
              expression: "annoyed",
              narration: "Centuries of military conquest won by Thutmose III vanished into ash in less than five years.",
              visual: "Maps of the Levant on military tables with red crosses marking fallen cities from Damascus to Byblos."
            },
            {
              bgType: "hittite_invasion_plain",
              characterPose: "generals_muttering_treason",
              expression: "annoyed",
              narration: "In the military barracks of Memphis, Egyptian generals watched their empire bleed—and began plotting treason.",
              visual: "General Horemheb tightening his bronze bracers, staring south toward Amarna with cold murderous hatred."
            }
          ]
        },
        {
          sceneNumber: 17,
          sceneTitle: "The Dust of Famine and Plague",
          beats: [
            {
              bgType: "plague_palace_chambers",
              characterPose: "coughing_plague_dust",
              expression: "scared",
              narration: "Then, the wrath of biology struck. Around 1340 BC, an apocalyptic pandemic invaded the desert city.",
              visual: "Sick citizens in ragged kilts coughing into cloths as dry desert wind whips dust through the streets."
            },
            {
              bgType: "plague_palace_chambers",
              characterPose: "royal_daughters_dying",
              expression: "scared",
              narration: "Likely tularemia carried by Mediterranean trade ships, the disease infiltrated the royal apartments.",
              visual: "Royal physicians burning pungent sage and applying crushed herbs to a feverish young princess."
            },
            {
              bgType: "plague_palace_chambers",
              characterPose: "weeping_over_burial_bier",
              expression: "shocked",
              narration: "Within months, three of Akhenaten's young daughters died. His revered mother, Queen Tiye, perished.",
              visual: "The Pharaoh on his knees clutching the limp hand of his daughter draped in a white linen shroud."
            },
            {
              bgType: "plague_palace_chambers",
              characterPose: "silent_desert_shadows",
              expression: "shocked",
              narration: "The cheerful carvings of laughing children stopped forever. A grim, terrifying silence choked the palaces.",
              visual: "Empty palace courtyards with flickering torches casting long eerie shadows on deserted stone colonnades."
            }
          ]
        },
        {
          sceneNumber: 18,
          sceneTitle: "The Disappearance of the Queen",
          beats: [
            {
              bgType: "empty_nefertiti_palace",
              characterPose: "nefertiti_portrait_fading",
              expression: "shocked",
              narration: "And then came the most baffling mystery in Egyptian history: Queen Nefertiti vanished without a trace.",
              visual: "A painted wall portrait of Nefertiti slowly obscured by blowing sheets of fine sand."
            },
            {
              bgType: "empty_nefertiti_palace",
              characterPose: "chiseled_away_queen_relief",
              expression: "shocked",
              narration: "In the fourteenth year of his reign, her name and image disappear completely from official royal records.",
              visual: "A temple relief where Nefertiti's face and cartouche have been roughly chiseled off with iron picks."
            },
            {
              bgType: "empty_nefertiti_palace",
              characterPose: "theories_of_disappearance",
              expression: "smug_curious",
              narration: "Did she succumb to the plague? Was she murdered in a palace coup? Or did she assume a male alter-ego to rule?",
              visual: "A shadowy figure in a Pharaoh's golden crown stepping out of the palace shadows into moonlight."
            },
            {
              bgType: "empty_nefertiti_palace",
              characterPose: "alone_in_empty_hall",
              expression: "deadpan",
              narration: "Whatever her fate, Akhenaten was left utterly alone in the blinding white glare of his ghost city.",
              visual: "The lone Pharaoh sitting on his stone throne in an echoing empty great hall with no queen beside him."
            }
          ]
        },
        {
          sceneNumber: 19,
          sceneTitle: "The Emperor's Mad Delusion",
          beats: [
            {
              bgType: "desert_temple_solitude",
              characterPose: "emaciated_pharaoh_pacing",
              expression: "scared",
              narration: "Consumed by grief, paranoia, and religious obsession, the Pharaoh descended into complete madness.",
              visual: "An emaciated, hollow-cheeked Akhenaten in stained linen pacing frantically around an altar."
            },
            {
              bgType: "desert_temple_solitude",
              characterPose: "refusing_generals_pleas",
              expression: "annoyed",
              narration: "He refused to see his generals. He ignored the collapse of trade. He barred the city gates to outsiders.",
              visual: "Guards slamming heavy wooden bronze-studded gates shut against kneeling envoys from Memphis."
            },
            {
              bgType: "desert_temple_solitude",
              characterPose: "screaming_at_silent_sun",
              expression: "shocked",
              narration: "Sand dunes began piling up in the temple hallways, but the Pharaoh remained in the open sun, screaming his prayers.",
              visual: "Sand blowing across the marble floors while the mad Pharaoh shakes his fists toward the sky."
            },
            {
              bgType: "desert_temple_solitude",
              characterPose: "screaming_at_silent_sun",
              expression: "scared",
              narration: "He had built a city for a god that could not hear, could not speak, and could not save him.",
              visual: "High bird's-eye view of the Pharaoh looking like a tiny ant trapped in the center of the vast desert expanse."
            }
          ]
        }
      ]
    },
    {
      chapterNumber: 5,
      chapterTitle: "Collapse & Enduring Legacy",
      scenes: [
        {
          sceneNumber: 20,
          sceneTitle: "Death in the Desert Palace",
          beats: [
            {
              bgType: "royal_wadi_tomb",
              characterPose: "deathbed_pharaoh_silent",
              expression: "peaceful",
              narration: "In 1336 BC, in the seventeenth year of his reign, Akhenaten drew his last breath at just thirty-five years old.",
              visual: "The dying Pharaoh lying on an ebony bed, his sunken eyes closing as sunset fades into night."
            },
            {
              bgType: "royal_wadi_tomb",
              characterPose: "sealing_desert_tomb",
              expression: "deadpan",
              narration: "He was hurriedly entombed in an unfinished rock-cut vault deep in the desolate Royal Wadi east of the city.",
              visual: "Priests carrying a plain gold-plated coffin into the dark narrow mouth of a canyon tomb."
            },
            {
              bgType: "royal_wadi_tomb",
              characterPose: "sealing_desert_tomb",
              expression: "deadpan",
              narration: "The moment the stone door slammed shut, a deathly silence fell over the city of Akhetaten.",
              visual: "Four workers using levers to seal a massive square limestone boulder across the tomb entrance."
            },
            {
              bgType: "royal_wadi_tomb",
              characterPose: "the_vengeance_awakens",
              expression: "determined",
              narration: "The sun experiment was finished. The counter-revolution was about to strike with apocalyptic fury.",
              visual: "Torches lighting up in the dark across the Nile as the old priesthood prepares to march."
            }
          ]
        },
        {
          sceneNumber: 21,
          sceneTitle: "The Return to Thebes & The Boy King",
          beats: [
            {
              bgType: "theban_restoration_throne",
              characterPose: "boy_king_tutankhamun",
              expression: "scared",
              narration: "The crown fell upon a nine-year-old boy: Prince Tutankhaten—'The Living Image of the Sun Disc.'",
              visual: "A frightened nine-year-old boy sitting on an enormous golden throne in oversized ceremonial robes."
            },
            {
              bgType: "theban_restoration_throne",
              characterPose: "horemheb_commanding_boy",
              expression: "determined",
              narration: "The child held no power. General Horemheb and the vizier Ay forced him to change his name to Tutankhamun.",
              visual: "The imposing General Horemheb towering over the child king, holding a papyrus decree of restoration."
            },
            {
              bgType: "theban_restoration_throne",
              characterPose: "abandoning_amarna_forever",
              expression: "determined",
              narration: "Amun was reinstated as King of the Gods. The royal court packed its baggage and abandoned Amarna forever.",
              visual: "Thousands of citizens marching away from the white city, leaving empty streets to the howling desert wind."
            },
            {
              bgType: "theban_restoration_throne",
              characterPose: "abandoning_amarna_forever",
              expression: "deadpan",
              narration: "The desert moved in immediately. Golden sand dunes spilled into living rooms and swallowed courtyards whole.",
              visual: "Sand pouring like waterfalls through palace windows, burying tiled floors in deep orange drifts."
            }
          ]
        },
        {
          sceneNumber: 22,
          sceneTitle: "The Great Dismantling",
          beats: [
            {
              bgType: "demolition_of_amarna",
              characterPose: "sledgehammer_squads_toppling",
              expression: "determined",
              narration: "Once the city stood empty, the revenge of the priests began in earnest.",
              visual: "Soldiers swinging heavy bronze sledgehammers into carved limestone columns, cracking them in half."
            },
            {
              bgType: "demolition_of_amarna",
              characterPose: "sledgehammer_squads_toppling",
              expression: "determined",
              narration: "Horemheb ordered the total dismantling of every single temple, palace, and altar in the city.",
              visual: "Statues of Akhenaten and Nefertiti smashed into fragments of white stone on the temple flagstones."
            },
            {
              bgType: "demolition_of_amarna",
              characterPose: "talatat_used_as_rubble",
              expression: "smug_curious",
              narration: "Tens of thousands of Talatat blocks were carted down to Thebes and used as hidden rubble inside Karnak's pylons.",
              visual: "Workers dumping carved blocks face-down into the hollow interior of a colossal pylon wall at Karnak."
            },
            {
              bgType: "demolition_of_amarna",
              characterPose: "talatat_used_as_rubble",
              expression: "smug_curious",
              narration: "Akhenaten's holy stones were literally buried inside the monuments of the gods he tried to eradicate.",
              visual: "A pylon being sealed shut with massive granite slabs, entombing the sun reliefs in total blackness."
            }
          ]
        },
        {
          sceneNumber: 23,
          sceneTitle: "The Pharaoh Erased From Time",
          beats: [
            {
              bgType: "erased_cartouche_wall",
              characterPose: "chipping_away_cartouches",
              expression: "determined",
              narration: "Then came damnatio memoriae: the complete spiritual assassination of the Pharaoh from history.",
              visual: "A stonemason violently gouging out the oval name cartouche of Akhenaten from an official temple wall."
            },
            {
              bgType: "erased_cartouche_wall",
              characterPose: "official_king_list_abydos",
              expression: "deadpan",
              narration: "On official king lists carved at Abydos, his name was deleted from the royal lineage entirely.",
              visual: "The Abydos King List carved in stone, with a visible blank gap jumping straight from Amenhotep III to Horemheb."
            },
            {
              bgType: "erased_cartouche_wall",
              characterPose: "the_great_criminal_edict",
              expression: "annoyed",
              narration: "In court documents and scribal rolls, his name was forbidden. He was called only 'The Great Criminal.'",
              visual: "A scribe dipping reed pen in red ink, writing the epithet 'The Rebel of Akhetaten' on papyrus."
            },
            {
              bgType: "erased_cartouche_wall",
              characterPose: "the_great_criminal_edict",
              expression: "deadpan",
              narration: "Egypt returned to its ancient rituals as if Akhenaten had never existed. The gods had won.",
              visual: "Priests in Karnak once again carrying the gilded bark of Amun on their shoulders in triumphal procession."
            }
          ]
        },
        {
          sceneNumber: 24,
          sceneTitle: "The Heretic Awakens",
          beats: [
            {
              bgType: "archaeological_resurrection",
              characterPose: "desert_sand_preserving",
              expression: "peaceful",
              narration: "For three thousand years, the desert sand guarded the heretic's secret.",
              visual: "Vast windswept sand dunes covering the lost city under a starry night sky with the moon above."
            },
            {
              bgType: "archaeological_resurrection",
              characterPose: "archaeologists_brushing_sand",
              expression: "awe_wonder",
              narration: "By burying his city and using his stones as filler, his enemies accidentally built him a time capsule.",
              visual: "A modern archaeologist with a soft brush clearing sand off the pristine carved limestone face of Akhenaten."
            },
            {
              bgType: "archaeological_resurrection",
              characterPose: "world_remembering_akhenaten",
              expression: "awe_wonder",
              narration: "In the 1890s, Amarna was unearthed, revealing the world's first monotheist and his unforgettable revolution.",
              visual: "Tourists and historians gathered around the exquisite bust of Nefertiti glowing under museum spotlights."
            },
            {
              bgType: "archaeological_resurrection",
              characterPose: "world_remembering_akhenaten",
              expression: "grinning",
              narration: "Akhenaten tried to delete the gods. They erased his city—but three millennia later, the world still remembers his name.",
              visual: "The radiant golden Aten sun disc shining brightly over the desert cliffs of Egypt into eternity."
            }
          ]
        }
      ]
    }
  ];

  // Flatten into 108 visual beats (all 24 scenes)
  const allBeats = [];
  let currentSec = 0;
  const beatDur = 5.5; // seconds per cut

  chapters.forEach(ch => {
    ch.scenes.forEach(sc => {
      sc.beats.forEach((b, bIdx) => {
        const beatIndex = allBeats.length + 1;
        const startSec = +(currentSec).toFixed(1);
        const endSec = +(currentSec + beatDur).toFixed(1);
        currentSec = endSec;

        allBeats.push({
          beatIndex,
          beatId: 'scene_' + String(beatIndex).padStart(3, '0'),
          chapterNumber: ch.chapterNumber,
          chapterTitle: ch.chapterTitle,
          sceneNumber: sc.sceneNumber,
          sceneTitle: sc.sceneTitle,
          bgType: b.bgType,
          characterPose: b.characterPose,
          expression: b.expression,
          narration: b.narration,
          gag: b.visual,
          visualDescription: b.visual,
          timing: {
            startSec,
            endSec,
            durationSec: beatDur,
            formattedStart: formatTime(startSec),
            formattedEnd: formatTime(endSec)
          }
        });
      });
    });
  });

  return {
    meta: {
      title: "Akhenaten: The Pharaoh Who Deleted The Gods",
      civilization: "Ancient Egypt (1330 BC)",
      channel: "Genius History // 2D Historical Documentaries",
      totalChapters: 5,
      totalScenes: 24,
      totalBeats: allBeats.length,
      targetDurationSec: Math.round(currentSec),
      formattedDuration: formatTime(currentSec),
      artStyle: "Minimalist 2D Hand-Drawn Comic Line Art // Flat Vector Colors",
      voiceProfile: "Authoritative Male Explanatory Documentary Narrator (en-US-ChristopherNeural)",
      zoomEnabled: false,
      captionsEnabled: false
    },
    beats: allBeats
  };
}

function formatTime(sec) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return m + ':' + String(s).padStart(2, '0');
}

module.exports = {
  buildHistoricalDocumentaryScreenplay
};
`;

fs.writeFileSync(targetPath, code, 'utf8');
console.log('✅ Historical Screenplay Builder (108 Beats) deployed to:', targetPath);
