const orchestrator = require('C:/Users/WINDOWS/.gemini/antigravity/scratch/youtube-automation-agent/agents/hermes-orchestrator.js');

async function main() {
  console.log('🤖 Launching Hermes Autonomous Bot Suite...');
  const result = await orchestrator.runPipeline('Akhenaten: The Pharaoh Who Deleted The Gods (Ancient Egypt, 1330 BC)');
  console.log('Pipeline Success:', result.success);
}

main().catch(err => {
  console.error('Error during pipeline execution:', err);
  process.exit(1);
});
