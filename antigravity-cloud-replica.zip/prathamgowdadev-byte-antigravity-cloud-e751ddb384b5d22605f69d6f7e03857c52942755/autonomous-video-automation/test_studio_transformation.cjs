const fs = require('fs');
const path = require('path');
const assert = require('assert');

console.log('════════════════════════════════════════════════════════════');
console.log('   VERIFYING ASURA AGENTIC AI WEBSITE DEVELOPER STUDIO      ');
console.log('════════════════════════════════════════════════════════════');

let passed = 0;
let failed = 0;

function runTest(name, fn) {
  try {
    fn();
    console.log(`  [PASS] ${name}`);
    passed++;
  } catch (e) {
    console.error(`  [FAIL] ${name}: ${e.message}`);
    failed++;
  }
}

console.log('\n--- 1. Testing Complete Purge of YouTube Video Automation ---');

runTest('youtube-automation-agent folder purged', () => {
  const p = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent';
  assert.strictEqual(fs.existsSync(p), false, 'youtube-automation-agent must not exist');
});

runTest('ai-shorts-factory folder purged', () => {
  const p = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\ai-shorts-factory';
  assert.strictEqual(fs.existsSync(p), false, 'ai-shorts-factory must not exist');
});

runTest('autonomous-content-engine folder purged', () => {
  const p = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\autonomous-content-engine';
  assert.strictEqual(fs.existsSync(p), false, 'autonomous-content-engine must not exist');
});

console.log('\n--- 2. Testing Desktop 1-Click Launchers ---');

runTest('ASURA AI Web Developer.bat exists on Desktop', () => {
  const p = 'C:\\Users\\WINDOWS\\Desktop\\ASURA AI Web Developer.bat';
  assert.ok(fs.existsSync(p), 'Desktop batch launcher must exist');
  const content = fs.readFileSync(p, 'utf8');
  assert.ok(content.includes('localhost:3000'), 'Launcher must target studio port');
});

runTest('ASURA AI Web Developer.lnk shortcut exists on Desktop', () => {
  const p = 'C:\\Users\\WINDOWS\\Desktop\\ASURA AI Web Developer.lnk';
  assert.ok(fs.existsSync(p), 'Desktop .lnk shortcut must exist');
});

console.log('\n--- 3. Testing Antigravity UI & Central Jarvis Orb in index.html ---');

const indexHtml = fs.readFileSync('C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system\\index.html', 'utf8');

runTest('Contains Antigravity-style left sidebar with New Conversation button', () => {
  assert.ok(indexHtml.includes('New Conversation'), 'Must have New Conversation button');
  assert.ok(indexHtml.includes('conversationsList'), 'Must have history list container');
  assert.ok(indexHtml.includes('Conversation History'), 'Must have Conversation History section');
  assert.ok(indexHtml.includes('Scheduled Tasks & Bots'), 'Must have Scheduled Tasks & Bots');
});

runTest('Contains central 3D/Canvas Jarvis Arc Reactor Orb', () => {
  assert.ok(indexHtml.includes('jarvisCanvas'), 'Must have jarvisCanvas element');
  assert.ok(indexHtml.includes('initJarvisOrb'), 'Must have 3D Jarvis Orb initialization script');
  assert.ok(indexHtml.includes('JARVIS NEURAL CORE'), 'Must display Jarvis holographic label');
});

runTest('Contains centered Antigravity/ChatGPT style prompt box', () => {
  assert.ok(indexHtml.includes('promptInput'), 'Must have promptInput');
  assert.ok(indexHtml.includes('Ask anything, @ to mention, / for actions'), 'Must match placeholder from user photo');
  assert.ok(indexHtml.includes('modelSelector'), 'Must have model selector dropdown');
});

runTest('Contains + button modal for Photos, Videos, ZIP, and .MD files', () => {
  assert.ok(indexHtml.includes('attachmentModal'), 'Must have attachmentModal');
  assert.ok(indexHtml.includes('image/*,video/mp4,.zip,.md,.txt'), 'Must accept photos, videos, zip, and md files');
  assert.ok(indexHtml.includes('ATTACH REFERENCE ASSETS'), 'Must have reference asset intake title');
});

runTest('Contains split-screen Agentic Workspace & Live Website Sandbox', () => {
  assert.ok(indexHtml.includes('viewWorkspace'), 'Must have viewWorkspace');
  assert.ok(indexHtml.includes('sandboxIframe'), 'Must have interactive sandbox iframe');
  assert.ok(indexHtml.includes('codeInspector'), 'Must have source code inspector');
  assert.ok(indexHtml.includes('AGENTIC REASONING TRAJECTORY'), 'Must show thought trajectory');
});

runTest('Contains dedicated Vercel Live Production Radar tab', () => {
  assert.ok(indexHtml.includes('viewRadar'), 'Must have viewRadar view');
  assert.ok(indexHtml.includes('LIVE VERCEL PRODUCTION RADAR'), 'Must display Vercel Radar title');
  assert.ok(indexHtml.includes('crypto-lottery'), 'Must track Crypto Lottery prototype');
  assert.ok(indexHtml.includes('bhoomiputra-real-estate'), 'Must track Bhoomiputra prototype');
  assert.ok(indexHtml.includes('skin-secrets-cochin'), 'Must track Skin Secrets prototype');
});

runTest('Contains persistent chat history in localStorage', () => {
  assert.ok(indexHtml.includes('STORAGE_KEY_CHATS'), 'Must have localStorage storage key');
  assert.ok(indexHtml.includes('saveHistory'), 'Must have saveHistory function');
  assert.ok(indexHtml.includes('loadHistory'), 'Must have loadHistory function');
});

console.log('\n════════════════════════════════════════════════════════════');
console.log(`TOTAL TESTS: ${passed + failed} | PASSED: ${passed} | FAILED: ${failed}`);
console.log('════════════════════════════════════════════════════════════');

if (failed > 0) process.exit(1);
