/**
 * ══════════════════════════════════════════════════════════════════════════════
 * HERMES VISUAL DIRECTOR // GLOBAL 2D HISTORICAL DOCUMENTARY SYSTEM
 * ══════════════════════════════════════════════════════════════════════════════
 * Implements strict hand-drawn comic visual generation (Genius History standard):
 * - 2D hand-drawn line art, crisp ink outlines, flat vector fills, parchment texture
 * - Generates exact standalone 2D image prompts following the user formula
 * - Exports clean prompts for all 24 scenes + 3 YouTube thumbnails
 * - Renders 100+ dedicated static visual cuts with zero camera pan/zoom drift
 */

const fs = require('fs');
const path = require('path');
const visualEngine = require('../utils/historical-visual-engine.js');

class HermesVisualDirector {
  constructor() {
    this.name = 'Hermes-VisualDirector';
    this.version = '6.0.0';
  }

  async renderAllBeats(screenplay) {
    const scenesDir = path.join(__dirname, '../assets/scenes');
    if (!fs.existsSync(scenesDir)) fs.mkdirSync(scenesDir, { recursive: true });

    const beats = screenplay.beats || [];
    console.log(`[${this.name}] 🎨 Synthesizing ${beats.length} Hand-Drawn 2D Historical Visual Cuts (Genius History Style)...`);

    const manifest = [];
    const promptList = [];

    for (let i = 0; i < beats.length; i++) {
      const beat = beats[i];
      
      // Ensure exact 2D image prompt
      const imagePrompt = beat.imagePrompt || visualEngine.generate2DImagePrompt(
        beat.visualDescription || beat.narration || 'Historical scene',
        'Ancient Egypt (1330 BC)',
        'Wide-angle cinematic view'
      );
      beat.imagePrompt = imagePrompt;

      // Render visual asset (JPG if generated, or high-fidelity 2D comic SVG)
      const renderRes = visualEngine.renderSceneVisual(beat, scenesDir);

      manifest.push({
        beatIndex: beat.beatIndex,
        beatId: beat.beatId,
        act: beat.act || beat.chapterNumber || 1,
        sceneNumber: beat.sceneNumber,
        sceneTitle: beat.sceneTitle,
        filePath: renderRes.filePath,
        relativePath: renderRes.relativePath,
        assetType: renderRes.type,
        imagePrompt: imagePrompt,
        narration: beat.narration,
        status: 'rendered'
      });

      promptList.push({
        cutNumber: beat.beatIndex,
        cutId: beat.beatId,
        chapter: beat.chapterNumber,
        sceneNumber: beat.sceneNumber,
        sceneTitle: beat.sceneTitle,
        voiceoverText: beat.narration,
        prompt: imagePrompt
      });
    }

    // Save visual manifest
    const manifestPath = path.join(__dirname, '../assets/visual-manifest.json');
    fs.writeFileSync(manifestPath, JSON.stringify(manifest, null, 2), 'utf8');

    // Save standalone prompts export
    const promptsExportPath = path.join(__dirname, '../assets/prompts-export.json');
    fs.writeFileSync(promptsExportPath, JSON.stringify(promptList, null, 2), 'utf8');

    // Also write a formatted text file for easy copy-pasting
    const formattedTextPath = path.join(__dirname, '../assets/prompts-export.txt');
    const txtContent = promptList.map(p => 
      `CUT #${p.cutNumber} [${p.cutId}] - Scene: ${p.sceneTitle}\nVOICEOVER: "${p.voiceoverText}"\n2D IMAGE PROMPT:\n${p.prompt}\n`
    ).join('\n---\n\n');
    fs.writeFileSync(formattedTextPath, txtContent, 'utf8');

    console.log(`[${this.name}] ✅ All ${manifest.length} Hand-Drawn 2D Visual Cuts rendered to ${scenesDir}`);
    console.log(`[${this.name}] 📋 Exported 2D image prompts to ${formattedTextPath}`);

    return manifest;
  }
}

module.exports = new HermesVisualDirector();
