async function searchZenn() {
  const url = 'https://www.youtube.com/watch?v=st_Ah6Ykbh4';
  try {
    const res = await fetch(url, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
        'Accept-Language': 'en-US,en;q=0.9'
      }
    });
    const html = await res.text();
    
    // Extract description
    const m = html.indexOf('"shortDescription":"');
    if (m !== -1) {
      const start = m + '"shortDescription":"'.length;
      let end = start;
      while (end < html.length && !(html[end] === '"' && html[end-1] !== '\\')) {
        end++;
      }
      const rawDesc = html.slice(start, end);
      console.log('--- FULL DESCRIPTION ---');
      console.log(rawDesc.replace(/\\n/g, '\n').replace(/\\"/g, '"'));
    }

    // Extract keywords
    const kwMatch = html.match(/"keywords":(\[.*?\])/);
    if (kwMatch) {
      console.log('--- KEYWORDS ---', kwMatch[1]);
    }
  } catch (e) {
    console.error(e.message);
  }
}
searchZenn();
