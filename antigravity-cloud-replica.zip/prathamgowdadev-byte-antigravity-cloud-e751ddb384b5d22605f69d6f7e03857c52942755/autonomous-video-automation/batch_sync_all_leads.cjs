const fs = require('fs');
const path = require('path');
const { ARCHETYPES, generateLuxuryHTML } = require('./brand_engine.cjs');

const GITHUB_TOKEN = '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';
const REPO = 'prathamgowda194-pixel/asura-system';

async function api(endpoint, method = 'GET', body = null) {
  const opts = {
    method,
    headers: {
      'Authorization': `Bearer ${GITHUB_TOKEN}`,
      'User-Agent': 'ASURA-Deployer',
      'Accept': 'application/vnd.github.v3+json'
    }
  };
  if (body) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(`https://api.github.com/repos/${REPO}${endpoint}`, opts);
  return await res.json();
}

async function run() {
  console.log('⚡ BATCH SYNCHRONIZING ALL VERIFIED PROTOTYPES WITH ZERO-SLOP NICHE MATRIX...');

  const leadsPath = path.join(__dirname, 'data', 'hunter_leads.json');
  const leads = JSON.parse(fs.readFileSync(leadsPath, 'utf8'));

  const treeEntries = [];

  for (const lead of leads) {
    const html = generateLuxuryHTML(lead);
    
    // Save locally
    const localDir = path.join(__dirname, 'projects', lead.slug);
    if (!fs.existsSync(localDir)) fs.mkdirSync(localDir, { recursive: true });
    fs.writeFileSync(path.join(localDir, 'index.html'), html, 'utf8');

    // Create blob
    const blob = await api('/git/blobs', 'POST', {
      content: Buffer.from(html, 'utf8').toString('base64'),
      encoding: 'base64'
    });

    treeEntries.push({ path: `projects/${lead.slug}/index.html`, mode: '100644', type: 'blob', sha: blob.sha });
    treeEntries.push({ path: `prototypes/${lead.slug}/index.html`, mode: '100644', type: 'blob', sha: blob.sha });
    console.log(`✅ Synced: ${lead.name} (${lead.slug})`);
  }

  // Add leads file blob
  const leadsBlob = await api('/git/blobs', 'POST', {
    content: Buffer.from(JSON.stringify(leads, null, 2), 'utf8').toString('base64'),
    encoding: 'base64'
  });
  treeEntries.push({ path: 'data/hunter_leads.json', mode: '100644', type: 'blob', sha: leadsBlob.sha });

  console.log(`🌳 Assembling git tree with ${treeEntries.length} entries...`);
  const ref = await api('/git/ref/heads/main');
  const parentSha = ref.object.sha;
  const parentCommit = await api(`/git/commits/${parentSha}`);

  const tree = await api('/git/trees', 'POST', {
    base_tree: parentCommit.tree.sha,
    tree: treeEntries
  });

  console.log('✍️ Signing atomic commit...');
  const commit = await api('/git/commits', 'POST', {
    message: 'feat(catalog): regenerate all client prototypes with zero-slop niche domain models & 12 archetypes',
    tree: tree.sha,
    parents: [parentSha]
  });

  console.log('🚀 Pushing to main branch...');
  const updatedRef = await api('/git/refs/heads/main', 'PATCH', {
    sha: commit.sha,
    force: false
  });

  console.log('🎉 ALL PROTOTYPES SYNCHRONIZED! Commit SHA:', updatedRef.object.sha);
}

run().catch(err => {
  console.error('❌ Error during batch sync:', err);
  process.exit(1);
});
