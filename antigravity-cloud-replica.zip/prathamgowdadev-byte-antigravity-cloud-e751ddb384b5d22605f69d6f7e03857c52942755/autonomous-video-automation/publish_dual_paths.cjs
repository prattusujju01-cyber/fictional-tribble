const fs = require('fs');
const path = require('path');
const { ARCHETYPES, generateLuxuryHTML } = require('./brand_engine.cjs');

const GITHUB_TOKEN = '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';
const REPO = 'prathamgowda194-pixel/asura-system';

const CLIENTS = [
  {
    slug: "bridge-property-consultants-mumbai",
    name: "Bridge Property Consultants",
    niche: "Luxury Real Estate & Villa Developers",
    city: "Mumbai, Maharashtra",
    phone: "+91 93202 93840",
    cleanPhone: "9320293840",
    address: "Below Flyover, Sanyas Ashram Chowk, Vile Parle West, Mumbai 400056",
    rating: "4.9",
    reviews: "129"
  },
  {
    slug: "gkb-gkb-construction-llp-building",
    name: "GKB Construction LLP",
    niche: "Civil Construction & Turnkey High-Rises",
    city: "Jaipur, Rajasthan",
    phone: "+91 93529 81701",
    cleanPhone: "9352981701",
    address: "C-Scheme & Tonk Road, Jaipur 302001",
    rating: "4.9",
    reviews: "114"
  },
  {
    slug: "skin-secrets-in-edappally-cochin-kochi",
    name: "Skin Secrets Aesthetic Clinic",
    niche: "Dermatology & Aesthetic Clinic",
    city: "Kochi, Kerala",
    phone: "+91 75609 07255",
    cleanPhone: "7560907255",
    address: "Metro Pillar 482, Edappally, Cochin 682024",
    rating: "4.8",
    reviews: "168"
  },
  {
    slug: "bhoomiputra-real-estate-developers",
    name: "Bhoomiputra Real Estate Developers",
    niche: "Luxury Real Estate & Land Promoters",
    city: "Bangalore, Karnataka",
    phone: "+91 63632 73458",
    cleanPhone: "6363273458",
    address: "Nagadevanahalli & Kengeri, Bangalore, Karnataka 560060",
    rating: "4.8",
    reviews: "145"
  },
  {
    slug: "all-smiles-dental-clinic-bangalore",
    name: "All Smiles Dental Clinic",
    niche: "Dental Clinic & Implantology Center",
    city: "Bangalore, Karnataka",
    phone: "+91 79751 92509",
    cleanPhone: "7975192509",
    address: "100 Feet Road, Indiranagar, Bangalore, Karnataka 560038",
    rating: "4.9",
    reviews: "184"
  },
  {
    slug: "impact-fitness-center-bangalore",
    name: "Impact Fitness Center",
    niche: "Premium Fitness & Crossfit Studio",
    city: "Bangalore, Karnataka",
    phone: "+91 87920 38282",
    cleanPhone: "8792038282",
    address: "Electronics City Phase 1, Bangalore, Karnataka 560100",
    rating: "4.8",
    reviews: "96"
  },
  {
    slug: "s-m-corporation-interiors-bangalore",
    name: "S M Corporation Interiors",
    niche: "Interior Architecture & Modular Living",
    city: "Bangalore, Karnataka",
    phone: "+91 99808 15604",
    cleanPhone: "9980815604",
    address: "27th Main Rd, HSR Layout Sector 2, Bangalore 560102",
    rating: "4.8",
    reviews: "72"
  },
  {
    slug: "xanadu-bangalore",
    name: "Xanadu Realty Estates",
    niche: "Luxury Real Estate & Villa Developers",
    city: "Bangalore, Karnataka",
    phone: "+91 76192 54435",
    cleanPhone: "7619254435",
    address: "Lavelle Road, Bangalore 560001",
    rating: "4.9",
    reviews: "88"
  },
  {
    slug: "mumbai-real-estate-professionals",
    name: "Mumbai Real Estate Professionals",
    niche: "Luxury Real Estate & Villa Developers",
    city: "Mumbai, Maharashtra",
    phone: "+91 84596 14982",
    cleanPhone: "8459614982",
    address: "BKC, Mumbai 400051",
    rating: "4.8",
    reviews: "75"
  },
  {
    slug: "blr-properties-in-kammanahalli-main",
    name: "BLR Properties Consultants",
    niche: "Luxury Real Estate & Villa Developers",
    city: "Bangalore, Karnataka",
    phone: "+91 84602 46249",
    cleanPhone: "8460246249",
    address: "Kammanahalli Main Road, Bangalore 560084",
    rating: "4.8",
    reviews: "101"
  },
  {
    slug: "shankar-real-estate-agency-bangalore",
    name: "Shankar Real Estate Agency",
    niche: "Real Estate Consultancy & Commercial Brokerage",
    city: "Bangalore, Karnataka",
    phone: "+91 70411 24398",
    cleanPhone: "7041124398",
    address: "Sanjay Nagar, Bangalore 560094",
    rating: "4.8",
    reviews: "166"
  },
  {
    slug: "kdc-dental-clinic-bangalore",
    name: "KDC Dental & Implantology",
    niche: "Dental Clinic & Implantology Center",
    city: "Bangalore, Karnataka",
    phone: "+91 80501 03103",
    cleanPhone: "8050103103",
    address: "Koramangala 4th Block, Bangalore 560034",
    rating: "4.8",
    reviews: "81"
  },
  {
    slug: "sp-interior-design-studio-in",
    name: "SP Interior Design Studio",
    niche: "Interior Architecture & Modular Living",
    city: "Bangalore, Karnataka",
    phone: "+91 99805 45562",
    cleanPhone: "9980545562",
    address: "Gattahalli & Sarjapur Road, Bangalore 560099",
    rating: "4.9",
    reviews: "54"
  },
  {
    slug: "karnataka-elite-nri-property-expo",
    name: "Karnataka Elite NRI Real Estate",
    niche: "Luxury Real Estate & Villa Developers",
    city: "Bangalore, Karnataka",
    phone: "+91 96860 40864",
    cleanPhone: "9686040864",
    address: "MG Road, Bangalore 560001",
    rating: "5.0",
    reviews: "60"
  },
  {
    slug: "dental-clinic-best-dentist-clinic",
    name: "Ridgetop Dental International",
    niche: "Dental Clinic & Implantology Center",
    city: "Bangalore, Karnataka",
    phone: "+91 80476 77564",
    cleanPhone: "8047677564",
    address: "Indiranagar, Bangalore 560038",
    rating: "4.8",
    reviews: "102"
  },
  {
    slug: "bangalore-real-estate-help-bangalore",
    name: "Prime Bengaluru Realty",
    niche: "Luxury Real Estate & Villa Developers",
    city: "Bangalore, Karnataka",
    phone: "+91 95850 22037",
    cleanPhone: "9585022037",
    address: "Whitefield, Bangalore 560066",
    rating: "4.9",
    reviews: "59"
  }
];

async function api(endpoint, method = 'GET', body = null) {
  const opts = {
    method,
    headers: {
      'Authorization': `Bearer ${GITHUB_TOKEN}`,
      'User-Agent': 'ASURA-Rebuilder',
      'Accept': 'application/vnd.github.v3+json'
    }
  };
  if (body) {
    opts.headers['Content-Type'] = 'application/json';
    opts.body = JSON.stringify(body);
  }
  const res = await fetch(`https://api.github.com/repos/${REPO}${endpoint}`, opts);
  return await res.json();
}

async function run() {
  console.log(`Creating blobs for both projects/ and prototypes/ paths...`);
  const treeEntries = [];

  for (let i = 0; i < CLIENTS.length; i++) {
    const client = CLIENTS[i];
    const archetype = ARCHETYPES[i % ARCHETYPES.length];
    const html = generateLuxuryHTML(client, archetype);

    const blobRes = await api('/git/blobs', 'POST', {
      content: Buffer.from(html, 'utf8').toString('base64'),
      encoding: 'base64'
    });

    // Write to both projects/ and prototypes/
    treeEntries.push({
      path: `projects/${client.slug}/index.html`,
      mode: '100644',
      type: 'blob',
      sha: blobRes.sha
    });
    treeEntries.push({
      path: `prototypes/${client.slug}/index.html`,
      mode: '100644',
      type: 'blob',
      sha: blobRes.sha
    });

    await new Promise(r => setTimeout(r, 200));
  }

  const ref = await api('/git/ref/heads/main');
  const parentSha = ref.object.sha;
  const parentCommit = await api(`/git/commits/${parentSha}`);

  const newTree = await api('/git/trees', 'POST', {
    base_tree: parentCommit.tree.sha,
    tree: treeEntries
  });

  const newCommit = await api('/git/commits', 'POST', {
    message: 'feat: publish all 16 luxury prototypes across projects and prototypes paths',
    tree: newTree.sha,
    parents: [parentSha]
  });

  await api('/git/refs/heads/main', 'PATCH', {
    sha: newCommit.sha,
    force: false
  });

  console.log(`🎉 SUCCESS! Published commit: ${newCommit.sha.slice(0, 7)}`);
}

run().catch(console.error);
