/**
 * ══════════════════════════════════════════════════════════════════════════════
 * HERMES VOICE STUDIO // GLOBAL 2D HISTORICAL DOCUMENTARY SYSTEM
 * ══════════════════════════════════════════════════════════════════════════════
 * Authoritative Male Explanatory Documentary Voice Actor with Dramatic Cadence:
 * - High-Prosody Microsoft Neural (en-US-ChristopherNeural)
 * - Direct ElevenLabs API connector (Marcus / Adam / Antoni)
 * - Timed narrative pacing strictly synchronized with 108 visual cuts
 */

const fs = require('fs');
const path = require('path');
const voiceEngine = require('../utils/voice-studio-engine.js');

class HermesVoiceStudio {
  constructor() {
    this.name = 'Hermes-VoiceStudio';
    this.version = '6.0.0';
  }

  async synthesizeNarration(screenplay) {
    const audioDir = path.join(__dirname, '../assets/audio');
    if (!fs.existsSync(audioDir)) fs.mkdirSync(audioDir, { recursive: true });

    const masterAudioPath = path.join(audioDir, 'narration.mp3');
    console.log(`[${this.name}] 🎙️ Synthesizing authoritative male documentary voiceover for: "${screenplay.meta.title}"...`);

    const beatsWithNarration = (screenplay.beats || []).filter(b => b.narration && b.narration.trim());
    const fullNarrationText = beatsWithNarration.map(b => b.narration).join(' ');

    console.log(`[${this.name}] 📜 Total script words: ${fullNarrationText.split(/\s+/).length} across ${beatsWithNarration.length} narrative beats.`);

    // Synthesize master narration audio via Voice Studio Engine
    const result = await voiceEngine.synthesizeSpeech(fullNarrationText, masterAudioPath);
    const sizeKB = Math.round((result.bytes || 0) / 1024);
    console.log(`[${this.name}] ✅ Master voiceover audio rendered: ${sizeKB} KB at ${masterAudioPath}`);

    // Build timeline timing map for each beat
    let currentSeconds = 0;
    const beatTimingMap = (screenplay.beats || []).map((beat, idx) => {
      const dur = beat.timing?.durationSec || beat.durationSec || 5.5;
      const start = currentSeconds;
      const end = +(currentSeconds + dur).toFixed(1);
      currentSeconds = end;

      return {
        beatId: beat.beatId,
        beatIndex: beat.beatIndex,
        act: beat.act || beat.chapterNumber || 1,
        sceneNumber: beat.sceneNumber,
        sceneTitle: beat.sceneTitle,
        startTimeSec: start,
        endTimeSec: end,
        durationSec: dur,
        narration: beat.narration,
        imagePrompt: beat.imagePrompt || ''
      };
    });

    const subPath = path.join(__dirname, '../assets/subtitles.json');
    fs.writeFileSync(subPath, JSON.stringify(beatTimingMap, null, 2), 'utf8');

    return {
      audioPath: masterAudioPath,
      relativePath: 'assets/audio/narration.mp3',
      totalEstimatedSeconds: currentSeconds,
      beatTimings: beatTimingMap,
      sizeKB
    };
  }
}

module.exports = new HermesVoiceStudio();
