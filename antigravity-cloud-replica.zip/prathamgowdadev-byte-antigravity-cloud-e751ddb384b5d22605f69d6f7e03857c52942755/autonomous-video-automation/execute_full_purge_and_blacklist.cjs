const fs = require('fs');
const path = require('path');

const GITHUB_TOKEN = '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';
const REPO_OWNER = 'prathamgowda194-pixel';
const REPO_NAME = 'asura-system';

const WORKSPACE_DIR = 'C:/Users/WINDOWS/.gemini/antigravity/scratch/asura-system';
const DATA_DIR = path.join(WORKSPACE_DIR, 'data');
const PROJECTS_DIR = path.join(WORKSPACE_DIR, 'projects');
const LEADS_FILE = path.join(DATA_DIR, 'hunter_leads.json');
const BLACKLIST_FILE = path.join(DATA_DIR, 'blacklisted_businesses.json');

const BLACKLIST = [
  { slug: "bridge-property-consultants-mumbai", name: "Bridge property consultants", cleanPhone: "9320293840", city: "Mumbai, Maharashtra" },
  { slug: "all-smiles-dental-clinic-bangalore", name: "All smiles dental clinic", cleanPhone: "9845012345", city: "Bangalore, Karnataka" },
  { slug: "s9-luxury-hair-studio-in-gachibowli", name: "S9 Luxury Hair studio", cleanPhone: "9849012345", city: "Hyderabad, Telangana" },
  { slug: "hyderabad-real-estate-hyderabad", name: "Hyderabad Real Estate", cleanPhone: "7337526868", city: "Hyderabad, Telangana" },
  { slug: "byob-restaurant-experience-in-gurgaon", name: "Byob restaurant", cleanPhone: "9654120004", city: "Gurgaon, Delhi NCR" },
  { slug: "architectural-exports-in-sion-west", name: "Architectural Exports insion west Mumbai", cleanPhone: "9372317501", city: "Mumbai, Maharashtra" },
  { slug: "lee-space-interior-design-in", name: "Lee Space Interior Design", cleanPhone: "8460558718", city: "Kochi, Kerala" },
  { slug: "taaam-fine-dining-private-limited", name: "Taaam Fine dining private limited", cleanPhone: "", city: "Bangalore, Karnataka" },
  { slug: "indus-dental-clinic-coimbatore", name: "Indus dental clinic", cleanPhone: "", city: "Coimbatore, Tamil Nadu" },
  { slug: "dev-interior-design-work-in-lgb-nagar", name: "Dev interior design work inLgb Nagar", cleanPhone: "", city: "Hyderabad, Telangana" },
  { slug: "sri-prathyangiradevi-real-estate", name: "Sri prathyangiridevi real estate", cleanPhone: "", city: "Chennai, Tamil Nadu" },
  { slug: "lawyer-advocates-at-1000-person", name: "Lawyer advocates at 1000/ person", cleanPhone: "", city: "Delhi NCR" },
  { slug: "india-sotheby-s-international-realty", name: "India sotheby's international reality", cleanPhone: "", city: "Mumbai, Maharashtra" },
  { slug: "mr-mrs-detailing-studio-jaipur", name: "Mr&mrs Detailing studio", cleanPhone: "", city: "Jaipur, Rajasthan" },
  { slug: "ravi-construction-in-mohali", name: "Ravi construction in mohali", cleanPhone: "", city: "Mohali, Punjab" },
  { slug: "s-k-sahil-civil-contractor-in-mapusa", name: "S K Sahil civil contractor in mapusa goa", cleanPhone: "", city: "Goa" },
  { slug: "eternal-fitness-center-bengaluru", name: "Eternal fitness centre", cleanPhone: "", city: "Bangalore, Karnataka" },
  { slug: "contractor-for-bathroom-construction", name: "Contractor for bathroom", cleanPhone: "", city: "Mumbai, Maharashtra" },
  { slug: "rahul-real-estate-in-vijay-nagar", name: "Rahul real estate vijaynagar indore", cleanPhone: "", city: "Indore, Madhya Pradesh" },
  { slug: "hair-treatment-in-pune-id-14651660530", name: "Hair treatment in pune", cleanPhone: "", city: "Pune, Maharashtra" },
  { slug: "if-they-won-twe-will-call-9748654545", name: "If they wont we will call", cleanPhone: "9748654545", city: "Kolkata, West Bengal" },
  { slug: "22-photos-of-naik-real-estate-in", name: "22 photos of naik real estate in santa cruz goa", cleanPhone: "", city: "Goa" },
  { slug: "building-construction-qamsham-infra", name: "Building construction qamsham infra developers", cleanPhone: "", city: "Hyderabad, Telangana" },
  { slug: "interior-designer-vendors-in", name: "Interior designer vendors in ahemadabadh", cleanPhone: "", city: "Ahmedabad, Gujarat" }
];

async function deleteGitHubFile(filePath) {
  const url = `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${filePath}`;
  try {
    const checkRes = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${GITHUB_TOKEN}`,
        'User-Agent': 'ASURA-Purge-Engine',
        'Accept': 'application/vnd.github.v3+json'
      }
    });

    if (checkRes.status === 200) {
      const data = await checkRes.json();
      const sha = data.sha;
      const delRes = await fetch(url, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${GITHUB_TOKEN}`,
          'Content-Type': 'application/json',
          'User-Agent': 'ASURA-Purge-Engine',
          'Accept': 'application/vnd.github.v3+json'
        },
        body: JSON.stringify({
          message: `chore(purge): permanently remove blacklisted client website ${filePath} [skip ci]`,
          sha: sha,
          branch: 'main'
        })
      });
      if (delRes.status === 200) {
        console.log(`   🗑️ [GITHUB DELETED] ${filePath}`);
        return true;
      } else {
        console.warn(`   ⚠️ [GITHUB DELETE FAILED ${delRes.status}] ${filePath}`);
      }
    } else if (checkRes.status === 404) {
      console.log(`   ℹ️ [GITHUB ALREADY ABSENT] ${filePath}`);
      return true;
    }
  } catch (e) {
    console.error(`   ❌ [GITHUB ERROR] ${filePath}: ${e.message}`);
  }
  return false;
}

async function runPurge() {
  console.log('================================================================');
  console.log('🛑 PHASE 1: PERMANENT PURGE OF 24 BLACKLISTED CLIENT WEBSITES');
  console.log('================================================================\n');

  // 1. Write blacklisted_businesses.json
  fs.writeFileSync(BLACKLIST_FILE, JSON.stringify(BLACKLIST, null, 2), 'utf8');
  console.log(`✅ [BLACKLIST CREATED] Saved ${BLACKLIST.length} entries to: ${BLACKLIST_FILE}`);

  const blacklistedSlugs = new Set(BLACKLIST.map(b => b.slug));

  // 2. Delete local folders from projects/
  console.log('\n📁 Purging local project folders...');
  let localDeleted = 0;
  for (const item of BLACKLIST) {
    const localDir = path.join(PROJECTS_DIR, item.slug);
    if (fs.existsSync(localDir)) {
      fs.rmSync(localDir, { recursive: true, force: true });
      console.log(`   🗑️ [LOCAL DELETED] projects/${item.slug}`);
      localDeleted++;
    }
  }
  console.log(`✅ Local deletion complete: ${localDeleted} project directories removed.`);

  // 3. Purge from hunter_leads.json
  console.log('\n📄 Cleaning hunter_leads.json...');
  if (fs.existsSync(LEADS_FILE)) {
    const leads = JSON.parse(fs.readFileSync(LEADS_FILE, 'utf8'));
    const initialCount = leads.length;
    const filteredLeads = leads.filter(l => !blacklistedSlugs.has(l.slug));
    fs.writeFileSync(LEADS_FILE, JSON.stringify(filteredLeads, null, 2), 'utf8');
    console.log(`✅ hunter_leads.json updated: Purged ${initialCount - filteredLeads.length} leads. Remaining: ${filteredLeads.length}`);
  }

  // 4. Delete from GitHub repository (triggers Vercel production sync)
  console.log('\n☁️ Deleting websites from GitHub repository & Vercel deployment...');
  let ghDeleted = 0;
  for (const item of BLACKLIST) {
    const filePath = `projects/${item.slug}/index.html`;
    const ok = await deleteGitHubFile(filePath);
    if (ok) ghDeleted++;
    // Polite delay between GitHub API requests
    await new Promise(r => setTimeout(r, 600));
  }
  console.log(`✅ GitHub repository sync complete: ${ghDeleted}/${BLACKLIST.length} processed.`);

  console.log('\n================================================================');
  console.log('🏆 PURGE & BLACKLIST PHASE 1 COMPLETE');
  console.log('================================================================\n');
}

runPurge().catch(console.error);
