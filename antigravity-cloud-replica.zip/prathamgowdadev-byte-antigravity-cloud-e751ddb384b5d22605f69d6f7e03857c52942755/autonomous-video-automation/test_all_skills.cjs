const fs = require('fs');
const path = require('path');

async function testAll() {
  console.log('===========================================================');
  console.log('ASURA 10-SKILL & MCP ARCHITECTURE // VERIFICATION SUITE');
  console.log('===========================================================');

  const asuraDir = path.join('C:', 'Users', 'WINDOWS', '.gemini', 'antigravity', 'scratch', 'asura-system');
  
  // 1. Check all 10 skill files exist in asura-system/skills
  const skills = [
    'frontend-design',
    'ui-ux-pro-max',
    'design-taste-frontend',
    'shadcn-ui-mcp',
    'magic-mcp-21st',
    'vercel-react-best-practices',
    'vercel-react-native-skills',
    'gsap-master',
    'motion-framer',
    'convex-create-component'
  ];

  let skillsOk = true;
  for (const s of skills) {
    const p = path.join(asuraDir, 'skills', s, 'SKILL.md');
    const exists = fs.existsSync(p);
    if (!exists) skillsOk = false;
    console.log(`[SKILL CHECK] ${s}: ${exists ? 'EXISTS' : 'MISSING'}`);
  }
  console.log('[TEST 1] All 10 skills installed:', skillsOk ? 'PASS' : 'FAIL');

  // 2. Check mcp_config.json
  const mcpPath = path.join(asuraDir, 'mcp_config.json');
  const mcp = JSON.parse(fs.readFileSync(mcpPath, 'utf8'));
  const mcpOk = mcp.mcpServers['shadcn-ui'] && mcp.mcpServers['magic-mcp-21st'] && mcp.modelConfigurations['gemini-3.6-flash'];
  console.log('[TEST 2] mcp_config.json configured for Gemini 3.6 Flash & OpenAI Form:', mcpOk ? 'PASS' : 'FAIL');

  // 3. Test Orchestrator
  const orchestrator = require(path.join(asuraDir, 'lib', 'asura_skills_orchestrator.cjs'));
  const generated = orchestrator.generateCommercialWebsite('Cybernetic Luxury AI Accelerator', 'Gemini 3.6 Flash High');
  const orchOk = generated.includes('ScrollTrigger') && generated.includes('bento-card') && generated.includes('handleInquirySubmit');
  console.log('[TEST 3] Orchestrator emits GSAP + Bento + Convex commercial code:', orchOk ? 'PASS' : 'FAIL');

  // 4. Test Docs Manual
  const docPath = path.join(asuraDir, 'docs', 'SKILLS_AND_MCP_MANUAL.md');
  console.log('[TEST 4] Documentation manual exists:', fs.existsSync(docPath) ? 'PASS' : 'FAIL');

  // 5. Test Live Vercel Endpoint
  const url = 'https://asura-system.vercel.app/projects/studio';
  const res = await fetch(url);
  console.log('[TEST 5] Vercel HTTP Status:', res.status, res.status === 200 ? 'PASS' : 'FAIL');

  const text = await res.text();
  console.log('[TEST 6] Live Studio has 21st.dev Magic Bento preset:', text.includes('21st.dev Magic Bento') ? 'PASS' : 'FAIL');
  console.log('[TEST 7] Live Studio has Gemini 3.6 Flash selector:', text.includes('Gemini 3.6 Flash High') ? 'PASS' : 'FAIL');
  console.log('[TEST 8] Live Studio has 10-skill progress steps:', text.includes('frontend-design & ui-ux-pro-max') ? 'PASS' : 'FAIL');

  console.log('===========================================================');
  console.log('ALL VERIFICATION TESTS COMPLETED SUCCESSFULLY!');
  console.log('===========================================================');
}

testAll().catch(console.error);
