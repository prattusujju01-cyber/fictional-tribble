const fs = require('fs');
const path = require('path');

const targetPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\utils\\historical-screenplay-builder.js';
let code = fs.readFileSync(targetPath, 'utf8');

// The 12 extra beats to add cleanly after specific beats
const extraBeats = [
  {
    targetNarration: 'Until one sickly young prince decided that eternity had lasted long enough.',
    beat: {
      bgType: 'egyptian_temple_karnak',
      characterPose: 'priests_counting_tribute',
      expression: 'smug_curious',
      narration: 'The High Priest of Amun was the shadow ruler of the kingdom, whispering commands behind gilded incense smoke.',
      visual: 'A high priest with an ornate leopard-skin stole glaring down from a carved stone dais.'
    }
  },
  {
    targetNarration: 'Until Amenhotep IV climbed the temple steps and made a declaration that stunned the empire.',
    beat: {
      bgType: 'cosmic_aten_revelation',
      characterPose: 'aten_sun_disc_radiant',
      expression: 'awe_wonder',
      narration: 'Light was no longer a mystery hidden behind temple veils; light was the universal father of every living thing.',
      visual: 'Solar rays piercing through temple doorways, casting blinding amber shafts across the sand.'
    }
  },
  {
    targetNarration: 'He ordered royal stonemasons across Egypt to take up bronze chisels and march into every temple.',
    beat: {
      bgType: 'temple_desecration_scaffold',
      characterPose: 'bronze_chisels_flying_dust',
      expression: 'determined',
      narration: "Every single hieroglyph spelling the plural word for 'gods' was gouged out with iron and stone.",
      visual: 'Close-up of a carved stone wall with the plural glyph for deities violently smashed into raw rubble.'
    }
  },
  {
    targetNarration: 'Tens of thousands of mudbrick houses, paved boulevards, and open-air courtyards erupted from the dust.',
    beat: {
      bgType: 'amarna_construction_rise',
      characterPose: 'roofless_temple_courtyards',
      expression: 'determined',
      narration: 'Thousands of stone cutters worked under armed guard day and night to manifest the holy city from raw stone.',
      visual: 'Torchlit night construction in the desert, with fires illuminating columns rising against the stars.'
    }
  },
  {
    targetNarration: 'He called it Akhetaten: The Horizon of the Sun Disc. Today, we know it as Amarna.',
    beat: {
      bgType: 'amarna_grand_avenue',
      characterPose: 'chariot_procession_gold',
      expression: 'grinning',
      narration: 'The Royal Road of Amarna stretched four miles long, wider than any boulevard in the ancient Mediterranean world.',
      visual: 'A vast paved ceremonial avenue stretching straight toward the horizon, lined with fluttering white banners.'
    }
  },
  {
    targetNarration: 'From his palace terrace, Akhenaten composed the Great Hymn to the Aten.',
    beat: {
      bgType: 'royal_palace_balcony',
      characterPose: 'pharaoh_chanting_hymn',
      expression: 'inspired',
      narration: "'When the chick in the egg cries in the shell, thou givest him breath therein to preserve him alive.'",
      visual: 'A small bird hatching from an egg illuminated by delicate golden sunbeams in a palace nest.'
    }
  },
  {
    targetNarration: 'She was depicted not as a quiet consort, but riding royal chariots and smiting enemies of the state.',
    beat: {
      bgType: 'nefertiti_throne_terrace',
      characterPose: 'wearing_blue_crown',
      expression: 'determined',
      narration: 'Her famous limestone bust, sculpted by Thutmose, would become the eternal global symbol of feminine grace.',
      visual: 'Sculptor Thutmose applying delicate black kohl pigment to the eye of the iconic blue-crowned bust.'
    }
  },
  {
    targetNarration: 'In Anatolia, the warlike Hittite Empire sensed Egyptian weakness and mobilized iron-clad armies.',
    beat: {
      bgType: 'hittite_invasion_plain',
      characterPose: 'hittite_chariots_charging',
      expression: 'shocked',
      narration: 'The strategic fortress city of Qadesh fell without a single Egyptian relief column sent to break the siege.',
      visual: 'Smoking ruins of a stone fortress with fallen Egyptian banners trampled under bronze chariot wheels.'
    }
  },
  {
    targetNarration: 'Amarna, once a buzzing paradise of twenty thousand souls, was consumed by weeping and funeral pyres.',
    beat: {
      bgType: 'plague_palace_chambers',
      characterPose: 'weeping_over_burial_bier',
      expression: 'scared',
      narration: 'The high desert sun offered no protection against microscopic death. The city became a silent tomb.',
      visual: 'A lone vulture circling high in the pale desert sky above the quiet white rooftops of Amarna.'
    }
  },
  {
    targetNarration: 'His body was hurried into a remote rock-cut tomb in the royal wadi and sealed away in haste.',
    beat: {
      bgType: 'royal_wadi_tomb',
      characterPose: 'sealing_desert_tomb',
      expression: 'deadpan',
      narration: 'No public mourning echoed through the streets. The priests of Thebes were already boarding their warships.',
      visual: 'War galleys on the Nile loaded with armed spearmen flying the ancient banners of falcon Horus.'
    }
  },
  {
    targetNarration: 'They systematically dismantled the sun city of Akhenaten stone by individual stone.',
    beat: {
      bgType: 'demolition_of_amarna',
      characterPose: 'talatat_used_as_rubble',
      expression: 'determined',
      narration: 'It was the largest systematic demolition campaign in the three-thousand-year chronicle of the pharaohs.',
      visual: 'Colossal dust clouds rising as the magnificent Great Palace of Akhenaten is pulled down by ropes.'
    }
  },
  {
    targetNarration: 'The pharaoh who deleted the gods had himself been deleted from the official memory of Egypt.',
    beat: {
      bgType: 'archaeological_resurrection',
      characterPose: 'world_remembering_akhenaten',
      expression: 'awe_wonder',
      narration: 'His revolutionary vision of light outlasted the bronze spears and stone temples of all who tried to destroy him.',
      visual: 'The golden sunset illuminating the modern Pyramids of Giza and the enduring sands of Egypt.'
    }
  }
];

// For each extra beat, find the closing brace of the beat containing targetNarration and insert the new beat after it
for (const eb of extraBeats) {
  const targetIndex = code.indexOf(eb.targetNarration);
  if (targetIndex === -1) {
    console.error('Could not find target narration:', eb.targetNarration);
    continue;
  }
  
  // Find the closing brace of this beat object
  const closeBraceIndex = code.indexOf('}', targetIndex);
  if (closeBraceIndex === -1) {
    console.error('Could not find closing brace for:', eb.targetNarration);
    continue;
  }
  
  const insertText = `,\n            {\n              bgType: "${eb.beat.bgType}",\n              characterPose: "${eb.beat.characterPose}",\n              expression: "${eb.beat.expression}",\n              narration: "${eb.beat.narration}",\n              visual: "${eb.beat.visual}"\n            }`;
  
  code = code.slice(0, closeBraceIndex + 1) + insertText + code.slice(closeBraceIndex + 1);
}

fs.writeFileSync(targetPath, code, 'utf8');
console.log('✅ Successfully expanded historical screenplay cleanly!');
