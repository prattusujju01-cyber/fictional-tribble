const fs = require('fs');
const path = require('path');

const target = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\assets\\scenes\\zenn_vector_test.svg';

const svg = `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720" width="1280" height="720">
  <!-- Background: Deep Navy Blue Night Sky -->
  <rect width="1280" height="720" fill="#1C3565"/>
  
  <!-- Ground: Flat Savanna Earth -->
  <rect y="560" width="1280" height="160" fill="#7A4B24"/>
  <line x1="0" y1="560" x2="1280" y2="560" stroke="#000000" stroke-width="4"/>

  <!-- Floating Predator Eyes in the Darkness -->
  <!-- Pair 1 (Upper Left) -->
  <g transform="translate(400, 160)">
    <ellipse cx="0" cy="0" rx="18" ry="20" fill="#FCD34D" stroke="#000000" stroke-width="3"/>
    <circle cx="-3" cy="0" r="6" fill="#000000"/>
    <ellipse cx="48" cy="0" rx="18" ry="20" fill="#FCD34D" stroke="#000000" stroke-width="3"/>
    <circle cx="45" cy="0" r="6" fill="#000000"/>
  </g>
  <!-- Pair 2 (Lower Left) -->
  <g transform="translate(260, 310)">
    <ellipse cx="0" cy="0" rx="20" ry="22" fill="#FCD34D" stroke="#000000" stroke-width="3"/>
    <circle cx="2" cy="0" r="7" fill="#000000"/>
    <ellipse cx="52" cy="0" rx="20" ry="22" fill="#FCD34D" stroke="#000000" stroke-width="3"/>
    <circle cx="50" cy="0" r="7" fill="#000000"/>
  </g>
  <!-- Pair 3 (Upper Right) -->
  <g transform="translate(850, 150)">
    <ellipse cx="0" cy="0" rx="18" ry="20" fill="#FCD34D" stroke="#000000" stroke-width="3"/>
    <circle cx="-3" cy="0" r="6" fill="#000000"/>
    <ellipse cx="48" cy="0" rx="18" ry="20" fill="#FCD34D" stroke="#000000" stroke-width="3"/>
    <circle cx="45" cy="0" r="6" fill="#000000"/>
  </g>
  <!-- Pair 4 (Lower Right) -->
  <g transform="translate(980, 300)">
    <ellipse cx="0" cy="0" rx="18" ry="21" fill="#FCD34D" stroke="#000000" stroke-width="3"/>
    <circle cx="-1" cy="0" r="6" fill="#000000"/>
    <ellipse cx="48" cy="0" rx="18" ry="21" fill="#FCD34D" stroke="#000000" stroke-width="3"/>
    <circle cx="47" cy="0" r="6" fill="#000000"/>
  </g>

  <!-- Stickman Character -->
  <g transform="translate(640, 360)">
    <!-- Stick Body -->
    <line x1="0" y1="-80" x2="0" y2="110" stroke="#000000" stroke-width="6" stroke-linecap="round"/>
    <!-- Arms in walking pose -->
    <line x1="0" y1="-40" x2="-60" y2="10" stroke="#000000" stroke-width="5" stroke-linecap="round"/>
    <line x1="-60" y1="10" x2="-75" y2="70" stroke="#000000" stroke-width="5" stroke-linecap="round"/>
    <line x1="0" y1="-40" x2="50" y2="10" stroke="#000000" stroke-width="5" stroke-linecap="round"/>
    <line x1="50" y1="10" x2="70" y2="60" stroke="#000000" stroke-width="5" stroke-linecap="round"/>
    <!-- Legs in walking pose -->
    <line x1="0" y1="110" x2="-65" y2="155" stroke="#000000" stroke-width="6" stroke-linecap="round"/>
    <line x1="-65" y1="155" x2="-95" y2="200" stroke="#000000" stroke-width="6" stroke-linecap="round"/>
    <line x1="0" y1="110" x2="40" y2="155" stroke="#000000" stroke-width="6" stroke-linecap="round"/>
    <line x1="40" y1="155" x2="70" y2="200" stroke="#000000" stroke-width="6" stroke-linecap="round"/>

    <!-- Head: Clean white circle with bold black outline -->
    <circle cx="0" cy="-155" r="72" fill="#FFFFFF" stroke="#000000" stroke-width="6"/>
    
    <!-- Deadpan Eyebrows (Horizontal) -->
    <line x1="-42" y1="-180" x2="-12" y2="-180" stroke="#000000" stroke-width="4" stroke-linecap="round"/>
    <line x1="12" y1="-180" x2="42" y2="-180" stroke="#000000" stroke-width="4" stroke-linecap="round"/>
    
    <!-- Wide Blank Cartoon Eyes -->
    <circle cx="-26" cy="-155" r="16" fill="#FFFFFF" stroke="#000000" stroke-width="3"/>
    <circle cx="-21" cy="-155" r="6" fill="#000000"/>
    <circle cx="26" cy="-155" r="16" fill="#FFFFFF" stroke="#000000" stroke-width="3"/>
    <circle cx="31" cy="-155" r="6" fill="#000000"/>

    <!-- Deadpan Mouth Line -->
    <line x1="-28" y1="-115" x2="28" y2="-115" stroke="#000000" stroke-width="4" stroke-linecap="round"/>
  </g>
</svg>
`;

fs.writeFileSync(target, svg, 'utf8');
console.log('✅ Zenn vector SVG created at:', target);
