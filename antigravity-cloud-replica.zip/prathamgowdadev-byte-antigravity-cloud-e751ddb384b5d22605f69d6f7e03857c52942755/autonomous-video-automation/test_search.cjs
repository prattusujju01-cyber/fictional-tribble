const FIRECRAWL_KEY = 'fc-9580658b488a4455850b07c92bd7ed59';

async function search(q) {
  const res = await fetch('https://api.firecrawl.dev/v1/search', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${FIRECRAWL_KEY}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ query: q, limit: 5 })
  });
  return await res.json();
}

async function run() {
  const queries = [
    '"Dental Clinic" "Bangalore" "whatsapp" "91" site:facebook.com',
    '"Interior Designer" "Bangalore" "whatsapp" "91" site:facebook.com'
  ];

  for (const q of queries) {
    console.log(`\n=== QUERY: ${q} ===`);
    const data = await search(q);
    for (const d of (data.data || [])) {
      console.log(`Title: ${d.title}`);
      console.log(`Desc: ${d.description ? d.description.slice(0, 180) : ''}...`);
    }
  }
}

run().catch(console.error);
