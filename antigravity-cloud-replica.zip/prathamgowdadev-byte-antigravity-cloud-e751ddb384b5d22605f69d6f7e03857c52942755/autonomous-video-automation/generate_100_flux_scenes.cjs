const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const WORKSPACE = 'C:/Users/WINDOWS/.gemini/antigravity/scratch/youtube-automation-agent';
const { Client } = require(path.join(WORKSPACE, 'node_modules/@gradio/client'));
const sharp = require(path.join(WORKSPACE, 'node_modules/sharp'));

const TOKEN = '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';
const SCENES_DIR = path.join(WORKSPACE, 'assets/scenes');
const SCREENPLAY_PATH = path.join(WORKSPACE, 'assets/screenplay.json');

// Old duplicate hashes from the 6 copied master files
const OLD_DUPLICATE_HASHES = new Set([
  'c92a09193a1b1f786d639c776fed6b60',
  'b51f359f202daf0b961d2d1b492d9f9a',
  '8493b06ae16af0acd33a8756a8e64ae0',
  '254d1b17d30081d2fd78cb0d0a22d5f3',
  '2ce79ae674dfaa559a20a37778eac3f9',
  'ab6453e6b0641318b256c39424a612d3'
]);

function getFileHash(filePath) {
  if (!fs.existsSync(filePath)) return null;
  const buffer = fs.readFileSync(filePath);
  return crypto.createHash('md5').update(buffer).digest('hex').toLowerCase();
}

async function runBatchGenerator(startIdx = 1, endIdx = 100) {
  console.log('================================================================');
  console.log('🚀 HERMES V8.0: AUTONOMOUS 100-SCENE FLUX VISUAL GENERATOR');
  console.log('🎨 Model: black-forest-labs/FLUX.1-schnell (ZeroGPU Engine)');
  console.log('🔑 Auth: User Hugging Face Token (Authenticated Unlimited Quota)');
  console.log(`🎯 Processing: Scenes ${startIdx} through ${endIdx}`);
  console.log('================================================================\n');

  const screenplay = JSON.parse(fs.readFileSync(SCREENPLAY_PATH, 'utf8'));
  const scenes = screenplay.scenes;

  console.log('Connecting to FLUX.1-schnell Gradio space...');
  let app = await Client.connect('black-forest-labs/FLUX.1-schnell', { token: TOKEN });
  console.log('✅ Connected to FLUX space successfully.\n');

  let generatedCount = 0;
  let skippedCount = 0;

  for (let i = startIdx - 1; i < Math.min(endIdx, scenes.length); i++) {
    const scene = scenes[i];
    const padNum = String(scene.sceneNumber).padStart(3, '0');
    const targetFile = path.join(SCENES_DIR, `scene_${padNum}.jpg`);

    // Check if valid unique image already exists
    const currentHash = getFileHash(targetFile);
    if (currentHash && !OLD_DUPLICATE_HASHES.has(currentHash)) {
      console.log(`⏩ [${scene.sceneNumber}/100] Scene ${padNum}: Already generated (${(fs.statSync(targetFile).size / 1024).toFixed(0)} KB) -> Skipping.`);
      skippedCount++;
      continue;
    }

    console.log(`🎨 [${scene.sceneNumber}/100] Rendering Scene ${padNum}: "${scene.sceneTitle}"...`);
    console.log(`   📝 Subprompt: ${scene.subPrompt.slice(0, 90)}...`);

    let success = false;
    let attempts = 0;

    while (!success && attempts < 3) {
      attempts++;
      try {
        const seed = Math.floor(Math.random() * 10000000);
        const result = await app.predict('/infer', [
          scene.fullPrompt,
          seed,
          true,
          1024,
          576,
          4
        ]);

        if (result && result.data && result.data[0] && result.data[0].url) {
          const imgUrl = result.data[0].url;
          const imgRes = await fetch(imgUrl, { headers: { Authorization: 'Bearer ' + TOKEN } });
          const webpBuf = Buffer.from(await imgRes.arrayBuffer());

          // Convert to pristine JPEG using sharp
          const jpgBuf = await sharp(webpBuf).jpeg({ quality: 92 }).toBuffer();
          fs.writeFileSync(targetFile, jpgBuf);

          console.log(`   ✅ [${scene.sceneNumber}/100] Scene ${padNum} SAVED: ${(jpgBuf.length / 1024).toFixed(0)} KB JPEG\n`);
          success = true;
          generatedCount++;
          
          // Small 1.5s delay between generations
          await new Promise(r => setTimeout(r, 1500));
        } else {
          throw new Error('No URL in predict result');
        }
      } catch (err) {
        console.warn(`   ⚠️ Attempt ${attempts} failed for scene ${scene.sceneNumber}: ${err.message}`);
        if (attempts >= 3) {
          console.error(`   ❌ Giving up on scene ${scene.sceneNumber} after 3 attempts.`);
        } else {
          try {
            app = await Client.connect('black-forest-labs/FLUX.1-schnell', { token: TOKEN });
          } catch(e) {}
          await new Promise(r => setTimeout(r, 4000));
        }
      }
    }
  }

  console.log('================================================================');
  console.log(`🎉 BATCH GENERATION RUN COMPLETE!`);
  console.log(`✨ Generated: ${generatedCount} new unique scenes`);
  console.log(`⏩ Skipped: ${skippedCount} already unique scenes`);
  console.log('================================================================\n');
}

const args = process.argv.slice(2);
const start = args[0] ? parseInt(args[0]) : 1;
const end = args[1] ? parseInt(args[1]) : 100;

runBatchGenerator(start, end).catch(err => {
  console.error('Fatal batch error:', err);
  process.exit(1);
});
