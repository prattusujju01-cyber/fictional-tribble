const fs = require('fs');
const path = require('path');

const indexPath = path.join('C:', 'Users', 'WINDOWS', '.gemini', 'antigravity', 'scratch', 'asura-system', 'index.html');
const html = fs.readFileSync(indexPath, 'utf8');

// Check script tags
const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/gi)];
console.log('Script tags matched:', scripts.length);
scripts.forEach((s, idx) => {
  try {
    new Function(s[1]);
    console.log(`Script block ${idx}: PARSED CLEANLY (0 errors)`);
  } catch (err) {
    console.error(`Script block ${idx}: PARSE ERROR:`, err.message);
  }
});

// Check orb elements
console.log('Has jarvisCanvas:', html.includes('id="jarvisCanvas"'));
console.log('Has jarvis-ring-outer:', html.includes('jarvis-ring-outer'));
console.log('Has jarvis-ring-middle:', html.includes('jarvis-ring-middle'));
console.log('Has jarvis-white-glow-bg:', html.includes('jarvis-white-glow-bg'));

// Check desktop launcher
const batPath = path.join('C:', 'Users', 'WINDOWS', 'Desktop', 'ASURA AI Web Developer.bat');
const bat = fs.readFileSync(batPath, 'utf8');
console.log('Desktop BAT content:\n' + bat);
