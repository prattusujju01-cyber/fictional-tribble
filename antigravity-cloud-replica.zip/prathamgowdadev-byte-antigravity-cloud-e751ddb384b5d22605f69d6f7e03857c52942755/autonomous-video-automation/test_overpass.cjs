const OVERPASS_MIRRORS = [
  "https://overpass.kumi.systems/api/interpreter",
  "https://lz4.overpass-api.de/api/interpreter",
  "https://overpass.private.coffee/api/interpreter",
  "https://overpass-api.de/api/interpreter"
];

async function testQuery() {
  // Miami center: 25.7617, -80.1918
  // Fast query: node(around:3000, 25.7617, -80.1918)["amenity"="dentist"];
  const query = `[out:json][timeout:10];
node(around:5000, 25.7617, -80.1918)["amenity"~"dentist|clinic|doctors"];
out body 15;`;

  for (const endpoint of OVERPASS_MIRRORS) {
    try {
      console.log(`Trying Overpass mirror: ${endpoint}...`);
      const res = await fetch(endpoint, {
        method: "POST",
        body: "data=" + encodeURIComponent(query),
        headers: {
          "Content-Type": "application/x-www-form-urlencoded",
          "User-Agent": "AsuraHunterEngine/1.0"
        }
      });
      console.log(`Mirror ${endpoint} returned status: ${res.status}`);
      if (res.status === 200) {
        const data = await res.json();
        console.log(`SUCCESS! Received ${data.elements?.length || 0} nodes.`);
        for (const el of (data.elements || []).slice(0, 5)) {
          console.log(`- ${el.tags?.name || 'Unnamed'} | Phone: ${el.tags?.phone || el.tags?.['contact:phone'] || 'N/A'} | Website: ${el.tags?.website || 'NONE'}`);
        }
        return;
      }
    } catch (e) {
      console.log(`Mirror ${endpoint} error: ${e.message}`);
    }
  }
}

testQuery();
