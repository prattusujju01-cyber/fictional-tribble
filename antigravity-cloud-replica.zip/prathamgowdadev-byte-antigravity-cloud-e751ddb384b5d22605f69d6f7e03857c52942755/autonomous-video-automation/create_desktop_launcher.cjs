const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const desktopPath = 'C:\\Users\\WINDOWS\\Desktop';
const batPath = path.join(desktopPath, 'ASURA AI Web Developer.bat');

const batContent = `@echo off
title ASURA AGENTIC AI WEBSITE DEVELOPER
color 0A
cls
echo ================================================================
echo           ASURA AGENTIC AI WEBSITE DEVELOPER STUDIO             
echo ================================================================
echo [*] Initializing local studio runtime on http://localhost:3000...
cd /d "C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system"
start "" /b node scripts/asura_studio_server.cjs
timeout /t 2 /nobreak >nul
echo [*] Opening Asura Studio in default browser...
start http://localhost:3000
echo.
echo [OK] Asura Agentic AI Website Developer is active!
echo      Workspace: http://localhost:3000
echo      Cloud URL: https://asura-system.vercel.app
echo ================================================================
`;

fs.writeFileSync(batPath, batContent, 'utf8');
console.log('Created: ' + batPath);

// Create .lnk shortcut with high-tech icon
try {
  const psCmd = `$s=(New-Object -COM WScript.Shell).CreateShortcut('C:\\Users\\WINDOWS\\Desktop\\ASURA AI Web Developer.lnk');$s.TargetPath='C:\\Users\\WINDOWS\\Desktop\\ASURA AI Web Developer.bat';$s.WorkingDirectory='C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system';$s.Description='Asura Agentic AI Website Developer';$s.IconLocation='shell32.dll,14';$s.Save()`;
  execSync(`powershell -NoProfile -Command "${psCmd}"`);
  console.log('Created: C:\\Users\\WINDOWS\\Desktop\\ASURA AI Web Developer.lnk');
} catch (e) {
  console.warn('LNK shortcut note:', e.message);
}
