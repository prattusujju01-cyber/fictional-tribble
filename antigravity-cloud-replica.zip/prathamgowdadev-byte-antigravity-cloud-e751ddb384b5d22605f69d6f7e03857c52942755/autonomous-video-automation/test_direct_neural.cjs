const WebSocket = require('C:/Users/WINDOWS/.gemini/antigravity/scratch/node_modules/ws');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const TRUSTED_TOKEN = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';
const SEC_VERSION = '1-130.0.2849.68';

function generateSecMsGec() {
  let ts = BigInt(Math.floor(Date.now() / 1000) + 11644473600);
  ts = ts - (ts % 300n);
  ts = ts * 10000000n;
  const str = ts.toString() + TRUSTED_TOKEN;
  return crypto.createHash('sha256').update(str, 'ascii').digest('hex').toUpperCase();
}

async function synthesizeText(text, voiceName = 'en-US-ChristopherNeural', outPath = './assets/audio/test_speech.mp3') {
  const connectionId = crypto.randomBytes(16).toString('hex');
  const secMsGec = generateSecMsGec();
  const muid = crypto.randomBytes(16).toString('hex').toUpperCase();
  const url = `wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1?TrustedClientToken=${TRUSTED_TOKEN}&ConnectionId=${connectionId}&Sec-MS-GEC=${secMsGec}&Sec-MS-GEC-Version=${SEC_VERSION}`;

  return new Promise((resolve, reject) => {
    const ws = new WebSocket(url, {
      headers: {
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0',
        'Origin': 'chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold',
        'Cookie': `muid=${muid};`
      }
    });

    const chunks = [];
    ws.on('open', () => {
      console.log('Connected to Neural TTS service...');
      const config = {
        context: {
          synthesis: {
            audio: {
              metadataoptions: { sentenceBoundaryEnabled: 'false', wordBoundaryEnabled: 'false' },
              outputFormat: 'audio-24khz-48kbitrate-mono-mp3'
            }
          }
        }
      };
      ws.send(`X-Timestamp:${new Date().toISOString()}\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n${JSON.stringify(config)}`);

      const parts = voiceName.split('-');
      const locale = `${parts[0]}-${parts[1]}`;
      const name = parts[2];
      const fullName = `Microsoft Server Speech Text to Speech Voice (${locale}, ${name})`;

      const ssml = `<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'><voice name='${fullName}'><prosody rate='+0%' pitch='+0Hz'>${text}</prosody></voice></speak>`;
      const reqId = crypto.randomBytes(16).toString('hex');
      ws.send(`X-RequestId:${reqId}\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:${new Date().toISOString()}Z\r\nPath:ssml\r\n\r\n${ssml}`);
    });

    ws.on('message', (data, isBinary) => {
      if (!isBinary) {
        const str = data.toString('utf8');
        if (str.includes('Path:turn.end')) {
          ws.close();
          const buffer = Buffer.concat(chunks);
          fs.mkdirSync(path.dirname(outPath), { recursive: true });
          fs.writeFileSync(outPath, buffer);
          resolve({ outPath, bytes: buffer.length });
        }
      } else {
        const headerLen = data.readUInt16BE(0);
        const audioBuf = data.subarray(headerLen + 2);
        chunks.push(audioBuf);
      }
    });

    ws.on('error', (err) => {
      reject(err);
    });

    setTimeout(() => {
      ws.close();
      if (chunks.length > 0) {
        const buffer = Buffer.concat(chunks);
        fs.mkdirSync(path.dirname(outPath), { recursive: true });
        fs.writeFileSync(outPath, buffer);
        resolve({ outPath, bytes: buffer.length });
      } else {
        reject(new Error('TTS timeout: No audio data received'));
      }
    }, 12000);
  });
}

synthesizeText('Tonight, when you flip a light switch in your bedroom, you literally do not think twice about it. But for 99.9% of human history, that switch did not exist.', 'en-US-ChristopherNeural')
  .then(res => console.log('🎉 SUCCESS! Neural Audio generated:', res.outPath, 'Bytes:', res.bytes))
  .catch(err => console.error('❌ Failed to synthesize:', err.message));
