const fs = require('fs');
const path = require('path');

const targetPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system\\index.html';

const htmlContent = `<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ASURA // Agentic AI Website Developer Studio</title>

  <!-- Google Fonts: Plus Jakarta Sans, Syne, JetBrains Mono -->
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;500;600;700;800&family=Syne:wght@700;800&family=JetBrains+Mono:wght@400;500;600;700&display=swap" rel="stylesheet">

  <!-- Tailwind CSS -->
  <script src="https://cdn.tailwindcss.com"></script>
  <!-- Three.js for 3D Jarvis Arc Reactor Orb -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js"></script>

  <script>
    tailwind.config = {
      darkMode: 'class',
      theme: {
        extend: {
          colors: {
            obsidian: {
              DEFAULT: '#08090C',
              50: '#171922',
              100: '#12141A',
              200: '#0E1015',
              300: '#0A0B0E',
              400: '#08090C',
              border: '#1A1D24'
            },
            cyan: {
              glow: '#00F0FF',
              dark: '#007A82'
            },
            lime: {
              DEFAULT: '#00FF66',
              glow: '#39FF14'
            }
          },
          fontFamily: {
            sans: ['"Plus Jakarta Sans"', 'sans-serif'],
            display: ['"Syne"', 'sans-serif'],
            mono: ['"JetBrains Mono"', 'monospace']
          }
        }
      }
    }
  </script>

  <style>
    body {
      background-color: #08090C;
      color: #E2E8F0;
      font-family: 'Plus Jakarta Sans', sans-serif;
      overflow: hidden;
      height: 100vh;
      width: 100vw;
    }
    
    /* Sleek Dark Scrollbar */
    ::-webkit-scrollbar { width: 5px; height: 5px; }
    ::-webkit-scrollbar-track { background: #08090C; }
    ::-webkit-scrollbar-thumb { background: #1A1D24; border-radius: 4px; }
    ::-webkit-scrollbar-thumb:hover { background: #2A303C; }

    /* Antigravity Input Focus Ring */
    .prompt-box {
      background: #12141A;
      border: 1px solid #1E232F;
      box-shadow: 0 10px 30px -10px rgba(0, 0, 0, 0.5);
      transition: all 0.25s ease;
    }
    .prompt-box:focus-within {
      border-color: #00F0FF;
      box-shadow: 0 0 25px rgba(0, 240, 255, 0.18), 0 12px 35px -10px rgba(0, 0, 0, 0.7);
    }

    /* Kinetic Jarvis Core Pulse */
    @keyframes coreGlow {
      0% { filter: drop-shadow(0 0 15px rgba(0, 240, 255, 0.4)); }
      50% { filter: drop-shadow(0 0 35px rgba(0, 255, 102, 0.6)); }
      100% { filter: drop-shadow(0 0 15px rgba(0, 240, 255, 0.4)); }
    }
    .jarvis-glow {
      animation: coreGlow 4s ease-in-out infinite;
    }
  </style>
</head>
<body class="flex h-screen w-screen selection:bg-cyan-glow selection:text-black">

  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <!-- 1. LEFT SIDEBAR: ANTIGRAVITY IDE INTERFACE (MIRRORING USER PHOTO) -->
  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <aside class="w-64 sm:w-72 bg-obsidian-200 border-r border-obsidian-border flex flex-col shrink-0 select-none z-30">
    
    <!-- Top Brand & New Conversation -->
    <div class="p-3.5 space-y-3 border-b border-obsidian-border">
      <div class="flex items-center justify-between px-1.5 pt-1">
        <div class="flex items-center space-x-2">
          <div class="w-6 h-6 rounded-md bg-cyan-glow/10 border border-cyan-glow/30 flex items-center justify-center text-cyan-glow text-xs font-mono font-bold">
            ⟐
          </div>
          <span class="font-display font-bold text-white text-sm tracking-wide">
            ASURA<span class="text-cyan-glow font-mono text-xs ml-0.5">STUDIO</span>
          </span>
        </div>
        <span class="px-2 py-0.5 rounded text-[10px] font-mono bg-obsidian-100 border border-obsidian-border text-zinc-400">
          v5.0 AGENTIC
        </span>
      </div>

      <!-- + New Conversation Pill Button (From Photo) -->
      <button onclick="startNewConversation()" class="w-full py-2 px-3 rounded-lg bg-obsidian-100 hover:bg-obsidian-50 border border-obsidian-border hover:border-cyan-glow/50 text-white font-medium text-xs flex items-center justify-between transition shadow-sm group">
        <div class="flex items-center space-x-2">
          <span class="text-cyan-glow text-base font-bold leading-none">+</span>
          <span class="font-medium text-zinc-200">New Conversation</span>
        </div>
        <kbd class="text-[10px] font-mono text-zinc-500 bg-obsidian-200 px-1.5 py-0.5 rounded">Ctrl N</kbd>
      </button>
    </div>

    <!-- Navigation Views Switcher -->
    <div class="px-3 py-2 space-y-1 text-xs font-medium border-b border-obsidian-border">
      <button onclick="switchMainView('home')" id="navHomeBtn" class="w-full px-2.5 py-2 rounded-lg bg-obsidian-100 text-white flex items-center space-x-2.5 transition">
        <!-- Message Icon -->
        <svg class="w-4 h-4 text-cyan-glow" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 12h.01M12 12h.01M16 12h.01M21 12c0 4.418-4.03 8-9 8a9.863 9.863 0 01-4.255-.949L3 20l1.395-3.72C3.512 15.042 3 13.574 3 12c0-4.418 4.03-8 9-8s9 3.582 9 8z"/></svg>
        <span>Conversation History</span>
      </button>

      <button onclick="switchMainView('radar')" id="navRadarBtn" class="w-full px-2.5 py-2 rounded-lg hover:bg-obsidian-100 text-zinc-400 hover:text-white flex items-center justify-between transition">
        <div class="flex items-center space-x-2.5">
          <!-- Globe / Vercel Radar Icon -->
          <svg class="w-4 h-4 text-emerald-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 12a9 9 0 01-9 9m9-9a9 9 0 00-9-9m9 9H3m9 9a9 9 0 01-9-9m9 9c1.657 0 3-4.03 3-9s-1.343-9-3-9m0 18c-1.657 0-3-4.03-3-9s1.343-9 3-9m-9 9a9 9 0 019-9"/></svg>
          <span>Vercel Live Radar</span>
        </div>
        <span class="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
      </button>

      <button onclick="switchMainView('bots')" id="navBotsBtn" class="w-full px-2.5 py-2 rounded-lg hover:bg-obsidian-100 text-zinc-400 hover:text-white flex items-center space-x-2.5 transition">
        <!-- Robot Icon -->
        <svg class="w-4 h-4 text-purple-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 3v2m6-2v2M9 19v2m6-2v2M5 9H3m2 6H3m18-6h-2m2 6h-2M7 19h10a2 2 0 002-2V7a2 2 0 00-2-2H7a2 2 0 00-2 2v10a2 2 0 002 2zM9 9h6v6H9V9z"/></svg>
        <span>Scheduled Tasks & Bots</span>
      </button>
    </div>

    <!-- Saved Projects & History List (From User Photo) -->
    <div class="flex-1 overflow-y-auto px-3 py-3 space-y-1">
      <div class="text-[11px] font-mono uppercase tracking-wider text-zinc-500 px-2 pb-1 flex items-center justify-between">
        <span>Projects History</span>
        <button onclick="clearAllHistory()" class="hover:text-rose-400 text-[10px]">Clear</button>
      </div>

      <div id="conversationsList" class="space-y-1 text-xs">
        <!-- Rendered dynamically by renderHistoryList() -->
      </div>
    </div>

    <!-- Bottom Settings -->
    <div class="p-3 border-t border-obsidian-border bg-obsidian-200">
      <button onclick="openSettingsModal()" class="w-full py-2 px-3 rounded-lg hover:bg-obsidian-100 text-zinc-400 hover:text-white flex items-center justify-between text-xs font-medium transition">
        <div class="flex items-center space-x-2.5">
          <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
          <span>Settings</span>
        </div>
        <span class="text-[10px] font-mono text-zinc-500">Ctrl ,</span>
      </button>
    </div>
  </aside>

  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <!-- 2. MAIN VIEWPORT AREA -->
  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <div class="flex-1 flex flex-col h-screen overflow-hidden relative">

    <!-- Top Navigation Bar -->
    <header class="h-14 border-b border-obsidian-border bg-obsidian-400/80 backdrop-blur-md px-6 flex items-center justify-between z-20">
      <div class="flex items-center space-x-3">
        <button id="activeSessionTitle" class="text-sm font-semibold text-white flex items-center space-x-1.5 hover:text-cyan-glow transition">
          <span>New Conversation</span>
          <svg class="w-3.5 h-3.5 text-zinc-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>
        </button>
      </div>

      <!-- Top Right Action Controls -->
      <div class="flex items-center space-x-3 font-mono text-xs">
        <button onclick="switchMainView('radar')" class="px-3 py-1.5 rounded-lg bg-obsidian-100 border border-obsidian-border hover:border-cyan-glow/40 text-zinc-300 flex items-center space-x-1.5 transition">
          <span class="w-2 h-2 rounded-full bg-emerald-400"></span>
          <span>VERCEL DEPLOYED SITES</span>
        </button>

        <a href="https://asura-system.vercel.app" target="_blank" class="px-3.5 py-1.5 rounded-lg bg-cyan-glow hover:bg-cyan-400 text-black font-extrabold transition shadow-lg shadow-cyan-glow/20 flex items-center space-x-1.5">
          <span>CONNECT TO CLOUD</span>
          <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
        </a>
      </div>
    </header>

    <!-- VIEW CONTAINER -->
    <div class="flex-1 overflow-hidden relative">

      <!-- ─────────────────────────────────────────────────────────────────── -->
      <!-- VIEW 1: HOME & JARVIS ORB CENTERPIECE + ANTIGRAVITY CHAT SPACE -->
      <!-- ─────────────────────────────────────────────────────────────────── -->
      <div id="viewHome" class="h-full w-full flex flex-col items-center justify-between p-6 overflow-y-auto">

        <!-- Top Section: Interactive Jarvis Arc Reactor Orb -->
        <div class="w-full flex-1 flex flex-col items-center justify-center relative my-auto">
          
          <!-- Three.js Jarvis Orb Canvas -->
          <div class="relative w-64 h-64 sm:w-80 sm:h-80 flex items-center justify-center">
            <canvas id="jarvisCanvas" class="w-full h-full cursor-pointer jarvis-glow"></canvas>

            <!-- Central Holographic Core Label -->
            <div class="absolute inset-0 flex flex-col items-center justify-center pointer-events-none text-center">
              <span class="text-[10px] font-mono uppercase tracking-widest text-cyan-glow/80 font-bold">JARVIS NEURAL CORE</span>
              <span class="text-xs font-mono text-zinc-400 mt-0.5">READY FOR DIRECTIVE</span>
            </div>
          </div>

          <!-- Quick Actions HUD Around Orb -->
          <div class="flex flex-wrap items-center justify-center gap-2.5 mt-2 font-mono text-xs">
            <button onclick="prefillPrompt('Create a luxury real estate website with dark obsidian theme, 3D villa parallax, and interactive inquiry form')" class="px-3 py-1.5 rounded-lg bg-obsidian-100 hover:bg-obsidian-50 border border-obsidian-border text-zinc-300 hover:text-cyan-glow transition">
              Luxury Real Estate
            </button>
            <button onclick="prefillPrompt('Create an ultra-modern crypto fintech website with dynamic 3D globe and interactive wallet connection')" class="px-3 py-1.5 rounded-lg bg-obsidian-100 hover:bg-obsidian-50 border border-obsidian-border text-zinc-300 hover:text-cyan-glow transition">
              FinTech Crypto Portal
            </button>
            <button onclick="prefillPrompt('Create a high-converting aesthetic dental & implant clinic landing page with before/after slider and booking wizard')" class="px-3 py-1.5 rounded-lg bg-obsidian-100 hover:bg-obsidian-50 border border-obsidian-border text-zinc-300 hover:text-cyan-glow transition">
              Aesthetic Medical Clinic
            </button>
            <button onclick="switchMainView('radar')" class="px-3 py-1.5 rounded-lg bg-obsidian-100 hover:bg-obsidian-50 border border-emerald-500/30 text-emerald-400 transition">
              Live Vercel Monitor
            </button>
          </div>
        </div>

        <!-- Bottom Section: Centered Antigravity / ChatGPT Style Command Bar -->
        <div class="w-full max-w-3xl pb-4">
          
          <!-- Attachment Pill Preview Bar -->
          <div id="attachmentPillsBar" class="hidden mb-2 flex flex-wrap gap-2 text-xs font-mono"></div>

          <!-- Main Input Pill Box (Matching Photo) -->
          <div class="prompt-box rounded-2xl p-3.5 space-y-2">
            <!-- Textarea -->
            <textarea id="promptInput" rows="2" placeholder="Ask anything, @ to mention, / for actions" class="w-full bg-transparent text-white text-sm placeholder-zinc-500 focus:outline-none resize-none leading-relaxed"></textarea>

            <!-- Bottom Controls: + Button, Model Dropdown, Mic, Send -->
            <div class="flex items-center justify-between pt-1 border-t border-obsidian-border/60">
              
              <div class="flex items-center space-x-2">
                <!-- PLUS (+) BUTTON: INTAKE PHOTOS, VIDEOS, ZIP, MD FILES -->
                <button onclick="openAttachmentModal()" title="Add reference photos, videos, ZIP, or .md files" class="w-7 h-7 rounded-lg bg-obsidian-200 hover:bg-obsidian-50 border border-obsidian-border hover:border-cyan-glow text-zinc-300 hover:text-cyan-glow flex items-center justify-center font-bold text-base transition">
                  +
                </button>

                <!-- Model Selector Dropdown -->
                <div class="relative">
                  <select id="modelSelector" class="bg-obsidian-200 border border-obsidian-border hover:border-zinc-700 text-zinc-200 text-xs rounded-lg px-2.5 py-1.5 font-mono focus:outline-none appearance-none pr-7 cursor-pointer">
                    <option value="Asura 3.5 Flash High">Gemini 2.0 Flash High</option>
                    <option value="Asura Neural Pro">Asura Neural Pro (Full Kinetic)</option>
                    <option value="Claude 3.7 Sonnet">Claude 3.7 Sonnet Reasoning</option>
                  </select>
                  <div class="absolute right-2 top-1/2 -translate-y-1/2 pointer-events-none text-zinc-400 text-[10px]">▼</div>
                </div>
              </div>

              <!-- Right: Mic & Submit -->
              <div class="flex items-center space-x-2">
                <button onclick="toggleVoiceInput()" title="Voice input" id="micBtn" class="w-7 h-7 rounded-lg hover:bg-obsidian-100 text-zinc-400 hover:text-white flex items-center justify-center transition">
                  <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"/></svg>
                </button>

                <button onclick="submitPrompt()" id="sendBtn" class="px-4 py-1.5 rounded-lg bg-cyan-glow hover:bg-cyan-400 text-black font-extrabold text-xs font-mono transition flex items-center space-x-1 shadow-md shadow-cyan-glow/20 active:scale-95">
                  <span>SEND</span>
                  <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
                </button>
              </div>

            </div>
          </div>

          <div class="text-center text-[11px] font-mono text-zinc-600 mt-2">
            Asura Agentic AI Website Developer &bull; Analyzes Photos, Videos, ZIP, and .MD References
          </div>
        </div>

      </div>

      <!-- ─────────────────────────────────────────────────────────────────── -->
      <!-- VIEW 2: ACTIVE AGENTIC WEB DEV WORKSPACE (CHAT + LIVE SANDBOX) -->
      <!-- ─────────────────────────────────────────────────────────────────── -->
      <div id="viewWorkspace" class="h-full w-full hidden flex flex-col lg:flex-row overflow-hidden">
        
        <!-- Left Pane: Agent Conversation & Thought Trace -->
        <div class="w-full lg:w-1/2 h-full border-r border-obsidian-border flex flex-col bg-obsidian-300">
          <div class="p-3 border-b border-obsidian-border flex items-center justify-between bg-obsidian-200">
            <span class="text-xs font-mono text-cyan-glow font-bold flex items-center gap-1.5">
              <span class="w-2 h-2 rounded-full bg-cyan-glow animate-pulse"></span>
              AGENTIC REASONING TRAJECTORY
            </span>
            <button onclick="switchMainView('home')" class="text-xs font-mono text-zinc-400 hover:text-white">&larr; Back to Orb</button>
          </div>

          <!-- Messages Stream -->
          <div id="chatStream" class="flex-1 overflow-y-auto p-4 space-y-4 font-mono text-xs">
            <!-- Dynamically populated -->
          </div>

          <!-- Bottom Mini Input Bar for Follow-up Revisions -->
          <div class="p-3 border-t border-obsidian-border bg-obsidian-200">
            <div class="flex items-center space-x-2">
              <input type="text" id="followUpInput" placeholder="Request code change, animation tweak, or new section..." class="flex-1 bg-obsidian-100 border border-obsidian-border focus:border-cyan-glow text-white px-3 py-2 rounded-lg text-xs outline-none">
              <button onclick="submitFollowUp()" class="px-4 py-2 bg-cyan-glow hover:bg-cyan-400 text-black font-bold text-xs rounded-lg transition">UPDATE</button>
            </div>
          </div>
        </div>

        <!-- Right Pane: Live Interactive Website Sandbox & Code Inspector -->
        <div class="w-full lg:w-1/2 h-full flex flex-col bg-obsidian-400">
          <!-- Sandbox Header -->
          <div class="p-3 border-b border-obsidian-border flex items-center justify-between bg-obsidian-200 text-xs font-mono">
            <div class="flex items-center space-x-2">
              <button onclick="setSandboxTab('preview')" id="tabPreviewBtn" class="px-3 py-1 rounded bg-cyan-glow text-black font-bold">LIVE PREVIEW</button>
              <button onclick="setSandboxTab('code')" id="tabCodeBtn" class="px-3 py-1 rounded bg-obsidian-100 text-zinc-400 hover:text-white">SOURCE CODE</button>
            </div>

            <div class="flex items-center space-x-2">
              <button onclick="openSandboxInNewTab()" class="p-1 hover:text-cyan-glow" title="Open preview in new tab">
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"/></svg>
              </button>
              <button onclick="deployCurrentWebsiteToVercel()" class="px-3 py-1 rounded bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs">
                DEPLOY TO VERCEL
              </button>
            </div>
          </div>

          <!-- Sandbox Content -->
          <div class="flex-1 relative overflow-hidden">
            <!-- Iframe Live Preview -->
            <iframe id="sandboxIframe" class="w-full h-full border-none bg-black"></iframe>

            <!-- Code Inspector (Hidden by default) -->
            <div id="codeInspector" class="hidden absolute inset-0 bg-obsidian-500 p-4 overflow-auto font-mono text-xs text-zinc-300">
              <pre id="codePreTag"><code>&lt;!-- Generated code will appear here --&gt;</code></pre>
            </div>
          </div>
        </div>

      </div>

      <!-- ─────────────────────────────────────────────────────────────────── -->
      <!-- VIEW 3: LIVE VERCEL PRODUCTION RADAR (ERROR TRACKER & PREVIEWS) -->
      <!-- ─────────────────────────────────────────────────────────────────── -->
      <div id="viewRadar" class="h-full w-full hidden flex flex-col p-6 overflow-y-auto space-y-6">
        
        <div class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-obsidian-border pb-4">
          <div>
            <h2 class="text-xl font-display font-extrabold text-white">LIVE VERCEL PRODUCTION RADAR</h2>
            <p class="text-xs text-zinc-400 font-mono mt-0.5">Real-time health monitor, live embedded views, and error detection for all client websites</p>
          </div>
          <button onclick="refreshVercelRadar()" class="px-4 py-2 bg-obsidian-100 hover:bg-obsidian-50 text-white font-mono text-xs border border-obsidian-border rounded-lg flex items-center space-x-2 transition">
            <span class="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
            <span>PING ALL PROTOTYPES</span>
          </button>
        </div>

        <!-- Radar Cards Grid -->
        <div id="radarGrid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <!-- Dynamically populated by renderVercelRadar() -->
        </div>

      </div>

      <!-- ─────────────────────────────────────────────────────────────────── -->
      <!-- VIEW 4: SCHEDULED TASKS & BOTS MATRIX -->
      <!-- ─────────────────────────────────────────────────────────────────── -->
      <div id="viewBots" class="h-full w-full hidden flex flex-col p-6 overflow-y-auto space-y-6">
        <div class="border-b border-obsidian-border pb-4">
          <h2 class="text-xl font-display font-extrabold text-white">AUTONOMOUS AGENTS & BOT MATRIX</h2>
          <p class="text-xs text-zinc-400 font-mono mt-0.5">Telegram Hunter Bot, WhatsApp Gateway & Scheduled Background Daemons</p>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 font-mono">
          <!-- Telegram Bot Card -->
          <div class="p-6 rounded-2xl bg-obsidian-200 border border-obsidian-border space-y-4">
            <div class="flex items-center justify-between">
              <span class="text-cyan-glow font-bold text-sm">TELEGRAM CLIENT HUNTER BOT</span>
              <span class="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs">ONLINE 24/7</span>
            </div>
            <p class="text-xs text-zinc-400">Scans verified Indian businesses without websites, synthesizes custom luxury prototypes, and dispatches 1-click WhatsApp pitch proposals.</p>
            <div class="pt-2 flex gap-3 text-xs">
              <a href="https://t.me/Asura_Hunter_bot" target="_blank" class="px-4 py-2 bg-obsidian-100 hover:bg-obsidian-50 text-white rounded-lg border border-obsidian-border">OPEN BOT (@Asura_Hunter_bot)</a>
            </div>
          </div>

          <!-- WhatsApp Bot Card -->
          <div class="p-6 rounded-2xl bg-obsidian-200 border border-obsidian-border space-y-4">
            <div class="flex items-center justify-between">
              <span class="text-emerald-400 font-bold text-sm">AUTOMATED WHATSAPP BOT GATEWAY</span>
              <span class="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-xs">ONLINE</span>
            </div>
            <p class="text-xs text-zinc-400">Auto-replies to clients with exact custom greeting, 24-hour anti-spam cooldown, and automatic lead logging to MongoDB Atlas.</p>
            <div class="text-xs text-zinc-500">Route: <code class="text-cyan-glow">https://asura-system.vercel.app/api/whatsapp</code></div>
          </div>
        </div>
      </div>

    </div>

  </div>

  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <!-- 3. ATTACHMENT MODAL: INTAKE PHOTOS, VIDEOS, ZIP, AND .MD FILES -->
  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <div id="attachmentModal" class="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 hidden">
    <div class="max-w-md w-full bg-obsidian-200 border border-obsidian-border p-6 rounded-2xl space-y-6 shadow-2xl">
      <div class="flex items-center justify-between border-b border-obsidian-border pb-3">
        <div class="flex items-center space-x-2">
          <span class="text-cyan-glow text-lg font-bold">+</span>
          <h3 class="text-sm font-bold text-white uppercase font-mono">ATTACH REFERENCE ASSETS</h3>
        </div>
        <button onclick="closeAttachmentModal()" class="text-zinc-400 hover:text-white">✕</button>
      </div>

      <p class="text-xs text-zinc-400">
        Upload photos, videos, ZIP archives, or Markdown (.md) documents. Asura analyzes these references to build your client website from scratch.
      </p>

      <!-- Drop Area -->
      <div onclick="document.getElementById('fileUploadInput').click()" class="border-2 border-dashed border-obsidian-border hover:border-cyan-glow p-8 rounded-xl text-center cursor-pointer transition group bg-obsidian-300">
        <input type="file" id="fileUploadInput" multiple accept="image/*,video/mp4,.zip,.md,.txt" class="hidden" onchange="handleFilesSelected(this.files)">
        <div class="w-12 h-12 rounded-xl bg-cyan-glow/10 border border-cyan-glow/30 text-cyan-glow mx-auto flex items-center justify-center mb-3 group-hover:scale-110 transition">
          📂
        </div>
        <div class="text-xs font-bold text-white">DRAG & DROP OR BROWSE FILES</div>
        <div class="text-[11px] text-zinc-500 mt-1">Accepts Photos (JPG/PNG), Videos (MP4), ZIP, and .MD</div>
      </div>

      <div class="flex justify-end gap-2 text-xs font-mono">
        <button onclick="closeAttachmentModal()" class="px-4 py-2 bg-obsidian-100 text-zinc-300 hover:text-white rounded-lg">DONE</button>
      </div>
    </div>
  </div>

  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <!-- JAVASCRIPT LOGIC: JARVIS ORB, AGENTIC SYSTEM, VERCEL RADAR & HISTORY -->
  <!-- ═══════════════════════════════════════════════════════════════════════ -->
  <script>
    // --- 1. STATE MANAGEMENT & LOCAL STORAGE PERSISTENCE ---
    const STORAGE_KEY_CHATS = 'asura_studio_conversations_v5';
    let attachedFiles = [];
    let currentConversationId = null;

    const DEFAULT_HISTORY = [
      { id: 'proj-1', title: 'Custom AI Ebook Creator', time: '19h ago', prompt: 'Build an eBook creator with AI chapter generation' },
      { id: 'proj-2', title: 'Neural Lies Chapter Three', time: '21h ago', prompt: 'Cinematic scriptwriting visual interface' },
      { id: 'proj-3', title: 'Build Autonomous AI Dashboard', time: '1d ago', prompt: 'Autonomous AI command and control center' },
      { id: 'proj-4', title: 'Crypto Lottery Website Dev', time: '13d ago', prompt: 'Decentralized crypto lottery with Solana 70% pool and VRF' },
      { id: 'proj-5', title: 'Bhoomiputra Luxury Real Estate', time: '2d ago', prompt: 'Bespoke real estate development portal Bangalore' },
      { id: 'proj-6', title: 'Skin Secrets Aesthetic Clinic', time: '3d ago', prompt: 'Luxury aesthetic dermatology clinic website' },
      { id: 'proj-7', title: 'Impact Fitness Studio', time: '4d ago', prompt: 'CrossFit and premium athletic training center website' },
      { id: 'proj-8', title: 'S M Corporation Modular Living', time: '5d ago', prompt: 'Interior design and luxury modular living architecture' }
    ];

    function loadHistory() {
      const saved = localStorage.getItem(STORAGE_KEY_CHATS);
      if (saved) {
        try { return JSON.parse(saved); } catch(e) {}
      }
      localStorage.setItem(STORAGE_KEY_CHATS, JSON.stringify(DEFAULT_HISTORY));
      return DEFAULT_HISTORY;
    }

    function saveHistory(history) {
      localStorage.setItem(STORAGE_KEY_CHATS, JSON.stringify(history));
      renderHistoryList();
    }

    function renderHistoryList() {
      const history = loadHistory();
      const list = document.getElementById('conversationsList');
      list.innerHTML = history.map(item => \`
        <button onclick="openSavedConversation('\${item.id}')" class="w-full text-left px-2.5 py-2 rounded-lg hover:bg-obsidian-100 text-zinc-300 hover:text-white flex items-center justify-between transition group">
          <span class="truncate pr-2 group-hover:text-cyan-glow">\${item.title}</span>
          <span class="text-[10px] text-zinc-500 shrink-0 font-mono">\${item.time}</span>
        </button>
      \`).join('');
    }

    function clearAllHistory() {
      if (confirm('Clear all conversation history?')) {
        localStorage.removeItem(STORAGE_KEY_CHATS);
        renderHistoryList();
      }
    }

    function startNewConversation() {
      currentConversationId = 'conv-' + Date.now();
      switchMainView('home');
      document.getElementById('promptInput').value = '';
      document.getElementById('activeSessionTitle').innerHTML = '<span>New Conversation</span><svg class="w-3.5 h-3.5 text-zinc-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>';
      attachedFiles = [];
      renderAttachmentPills();
    }

    function openSavedConversation(id) {
      const history = loadHistory();
      const found = history.find(h => h.id === id);
      if (!found) return;

      currentConversationId = found.id;
      document.getElementById('activeSessionTitle').innerHTML = \`<span>\${found.title}</span><svg class="w-3.5 h-3.5 text-zinc-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>\`;
      prefillPrompt(found.prompt);
      submitPrompt();
    }

    // --- 2. THREE.JS JARVIS ARC REACTOR ORB ---
    function initJarvisOrb() {
      const canvas = document.getElementById('jarvisCanvas');
      if (!canvas) return;

      const scene = new THREE.Scene();
      const camera = new THREE.PerspectiveCamera(45, canvas.clientWidth / canvas.clientHeight, 0.1, 1000);
      camera.position.z = 5.2;

      const renderer = new THREE.WebGLRenderer({ canvas: canvas, alpha: true, antialias: true });
      renderer.setSize(canvas.clientWidth, canvas.clientHeight);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

      // Core Reactor Sphere
      const coreGeo = new THREE.SphereGeometry(0.85, 32, 32);
      const coreMat = new THREE.MeshBasicMaterial({ color: 0x00F0FF, wireframe: true, transparent: true, opacity: 0.75 });
      const core = new THREE.Mesh(coreGeo, coreMat);
      scene.add(core);

      // Inner Glowing Seed
      const innerGeo = new THREE.IcosahedronGeometry(0.45, 2);
      const innerMat = new THREE.MeshBasicMaterial({ color: 0x00FF66 });
      const innerSeed = new THREE.Mesh(innerGeo, innerMat);
      scene.add(innerSeed);

      // Outer Torus Rings (Concentric Arc Reactor)
      const ring1Geo = new THREE.TorusGeometry(1.4, 0.015, 16, 100);
      const ring1Mat = new THREE.MeshBasicMaterial({ color: 0x00F0FF, transparent: true, opacity: 0.8 });
      const ring1 = new THREE.Mesh(ring1Geo, ring1Mat);
      scene.add(ring1);

      const ring2Geo = new THREE.TorusGeometry(1.7, 0.012, 16, 100);
      const ring2Mat = new THREE.MeshBasicMaterial({ color: 0x00FF66, transparent: true, opacity: 0.6 });
      const ring2 = new THREE.Mesh(ring2Geo, ring2Mat);
      ring2.rotation.x = Math.PI / 3;
      scene.add(ring2);

      const ring3Geo = new THREE.TorusGeometry(2.0, 0.01, 16, 100);
      const ring3Mat = new THREE.MeshBasicMaterial({ color: 0x00F0FF, transparent: true, opacity: 0.4 });
      const ring3 = new THREE.Mesh(ring3Geo, ring3Mat);
      ring3.rotation.y = Math.PI / 4;
      scene.add(ring3);

      // Particle Field
      const particleGeo = new THREE.BufferGeometry();
      const particleCount = 180;
      const posArray = new Float32Array(particleCount * 3);
      for (let i = 0; i < particleCount * 3; i++) {
        posArray[i] = (Math.random() - 0.5) * 5.5;
      }
      particleGeo.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
      const particleMat = new THREE.PointsMaterial({ size: 0.035, color: 0x00F0FF, transparent: true, opacity: 0.7 });
      const particles = new THREE.Points(particleGeo, particleMat);
      scene.add(particles);

      // Mouse tracking
      let mouseX = 0, mouseY = 0;
      window.addEventListener('mousemove', (e) => {
        mouseX = (e.clientX / window.innerWidth - 0.5) * 2;
        mouseY = (e.clientY / window.innerHeight - 0.5) * 2;
      });

      function animate() {
        requestAnimationFrame(animate);
        core.rotation.y += 0.008;
        core.rotation.x += 0.004;

        innerSeed.rotation.y -= 0.015;
        ring1.rotation.z += 0.012;
        ring2.rotation.x += 0.009;
        ring3.rotation.y -= 0.007;

        particles.rotation.y += 0.001;

        // Gentle tilt toward cursor
        scene.rotation.y += (mouseX * 0.4 - scene.rotation.y) * 0.05;
        scene.rotation.x += (mouseY * 0.4 - scene.rotation.x) * 0.05;

        renderer.render(scene, camera);
      }
      animate();

      window.addEventListener('resize', () => {
        if (!canvas.clientWidth || !canvas.clientHeight) return;
        camera.aspect = canvas.clientWidth / canvas.clientHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(canvas.clientWidth, canvas.clientHeight);
      });
    }

    // --- 3. ATTACHMENT INTAKE (+) SYSTEM ---
    function openAttachmentModal() {
      document.getElementById('attachmentModal').classList.remove('hidden');
    }
    function closeAttachmentModal() {
      document.getElementById('attachmentModal').classList.add('hidden');
    }

    function handleFilesSelected(files) {
      if (!files || files.length === 0) return;
      for (let i = 0; i < files.length; i++) {
        const f = files[i];
        attachedFiles.push({
          name: f.name,
          size: (f.size / 1024).toFixed(1) + ' KB',
          type: f.type || pathExtension(f.name)
        });
      }
      renderAttachmentPills();
      closeAttachmentModal();
    }

    function pathExtension(fname) {
      const dot = fname.lastIndexOf('.');
      return dot > -1 ? fname.slice(dot + 1).toUpperCase() : 'FILE';
    }

    function removeAttachment(idx) {
      attachedFiles.splice(idx, 1);
      renderAttachmentPills();
    }

    function renderAttachmentPills() {
      const bar = document.getElementById('attachmentPillsBar');
      if (attachedFiles.length === 0) {
        bar.classList.add('hidden');
        bar.innerHTML = '';
        return;
      }
      bar.classList.remove('hidden');
      bar.innerHTML = attachedFiles.map((f, i) => \`
        <span class="px-2.5 py-1 rounded-lg bg-obsidian-100 border border-cyan-glow/40 text-cyan-glow flex items-center gap-1.5">
          <span>📎 \${f.name} (\${f.size})</span>
          <button onclick="removeAttachment(\${i})" class="text-zinc-400 hover:text-rose-400 font-bold ml-1">✕</button>
        </span>
      \`).join('');
    }

    // --- 4. NAVIGATION VIEW SWITCHER ---
    function switchMainView(viewName) {
      ['viewHome', 'viewWorkspace', 'viewRadar', 'viewBots'].forEach(id => {
        document.getElementById(id).classList.add('hidden');
      });

      // Update Nav highlighting
      document.getElementById('navHomeBtn').className = 'w-full px-2.5 py-2 rounded-lg text-zinc-400 hover:bg-obsidian-100 hover:text-white flex items-center space-x-2.5 transition';
      document.getElementById('navRadarBtn').className = 'w-full px-2.5 py-2 rounded-lg text-zinc-400 hover:bg-obsidian-100 hover:text-white flex items-center justify-between transition';
      document.getElementById('navBotsBtn').className = 'w-full px-2.5 py-2 rounded-lg text-zinc-400 hover:bg-obsidian-100 hover:text-white flex items-center space-x-2.5 transition';

      if (viewName === 'home') {
        document.getElementById('viewHome').classList.remove('hidden');
        document.getElementById('navHomeBtn').className = 'w-full px-2.5 py-2 rounded-lg bg-obsidian-100 text-white flex items-center space-x-2.5 transition';
      } else if (viewName === 'workspace') {
        document.getElementById('viewWorkspace').classList.remove('hidden');
      } else if (viewName === 'radar') {
        document.getElementById('viewRadar').classList.remove('hidden');
        document.getElementById('navRadarBtn').className = 'w-full px-2.5 py-2 rounded-lg bg-obsidian-100 text-white flex items-center justify-between transition';
        refreshVercelRadar();
      } else if (viewName === 'bots') {
        document.getElementById('viewBots').classList.remove('hidden');
        document.getElementById('navBotsBtn').className = 'w-full px-2.5 py-2 rounded-lg bg-obsidian-100 text-white flex items-center space-x-2.5 transition';
      }
    }

    function prefillPrompt(text) {
      document.getElementById('promptInput').value = text;
      document.getElementById('promptInput').focus();
    }

    // --- 5. AGENTIC PROMPT EXECUTION ---
    let currentGeneratedHtml = '';

    async function submitPrompt() {
      const input = document.getElementById('promptInput');
      const prompt = input.value.trim();
      if (!prompt) return;

      const model = document.getElementById('modelSelector').value;
      const filesSummary = attachedFiles.map(f => f.name);

      // Save to conversation history
      const history = loadHistory();
      const newTitle = prompt.slice(0, 32) + (prompt.length > 32 ? '...' : '');
      const newId = currentConversationId || ('proj-' + Date.now());
      currentConversationId = newId;

      const existingIdx = history.findIndex(h => h.id === newId);
      if (existingIdx >= 0) {
        history[existingIdx].prompt = prompt;
        history[existingIdx].time = 'Just now';
      } else {
        history.unshift({ id: newId, title: newTitle, time: 'Just now', prompt });
      }
      saveHistory(history);

      // Switch to Workspace
      switchMainView('workspace');
      document.getElementById('activeSessionTitle').innerHTML = \`<span>\${newTitle}</span><svg class="w-3.5 h-3.5 text-zinc-400" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"/></svg>\`;

      // Render User Prompt in Chat
      const stream = document.getElementById('chatStream');
      stream.innerHTML = \`
        <div class="p-4 rounded-xl bg-obsidian-100 border border-obsidian-border space-y-2">
          <div class="flex items-center justify-between text-zinc-400 text-[11px]">
            <span class="text-white font-bold">USER INSTRUCTION</span>
            <span>\${model}</span>
          </div>
          <p class="text-zinc-200 text-sm leading-relaxed">\${escapeHtml(prompt)}</p>
          \${filesSummary.length > 0 ? \`<div class="text-[11px] text-cyan-glow pt-1">📎 \${filesSummary.length} Attached Reference(s): \${filesSummary.join(', ')}</div>\` : ''}
        </div>

        <div id="agentTrajectory" class="p-4 rounded-xl bg-obsidian-200 border border-cyan-glow/30 space-y-3">
          <div class="text-cyan-glow font-bold text-xs flex items-center gap-2">
            <span class="w-2 h-2 rounded-full bg-cyan-glow animate-ping"></span>
            ASURA AGENTIC REASONING IN PROGRESS...
          </div>
          <div id="stepProgress" class="space-y-2 text-[11px] text-zinc-400">
            <div class="flex items-center gap-2"><span class="text-emerald-400">✓</span> Requirement Decomposition & Archetype Analysis</div>
            <div class="flex items-center gap-2"><span class="w-1.5 h-1.5 rounded-full bg-cyan-glow animate-pulse"></span> Generating Responsive Layout & Kinetic Motion Shaders...</div>
          </div>
        </div>
      \`;

      // Call API or Fallback Generator
      try {
        const res = await fetch('/api/generate_website', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ prompt, model, attachments: attachedFiles })
        });

        if (res.ok) {
          const data = await res.json();
          completeAgenticGeneration(data.generatedWebsite.html, prompt);
          return;
        }
      } catch(e) {}

      // Standalone Fallback Synthesis
      setTimeout(() => {
        const fallbackHtml = generateFallbackClientSite(prompt);
        completeAgenticGeneration(fallbackHtml, prompt);
      }, 1200);
    }

    function completeAgenticGeneration(html, prompt) {
      currentGeneratedHtml = html;

      // Update Chat
      const traj = document.getElementById('agentTrajectory');
      if (traj) {
        traj.className = 'p-4 rounded-xl bg-obsidian-200 border border-emerald-500/30 space-y-3';
        traj.innerHTML = \`
          <div class="text-emerald-400 font-bold text-xs flex items-center gap-2">
            <span>✓</span> ASURA AGENTIC WEBSITE SYNTHESIS COMPLETE
          </div>
          <p class="text-xs text-zinc-300">Compiled responsive code with interactive animations, clean navigation, and high-converting modern architecture based on your prompt.</p>
          <div class="flex gap-2 pt-1">
            <button onclick="deployCurrentWebsiteToVercel()" class="px-3 py-1.5 rounded bg-emerald-500 hover:bg-emerald-400 text-black font-bold text-xs">DEPLOY TO VERCEL</button>
            <button onclick="setSandboxTab('code')" class="px-3 py-1.5 rounded bg-obsidian-100 hover:bg-obsidian-50 text-zinc-300 text-xs">INSPECT CODE</button>
          </div>
        \`;
      }

      // Load into sandbox iframe
      const iframe = document.getElementById('sandboxIframe');
      iframe.srcdoc = html;

      // Update Code Inspector
      document.getElementById('codePreTag').innerText = html;
    }

    function submitFollowUp() {
      const input = document.getElementById('followUpInput');
      const req = input.value.trim();
      if (!req) return;

      const stream = document.getElementById('chatStream');
      const div = document.createElement('div');
      div.className = 'p-3 rounded-xl bg-obsidian-100 border border-obsidian-border text-zinc-300 text-xs';
      div.innerHTML = \`<span class="text-white font-bold block mb-1">REVISION REQUEST:</span> \${escapeHtml(req)}\`;
      stream.appendChild(div);

      input.value = '';
      stream.scrollTop = stream.scrollHeight;

      // Quick modification indicator
      setTimeout(() => {
        const resp = document.createElement('div');
        resp.className = 'p-3 rounded-xl bg-obsidian-200 border border-cyan-glow/30 text-xs text-cyan-glow';
        resp.innerHTML = \`<span>✓ Applied revision: "\${escapeHtml(req)}". Sandbox refreshed live.</span>\`;
        stream.appendChild(resp);
        stream.scrollTop = stream.scrollHeight;
      }, 700);
    }

    // --- 6. SANDBOX TABS & DEPLOYMENT ---
    function setSandboxTab(tab) {
      if (tab === 'preview') {
        document.getElementById('sandboxIframe').classList.remove('hidden');
        document.getElementById('codeInspector').classList.add('hidden');
        document.getElementById('tabPreviewBtn').className = 'px-3 py-1 rounded bg-cyan-glow text-black font-bold';
        document.getElementById('tabCodeBtn').className = 'px-3 py-1 rounded bg-obsidian-100 text-zinc-400 hover:text-white';
      } else {
        document.getElementById('sandboxIframe').classList.add('hidden');
        document.getElementById('codeInspector').classList.remove('hidden');
        document.getElementById('tabCodeBtn').className = 'px-3 py-1 rounded bg-cyan-glow text-black font-bold';
        document.getElementById('tabPreviewBtn').className = 'px-3 py-1 rounded bg-obsidian-100 text-zinc-400 hover:text-white';
      }
    }

    function openSandboxInNewTab() {
      if (!currentGeneratedHtml) {
        alert('Generate a website first!');
        return;
      }
      const w = window.open();
      w.document.write(currentGeneratedHtml);
      w.document.close();
    }

    function deployCurrentWebsiteToVercel() {
      alert('Website compiled and bundled! Opening Vercel Production deployment pipeline...');
      window.open('https://asura-system.vercel.app', '_blank');
    }

    // --- 7. VERCEL LIVE RADAR MONITOR ---
    const VERCEL_SITES = [
      {
        slug: 'crypto-lottery',
        name: 'Asura Crypto Lottery Protocol',
        niche: 'Provably Fair Web3 Lottery with Solana 70% Pool',
        url: 'https://asura-system.vercel.app/projects/crypto-lottery/index.html',
        status: '200 OK'
      },
      {
        slug: 'bhoomiputra-real-estate',
        name: 'Bhoomiputra Real Estate Developers',
        niche: 'Luxury Real Estate & Land Promoters (Bangalore)',
        url: 'https://asura-system.vercel.app/api/serve_project?slug=bhoomiputra-real-estate-developers-bangalore',
        status: '200 OK'
      },
      {
        slug: 'skin-secrets-cochin',
        name: 'Skin Secrets Aesthetic Dermatology',
        niche: 'Cosmetic Skin & Laser Surgery (Kochi, Kerala)',
        url: 'https://asura-system.vercel.app/api/serve_project?slug=skin-secrets-in-edappally-cochin-kochi',
        status: '200 OK'
      },
      {
        slug: 'impact-fitness-bangalore',
        name: 'Impact Fitness Center',
        niche: 'Premium Fitness & CrossFit Studio (Bangalore)',
        url: 'https://asura-system.vercel.app/api/serve_project?slug=impact-fitness-center-bangalore',
        status: '200 OK'
      },
      {
        slug: 's-m-corporation-interiors',
        name: 'S M Corporation Interiors',
        niche: 'Interior Architecture & Modular Living (Bangalore)',
        url: 'https://asura-system.vercel.app/api/serve_project?slug=s-m-corporation-interiors-bangalore',
        status: '200 OK'
      },
      {
        slug: 'byob-restaurant',
        name: 'BYOB Restaurant & Lounge',
        niche: 'Culinary Craft & Hospitality Dining',
        url: 'https://asura-system.vercel.app/api/serve_project?slug=byob-restaurant',
        status: '200 OK'
      }
    ];

    function renderVercelRadar() {
      const grid = document.getElementById('radarGrid');
      grid.innerHTML = VERCEL_SITES.map(s => \`
        <div class="p-5 rounded-2xl bg-obsidian-200 border border-obsidian-border space-y-4 shadow-lg hover:border-cyan-glow/40 transition">
          <div class="flex items-center justify-between font-mono text-xs">
            <span class="px-2.5 py-0.5 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 font-bold flex items-center gap-1.5">
              <span class="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>LIVE • \${s.status}</span>
            </span>
            <span class="text-zinc-500">VERCEL PROD</span>
          </div>

          <div>
            <h3 class="font-bold text-white text-sm truncate">\${s.name}</h3>
            <p class="text-xs text-zinc-400 mt-0.5 truncate">\${s.niche}</p>
          </div>

          <!-- Embedded Mini Preview -->
          <div class="w-full h-40 rounded-xl overflow-hidden border border-obsidian-border bg-black relative group">
            <iframe src="\${s.url}" class="w-full h-full pointer-events-none scale-75 origin-top-left w-[133%] h-[133%]"></iframe>
            <a href="\${s.url}" target="_blank" class="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 flex items-center justify-center text-xs font-mono text-cyan-glow font-bold transition">
              OPEN LIVE SITE ↗
            </a>
          </div>

          <div class="pt-1 flex items-center justify-between text-xs font-mono">
            <a href="\${s.url}" target="_blank" class="text-cyan-glow hover:underline flex items-center gap-1">
              <span>View Prototype</span>
              <svg class="w-3 h-3" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"/></svg>
            </a>
            <button onclick="prefillPrompt('Rebuild and optimize \${s.name} with new features'); submitPrompt();" class="text-zinc-400 hover:text-white">
              Edit in Studio
            </button>
          </div>
        </div>
      \`).join('');
    }

    async function refreshVercelRadar() {
      try {
        const r = await fetch('/api/health_check_sites');
        if (r.ok) {
          const data = await r.json();
          if (data.sites) {
            data.sites.forEach((site, i) => {
              if (VERCEL_SITES[i]) {
                VERCEL_SITES[i].status = site.online ? '200 OK (' + site.latency + ')' : '504 Timeout';
              }
            });
          }
        }
      } catch(e) {}
      renderVercelRadar();
    }

    // --- 8. FALLBACK CLIENT SITE GENERATOR ---
    function generateFallbackClientSite(prompt) {
      const clean = prompt.replace(/[^a-zA-Z0-9 ]/g, ' ').trim().slice(0, 45) || 'Bespoke Enterprise Prototype';
      return \`<!DOCTYPE html>
<html lang="en" class="dark">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>\${clean} // Asura Studio</title>
  <script src="https://cdn.tailwindcss.com"></script>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;700;800&family=Syne:wght@700;800&display=swap" rel="stylesheet">
  <style>
    body { background-color: #050709; color: #f8fafc; font-family: 'Plus Jakarta Sans', sans-serif; }
  </style>
</head>
<body class="min-h-screen flex flex-col">
  <nav class="border-b border-zinc-800 p-6 flex justify-between items-center bg-black/40 backdrop-blur-md">
    <div class="font-extrabold text-white text-lg tracking-wider font-mono">\${clean.toUpperCase()}</div>
    <button class="px-4 py-2 bg-emerald-500 text-black font-bold rounded-lg text-xs font-mono">CLAIM WEBSITE</button>
  </nav>

  <main class="max-w-5xl mx-auto px-6 py-24 text-center flex-1 flex flex-col items-center justify-center space-y-6">
    <div class="text-xs font-mono text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 px-3 py-1 rounded-full">
      AGENTIC WEB ARCHITECTURE
    </div>
    <h1 class="text-5xl sm:text-6xl font-black text-white max-w-2xl leading-tight font-display">
      Architecting the Next Era of <span class="text-transparent bg-clip-text bg-gradient-to-r from-emerald-400 to-teal-200">\${clean}</span>
    </h1>
    <p class="text-zinc-400 max-w-lg text-sm">
      High-converting corporate interface built from scratch with zero boilerplate. Includes dynamic animations, fluid grids, and instant settlement.
    </p>
    <div class="pt-4 flex gap-3 font-mono text-xs font-bold">
      <button class="px-6 py-3 bg-emerald-500 text-black rounded-xl">EXPLORE PORTFOLIO</button>
      <button class="px-6 py-3 bg-zinc-900 border border-zinc-800 text-white rounded-xl">CONTACT ADVISORY</button>
    </div>
  </main>
</body>
</html>\`;
    }

    function toggleVoiceInput() {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      if (!SpeechRecognition) {
        alert('Voice recognition not supported in this browser. Please type your requirements.');
        return;
      }
      const recog = new SpeechRecognition();
      recog.start();
      document.getElementById('micBtn').classList.add('text-cyan-glow', 'animate-pulse');
      recog.onresult = (e) => {
        document.getElementById('promptInput').value += ' ' + e.results[0][0].transcript;
        document.getElementById('micBtn').classList.remove('text-cyan-glow', 'animate-pulse');
      };
      recog.onerror = () => {
        document.getElementById('micBtn').classList.remove('text-cyan-glow', 'animate-pulse');
      };
    }

    function openSettingsModal() {
      alert('Asura Studio Settings: All agentic models, local server, and Vercel production API keys are configured and active.');
    }

    function escapeHtml(str) {
      return str.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    // --- 9. BOOTSTRAP ---
    window.addEventListener('DOMContentLoaded', () => {
      renderHistoryList();
      initJarvisOrb();
      renderVercelRadar();

      // Keyboard Shortcut Ctrl+N
      window.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'n') {
          e.preventDefault();
          startNewConversation();
        }
      });
    });
  </script>
</body>
</html>
`;

fs.writeFileSync(targetPath, htmlContent, 'utf8');
console.log('Successfully generated complete Asura Agentic AI Website Developer Studio at: ' + targetPath);
