async function testNominatim() {
  try {
    const url = "https://nominatim.openstreetmap.org/search?q=gym+in+Miami&format=json&addressdetails=1&extratags=1&limit=10";
    console.log("Fetching Nominatim:", url);
    const res = await fetch(url, {
      headers: {
        "User-Agent": "AsuraHunterLeadEngine/1.0 (contact@asura-system.com)"
      }
    });
    console.log("Status:", res.status);
    const data = await res.json();
    console.log("Found:", data.length, "results");
    for (const item of data) {
      const extra = item.extratags || {};
      const hasWebsite = extra.website || extra["contact:website"];
      console.log(`- Name: ${item.name || item.display_name.split(',')[0]} | City: ${item.address?.city || 'Miami'} | Phone: ${extra.phone || extra['contact:phone'] || 'No phone'} | Website: ${hasWebsite || 'NO WEBSITE'}`);
    }
  } catch (e) {
    console.error(e.message);
  }
}

testNominatim();
