const fs = require('fs');
const path = require('path');

const GITHUB_TOKEN = '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';
const REPO = 'prathamgowda194-pixel/asura-system';

async function commitFile(relPath, localFilePath) {
  const url = `https://api.github.com/repos/${REPO}/contents/${relPath}`;
  let sha = null;
  try {
    const res = await fetch(url, {
      headers: { 'Authorization': `Bearer ${GITHUB_TOKEN}`, 'User-Agent': 'Node' }
    });
    if (res.status === 200) {
      const data = await res.json();
      sha = data.sha;
    }
  } catch (e) {}

  const content = fs.readFileSync(localFilePath, 'utf8');
  const base64 = Buffer.from(content, 'utf8').toString('base64');
  const body = {
    message: `chore: update ${relPath} with instant hunt delivery and pause/resume support [skip ci]`,
    content: base64,
    branch: 'main'
  };
  if (sha) body.sha = sha;

  const putRes = await fetch(url, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${GITHUB_TOKEN}`,
      'Content-Type': 'application/json',
      'User-Agent': 'Node'
    },
    body: JSON.stringify(body)
  });

  console.log(`Updated ${relPath}: HTTP ${putRes.status}`);
}

async function run() {
  const root = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system';
  await commitFile('api/telegram_webhook.js', path.join(root, 'api', 'telegram_webhook.js'));
  await commitFile('hunter_daemon.cjs', path.join(root, 'hunter_daemon.cjs'));
  await commitFile('hunter_engine.cjs', path.join(root, 'hunter_engine.cjs'));
}

run().catch(console.error);
