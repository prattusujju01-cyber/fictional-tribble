const fs = require('fs');
const path = require('path');

const targetPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\utils\\master-zenn-screenplay-builder.js';

const code = `/**
 * ══════════════════════════════════════════════════════════════════════════════
 * MASTER ZENN SCREENPLAY BUILDER // 120 DEDICATED VISUAL BEATS (10 MINUTES)
 * ══════════════════════════════════════════════════════════════════════════════
 * Strict Anti-AI-Slop Architecture:
 * - 120 distinct visual beats (~5 seconds per beat)
 * - Each beat strictly matches the narration text at that exact moment
 * - Zero generic placeholders: every scene has distinct character acting, props, and setting
 * - Full 10-minute evolutionary/anthropological narrative:
 *   Act 1: The Modern Amnesia & The Primordial Dark (Beats 1-25)
 *   Act 2: The Arboreal Refuge & The Prometheus Spark (Beats 26-50)
 *   Act 3: The Lost Architecture: Medieval Biphasic Sleep (Beats 51-75)
 *   Act 4: The Electrical Coup & The Lab Rediscovery (Beats 76-100)
 *   Act 5: Reclaiming Your Evolutionary Biology (Beats 101-120)
 */

function build120BeatZennScreenplay() {
  const rawBeats = [
    // ── ACT 1: THE MODERN AMNESIA & THE PRIMORDIAL DARK (Beats 1 - 25) ────────
    {
      act: 1,
      bgType: 'modern_bedroom_night',
      characterPose: 'bed_phone_scroll',
      expression: 'deadpan',
      narration: 'Tonight, when you flip a light switch in your bedroom, you literally do not think twice about it.',
      visual: 'Stickman lying under bedroom covers illuminated exclusively by the bright blue glow of a smartphone.'
    },
    {
      act: 1,
      bgType: 'modern_living_room',
      characterPose: 'flipping_wall_switch',
      expression: 'deadpan',
      narration: 'A tiny flick of your thumb, and your ceiling instantly unleashes the raw luminous energy of an artificial indoor sun.',
      visual: 'Stickman clicking an oversized white wall switch, unleashing brilliant yellow ceiling light beams.'
    },
    {
      act: 1,
      bgType: 'modern_living_room_blinding',
      characterPose: 'blasted_by_sunlamp',
      expression: 'annoyed',
      narration: 'It floods your retina with ten thousand lumens at midnight, tricking your ancient primate brain into believing it is high noon.',
      visual: 'Stickman shielding his eyes with one arm on a purple sofa as a massive ceiling lamp blazes above him.'
    },
    {
      act: 1,
      bgType: 'modern_kitchen_midnight',
      characterPose: 'eating_cereal_fridge',
      expression: 'sleepy',
      narration: 'You can raid your refrigerator at 2:00 AM, eat a bowl of sugary cereal, and completely forget that pitch darkness even exists.',
      visual: 'Stickman holding a spoon and cereal bowl before an open refrigerator glowing with bright cool white light.'
    },
    {
      act: 1,
      bgType: 'ancient_savanna_dusk',
      characterPose: 'walking_savanna',
      expression: 'deadpan',
      narration: 'But for ninety-nine point nine percent of human history, that switch was non-existent.',
      visual: 'Stickman walking casually across an ancient East African savanna as the red sun sets on the flat horizon.'
    },
    {
      act: 1,
      bgType: 'ancient_savanna_pitch_black',
      characterPose: 'standing_darkness',
      expression: 'scared',
      narration: 'For over three hundred thousand years, when the sun dipped beneath the horizon, humanity was plunged into total, suffocating blackness.',
      visual: 'Deep navy and black void with only the white silhouette of our stickman trembling with tiny bead-sweat.'
    },
    {
      act: 1,
      bgType: 'ancient_savanna_stalking_eyes',
      characterPose: 'looking_around_nervous',
      expression: 'scared',
      narration: 'And out there in that ancient African dark, humans were not the apex rulers of the food chain.',
      visual: 'Five pairs of predatory glowing yellow feline eyes opening all around the stickman in the pitch-black tall grass.'
    },
    {
      act: 1,
      bgType: 'evolution_primate_diagram',
      characterPose: 'pointing_diagram',
      expression: 'smug_curious',
      narration: 'To understand how terrifying the night truly was, we have to look directly at our primate biology.',
      visual: 'Stickman holding a pointer stick next to an anatomical diagram of a human eyeball compared to an owl eyeball.'
    },
    {
      act: 1,
      bgType: 'evolution_primate_diagram',
      characterPose: 'examining_monkey',
      expression: 'deadpan',
      narration: 'Primates were engineered strictly for high-definition color vision during bright daylight hours.',
      visual: 'A cartoon monkey sitting on a rock eating a banana while bathed in warm golden daylight.'
    },
    {
      act: 1,
      bgType: 'retina_cone_rod_diagram',
      characterPose: 'holding_magnifying_glass',
      expression: 'smug_curious',
      narration: 'We have millions of cones for spotting ripe berries and camouflaged snakes in the green canopy.',
      visual: 'Stickman with a magnifying glass examining colorful red, green, and blue cone photoreceptors.'
    },
    {
      act: 1,
      bgType: 'night_vision_contrast',
      characterPose: 'blindfolded_fumbling',
      expression: 'shocked',
      narration: 'But when night falls, our photoreceptors are practically useless. In deep darkness, humans are effectively blind.',
      visual: 'Stickman with hands stretched out blindly bumping his knee against a jagged ancient boulder.'
    },
    {
      act: 1,
      bgType: 'predator_savanna_profile',
      characterPose: 'cowering_grass',
      expression: 'scared',
      narration: 'Meanwhile, almost every single carnivore on the savanna evolved specifically to dominate the dark.',
      visual: 'A giant muscular spotted leopard with razor-sharp whiskers crouched on a tree limb looking down hungrily.'
    },
    {
      act: 1,
      bgType: 'predator_tapetum_diagram',
      characterPose: 'drawing_chalkboard',
      expression: 'smug_curious',
      narration: 'Big cats possess a specialized mirror behind their retinas called the tapetum lucidum.',
      visual: 'Stickman at a chalkboard illustrating the retro-reflective tapetum lucidum layer bouncing incoming starlight.'
    },
    {
      act: 1,
      bgType: 'predator_night_vision_pov',
      characterPose: 'spotted_in_crosshairs',
      expression: 'shocked',
      narration: 'It reflects incoming photons like night-vision goggles, turning a starlit field into high-contrast hunting grounds.',
      visual: 'Green-tinted thermal night-vision POV looking through the tall grass directly at our clueless glowing stickman.'
    },
    {
      act: 1,
      bgType: 'ancient_hominid_fleeing',
      characterPose: 'sprinting_panicked',
      expression: 'scared',
      narration: 'If an early hominid found themselves on open ground after twilight, their life expectancy was measured in minutes.',
      visual: 'Early human stickman sprinting at full speed with dust clouds trailing behind him, clutching a simple wooden stick.'
    },
    {
      act: 1,
      bgType: 'megafauna_shadows',
      characterPose: 'looking_up_terror',
      expression: 'scared',
      narration: 'Dinofelis, a prehistoric saber-toothed cat the size of a lion, specialized almost exclusively in hunting early hominids.',
      visual: 'Massive towering saber-toothed beast silhouette casting a monstrous shadow over the tiny cowering stickman.'
    },
    {
      act: 1,
      bgType: 'fossil_skull_evidence',
      characterPose: 'holding_skull_prop',
      expression: 'deadpan',
      narration: 'Fossilized hominid skulls have been discovered in South African caves with two distinct puncture holes matching saber-teeth.',
      visual: 'Stickman holding an ancient hominid skull showing two undeniable fang puncture wounds at the rear cranium.'
    },
    {
      act: 1,
      bgType: 'sun_dropping_horizon',
      characterPose: 'watching_sunset_panic',
      expression: 'scared',
      narration: 'So every single day, as the sun began to cast long orange shadows, a primal dread gripped the entire tribe.',
      visual: 'Giant burning orange sun sinking below a black horizon as stickman checks the vanishing horizon with frantic sweat.'
    },
    {
      act: 1,
      bgType: 'ancestor_tribe_gathering',
      characterPose: 'calling_tribe_members',
      expression: 'shouting',
      narration: 'There was no lounging around, no evening reading, no leisure. You had to find immediate sanctuary.',
      visual: 'Stickman waving frantically with two hands, signaling his scattered tribe mates to drop food and run.'
    },
    {
      act: 1,
      bgType: 'shelter_search_panic',
      characterPose: 'scrambling_rocks',
      expression: 'scared',
      narration: 'You needed high ground, deep caves, or vertical escape before the nocturnal hunters took over the earth.',
      visual: 'Stickman scrambling frantically over steep jagged gray limestone rocks to escape the savanna floor.'
    },
    {
      act: 1,
      bgType: 'ancient_acacia_landscape',
      characterPose: 'pointing_at_acacia',
      expression: 'smug_curious',
      narration: 'And before humans conquered the element of fire, that sanctuary had only one address: up in the trees.',
      visual: 'A tall sprawling ancient African acacia tree with sturdy branches extending against the darkening sky.'
    },
    {
      act: 1,
      bgType: 'chimp_sleeping_platform',
      characterPose: 'observing_chimp_nest',
      expression: 'smug_curious',
      narration: 'Just like chimpanzees and orangutans do today, our early ancestors were arboreal sleepers.',
      visual: 'Stickman taking field notes next to a large chimpanzee woven platform nest high up in tree boughs.'
    },
    {
      act: 1,
      bgType: 'arboreal_branch_balance',
      characterPose: 'balancing_branch_wobbly',
      expression: 'nervous',
      narration: 'Every evening, they would bend living boughs and weave temporary mattress platforms high above predator jaws.',
      visual: 'Stickman balancing precariously on a swaying leafy branch, weaving together supple green twigs.'
    },
    {
      act: 1,
      bgType: 'treetop_wind_storm',
      characterPose: 'clutching_trunk_wind',
      expression: 'scared',
      narration: 'Imagine trying to sleep thirty feet in the air, in the freezing wind, while hyenas laugh on the dirt below.',
      visual: 'Stickman clutching a tree trunk as howling wind whips leaves across the screen and yellow eyes circle below.'
    },
    {
      act: 1,
      bgType: 'fractured_primate_sleep',
      characterPose: 'twitching_alert',
      expression: 'shocked',
      narration: 'Deep REM sleep was dangerous. If your muscles fully relaxed in REM atony, you rolled off the branch and died.',
      visual: 'Stickman dangling by one hand off a tree branch with eyes popping wide in sudden midnight panic.'
    },

    // ── ACT 2: THE ARBOREAL REFUGE & THE PROMETHEUS SPARK (Beats 26 - 50) ─────
    {
      act: 2,
      bgType: 'lightning_storm_savanna',
      characterPose: 'watching_lightning_awe',
      expression: 'shocked',
      narration: 'And then, somewhere around one million years ago, everything changed with a single flash from the sky.',
      visual: 'A giant jagged purple-white lightning bolt striking an ancient dry dead tree trunk on the savanna.'
    },
    {
      act: 2,
      bgType: 'burning_branch_discovery',
      characterPose: 'approaching_flame_cautious',
      expression: 'awe_wonder',
      narration: 'While every other animal fled in terror from wildfire, a courageous hominid crept toward the smoldering ash.',
      visual: 'Stickman creeping low to the ground toward a smoking, glowing red and orange burning branch.'
    },
    {
      act: 2,
      bgType: 'holding_first_torch',
      characterPose: 'holding_flaming_branch',
      expression: 'awe_wonder',
      narration: 'They picked up a burning bough, lifted it into the darkness, and noticed a miracle: the predators backed away.',
      visual: 'Stickman holding high a blazing torch; silhouettes of predatory hyenas skittering backward into shadow.'
    },
    {
      act: 2,
      bgType: 'striking_flint_sparks',
      characterPose: 'striking_flint_sparks',
      expression: 'determined',
      narration: 'Eventually, our ancestors unlocked the secret of friction: striking flint against iron pyrite to birth their own sparks.',
      visual: 'Close-up of stickman crouched over dry grass tinder, smashing two gray flint stones producing yellow sparks.'
    },
    {
      act: 2,
      bgType: 'feeding_tender_embers',
      characterPose: 'blowing_on_ember',
      expression: 'focused',
      narration: 'Gently blowing into the fragile amber ember until oxygen ignited a persistent golden flame.',
      visual: 'Stickman cupping hands around a glowing red ember, cheeks puffed out blowing life into a curl of smoke.'
    },
    {
      act: 2,
      bgType: 'first_ground_campfire',
      characterPose: 'sitting_by_campfire',
      expression: 'peaceful',
      narration: 'For the first time in three million years of evolution, humans could sleep on the solid ground without being eaten alive.',
      visual: 'A roaring stone-ringed campfire illuminating stickman curled peacefully on animal skins on the ground.'
    },
    {
      act: 2,
      bgType: 'predators_repelled_circle',
      characterPose: 'waving_stick_at_shadows',
      expression: 'smug_curious',
      narration: 'Fire created a dome of security. Light was not just illumination—it was an invisible fortress wall.',
      visual: 'A wide circular golden dome of campfire light in the pitch dark savanna, with predators pacing helplessly outside.'
    },
    {
      act: 2,
      bgType: 'deep_rem_sleep_revolution',
      characterPose: 'sleeping_deep_ground',
      expression: 'peaceful',
      narration: 'Because they no longer feared falling from branches, early humans experienced deep slow-wave and REM sleep cycles.',
      visual: 'Stickman sleeping serenely with Zzz bubbles floating, brain radiating glowing blue waves of deep restoration.'
    },
    {
      act: 2,
      bgType: 'brain_expansion_chart',
      characterPose: 'pointing_brain_growth',
      expression: 'smug_curious',
      narration: 'Neuroscientists believe this explosion in deep REM sleep is what supercharged human cognitive evolution and memory.',
      visual: 'Stickman beside a timeline chart showing hominid brain volume doubling rapidly after the mastery of fire.'
    },
    {
      act: 2,
      bgType: 'cooking_meat_hearth',
      characterPose: 'roasting_meat_skewer',
      expression: 'grinning',
      narration: 'Cooking food predigested calories, shrinking our digestive tracts and fueling our massive energy-hungry brains.',
      visual: 'Stickman roasting a skewered fish over red coals, grinning with saliva dripping happily.'
    },
    {
      act: 2,
      bgType: 'tribe_circle_storytelling',
      characterPose: 'storytelling_tribal_circle',
      expression: 'animated',
      narration: 'But fire did something even more profound: it created the very first evening culture.',
      visual: 'Five stickman tribe members sitting around the dancing campfire, one standing with arms raised recounting a myth.'
    },
    {
      act: 2,
      bgType: 'daytime_vs_night_talk',
      characterPose: 'contrasting_speech_bubbles',
      expression: 'smug_curious',
      narration: 'Anthropologist Polly Wiessner studied the Ju/’hoansi Bushmen and found that daytime talk is ninety percent practical tasks.',
      visual: 'Split comparison: daytime shows stickman trading hunting arrows; nighttime shows stickman dancing and chanting.'
    },
    {
      act: 2,
      bgType: 'night_fireside_myths',
      characterPose: 'gazing_into_embers',
      expression: 'awe_wonder',
      narration: 'At night around the fire, eighty-one percent of conversation transformed into myths, folklore, songs, and cosmology.',
      visual: 'Glowing embers rising into the starry Milky Way as tribal figures listen captivated to ancestral tales.'
    },
    {
      act: 2,
      bgType: 'cave_art_flickering_torch',
      characterPose: 'painting_cave_wall',
      expression: 'inspired',
      narration: 'Deep inside French caves like Lascaux and Chauvet, ancestors painted galloping bison using flickering animal-fat lamps.',
      visual: 'Stickman painting a magnificent red-ochre mammoth on a dark rocky cave wall by the warm glow of a tallow cup.'
    },
    {
      act: 2,
      bgType: 'animated_cave_shadows',
      characterPose: 'watching_animated_bison',
      expression: 'awe_wonder',
      narration: 'In the flickering yellow torchlight, the overlapping bison legs appeared to run across the stone—the first motion pictures.',
      visual: 'Torchlight casting undulating shadows on eight-legged cave bison, producing an illusion of prehistoric cinematic movement.'
    },
    {
      act: 2,
      bgType: 'hearth_as_social_glue',
      characterPose: 'sharing_food_bowl',
      expression: 'peaceful',
      narration: 'Fire was the original social network. It brought disparate clans together into unified, cooperative societies.',
      visual: 'Two stickman figures from different clans shaking hands across the hearth with warm smiles.'
    },
    {
      act: 2,
      bgType: 'night_remains_dominant',
      characterPose: 'looking_at_stars_vast',
      expression: 'deadpan',
      narration: 'Yet even with campfires and clay oil lamps, night remained overwhelmingly dominant across planet Earth.',
      visual: 'A tiny pinpoint campfire in a colossal vast dark landscape beneath billions of shimmering desert stars.'
    },
    {
      act: 2,
      bgType: 'ancient_oil_lamp_clay',
      characterPose: 'holding_terracotta_lamp',
      expression: 'deadpan',
      narration: 'A clay oil lamp produced barely one-hundredth the light of a single modern 60-watt bulb.',
      visual: 'Stickman holding a tiny smoking terracotta olive oil lamp that barely illuminates his own nose.'
    },
    {
      act: 2,
      bgType: 'smoky_wick_dimness',
      characterPose: 'coughing_lamp_smoke',
      expression: 'annoyed',
      narration: 'It was smoky, dim, smelled like burning animal grease, and guttered out with the slightest gust of wind.',
      visual: 'Stickman coughing from pungent gray smoke wafting from a crude animal fat wick lamp.'
    },
    {
      act: 2,
      bgType: 'natural_circadian_synchrony',
      characterPose: 'yawning_sunset_glow',
      expression: 'sleepy',
      narration: 'And because artificial light was so weak, human biology remained perfectly synchronized with the natural solar rhythm.',
      visual: 'Stickman yawning widely as the amber sunset transitions into tranquil indigo dusk.'
    },
    {
      act: 2,
      bgType: 'pineal_gland_diagram',
      characterPose: 'pointing_at_pineal_gland',
      expression: 'smug_curious',
      narration: 'The moment dusk arrived, specialized retinal ganglion cells signaled the brain’s master clock: the suprachiasmatic nucleus.',
      visual: 'Diagram of human brain cross-section with an illuminated suprachiasmatic nucleus dispatching neurochemical signals.'
    },
    {
      act: 2,
      bgType: 'melatonin_cascade_flood',
      characterPose: 'bathed_in_melatonin',
      expression: 'peaceful',
      narration: 'The pineal gland opened its gates, flooding the bloodstream with natural melatonin to prepare the body for deep rest.',
      visual: 'Cartoon representation of pineal gland releasing glowing blue melatonin drops washing gently over the body.'
    },
    {
      act: 2,
      bgType: 'seasonal_sleep_expansion',
      characterPose: 'winter_vs_summer_sleep',
      expression: 'smug_curious',
      narration: 'In winter months with fourteen hours of darkness, humans slept much longer, resting in rhythm with the seasons.',
      visual: 'Split screen: summer short nap under leafy tree vs winter long cozy slumber inside a warm animal-hide shelter.'
    },
    {
      act: 2,
      bgType: 'no_alarm_clocks_ever',
      characterPose: 'sleeping_smiling_sun',
      expression: 'peaceful',
      narration: 'No one had alarms, no one counted eight hours, and no one panicked about waking up in the middle of the night.',
      visual: 'Stickman sleeping with zero stress; morning golden sun rays gently peeking through leaves to wake him.'
    },
    {
      act: 2,
      bgType: 'mystery_of_midnight',
      characterPose: 'waking_in_middle_of_night',
      expression: 'peaceful',
      narration: 'Because for centuries, waking up in the middle of the night wasn’t a medical disorder—it was completely expected.',
      visual: 'Stickman sitting up in bed calmly in the quiet dark, looking out a small window at the moon without any panic.'
    },

    // ── ACT 3: THE LOST ARCHITECTURE: MEDIEVAL BIPHASIC SLEEP (Beats 51 - 75) ──
    {
      act: 3,
      bgType: 'medieval_timber_bedroom',
      characterPose: 'sitting_in_four_poster_bed',
      expression: 'peaceful',
      narration: 'Historian Roger Ekirch spent sixteen years combing through court depositions, diaries, and ancient medical treatises.',
      visual: 'Stickman scholar wearing round glasses reading through stacks of crumbling 16th-century leather-bound court logs.'
    },
    {
      act: 3,
      bgType: 'archival_scroll_zoom',
      characterPose: 'pointing_latin_text',
      expression: 'smug_curious',
      narration: 'And he stumbled upon an astonishing historical phrase repeated thousands of times: First Sleep and Second Sleep.',
      visual: 'Close-up on parchment scroll displaying ornate gothic script highlighted: Primo Somno and Second Sleep.'
    },
    {
      act: 3,
      bgType: 'medieval_evening_family',
      characterPose: 'tucking_under_wool_blankets',
      expression: 'sleepy',
      narration: 'In pre-industrial Europe, families would turn in around 9:00 PM as darkness enveloped the village.',
      visual: 'Medieval timber cottage with thatched roof; stickman tucking under thick wool blankets by the embers.'
    },
    {
      act: 3,
      bgType: 'first_sleep_depth',
      characterPose: 'deep_first_sleep',
      expression: 'peaceful',
      narration: 'They would drift into their first sleep—a deep, restorative slumber lasting about four hours.',
      visual: 'Stickman deeply asleep in wooden box-bed, surrounded by cozy shadows and a gentle night sky.'
    },
    {
      act: 3,
      bgType: 'midnight_awakening_calm',
      characterPose: 'sitting_up_candle_table',
      expression: 'peaceful',
      narration: 'Then, right around midnight or 1:00 AM, the entire village would naturally and peacefully wake up.',
      visual: 'Stickman sitting up smoothly in bed, stretching arms without an ounce of grogginess or anxiety.'
    },
    {
      act: 3,
      bgType: 'the_watch_dorveille',
      characterPose: 'lighting_tallow_candle',
      expression: 'calm_focused',
      narration: 'This conscious window was called the watch, or in French, dorveille—literally waking-sleep.',
      visual: 'Stickman striking a sulfur match to light a single wax candle on a rough oak wooden bedside table.'
    },
    {
      act: 3,
      bgType: 'midnight_activity_reading',
      characterPose: 'reading_bible_candlelight',
      expression: 'focused',
      narration: 'For the next sixty to ninety minutes, people stayed awake inside their dimly lit cottages doing quiet activities.',
      visual: 'Stickman wrapped in a thick wool blanket, comfortably reading a leather book by flickering candle flame.'
    },
    {
      act: 3,
      bgType: 'midnight_philosophy_writing',
      characterPose: 'writing_quill_parchment',
      expression: 'inspired',
      narration: 'Philosophers wrote their most profound treatises; poets dipped quills into ink while the world outside was dead quiet.',
      visual: 'Stickman writing vigorously with a goose feather quill onto parchment, ideas glowing visibly above his head.'
    },
    {
      act: 3,
      bgType: 'midnight_prayer_reflection',
      characterPose: 'kneeling_prayer_window',
      expression: 'peaceful',
      narration: 'Special prayer books were authored specifically for the midnight hour, viewing it as a holy time of clarity.',
      visual: 'Stickman kneeling quietly beside a stone mullioned window gazing up at the crescent moon in prayer.'
    },
    {
      act: 3,
      bgType: 'midnight_neighbor_visit',
      characterPose: 'waving_to_neighbor_lantern',
      expression: 'grinning',
      narration: 'Peasants would visit next-door neighbors, chat quietly across fence posts, or smoke a pipe on the porch.',
      visual: 'Stickman holding a small horn lantern waving over a low wooden fence to a neighbor leaning on his broom.'
    },
    {
      act: 3,
      bgType: 'tending_hearth_chores',
      characterPose: 'poking_embers_fireplace',
      expression: 'focused',
      narration: 'Others added wood to the embers, checked on farm animals in the barn, or brewed medicinal herbal teas.',
      visual: 'Stickman with iron fire-tongs placing a fresh split birch log into the glowing kitchen hearth.'
    },
    {
      act: 3,
      bgType: 'intimacy_between_sleeps',
      characterPose: 'tender_conversation_bed',
      expression: 'peaceful',
      narration: 'Doctors in the 1500s even noted that the window between sleeps was the best time for intimacy and conception.',
      visual: 'Stickman holding hands gently across the bedside with his partner in the soft amber candle glow.'
    },
    {
      act: 3,
      bgType: 'relaxation_no_panic',
      characterPose: 'sipping_herbal_mug',
      expression: 'peaceful',
      narration: 'Notice what nobody was doing: nobody was staring at an alarm clock hyperventilating that they were awake at 1:00 AM.',
      visual: 'Stickman sipping a warm steaming mug with a relaxed smile, leaning back against plump feather pillows.'
    },
    {
      act: 3,
      bgType: 'second_sleep_transition',
      characterPose: 'blowing_out_candle',
      expression: 'sleepy',
      narration: 'After about an hour or two of relaxed consciousness, drowsiness would gently wash over the body a second time.',
      visual: 'Stickman gently blowing out the tallow candle, as a delicate trail of white smoke drifts toward the ceiling.'
    },
    {
      act: 3,
      bgType: 'second_sleep_dreams',
      characterPose: 'vivid_second_sleep_dreaming',
      expression: 'peaceful',
      narration: 'They would slide into their Second Sleep until sunrise—a phase renowned for extraordinarily vivid dreams.',
      visual: 'Stickman sleeping serenely beneath a dream bubble featuring colorful flying fish and castles in the clouds.'
    },
    {
      act: 3,
      bgType: 'historical_literature_canterbury',
      characterPose: 'holding_chaucer_book',
      expression: 'smug_curious',
      narration: 'This was not a bizarre quirk. It appears in Homer’s Odyssey, Virgil’s Aeneid, and Chaucer’s Canterbury Tales.',
      visual: 'Stickman pointing to illuminated medieval manuscripts referencing characters waking after their first sleep.'
    },
    {
      act: 3,
      bgType: 'candle_economics_expensive',
      characterPose: 'holding_expensive_tallow',
      expression: 'annoyed',
      narration: 'Why didn’t they just stay up all night with candles? Because candles in the 1700s were brutally expensive.',
      visual: 'Stickman inspecting an expensive beeswax candle marked with a giant price tag of gold coins.'
    },
    {
      act: 3,
      bgType: 'smelly_tallow_rushes',
      characterPose: 'pinching_nose_smelly_candle',
      expression: 'annoyed',
      narration: 'Poor folks used tallow candles made from rendered beef or mutton fat that sputtered foul black smoke.',
      visual: 'Stickman holding a sputtering, dripping tallow reed candle while pinching his nose in disgust.'
    },
    {
      act: 3,
      bgType: 'rushlight_burning_fast',
      characterPose: 'watching_rushlight_expire',
      expression: 'deadpan',
      narration: 'A simple rushlight burned down in twenty minutes. You simply could not afford to waste light on trivial chores.',
      visual: 'A thin rushlight burning down rapidly to a cold metal clip in a matter of minutes.'
    },
    {
      act: 3,
      bgType: 'curfew_cover_fire',
      characterPose: 'putting_cover_on_hearth',
      expression: 'focused',
      narration: 'Town bells rang curfew—from the French couvre-feu, meaning cover the fire—to prevent midnight city blazes.',
      visual: 'Village church bell tower tolling midnight as stickman places a domed brass lid over the living coals.'
    },
    {
      act: 3,
      bgType: 'darkness_rules_cities',
      characterPose: 'empty_cobblestone_dark',
      expression: 'deadpan',
      narration: 'London, Paris, and Rome were pitch black labyrinths where footpads and cutpurses ruled the cobblestone streets.',
      visual: 'Dark cobblestone street in old London shrouded in dense river fog with only distant moonlight glinting.'
    },
    {
      act: 3,
      bgType: 'link_boys_for_hire',
      characterPose: 'link_boy_torch_hire',
      expression: 'smug_curious',
      narration: 'Wealthy gentlemen had to hire link-boys—young orphans carrying burning pitch torches to escort them home.',
      visual: 'A young boy stickman holding a smoking flare torch guiding a gentleman in a tricorn hat through dark alleys.'
    },
    {
      act: 3,
      bgType: 'nature_in_charge',
      characterPose: 'sleeping_in_harmony',
      expression: 'peaceful',
      narration: 'For thousands of years, nature dictated human slumber. But an industrial storm was gathering on the horizon.',
      visual: 'Stickman sleeping peacefully as in the distant background, industrial brick chimneys begin to sprout.'
    },
    {
      act: 3,
      bgType: 'early_gas_lighting',
      characterPose: 'watching_gas_lamp_ignite',
      expression: 'shocked',
      narration: 'In the early 1800s, gas pipes began snaking beneath city streets, feeding hissed yellow jets of burning coal gas.',
      visual: 'A lamplighter with a long pole lighting a glass gas lantern on a London street corner, casting amber light.'
    },
    {
      act: 3,
      bgType: 'night_shift_birth',
      characterPose: 'factory_worker_night',
      expression: 'deadpan',
      narration: 'Suddenly, factories could run around the clock. The night shift was born—and sleep was commodified.',
      visual: 'Stickman in overalls clocking into a noisy textile factory at 11:00 PM beneath rows of burning gas jets.'
    },

    // ── ACT 4: THE ELECTRICAL COUP & THE LAB REDISCOVERY (Beats 76 - 100) ────
    {
      act: 4,
      bgType: 'edison_laboratory_1879',
      characterPose: 'edison_holding_bulb',
      expression: 'smug_curious',
      narration: 'Then came October 1879, inside Thomas Edison’s workshop in Menlo Park, New Jersey.',
      visual: 'Edison-stickman in apron holding up a pear-shaped glass bulb with a carbonized bamboo filament.'
    },
    {
      act: 4,
      bgType: 'incandescent_flash',
      characterPose: 'watching_bulb_glow',
      expression: 'awe_wonder',
      narration: 'Edison flipped the current, and that fragile carbon filament burned steadily for thirteen and a half hours.',
      visual: 'The bulb blazes with bright warm electric light, illuminating blueprints and glass beakers in the lab.'
    },
    {
      act: 4,
      bgType: 'electric_grid_expansion',
      characterPose: 'watching_power_lines',
      expression: 'shocked',
      narration: 'Within decades, copper wires were strung across every continent, pushing darkness out of homes forever.',
      visual: 'Power poles and high-voltage electrical wires stretching over hills, illuminating houses across the map.'
    },
    {
      act: 4,
      bgType: 'death_of_two_sleeps',
      characterPose: 'compressing_sleep_block',
      expression: 'annoyed',
      narration: 'With bright electric light extending leisure past 11:00 PM, waking up at 1:00 AM became impossible.',
      visual: 'Stickman looking at a clock showing 11:30 PM, looking exhausted as his sleep window is compressed.'
    },
    {
      act: 4,
      bgType: 'eight_hour_construct',
      characterPose: 'pointing_at_factory_rule',
      expression: 'smug_curious',
      narration: 'Industrial society mandated a new standard: eight hours work, eight hours leisure, eight hours consolidated sleep.',
      visual: 'Stickman pointing at an industrial Victorian pie chart cleanly divided into three identical 8-hour slices.'
    },
    {
      act: 4,
      bgType: 'invention_of_insomnia',
      characterPose: 'panicking_over_insomnia',
      expression: 'scared',
      narration: 'And almost overnight, the medical term maintenance insomnia was born.',
      visual: 'Stickman reading a medical textbook entry titled INSOMNIA with a giant red warning stamp.'
    },
    {
      act: 4,
      bgType: 'the_modern_guilt_trip',
      characterPose: 'tossing_turning_bed',
      expression: 'scared',
      narration: 'If you woke up at 3:00 AM, society told you your body was defective, broken, and in need of pharmaceutical pills.',
      visual: 'Stickman tossing and turning in bed, clutching his hair in anguish under a giant flashing question mark.'
    },
    {
      act: 4,
      bgType: 'sleeping_pill_bottle',
      characterPose: 'holding_pill_bottle',
      expression: 'deadpan',
      narration: 'Millions of dollars were poured into sedatives designed to chemically force the brain into an artificial eight-hour coma.',
      visual: 'Stickman staring at a giant orange pharmaceutical prescription pill bottle labeled KNOCKOUT-800.'
    },
    {
      act: 4,
      bgType: 'historical_amnesia',
      characterPose: 'forgetting_history',
      expression: 'smug_curious',
      narration: 'By the 1920s, humanity had completely forgotten that biphasic sleep had ever existed for three thousand years.',
      visual: 'A vintage calendar flipping forward rapidly from 1850 to 1920, sweeping ancient sleep records under the rug.'
    },
    {
      act: 4,
      bgType: 'dr_wehr_nih_lab_1992',
      characterPose: 'dr_wehr_standing_lab',
      expression: 'smug_curious',
      narration: 'Until 1992, when a visionary psychiatrist named Dr. Thomas Wehr conducted an extraordinary experiment at the NIH.',
      visual: 'Dr. Wehr stickman in a white lab coat standing inside a sterile National Institutes of Health research laboratory.'
    },
    {
      act: 4,
      bgType: 'lab_protocol_darkness',
      characterPose: 'turning_off_lab_lights',
      expression: 'focused',
      narration: 'He took fifteen healthy human volunteers and placed them in a controlled environment stripped of all artificial light.',
      visual: 'Volunteers sitting in comfortable laboratory suites as Dr. Wehr switches off all electrical light sources.'
    },
    {
      act: 4,
      bgType: 'fourteen_hours_darkness',
      characterPose: 'sitting_in_fourteen_hour_dark',
      expression: 'deadpan',
      narration: 'For four solid weeks, every day at 6:00 PM, the subjects were placed in pitch darkness for fourteen hours.',
      visual: 'A digital laboratory monitor counting down 14:00:00 of darkness while subjects relax in comfortable beds.'
    },
    {
      act: 4,
      bgType: 'week_one_sleep_rebound',
      characterPose: 'exhausted_sleeping_long',
      expression: 'sleepy',
      narration: 'During the first week, subjects simply crashed, sleeping eleven hours a night to pay off chronic modern sleep debt.',
      visual: 'Stickman completely passed out under a heavy laboratory duvet, snoring loudly with sleep debt meter resetting.'
    },
    {
      act: 4,
      bgType: 'week_three_shift',
      characterPose: 'sitting_up_in_lab_bed',
      expression: 'peaceful',
      narration: 'But by week three and four, something deeply profound and biological occurred.',
      visual: 'Stickman sitting up in bed in the dark lab room at 2:00 AM, looking calm, clear-headed, and perfectly serene.'
    },
    {
      act: 4,
      bgType: 'reversion_to_biphasic',
      characterPose: 'examining_eeg_printout',
      expression: 'shocked',
      narration: 'Their brains automatically reorganized their sleep into two distinct four-hour blocks separated by a calm waking interval.',
      visual: 'Dr. Wehr holding up a long EEG polysomnogram paper showing two perfect sleep hills with a 2-hour flat awake plateau.'
    },
    {
      act: 4,
      bgType: 'prolactin_serenity_flood',
      characterPose: 'bathed_in_prolactin_calm',
      expression: 'peaceful',
      narration: 'Blood tests revealed that during that midnight awake window, the pituitary gland secreted massive surges of prolactin.',
      visual: 'A chemical test tube glowing emerald green with a badge reading PROLACTIN: MEDITATIVE CALM.'
    },
    {
      act: 4,
      bgType: 'prolactin_zen_state',
      characterPose: 'floating_in_zen_state',
      expression: 'peaceful',
      narration: 'Prolactin is the exact hormone produced after intense intimacy—it induces an altered state of tranquil, meditative serenity.',
      visual: 'Stickman sitting cross-legged floating gently above his bed in a state of tranquil Zen clarity and peace.'
    },
    {
      act: 4,
      bgType: 'no_anxiety_just_peace',
      characterPose: 'smiling_in_the_dark',
      expression: 'peaceful',
      narration: 'Subjects reported they were not bored, they were not anxious, and they had never felt more at peace in their entire lives.',
      visual: 'Stickman resting his head on his hands, looking into the darkness with a soft contented smile.'
    },
    {
      act: 4,
      bgType: 'hardwired_in_dna',
      characterPose: 'pointing_dna_helix',
      expression: 'smug_curious',
      narration: 'Dr. Wehr’s landmark study proved that biphasic sleep is not a historical social fad—it is hardwired into human DNA.',
      visual: 'Stickman standing proudly beside a glowing double-helix DNA strand containing ancient circadian code.'
    },
    {
      act: 4,
      bgType: 'modern_phone_sabotage',
      characterPose: 'smartphone_blue_laser_eyes',
      expression: 'annoyed',
      narration: 'And yet, modern humans spend every evening sabotaging this ancient machinery with a handheld glowing glass slab.',
      visual: 'Stickman lying in bed with a smartphone shooting bright blue laser beams directly into his dilated pupils.'
    },

    // ── ACT 5: RECLAIMING YOUR EVOLUTIONARY BIOLOGY (Beats 101 - 120) ──────────
    {
      act: 5,
      bgType: 'the_3am_panic_loop',
      characterPose: 'staring_clock_3am',
      expression: 'scared',
      narration: 'Tonight, millions of people will wake up at 3:14 AM and immediately enter a cycle of panic.',
      visual: 'Stickman staring in horror at a glowing red bedside digital alarm clock displaying 03:14 AM.'
    },
    {
      act: 5,
      bgType: 'toxic_internal_monologue',
      characterPose: 'holding_head_anguish',
      expression: 'scared',
      narration: 'If I fall asleep right now, I will get three hours and forty minutes. My presentation tomorrow is going to be a disaster.',
      visual: 'Comic thought bubble above stickman showing him failing a business presentation with charts crashing down.'
    },
    {
      act: 5,
      bgType: 'reaching_for_phone_disaster',
      characterPose: 'grabbing_phone_nightstand',
      expression: 'annoyed',
      narration: 'And then, in their desperation, they make the fatal mistake: they grab their phone and start scrolling.',
      visual: 'Stickman’s hand reaching out to grab the glowing smartphone off the nightstand in the pitch black.'
    },
    {
      act: 5,
      bgType: 'melatonin_instant_shutoff',
      characterPose: 'brain_emergency_shutoff',
      expression: 'shocked',
      narration: 'That 460-nanometer blue light strikes the melanopsin receptors in your retina, slamming the emergency brake on melatonin.',
      visual: 'Inside the brain: a cartoon nerve operator pulling a big red emergency lever labeled MELATONIN SHUTDOWN.'
    },
    {
      act: 5,
      bgType: 'cortisol_spike_heart',
      characterPose: 'heart_racing_clutch_chest',
      expression: 'scared',
      narration: 'Your brain assumes sunrise just occurred. It spikes cortisol, jacks up your core body temperature, and ruins the night.',
      visual: 'Stickman clutching his chest as a cartoon heart hammers visibly and an internal thermometer shoots into red.'
    },
    {
      act: 5,
      bgType: 'morning_zombie_grogginess',
      characterPose: 'stumbling_zombie_coffee',
      expression: 'sleepy',
      narration: 'You drag yourself out of bed at 7:00 AM feeling like you have been run over by an ancient woolly mammoth.',
      visual: 'Stickman stumbling like a zombie with dark eye bags, dragging an empty coffee mug toward the kitchen.'
    },
    {
      act: 5,
      bgType: 'actionable_protocol_shift',
      characterPose: 'presenting_solution_board',
      expression: 'smug_curious',
      narration: 'So how do we fix this? How do we realign our modern lives with our evolutionary biology?',
      visual: 'Stickman standing beside an action roadmap labeled EVOLUTIONARY SLEEP BLUEPRINT with a bright green checkmark.'
    },
    {
      act: 5,
      bgType: 'step_one_viewing_sunset',
      characterPose: 'watching_sunset_balcony',
      expression: 'peaceful',
      narration: 'Step one: watch the sunset. The low-angle red and orange wavelength photons calibrate your circadian clock.',
      visual: 'Stickman leaning on a balcony railing watching a magnificent golden-red sunset over gentle rolling hills.'
    },
    {
      act: 5,
      bgType: 'step_two_amber_lighting',
      characterPose: 'switching_to_warm_lamp',
      expression: 'peaceful',
      narration: 'Step two: dim overhead bright white lights after 8:00 PM. Switch to warm, low-standing amber lamps or candlelight.',
      visual: 'Stickman clicking off blinding white ceiling fluorescents and turning on a warm, low amber corner lamp.'
    },
    {
      act: 5,
      bgType: 'step_three_cool_room',
      characterPose: 'adjusting_thermostat_65',
      expression: 'focused',
      narration: 'Step three: drop your bedroom temperature to around sixty-five degrees Fahrenheit, mimicking the cool night savanna.',
      visual: 'Stickman adjusting a digital wall thermostat down to 65°F (18°C) as cool soothing breezes flow through.'
    },
    {
      act: 5,
      bgType: 'step_four_phone_banishment',
      characterPose: 'locking_phone_drawer',
      expression: 'determined',
      narration: 'Step four: banish your phone from arm’s reach. Charge it in the hallway or inside a drawer.',
      visual: 'Stickman locking his smartphone inside a wooden desk drawer with a padlock, giving a firm thumbs-up.'
    },
    {
      act: 5,
      bgType: 'step_five_the_3am_reframe',
      characterPose: 'sitting_up_3am_smiling',
      expression: 'peaceful',
      narration: 'And most importantly: when you wake up at 3:00 AM, do not panic. Smile, because your biology is working perfectly.',
      visual: 'Stickman sitting up in bed at 3:00 AM with a calm, serene smile, hands resting comfortably on his knees.'
    },
    {
      act: 5,
      bgType: 'step_five_calm_activities',
      characterPose: 'reading_paper_book_dim',
      expression: 'peaceful',
      narration: 'Keep the room dim. Read a real paper book, listen to soft music, or just lie there and enjoy the quiet watch.',
      visual: 'Stickman reading a physical paper novel under a gentle warm reading clip-lamp with cozy socks on.'
    },
    {
      act: 5,
      bgType: 'second_sleep_arrival',
      characterPose: 'drifting_into_second_sleep',
      expression: 'sleepy',
      narration: 'Within thirty or forty minutes, that ancient prolactin wave will carry you smoothly into your second sleep.',
      visual: 'Stickman sliding eyelids shut, slipping effortlessly beneath soft blankets as golden dream particles sparkle.'
    },
    {
      act: 5,
      bgType: 'waking_reborn_sunlight',
      characterPose: 'stretching_arms_sunlight',
      expression: 'grinning',
      narration: 'You will wake up refreshed, grounded, and connected to hundreds of generations of ancestors who walked before you.',
      visual: 'Morning golden sunlight streaming through the bedroom window as stickman stretches with vibrant energy and vitality.'
    },
    {
      act: 5,
      bgType: 'closing_ancestral_constellation',
      characterPose: 'looking_up_starry_sky',
      expression: 'awe_wonder',
      narration: 'Darkness was never your enemy. It was the ancient cradle that made us human.',
      visual: 'Stickman standing on a hill under an awe-inspiring starry night sky, with ancestral silhouettes reflected in the stars.'
    },
    {
      act: 5,
      bgType: 'channel_outro_subscribe',
      characterPose: 'holding_subscribe_bell',
      expression: 'grinning',
      narration: 'If you learned something tonight, leave a comment below with your sleep habits and subscribe to Zenn. Sleep well.',
      visual: 'Stickman ringing a golden YouTube notification bell with a red SUBSCRIBE button and warm friendly grin.'
    }
  ];

  const totalDuration = 600;
  const beatDuration = totalDuration / rawBeats.length;

  const beats = rawBeats.map((b, idx) => {
    const beatIndex = idx + 1;
    const startSec = +(idx * beatDuration).toFixed(2);
    const endSec = +((idx + 1) * beatDuration).toFixed(2);
    const id = 'scene_' + String(beatIndex).padStart(3, '0');

    return {
      beatIndex,
      beatId: id,
      act: b.act,
      bgType: b.bgType,
      sceneType: b.characterPose,
      characterPose: b.characterPose,
      expression: b.expression,
      narration: b.narration,
      gag: b.visual,
      visualDescription: b.visual,
      timing: {
        startSec,
        endSec,
        durationSec: +(endSec - startSec).toFixed(2),
        formattedStart: formatTime(startSec),
        formattedEnd: formatTime(endSec)
      }
    };
  });

  return {
    meta: {
      title: 'Why Humans Slept Twice A Night (And How Modern Lights Broke Your Brain)',
      channel: 'Zenn Anthropology',
      totalBeats: beats.length,
      targetDurationSec: totalDuration,
      formattedDuration: '10:00',
      artStyle: 'Authentic Hand-Drawn 2D Webcomic Stickman // Organic Ink Linework',
      antiAiSlop: true,
      zoomEnabled: false,
      captionsEnabled: false
    },
    beats
  };
}

function formatTime(sec) {
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60);
  return m + ':' + String(s).padStart(2, '0');
}

module.exports = {
  build85BeatZennScreenplay: build120BeatZennScreenplay,
  build120BeatZennScreenplay: build120BeatZennScreenplay
};
`;

fs.writeFileSync(targetPath, code, 'utf8');
console.log('✅ Master 120-Beat Screenplay Builder written to:', targetPath);
