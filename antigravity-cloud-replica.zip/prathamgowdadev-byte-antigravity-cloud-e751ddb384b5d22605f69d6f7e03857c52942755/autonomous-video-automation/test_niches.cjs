const { ARCHETYPES, generateLuxuryHTML } = require('./brand_engine.cjs');

const testLeads = [
  { slug: 'skin-secrets-in-edappally-cochin-kochi', name: 'Skin Secrets Aesthetic Clinic', niche: 'Dermatology & Aesthetic Clinic', city: 'Kochi, Kerala', phone: '+91 75609 07255' },
  { slug: 'gkb-gkb-construction-llp-building', name: 'GKB Construction LLP', niche: 'Civil Construction & Turnkey High-Rises', city: 'Jaipur, Rajasthan', phone: '+91 93529 81701' },
  { slug: 'all-smiles-dental-clinic-bangalore', name: 'All Smiles Dental Clinic', niche: 'Dental Clinic & Implantology Center', city: 'Bangalore, Karnataka', phone: '+91 79751 92509' },
  { slug: 'impact-fitness-center-bangalore', name: 'Impact Fitness Center', niche: 'Premium Fitness & Crossfit Studio', city: 'Bangalore, Karnataka', phone: '+91 87920 38282' },
  { slug: 'byob-restaurant-experience-in-gurgaon', name: 'BYOB Restaurant Experience Gurgaon', niche: 'Artisanal Dining & Alfresco BYOB Sanctuary', city: 'Gurgaon, Delhi NCR', phone: '+91 96541 20004' }
];

testLeads.forEach(l => {
  const html = generateLuxuryHTML(l);
  console.log('\n========================================');
  console.log('CLIENT:', l.name);
  console.log('NICHE:', l.niche);
  
  const h1Match = html.match(/<h1[\s\S]*?<\/h1>/);
  const h1 = h1Match ? h1Match[0].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim() : 'NONE';
  console.log('HEADLINE:', h1);

  const statsMatches = html.match(/<div class="text-3xl[\s\S]*?<\/div>/g) || [];
  const stats = statsMatches.map(s => s.replace(/<[^>]+>/g, '').trim());
  console.log('STATS:', stats);

  const delivMatch = html.match(/<h2 class="text-3xl[\s\S]*?<\/h2>/);
  const deliv = delivMatch ? delivMatch[0].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim() : 'NONE';
  console.log('DELIVERABLES TITLE:', deliv);

  if (l.slug.includes('skin') && h1.toLowerCase().includes('architectural')) {
    console.error('❌ BUG: Skin Secrets has architectural headline!');
  } else if (l.slug.includes('skin')) {
    console.log('✅ Skin Secrets has dermatology headline!');
  }

  if (l.slug.includes('byob') && stats.some(s => s.includes('0k') || s.includes('0+ BOTTLES'))) {
    console.error('❌ BUG: BYOB has broken counter slop!');
  } else if (l.slug.includes('byob')) {
    console.log('✅ BYOB has solid dining stats!');
  }
});
