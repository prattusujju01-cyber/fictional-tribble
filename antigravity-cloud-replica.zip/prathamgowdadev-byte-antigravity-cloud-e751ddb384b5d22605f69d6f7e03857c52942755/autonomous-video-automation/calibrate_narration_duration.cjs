const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

const workspaceDir = 'C:/Users/WINDOWS/.gemini/antigravity/scratch/youtube-automation-agent';
const ffmpegPath = path.join(workspaceDir, 'node_modules/ffmpeg-static/ffmpeg.exe');
const audioDir = path.join(workspaceDir, 'assets/audio');
const assetsDir = path.join(workspaceDir, 'assets');

const inputAudio = path.join(audioDir, 'narration.mp3');
const tempAudio = path.join(audioDir, 'narration_under10m.mp3');
const backupAudio = path.join(audioDir, 'narration_original.mp3');

// 1. Read existing durations
const durationsPath = path.join(assetsDir, 'scene_durations.json');
const rawDurations = JSON.parse(fs.readFileSync(durationsPath, 'utf8'));

const originalTotalSec = rawDurations[rawDurations.length - 1].endSec;
const targetTotalSec = 572.0; // 9 minutes 32 seconds (strictly under 10:00)
const speedFactor = originalTotalSec / targetTotalSec; // ~1.84

console.log(`Original duration: ${originalTotalSec}s (${(originalTotalSec/60).toFixed(2)}m)`);
console.log(`Target duration: ${targetTotalSec}s (9:32m)`);
console.log(`Speed factor: ${speedFactor.toFixed(3)}x`);

// 2. Run ffmpeg atempo to speed up audio cleanly with high audio quality
if (!fs.existsSync(backupAudio)) {
  fs.copyFileSync(inputAudio, backupAudio);
}

// atempo filter max is 2.0 per filter instance
const cmd = `"${ffmpegPath}" -y -i "${backupAudio}" -filter:a "atempo=${speedFactor.toFixed(4)}" -b:a 64k "${tempAudio}"`;
console.log('Running ffmpeg speed calibration...');
execSync(cmd, { stdio: 'inherit' });

// Replace narration.mp3 with calibrated audio
fs.copyFileSync(tempAudio, inputAudio);
fs.unlinkSync(tempAudio);

console.log('✅ Audio calibrated and replaced: assets/audio/narration.mp3');

// 3. Scale scene_durations.json exactly to match calibrated audio
let cumulative = 0;
const calibratedDurations = rawDurations.map((d, i) => {
  const scaledDuration = Math.round((d.durationSec / speedFactor) * 10) / 10;
  const startSec = Math.round(cumulative * 10) / 10;
  const endSec = Math.round((cumulative + scaledDuration) * 10) / 10;
  cumulative += scaledDuration;
  return {
    sceneNumber: d.sceneNumber,
    sceneId: d.sceneId,
    startSec: startSec,
    durationSec: scaledDuration,
    endSec: endSec,
    bytes: Math.round(d.bytes / speedFactor)
  };
});

fs.writeFileSync(durationsPath, JSON.stringify(calibratedDurations, null, 2), 'utf8');
const finalSec = calibratedDurations[calibratedDurations.length - 1].endSec;
const finalMins = Math.floor(finalSec / 60);
const finalSecs = Math.round(finalSec % 60);
console.log(`✅ scene_durations.json updated: ${finalMins}:${String(finalSecs).padStart(2, '0')} (${finalSec}s total runtime)`);
