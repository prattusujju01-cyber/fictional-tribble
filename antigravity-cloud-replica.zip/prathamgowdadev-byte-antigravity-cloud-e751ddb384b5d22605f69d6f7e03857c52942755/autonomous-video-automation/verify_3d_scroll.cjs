/**
 * verify_3d_scroll.cjs
 * Validates Studio HTML safety and Pixnova 3D scroll animations
 */

const fs = require('fs');
const path = require('path');
const assert = require('assert');

console.log('--- RUNNING 3D SCROLL & STUDIO VERIFICATION ---');

const BASE_DIR = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system';
const STUDIO_PATH = path.join(BASE_DIR, 'projects', 'studio', 'index.html');
const PIXNOVA_PATH = path.join(BASE_DIR, 'projects', 'pixnova', 'index.html');

// 1. Studio Inspection
const studio = fs.readFileSync(STUDIO_PATH, 'utf8');
assert(!studio.includes("html += '<!DOCTYPE html>"), 'Studio MUST NOT leak raw generator strings outside script');
assert(!studio.includes('html += \'  <script'), 'Studio MUST NOT have unescaped script strings');
assert(studio.includes('jarvisCanvas'), 'Studio MUST contain 3D Jarvis Arc Reactor Orb canvas');
assert(studio.includes('historyListContainer'), 'Studio MUST contain project history container');
assert(studio.includes('deleteConversation'), 'Studio MUST have individual delete conversation buttons');
console.log('✓ Test 1 Passed: Studio UI verified clean, zero raw string leakage, Jarvis Orb intact.');

// 2. Pixnova 3D Scroll Inspection
const pixnova = fs.readFileSync(PIXNOVA_PATH, 'utf8');
assert(pixnova.includes('3D Scroll: The Architectural Process'), 'Pixnova MUST include 3D CAD Blueprint Scroll');
assert(pixnova.includes('3D Scroll: Exploded Device Assembly'), 'Pixnova MUST include 3D Mobile Exploded Assembly Scroll');
assert(pixnova.includes('Noir: It Begins with the Bean'), 'Pixnova MUST include 3D Coffee Roaster Scroll');
assert(pixnova.includes('bhoomiputra-real-estate-developers-bangalore'), 'Pixnova MUST link to Bhoomiputra Real Estate');
assert(pixnova.includes('skin-secrets-in-edappally-cochin-kochi'), 'Pixnova MUST link to Skin Secrets Clinic');
assert(pixnova.includes('crypto-lottery/index.html'), 'Pixnova MUST link to Crypto Lottery');
assert(pixnova.includes('impact-fitness-center-bangalore'), 'Pixnova MUST link to Impact Fitness');
assert(pixnova.includes('gsap.registerPlugin(ScrollTrigger)'), 'Pixnova MUST initialize GSAP ScrollTrigger');
console.log('✓ Test 2 Passed: Pixnova 3D Scroll Engine verified with all 4 vertical animations and live working client links.');

console.log('--- ALL VERIFICATIONS PASSED (2/2) ---');
