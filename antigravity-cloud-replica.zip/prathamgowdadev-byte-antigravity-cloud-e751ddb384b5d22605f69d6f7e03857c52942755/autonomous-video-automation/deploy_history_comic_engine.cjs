const fs = require('fs');
const path = require('path');

const targetPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\utils\\hand-drawn-comic-engine.js';
let code = fs.readFileSync(targetPath, 'utf8');

const injection = `
    // ── ANCIENT EGYPTIAN HISTORICAL SCENES ─────────────────────────────────────
    if (bgType.includes('karnak') || bgType.includes('temple') || bgType.includes('desecration')) {
      bgHtml = \`
        <rect width="1280" height="720" fill="#FEF3C7"/>
        <line x1="0" y1="560" x2="1280" y2="560" stroke="#78350F" stroke-width="4.5"/>
        <!-- Massive Sandstone Pylon Columns with Carvings -->
        <rect x="120" y="100" width="160" height="460" fill="#D97706" stroke="#000" stroke-width="5"/>
        <rect x="1000" y="100" width="160" height="460" fill="#D97706" stroke="#000" stroke-width="5"/>
        <!-- Column Lotiform capitals -->
        <path d="M 100 120 Q 200 60 300 120 L 280 160 L 120 160 Z" fill="#B45309" stroke="#000" stroke-width="4"/>
        <path d="M 980 120 Q 1080 60 1180 120 L 1160 160 L 1000 160 Z" fill="#B45309" stroke="#000" stroke-width="4"/>
        <!-- Golden Falcon Horus / Anubis Statue -->
        <rect x="820" y="340" width="100" height="220" rx="6" fill="#F59E0B" stroke="#000" stroke-width="4"/>
        <circle cx="870" cy="310" r="32" fill="#F59E0B" stroke="#000" stroke-width="3"/>
        <polygon points="850,310 820,325 850,340" fill="#EA580C" stroke="#000" stroke-width="2"/>
        <!-- Incense smoke curls -->
        <path d="M 380 520 Q 360 440 390 380 Q 420 320 380 260" stroke="#CBD5E1" stroke-width="6" fill="none" opacity="0.6"/>
        <circle cx="380" cy="530" r="22" fill="#334155" stroke="#000" stroke-width="3"/>
      \`;
      actorsHtml = this.renderCharacter(580, 440, pose, expr, 1.05);

    } else if (bgType.includes('aten') || bgType.includes('cosmic') || bgType.includes('revelation') || bgType.includes('sun_disc')) {
      bgHtml = \`
        <rect width="1280" height="720" fill="#0B132B"/>
        <!-- Desert Horizon -->
        <path d="M 0 580 Q 640 540 1280 580 L 1280 720 L 0 720 Z" fill="#D97706"/>
        <line x1="0" y1="580" x2="1280" y2="580" stroke="#78350F" stroke-width="4"/>
        <!-- Colossal Radiant Aten Sun Disc -->
        <circle cx="640" cy="220" r="95" fill="#FBBF24" stroke="#D97706" stroke-width="8"/>
        <circle cx="640" cy="220" r="85" fill="#FEF08A"/>
        <!-- Solar Rays Ending in Tiny Hands -->
        <g stroke="#FBBF24" stroke-width="4" stroke-linecap="round">
          <line x1="640" y1="315" x2="640" y2="480"/>
          <circle cx="640" cy="485" r="7" fill="#F59E0B"/>
          <line x1="560" y1="280" x2="440" y2="440"/>
          <circle cx="435" cy="445" r="7" fill="#F59E0B"/>
          <line x1="720" y1="280" x2="840" y2="440"/>
          <circle cx="845" cy="445" r="7" fill="#F59E0B"/>
          <line x1="500" y1="220" x2="320" y2="340"/>
          <circle cx="315" cy="345" r="7" fill="#F59E0B"/>
          <line x1="780" y1="220" x2="960" y2="340"/>
          <circle cx="965" cy="345" r="7" fill="#F59E0B"/>
        </g>
      \`;
      actorsHtml = this.renderCharacter(640, 460, pose, expr, 1.1);

    } else if (bgType.includes('exodus') || bgType.includes('nile') || bgType.includes('cliff') || bgType.includes('boundary')) {
      bgHtml = \`
        <rect width="1280" height="720" fill="#38BDF8"/>
        <!-- Sparkling Nile River -->
        <rect y="440" width="1280" height="280" fill="#0284C7"/>
        <line x1="0" y1="440" x2="1280" y2="440" stroke="#0369A1" stroke-width="4"/>
        <!-- Sheer Limestone Desert Cliffs -->
        <polygon points="0,440 280,180 520,320 860,160 1280,340 1280,440" fill="#FDE68A" stroke="#B45309" stroke-width="5"/>
        <polygon points="120,440 360,220 600,340 920,200 1280,380 1280,440" fill="#F59E0B" opacity="0.4"/>
        <!-- Wooden Egyptian Nile Sailing Barge -->
        <g transform="translate(480, 410)">
          <path d="M 0 60 Q 180 110 360 60 L 330 30 L 30 30 Z" fill="#92400E" stroke="#000" stroke-width="4"/>
          <line x1="180" y1="30" x2="180" y2="-120" stroke="#78350F" stroke-width="6"/>
          <polygon points="180,-110 300,-40 180,-30" fill="#FEF3C7" stroke="#000" stroke-width="3"/>
        </g>
      \`;
      actorsHtml = this.renderCharacter(380, 390, pose, expr, 1.0);

    } else if (bgType.includes('amarna') || bgType.includes('avenue') || bgType.includes('balcony') || bgType.includes('paradise')) {
      bgHtml = \`
        <rect width="1280" height="720" fill="#FFFBEB"/>
        <line x1="0" y1="560" x2="1280" y2="560" stroke="#78350F" stroke-width="4.5"/>
        <!-- Gleaming White Roofless Temples & Colonnades -->
        <rect x="80" y="240" width="1120" height="320" fill="#FFFFFF" stroke="#000" stroke-width="4.5"/>
        <!-- Geometric Painted Lotus Bands -->
        <rect x="80" y="240" width="1120" height="35" fill="#0284C7"/>
        <rect x="80" y="275" width="1120" height="15" fill="#F59E0B"/>
        <!-- Rows of open-air offering altars under the sky -->
        <rect x="220" y="470" width="80" height="90" fill="#FDE68A" stroke="#000" stroke-width="3"/>
        <rect x="420" y="470" width="80" height="90" fill="#FDE68A" stroke="#000" stroke-width="3"/>
        <rect x="820" y="470" width="80" height="90" fill="#FDE68A" stroke="#000" stroke-width="3"/>
        <rect x="1020" y="470" width="80" height="90" fill="#FDE68A" stroke="#000" stroke-width="3"/>
        <!-- Piles of bread & pomegranates on altars -->
        <circle cx="260" cy="460" r="14" fill="#EA580C"/>
        <circle cx="460" cy="460" r="14" fill="#EA580C"/>
        <circle cx="860" cy="460" r="14" fill="#EA580C"/>
        <circle cx="1060" cy="460" r="14" fill="#EA580C"/>
        <!-- Blazing Midday Sun in open roof -->
        <circle cx="640" cy="110" r="65" fill="#FBBF24" stroke="#D97706" stroke-width="5"/>
      \`;
      actorsHtml = this.renderCharacter(640, 440, pose, expr, 1.05);

    } else if (bgType.includes('cuneiform') || bgType.includes('archive') || bgType.includes('tablets')) {
      bgHtml = \`
        <rect width="1280" height="720" fill="#1C1917"/>
        <line x1="0" y1="560" x2="1280" y2="560" stroke="#000" stroke-width="4.5"/>
        <!-- Wooden archive shelving with hundreds of cuneiform tablets -->
        <rect x="140" y="120" width="460" height="440" fill="#44403C" stroke="#000" stroke-width="5"/>
        <line x1="140" y1="230" x2="600" y2="230" stroke="#000" stroke-width="4"/>
        <line x1="140" y1="340" x2="600" y2="340" stroke="#000" stroke-width="4"/>
        <line x1="140" y1="450" x2="600" y2="450" stroke="#000" stroke-width="4"/>
        <!-- Baked clay tablets lined up -->
        <g fill="#D97706" stroke="#000" stroke-width="2">
          <rect x="160" y="160" width="45" height="60" rx="4"/>
          <rect x="220" y="160" width="45" height="60" rx="4"/>
          <rect x="280" y="160" width="45" height="60" rx="4"/>
          <rect x="340" y="160" width="45" height="60" rx="4"/>
          <rect x="400" y="160" width="45" height="60" rx="4"/>
          <rect x="160" y="270" width="45" height="60" rx="4"/>
          <rect x="220" y="270" width="45" height="60" rx="4"/>
          <rect x="280" y="270" width="45" height="60" rx="4"/>
          <rect x="160" y="380" width="45" height="60" rx="4"/>
          <rect x="220" y="380" width="45" height="60" rx="4"/>
        </g>
        <!-- Slanted ray of dramatic window light cutting through dust -->
        <polygon points="900,0 1280,0 1280,560 750,560" fill="rgba(251, 191, 36, 0.12)"/>
      \`;
      actorsHtml = this.renderCharacter(860, 440, pose, expr, 1.05);

    } else if (bgType.includes('hittite') || bgType.includes('invasion') || bgType.includes('battle')) {
      bgHtml = \`
        <rect width="1280" height="720" fill="#7C2D12"/>
        <!-- Arid Syrian battlefield horizon -->
        <rect y="520" width="1280" height="200" fill="#451A03"/>
        <line x1="0" y1="520" x2="1280" y2="520" stroke="#000" stroke-width="4.5"/>
        <!-- Burning Egyptian Watchtower in Background -->
        <rect x="950" y="280" width="120" height="240" fill="#292524" stroke="#000" stroke-width="4"/>
        <!-- Flames & billowing smoke -->
        <path d="M 950 280 Q 990 180 1020 280 Q 1060 160 1070 280" fill="#EA580C"/>
        <path d="M 970 280 Q 1010 200 1030 280" fill="#FBBF24"/>
        <!-- Hittite War Chariot silhouette -->
        <g transform="translate(180, 410)">
          <circle cx="80" cy="90" r="45" fill="#78350F" stroke="#000" stroke-width="5"/>
          <rect x="0" y="30" width="160" height="60" rx="8" fill="#B45309" stroke="#000" stroke-width="4"/>
          <line x1="160" y1="70" x2="320" y2="50" stroke="#78350F" stroke-width="7"/>
        </g>
      \`;
      actorsHtml = this.renderCharacter(620, 420, pose, expr, 1.05);

    } else if (bgType.includes('demolition') || bgType.includes('erased') || bgType.includes('tomb') || bgType.includes('archaeological')) {
      bgHtml = \`
        <rect width="1280" height="720" fill="#FEF08A"/>
        <!-- Desert ruins under burning sky -->
        <path d="M 0 540 Q 400 480 800 540 Q 1100 500 1280 540 L 1280 720 L 0 720 Z" fill="#D97706"/>
        <line x1="0" y1="540" x2="1280" y2="540" stroke="#78350F" stroke-width="4.5"/>
        <!-- Toppled, broken limestone column drums lying in sand -->
        <ellipse cx="280" cy="560" rx="70" ry="35" fill="#FDE68A" stroke="#000" stroke-width="4"/>
        <rect x="230" y="520" width="120" height="40" fill="#F59E0B" stroke="#000" stroke-width="3"/>
        <ellipse cx="980" cy="550" rx="80" ry="40" fill="#FDE68A" stroke="#000" stroke-width="4"/>
        <!-- Carved damaged head emerging from the sand -->
        <path d="M 720 540 C 700 480 740 430 790 440 C 830 430 860 480 840 540 Z" fill="#FEF3C7" stroke="#000" stroke-width="4"/>
      \`;
      actorsHtml = this.renderCharacter(520, 440, pose, expr, 1.05);
    } else `;

if (!code.includes('ANCIENT EGYPTIAN HISTORICAL SCENES')) {
  code = code.replace("if (bgType.includes('bedroom')", injection + "if (bgType.includes('bedroom')");
  fs.writeFileSync(targetPath, code, 'utf8');
  console.log('✅ Hand-Drawn Comic Engine upgraded with Ancient Egyptian Historical Visuals!');
} else {
  console.log('Egyptian themes already present in comic engine.');
}
