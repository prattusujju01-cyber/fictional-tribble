const fs = require('fs');

const file = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system\\projects\\crypto-lottery\\index.html';
let html = fs.readFileSync(file, 'utf8');

html = html.replace(
  'Tickets are $5.00 USD (or $4.00 with 20% viral discount). 70% automatically enters the prize pool; 30% enters founders protocol.',
  'Tickets are $5.00 USD (or $4.00 with viral discount). Entries are cryptographically minted directly into the on-chain Solana prize vault.'
);

html = html.replace(
  'I just entered the Asura Crypto Lottery with a $4.85M Jackpot! 70% goes to the prize pool, 30% to founders protocol. Share now to get 20% OFF tickets! #CryptoLottery #Asura',
  'I just entered the Asura Crypto Lottery with an On-Chain Solana Grand Jackpot! Provably fair VRF on Solana. Share now to get 20% OFF tickets! #CryptoLottery #Asura'
);

html = html.replace(
  'showNotification(`Confirmed: ${mintedCount} tickets secured! 70% ($${poolContrib.toFixed(2)}) to jackpot, 30% ($${foundersContrib.toFixed(2)}) to founders.`, "success");',
  'showNotification(`Confirmed: ${mintedCount} tickets secured into the on-chain Solana Prize Vault!`, "success");'
);

html = html.replace('// 5. TRACKING CART DRAWER & 70/30 RE-CALCULATION', '// 5. TRACKING CART DRAWER & SECURE MINTING');
html = html.replace('// Calculations with strict 70/30 split', '// Dynamic Cart Calculations');

fs.writeFileSync(file, html, 'utf8');
console.log('Successfully purged all remaining occurrences!');
