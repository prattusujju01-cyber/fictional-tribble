const fs = require('fs');
const path = require('path');

const GITHUB_TOKEN = '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';
const REPO_OWNER = 'prathamgowda194-pixel';
const REPO_NAME = 'asura-system';
const WORKSPACE_DIR = 'C:/Users/WINDOWS/.gemini/antigravity/scratch/asura-system';

const filesToSync = [
  'api/serve_project.js',
  'api/cron_hunt.js',
  'free_crawler_engine.cjs',
  'deduplication_vault.cjs',
  'data/blacklisted_businesses.json'
];

async function syncFile(relPath) {
  const localPath = path.join(WORKSPACE_DIR, relPath);
  if (!fs.existsSync(localPath)) {
    console.warn(`File not found: ${localPath}`);
    return false;
  }

  const content = fs.readFileSync(localPath, 'utf8');
  const base64Content = Buffer.from(content, 'utf8').toString('base64');
  const url = `https://api.github.com/repos/${REPO_OWNER}/${REPO_NAME}/contents/${relPath}`;

  let sha = null;
  try {
    const check = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${GITHUB_TOKEN}`,
        'User-Agent': 'ASURA-Sync',
        'Accept': 'application/vnd.github.v3+json'
      }
    });
    if (check.status === 200) {
      const data = await check.json();
      sha = data.sha;
    }
  } catch (e) {}

  const body = {
    message: `feat(upgrade): deploy free crawler, blacklist filter, and strict deduplication vault for ${relPath} [skip ci]`,
    content: base64Content,
    branch: 'main'
  };
  if (sha) body.sha = sha;

  try {
    const putRes = await fetch(url, {
      method: 'PUT',
      headers: {
        'Authorization': `Bearer ${GITHUB_TOKEN}`,
        'Content-Type': 'application/json',
        'User-Agent': 'ASURA-Sync',
        'Accept': 'application/vnd.github.v3+json'
      },
      body: JSON.stringify(body)
    });

    if (putRes.status === 200 || putRes.status === 201) {
      console.log(`✅ [SYNCED TO GITHUB] ${relPath}`);
      return true;
    } else {
      const err = await putRes.text();
      console.warn(`⚠️ [SYNC FAILED ${putRes.status}] ${relPath}: ${err.slice(0, 100)}`);
    }
  } catch (e) {
    console.error(`❌ [SYNC EXCEPTION] ${relPath}: ${e.message}`);
  }
  return false;
}

async function run() {
  console.log('Deploying upgraded engine files to GitHub for Vercel production sync...\n');
  for (const f of filesToSync) {
    await syncFile(f);
    await new Promise(r => setTimeout(r, 1000));
  }
  console.log('\nAll core files synchronized to GitHub!');
}

run().catch(console.error);
