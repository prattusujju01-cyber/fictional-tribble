const GEMINI_KEY = "AQ.Ab8RN6LQTcBVg27285xhxo4j7NrFIsXGY9tKv96nGlh6e6rlDQ";

async function testGemini() {
  const models = ["gemini-2.5-flash", "gemini-2.0-flash", "gemini-1.5-flash", "gemini-3.6-flash"];
  for (const m of models) {
    try {
      console.log(`Testing model: ${m}...`);
      const url = `https://generativelanguage.googleapis.com/v1beta/models/${m}:generateContent?key=${GEMINI_KEY}`;
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          contents: [{ parts: [{ text: "Say 'ASURA ENGINE ONLINE' in 3 words." }] }]
        })
      });
      console.log(`Model ${m} status:`, res.status);
      const data = await res.json();
      if (res.status === 200) {
        console.log("Response:", data.candidates?.[0]?.content?.parts?.[0]?.text);
        return;
      } else {
        console.log("Error:", data.error?.message);
      }
    } catch (e) {
      console.error(`Error with ${m}:`, e.message);
    }
  }
}

testGemini();
