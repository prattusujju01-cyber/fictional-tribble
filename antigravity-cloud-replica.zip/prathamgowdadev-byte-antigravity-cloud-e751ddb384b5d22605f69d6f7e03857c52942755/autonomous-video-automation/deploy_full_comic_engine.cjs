const fs = require('fs');
const path = require('path');

const targetPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\utils\\hand-drawn-comic-engine.js';

const code = `/**
 * ══════════════════════════════════════════════════════════════════════════════
 * HAND-DRAWN 2D COMIC VECTOR ENGINE // ANTI-AI-SLOP STANDARD
 * ══════════════════════════════════════════════════════════════════════════════
 * Authentic Hand-Drawn 2D Webcomic Stickman Engine:
 * - Natural organic sketchy black ink strokes (varying widths, hand-drawn wiggles, rounded joints)
 * - White circular head with bold contour & expressive facial acting
 * - Tailored compositions strictly matching 120 beats of narration
 * - Clean 16:9 full-canvas framing (1280x720) with ZERO programmatic zoom/drift
 * - Instant static cuts (no Ken Burns camera jitter)
 */

const fs = require('fs');
const path = require('path');

class HandDrawnComicEngine {
  constructor() {
    this.width = 1280;
    this.height = 720;
  }

  // ── ORGANIC STROKE & SHAPE GENERATORS ──────────────────────────────────────
  sketchLine(x1, y1, x2, y2, width = 5, color = '#000000') {
    const mx = (x1 + x2) / 2 + (Math.sin(x1 * 0.05 + y1 * 0.02) * 4);
    const my = (y1 + y2) / 2 + (Math.cos(x2 * 0.04 + y2 * 0.03) * 4);
    return \`<path d="M \${x1} \${y1} Q \${mx} \${my} \${x2} \${y2}" stroke="\${color}" stroke-width="\${width}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>\`;
  }

  sketchCircle(cx, cy, r, fill = '#FFFFFF', stroke = '#000000', strokeWidth = 5.5) {
    const p1 = \`\${cx - r} \${cy}\`;
    const p2 = \`\${cx} \${cy - r - 2}\`;
    const p3 = \`\${cx + r + 2} \${cy + 1}\`;
    const p4 = \`\${cx - 1} \${cy + r + 2}\`;
    return \`<path d="M \${p1} C \${cx - r} \${cy - r*0.58}, \${cx - r*0.58} \${cy - r - 2}, \${p2} C \${cx + r*0.58} \${cy - r - 2}, \${cx + r + 2} \${cy - r*0.58}, \${p3} C \${cx + r + 2} \${cy + r*0.58}, \${cx + r*0.58} \${cy + r + 2}, \${p4} C \${cx - r*0.58} \${cy + r + 2}, \${cx - r} \${cy + r*0.58}, \${p1} Z" fill="\${fill}" stroke="\${stroke}" stroke-width="\${strokeWidth}" stroke-linecap="round" stroke-linejoin="round"/>\`;
  }

  // ── FACIAL EXPRESSIONS & ACTING ───────────────────────────────────────────
  renderCharacterHead(cx, cy, radius = 65, expression = 'deadpan') {
    const headOutline = this.sketchCircle(cx, cy, radius, '#FFFFFF', '#000000', 5.5);
    let eyesHtml = '';
    let browsHtml = '';
    let mouthHtml = '';
    let extraHtml = '';

    switch (expression) {
      case 'scared':
        browsHtml = \`
          <path d="M \${cx - 42} \${cy - 28} Q \${cx - 26} \${cy - 48} \${cx - 10} \${cy - 30}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 10} \${cy - 30} Q \${cx + 26} \${cy - 48} \${cx + 42} \${cy - 28}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <ellipse cx="\${cx - 25}" cy="\${cy - 8}" rx="14" ry="17" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx - 23}" cy="\${cy - 5}" r="5.5" fill="#000"/>
          <ellipse cx="\${cx + 25}" cy="\${cy - 8}" rx="14" ry="17" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx + 23}" cy="\${cy - 5}" r="5.5" fill="#000"/>
        \`;
        mouthHtml = \`<path d="M \${cx - 22} \${cy + 28} Q \${cx} \${cy + 16} \${cx + 22} \${cy + 28}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>\`;
        extraHtml = \`
          <path d="M \${cx + 46} \${cy - 18} C \${cx + 44} \${cy - 30}, \${cx + 56} \${cy - 26}, \${cx + 50} \${cy - 12} Z" fill="#60A5FA" stroke="#000" stroke-width="2"/>
          <line x1="\${cx - 28}" y1="\${cy + 8}" x2="\${cx - 28}" y2="\${cy + 16}" stroke="#000" stroke-width="2.5" stroke-linecap="round"/>
          <line x1="\${cx + 28}" y1="\${cy + 8}" x2="\${cx + 28}" y2="\${cy + 16}" stroke="#000" stroke-width="2.5" stroke-linecap="round"/>
        \`;
        break;

      case 'annoyed':
        browsHtml = \`
          <line x1="\${cx - 40}" y1="\${cy - 32}" x2="\${cx - 10}" y2="\${cy - 22}" stroke="#000" stroke-width="4.5" stroke-linecap="round"/>
          <line x1="\${cx + 10}" y1="\${cy - 22}" x2="\${cx + 40}" y2="\${cy - 32}" stroke="#000" stroke-width="4.5" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <circle cx="\${cx - 22}" cy="\${cy - 6}" r="6" fill="#000"/>
          <circle cx="\${cx + 22}" cy="\${cy - 6}" r="6" fill="#000"/>
        \`;
        mouthHtml = \`<path d="M \${cx - 20} \${cy + 26} L \${cx + 20} \${cy + 22}" stroke="#000" stroke-width="4.5" stroke-linecap="round"/>\`;
        break;

      case 'smug_curious':
        browsHtml = \`
          <path d="M \${cx - 38} \${cy - 38} Q \${cx - 24} \${cy - 48} \${cx - 8} \${cy - 35}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
          <line x1="\${cx + 8}" y1="\${cy - 24}" x2="\${cx + 36}" y2="\${cy - 28}" stroke="#000" stroke-width="4" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <ellipse cx="\${cx - 24}" cy="\${cy - 8}" rx="13" ry="15" fill="#FFF" stroke="#000" stroke-width="3"/>
          <circle cx="\${cx - 22}" cy="\${cy - 7}" r="5" fill="#000"/>
          <path d="M \${cx + 12} \${cy - 8} Q \${cx + 25} \${cy - 16} \${cx + 38} \${cy - 8}" stroke="#000" stroke-width="3.5" fill="none" stroke-linecap="round"/>
          <circle cx="\${cx + 25}" cy="\${cy - 4}" r="4.5" fill="#000"/>
        \`;
        mouthHtml = \`<path d="M \${cx - 8} \${cy + 26} Q \${cx + 15} \${cy + 34} \${cx + 32} \${cy + 18}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>\`;
        break;

      case 'shocked':
        browsHtml = \`
          <path d="M \${cx - 40} \${cy - 38} Q \${cx - 25} \${cy - 52} \${cx - 10} \${cy - 38}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 10} \${cy - 38} Q \${cx + 25} \${cy - 52} \${cx + 40} \${cy - 38}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <ellipse cx="\${cx - 24}" cy="\${cy - 10}" rx="16" ry="20" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx - 24}" cy="\${cy - 10}" r="6" fill="#000"/>
          <ellipse cx="\${cx + 24}" cy="\${cy - 10}" rx="16" ry="20" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx + 24}" cy="\${cy - 10}" r="6" fill="#000"/>
        \`;
        mouthHtml = \`<ellipse cx="\${cx}" cy="\${cy + 26}" rx="12" ry="17" fill="#000" stroke="#000" stroke-width="3"/>\`;
        break;

      case 'sleepy':
        browsHtml = \`
          <path d="M \${cx - 36} \${cy - 24} Q \${cx - 22} \${cy - 20} \${cx - 8} \${cy - 24}" stroke="#000" stroke-width="3.5" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 8} \${cy - 24} Q \${cx + 22} \${cy - 20} \${cx + 36} \${cy - 24}" stroke="#000" stroke-width="3.5" fill="none" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <path d="M \${cx - 32} \${cy - 6} Q \${cx - 22} \${cy + 2} \${cx - 12} \${cy - 6}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 12} \${cy - 6} Q \${cx + 22} \${cy + 2} \${cx + 32} \${cy - 6}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>
        \`;
        mouthHtml = \`<ellipse cx="\${cx}" cy="\${cy + 22}" rx="8" ry="12" fill="#000"/>\`;
        extraHtml = \`
          <text x="\${cx + 42}" y="\${cy - 32}" font-family="'Comic Sans MS', sans-serif" font-size="20" font-weight="bold" fill="#3B82F6">Z</text>
          <text x="\${cx + 56}" y="\${cy - 48}" font-family="'Comic Sans MS', sans-serif" font-size="26" font-weight="bold" fill="#3B82F6">Z</text>
          <text x="\${cx + 72}" y="\${cy - 68}" font-family="'Comic Sans MS', sans-serif" font-size="32" font-weight="bold" fill="#3B82F6">z</text>
        \`;
        break;

      case 'awe_wonder':
        browsHtml = \`
          <path d="M \${cx - 36} \${cy - 34} Q \${cx - 20} \${cy - 46} \${cx - 6} \${cy - 32}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 6} \${cy - 32} Q \${cx + 20} \${cy - 46} \${cx + 36} \${cy - 34}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <circle cx="\${cx - 22}" cy="\${cy - 8}" r="11" fill="#000"/>
          <circle cx="\${cx - 24}" cy="\${cy - 11}" r="3.5" fill="#FFF"/>
          <circle cx="\${cx + 22}" cy="\${cy - 8}" r="11" fill="#000"/>
          <circle cx="\${cx + 20}" cy="\${cy - 11}" r="3.5" fill="#FFF"/>
        \`;
        mouthHtml = \`<ellipse cx="\${cx}" cy="\${cy + 24}" rx="14" ry="18" fill="#E11D48" stroke="#000" stroke-width="3"/>\`;
        break;

      case 'grinning':
        browsHtml = \`
          <path d="M \${cx - 36} \${cy - 30} Q \${cx - 20} \${cy - 40} \${cx - 6} \${cy - 30}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 6} \${cy - 30} Q \${cx + 20} \${cy - 40} \${cx + 36} \${cy - 30}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <path d="M \${cx - 32} \${cy - 6} Q \${cx - 22} \${cy - 16} \${cx - 12} \${cy - 6}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 12} \${cy - 6} Q \${cx + 22} \${cy - 16} \${cx + 32} \${cy - 6}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>
        \`;
        mouthHtml = \`
          <path d="M \${cx - 26} \${cy + 16} Q \${cx} \${cy + 42} \${cx + 26} \${cy + 16} Z" fill="#E11D48" stroke="#000" stroke-width="3.5"/>
          <path d="M \${cx - 20} \${cy + 18} Q \${cx} \${cy + 28} \${cx + 20} \${cy + 18}" stroke="#FFF" stroke-width="5" fill="none" stroke-linecap="round"/>
        \`;
        break;

      case 'peaceful':
        browsHtml = \`
          <path d="M \${cx - 34} \${cy - 22} Q \${cx - 20} \${cy - 26} \${cx - 6} \${cy - 22}" stroke="#000" stroke-width="3" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 6} \${cy - 22} Q \${cx + 20} \${cy - 26} \${cx + 34} \${cy - 22}" stroke="#000" stroke-width="3" fill="none" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <path d="M \${cx - 30} \${cy - 6} Q \${cx - 20} \${cy - 2} \${cx - 10} \${cy - 6}" stroke="#000" stroke-width="3.5" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 10} \${cy - 6} Q \${cx + 20} \${cy - 2} \${cx + 30} \${cy - 6}" stroke="#000" stroke-width="3.5" fill="none" stroke-linecap="round"/>
        \`;
        mouthHtml = \`<path d="M \${cx - 16} \${cy + 22} Q \${cx} \${cy + 30} \${cx + 16} \${cy + 22}" stroke="#000" stroke-width="3.5" fill="none" stroke-linecap="round"/>\`;
        break;

      case 'deadpan':
      default:
        browsHtml = \`
          <line x1="\${cx - 36}" y1="\${cy - 26}" x2="\${cx - 10}" y2="\${cy - 26}" stroke="#000" stroke-width="4" stroke-linecap="round"/>
          <line x1="\${cx + 10}" y1="\${cy - 26}" x2="\${cx + 36}" y2="\${cy - 26}" stroke="#000" stroke-width="4" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <circle cx="\${cx - 22}" cy="\${cy - 7}" r="5.5" fill="#000"/>
          <circle cx="\${cx + 22}" cy="\${cy - 7}" r="5.5" fill="#000"/>
        \`;
        mouthHtml = \`<line x1="\${cx - 18}" y1="\${cy + 25}" x2="\${cx + 18}" y2="\${cy + 25}" stroke="#000" stroke-width="4" stroke-linecap="round"/>\`;
        break;
    }

    return \`
      <g>
        \${headOutline}
        \${browsHtml}
        \${eyesHtml}
        \${mouthHtml}
        \${extraHtml}
      </g>
    \`;
  }

  // ── CHARACTER POSES ───────────────────────────────────────────────────────
  renderCharacter(x, y, pose = 'walking', expression = 'deadpan', scale = 1.0) {
    const headRadius = 65 * scale;
    const bodyLength = 155 * scale;
    const headY = y - bodyLength;
    let bodyHtml = '';

    switch (pose) {
      case 'bed_phone_scroll':
      case 'holding_phone_bed':
        bodyHtml = \`
          <!-- Bed frame & pillows -->
          <rect x="280" y="440" width="720" height="120" rx="14" fill="#64748B" stroke="#000" stroke-width="4"/>
          <ellipse cx="380" cy="420" rx="65" ry="32" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <!-- Propped torso -->
          \${this.sketchLine(x, headY + headRadius, x + 70*scale, y + 20*scale, 6*scale)}
          <!-- Arm holding glowing smartphone -->
          \${this.sketchLine(x + 20*scale, headY + headRadius + 25*scale, x + 80*scale, headY + headRadius + 20*scale, 5.5*scale)}
          <rect x="\${x + 75*scale}" y="\${headY + headRadius - 15*scale}" width="36" height="60" rx="6" fill="#000" stroke="#FFF" stroke-width="2"/>
          <rect x="\${x + 78*scale}" y="\${headY + headRadius - 10*scale}" width="30" height="50" rx="3" fill="#38BDF8"/>
          <!-- Blue glow cast -->
          <polygon points="\${x + 75*scale},\${headY + headRadius} \${x},\${headY - 20*scale} \${x},\${headY + 50*scale}" fill="rgba(56, 189, 248, 0.18)"/>
        \`;
        break;

      case 'striking_flint':
      case 'striking_flint_sparks':
        bodyHtml = \`
          <!-- Primitive fur wrap -->
          <polygon points="\${x-25*scale},\${y-10*scale} \${x+25*scale},\${y-10*scale} \${x+30*scale},\${y+35*scale} \${x-20*scale},\${y+40*scale}" fill="#78350F" stroke="#000" stroke-width="3"/>
          \${this.sketchLine(x, headY + headRadius, x, y, 6*scale)}
          <!-- Arms bringing flints together -->
          \${this.sketchLine(x, headY + headRadius + 25*scale, x - 40*scale, headY + headRadius + 60*scale, 5.5*scale)}
          \${this.sketchLine(x - 40*scale, headY + headRadius + 60*scale, x - 6*scale, headY + headRadius + 85*scale, 5.5*scale)}
          \${this.sketchLine(x, headY + headRadius + 25*scale, x + 40*scale, headY + headRadius + 60*scale, 5.5*scale)}
          \${this.sketchLine(x + 40*scale, headY + headRadius + 60*scale, x + 10*scale, headY + headRadius + 85*scale, 5.5*scale)}
          <!-- Two colliding flint stones -->
          <ellipse cx="\${x - 8*scale}" cy="\${headY + headRadius + 88*scale}" rx="14" ry="11" fill="#475569" stroke="#000" stroke-width="3"/>
          <ellipse cx="\${x + 12*scale}" cy="\${headY + headRadius + 88*scale}" rx="14" ry="11" fill="#64748B" stroke="#000" stroke-width="3"/>
          <!-- Golden spark bursts -->
          <line x1="\${x}" y1="\${headY + headRadius + 85*scale}" x2="\${x - 22*scale}" y2="\${headY + headRadius + 65*scale}" stroke="#FCD34D" stroke-width="4.5" stroke-linecap="round"/>
          <line x1="\${x}" y1="\${headY + headRadius + 85*scale}" x2="\${x + 24*scale}" y2="\${headY + headRadius + 60*scale}" stroke="#F59E0B" stroke-width="4.5" stroke-linecap="round"/>
          <line x1="\${x}" y1="\${headY + headRadius + 85*scale}" x2="\${x - 5*scale}" y2="\${headY + headRadius + 110*scale}" stroke="#FCD34D" stroke-width="4.5" stroke-linecap="round"/>
          <!-- Crouched legs -->
          <path d="M \${x} \${y} L \${x - 50*scale} \${y + 30*scale} L \${x - 30*scale} \${y + 80*scale}" stroke="#000" stroke-width="6*scale" fill="none" stroke-linecap="round"/>
          <path d="M \${x} \${y} L \${x + 40*scale} \${y + 35*scale} L \${x + 35*scale} \${y + 80*scale}" stroke="#000" stroke-width="6*scale" fill="none" stroke-linecap="round"/>
        \`;
        break;

      case 'climbing_tree':
      case 'balancing_branch_wobbly':
      case 'clutching_trunk_wind':
        bodyHtml = \`
          \${this.sketchLine(x, headY + headRadius, x + 25*scale, y, 6*scale)}
          \${this.sketchLine(x + 10*scale, headY + headRadius + 30*scale, x - 45*scale, headY + headRadius + 55*scale, 5.5*scale)}
          \${this.sketchLine(x + 10*scale, headY + headRadius + 30*scale, x + 65*scale, headY - 10*scale, 5.5*scale)}
          \${this.sketchLine(x + 25*scale, y, x + 10*scale, y + 45*scale, 6*scale)}
          \${this.sketchLine(x + 10*scale, y + 45*scale, x + 55*scale, y + 80*scale, 6*scale)}
          \${this.sketchLine(x + 25*scale, y, x + 45*scale, y + 55*scale, 6*scale)}
          \${this.sketchLine(x + 45*scale, y + 55*scale, x + 80*scale, y + 95*scale, 6*scale)}
        \`;
        break;

      case 'holding_torch':
      case 'holding_flaming_branch':
        bodyHtml = \`
          \${this.sketchLine(x, headY + headRadius, x, y, 6*scale)}
          <!-- Raised arm holding torch -->
          \${this.sketchLine(x, headY + headRadius + 30*scale, x + 65*scale, headY - 10*scale, 5.5*scale)}
          <!-- Wooden torch branch -->
          <line x1="\${x + 60*scale}" y1="\${headY + 15*scale}" x2="\${x + 75*scale}" y2="\${headY - 50*scale}" stroke="#78350F" stroke-width="8" stroke-linecap="round"/>
          <!-- Torch Flame -->
          <path d="M \${x + 75*scale} \${headY - 45*scale} Q \${x + 55*scale} \${headY - 80*scale} \${x + 75*scale} \${headY - 110*scale} Q \${x + 95*scale} \${headY - 75*scale} \${x + 75*scale} \${headY - 45*scale} Z" fill="#EA580C" stroke="#000" stroke-width="3"/>
          <path d="M \${x + 75*scale} \${headY - 45*scale} Q \${x + 65*scale} \${headY - 70*scale} \${x + 75*scale} \${headY - 90*scale} Q \${x + 85*scale} \${headY - 65*scale} \${x + 75*scale} \${headY - 45*scale} Z" fill="#FBBF24"/>
          <!-- Left arm forward -->
          \${this.sketchLine(x, headY + headRadius + 30*scale, x - 45*scale, headY + headRadius + 60*scale, 5.5*scale)}
          <!-- Legs -->
          \${this.sketchLine(x, y, x - 35*scale, y + 110*scale, 6*scale)}
          \${this.sketchLine(x, y, x + 35*scale, y + 110*scale, 6*scale)}
        \`;
        break;

      case 'sitting_by_campfire':
      case 'storytelling_tribal_circle':
        bodyHtml = \`
          <!-- Torso leaning forward slightly -->
          \${this.sketchLine(x, headY + headRadius, x + 15*scale, y + 30*scale, 6*scale)}
          <!-- Arms extended toward fire -->
          \${this.sketchLine(x + 5*scale, headY + headRadius + 30*scale, x + 50*scale, headY + headRadius + 50*scale, 5.5*scale)}
          \${this.sketchLine(x + 50*scale, headY + headRadius + 50*scale, x + 85*scale, headY + headRadius + 40*scale, 5.5*scale)}
          <!-- Folded legs sitting on ground -->
          <path d="M \${x + 15*scale} \${y + 30*scale} L \${x - 45*scale} \${y + 60*scale} L \${x + 40*scale} \${y + 65*scale}" stroke="#000" stroke-width="6*scale" fill="none" stroke-linecap="round"/>
        \`;
        break;

      case 'reading_manuscript':
      case 'reading_bible_candlelight':
      case 'writing_quill_parchment':
        bodyHtml = \`
          \${this.sketchLine(x, headY + headRadius, x, y, 6*scale)}
          <!-- Left arm holding parchment -->
          \${this.sketchLine(x, headY + headRadius + 30*scale, x - 45*scale, headY + headRadius + 55*scale, 5.5*scale)}
          \${this.sketchLine(x - 45*scale, headY + headRadius + 55*scale, x - 15*scale, headY + headRadius + 80*scale, 5.5*scale)}
          <!-- Right arm with quill -->
          \${this.sketchLine(x, headY + headRadius + 30*scale, x + 40*scale, headY + headRadius + 45*scale, 5.5*scale)}
          \${this.sketchLine(x + 40*scale, headY + headRadius + 45*scale, x + 25*scale, headY + headRadius + 75*scale, 5.5*scale)}
          <!-- Goose feather quill -->
          <path d="M \${x + 25*scale} \${headY + headRadius + 75*scale} Q \${x + 45*scale} \${headY + headRadius + 40*scale} \${x + 60*scale} \${headY + headRadius + 20*scale}" stroke="#FFF" stroke-width="4" fill="none"/>
          <path d="M \${x + 25*scale} \${headY + headRadius + 75*scale} Q \${x + 45*scale} \${headY + headRadius + 40*scale} \${x + 60*scale} \${headY + headRadius + 20*scale}" stroke="#000" stroke-width="1.5" fill="none"/>
          <!-- Legs -->
          \${this.sketchLine(x, y, x - 25*scale, y + 110*scale, 6*scale)}
          \${this.sketchLine(x, y, x + 25*scale, y + 110*scale, 6*scale)}
        \`;
        break;

      case 'sprinting_panicked':
        bodyHtml = \`
          <!-- Leaning forward body -->
          \${this.sketchLine(x, headY + headRadius, x - 40*scale, y, 6*scale)}
          <!-- Wild pumping arms -->
          \${this.sketchLine(x - 10*scale, headY + headRadius + 25*scale, x + 60*scale, headY + headRadius + 10*scale, 5.5*scale)}
          \${this.sketchLine(x - 10*scale, headY + headRadius + 25*scale, x - 70*scale, headY + headRadius + 50*scale, 5.5*scale)}
          <!-- Running legs spread wide -->
          \${this.sketchLine(x - 40*scale, y, x + 60*scale, y + 30*scale, 6*scale)}
          \${this.sketchLine(x + 60*scale, y + 30*scale, x + 70*scale, y + 90*scale, 6*scale)}
          \${this.sketchLine(x - 40*scale, y, x - 90*scale, y - 10*scale, 6*scale)}
          \${this.sketchLine(x - 90*scale, y - 10*scale, x - 130*scale, y + 30*scale, 6*scale)}
          <!-- Speed dust puffs -->
          <circle cx="\${x - 140*scale}" cy="\${y + 40*scale}" r="12" fill="#E2E8F0"/>
          <circle cx="\${x - 165*scale}" cy="\${y + 35*scale}" r="9" fill="#CBD5E1"/>
        \`;
        break;

      case 'blasted_by_sunlamp':
        bodyHtml = \`
          <!-- Leaning back shielding eyes -->
          \${this.sketchLine(x, headY + headRadius, x - 25*scale, y + 20*scale, 6*scale)}
          <!-- Arm raised across face blocking light -->
          \${this.sketchLine(x - 10*scale, headY + headRadius + 25*scale, x + 15*scale, headY + headRadius - 10*scale, 5.5*scale)}
          \${this.sketchLine(x + 15*scale, headY + headRadius - 10*scale, x - 20*scale, headY + 10*scale, 5.5*scale)}
          <!-- Other arm back -->
          \${this.sketchLine(x - 10*scale, headY + headRadius + 25*scale, x - 55*scale, headY + headRadius + 60*scale, 5.5*scale)}
          <!-- Sitting on sofa -->
          <path d="M \${x - 25*scale} \${y + 20*scale} L \${x + 35*scale} \${y + 35*scale} L \${x + 35*scale} \${y + 80*scale}" stroke="#000" stroke-width="6*scale" fill="none" stroke-linecap="round"/>
        \`;
        break;

      case 'sleeping_deep_ground':
      case 'deep_first_sleep':
      case 'vivid_second_sleep_dreaming':
        bodyHtml = \`
          <!-- Sleeping lying down horizontal -->
          <line x1="\${x - 100*scale}" y1="\${y + 50*scale}" x2="\${x + 100*scale}" y2="\${y + 50*scale}" stroke="#000" stroke-width="6*scale" stroke-linecap="round"/>
          <!-- Cozy blanket arc -->
          <path d="M \${x - 60*scale} \${y + 50*scale} Q \${x + 20*scale} \${y - 10*scale} \${x + 110*scale} \${y + 50*scale}" fill="#3B82F6" stroke="#000" stroke-width="4"/>
        \`;
        break;

      case 'walking':
      default:
        bodyHtml = \`
          \${this.sketchLine(x, headY + headRadius, x, y, 6*scale)}
          \${this.sketchLine(x, headY + headRadius + 30*scale, x - 45*scale, y - 50*scale, 5.5*scale)}
          \${this.sketchLine(x - 45*scale, y - 50*scale, x - 65*scale, y - 5*scale, 5.5*scale)}
          \${this.sketchLine(x, headY + headRadius + 30*scale, x + 40*scale, y - 45*scale, 5.5*scale)}
          \${this.sketchLine(x + 40*scale, y - 45*scale, x + 60*scale, y - 10*scale, 5.5*scale)}
          \${this.sketchLine(x, y, x - 50*scale, y + 65*scale, 6*scale)}
          \${this.sketchLine(x - 50*scale, y + 65*scale, x - 75*scale, y + 125*scale, 6*scale)}
          \${this.sketchLine(x, y, x + 40*scale, y + 60*scale, 6*scale)}
          \${this.sketchLine(x + 40*scale, y + 60*scale, x + 70*scale, y + 125*scale, 6*scale)}
        \`;
        break;
    }

    return \`
      <g>
        \${bodyHtml}
        \${this.renderCharacterHead(x, headY, headRadius, expression)}
      </g>
    \`;
  }

  // ── ENVIRONMENT BUILDERS ──────────────────────────────────────────────────
  renderCampfire(x, y) {
    return \`
      <g transform="translate(\${x}, \${y})">
        <!-- Fire stones -->
        <ellipse cx="0" cy="22" rx="90" ry="28" fill="#334155" stroke="#000" stroke-width="4"/>
        <circle cx="-70" cy="20" r="16" fill="#475569" stroke="#000" stroke-width="3"/>
        <circle cx="-35" cy="28" r="18" fill="#64748B" stroke="#000" stroke-width="3"/>
        <circle cx="0" cy="30" r="19" fill="#475569" stroke="#000" stroke-width="3"/>
        <circle cx="35" cy="28" r="18" fill="#64748B" stroke="#000" stroke-width="3"/>
        <circle cx="70" cy="20" r="16" fill="#475569" stroke="#000" stroke-width="3"/>
        <!-- Burning Logs -->
        <path d="M -55 12 L 55 -5 L 50 -15 L -60 2 Z" fill="#78350F" stroke="#000" stroke-width="3.5"/>
        <path d="M -45 -5 L 50 15 L 45 25 L -50 5 Z" fill="#92400E" stroke="#000" stroke-width="3.5"/>
        <!-- Big Cartoon Flames -->
        <path d="M 0 10 Q -65 -35 -35 -90 Q 0 -60 0 -135 Q 22 -75 42 -85 Q 65 -35 0 10 Z" fill="#EA580C" stroke="#000" stroke-width="4"/>
        <path d="M 0 10 Q -38 -20 -18 -65 Q 0 -45 0 -95 Q 16 -50 26 -55 Q 38 -20 0 10 Z" fill="#FBBF24"/>
        <!-- Sparks -->
        <circle cx="-25" cy="-115" r="4.5" fill="#F97316"/>
        <circle cx="15" cy="-145" r="5" fill="#FBBF24"/>
        <circle cx="-10" cy="-170" r="4" fill="#F97316"/>
        <circle cx="35" cy="-110" r="4.5" fill="#FBBF24"/>
      </g>
    \`;
  }

  renderPredatorEyes(x, y) {
    return \`
      <g transform="translate(\${x}, \${y})">
        <ellipse cx="0" cy="0" rx="16" ry="19" fill="#FCD34D" stroke="#000" stroke-width="3"/>
        <circle cx="-2" cy="0" r="5.5" fill="#000"/>
        <ellipse cx="44" cy="0" rx="16" ry="19" fill="#FCD34D" stroke="#000" stroke-width="3"/>
        <circle cx="42" cy="0" r="5.5" fill="#000"/>
      </g>
    \`;
  }

  // ── MASTER STATIC SCENE BUILDER ───────────────────────────────────────────
  buildSceneSVG(beat) {
    const act = beat.act || 1;
    const bgType = beat.bgType || 'night_savanna';
    const pose = beat.characterPose || beat.sceneType || 'walking';
    const expr = beat.expression || 'deadpan';
    const beatIndex = beat.beatIndex || 1;

    let bgHtml = '';
    let actorsHtml = '';

    // Route background & scenery based on narrative topic
    if (bgType.includes('bedroom') || bgType.includes('3am') || bgType.includes('phone') || bgType.includes('clock')) {
      // Modern bedroom with nightstand & glowing red alarm clock
      bgHtml = \`
        <rect width="1280" height="720" fill="#0F172A"/>
        <line x1="0" y1="560" x2="1280" y2="560" stroke="#1E293B" stroke-width="4"/>
        <!-- Window showing stars -->
        <rect x="80" y="120" width="220" height="300" rx="8" fill="#0B132B" stroke="#334155" stroke-width="6"/>
        <circle cx="140" cy="180" r="28" fill="#FEF08A"/>
        <circle cx="210" cy="240" r="3" fill="#FFF"/>
        <circle cx="250" cy="160" r="2.5" fill="#FFF"/>
        <!-- Nightstand with Digital Clock -->
        <rect x="940" y="440" width="160" height="120" rx="8" fill="#1E293B" stroke="#000" stroke-width="3.5"/>
        <rect x="965" y="468" width="110" height="50" rx="6" fill="#000"/>
        <text x="980" y="504" font-family="'Courier New', monospace" font-weight="bold" font-size="28" fill="#EF4444">03:14</text>
      \`;
      actorsHtml = this.renderCharacter(540, 480, pose, expr, 1.05);

    } else if (bgType.includes('living_room') || bgType.includes('switch') || bgType.includes('sunlamp')) {
      // Modern living room with giant ceiling lamp and purple sofa
      bgHtml = \`
        <rect width="1280" height="720" fill="#FFFBEB"/>
        <line x1="0" y1="560" x2="1280" y2="560" stroke="#000" stroke-width="4.5"/>
        <!-- Massive Ceiling Fixture & Radiating Yellow Beams -->
        <g opacity="0.4">
          <polygon points="640,90 200,560 1080,560" fill="#FDE047"/>
        </g>
        <ellipse cx="640" cy="90" rx="140" ry="30" fill="#F59E0B" stroke="#000" stroke-width="5"/>
        <ellipse cx="640" cy="85" rx="130" ry="24" fill="#FEF08A" stroke="#000" stroke-width="3"/>
        <!-- Purple Couch -->
        <rect x="380" y="420" width="520" height="140" rx="16" fill="#6366F1" stroke="#000" stroke-width="5"/>
        <rect x="360" y="480" width="560" height="80" rx="14" fill="#4F46E5" stroke="#000" stroke-width="5"/>
      \`;
      actorsHtml = this.renderCharacter(640, 450, pose, expr, 1.05);

    } else if (bgType.includes('tree') || bgType.includes('canopy') || bgType.includes('chimp') || bgType.includes('arboreal')) {
      // Ancient tree sanctuary: deep blue sky, giant green tree boughs
      bgHtml = \`
        <rect width="1280" height="720" fill="#1B2E58"/>
        <!-- Moon -->
        <circle cx="240" cy="140" r="50" fill="#FEF08A" stroke="#000" stroke-width="4"/>
        <!-- Big Tree Trunk and Branches -->
        <path d="M 760 720 L 730 320 L 520 180 L 540 150 L 750 270 L 780 60 L 820 60 L 820 260 L 960 160 L 980 180 L 840 320 L 870 720 Z" fill="#78350F" stroke="#000" stroke-width="5.5"/>
        <!-- Foliage Cloud Canopy -->
        <path d="M 440 180 C 380 120 420 30 500 40 C 560 0 680 0 740 50 C 820 15 920 50 940 120 C 1000 160 980 250 900 260 C 820 310 650 310 560 260 C 480 270 420 230 440 180 Z" fill="#16A34A" stroke="#000" stroke-width="5.5"/>
        <!-- Predator eyes stalking below -->
        \${this.renderPredatorEyes(320, 620)}
        \${this.renderPredatorEyes(980, 630)}
      \`;
      actorsHtml = this.renderCharacter(640, 240, pose, expr, 0.95);

    } else if (bgType.includes('campfire') || bgType.includes('flame') || bgType.includes('torch') || bgType.includes('hearth') || bgType.includes('flint')) {
      // Ancient campfire circle: golden dome of light in the darkness
      bgHtml = \`
        <rect width="1280" height="720" fill="#0B132B"/>
        <!-- Earth Ground -->
        <rect y="540" width="1280" height="180" fill="#78350F"/>
        <line x1="0" y1="540" x2="1280" y2="540" stroke="#000" stroke-width="4.5"/>
        <!-- Golden Dome of Light -->
        <ellipse cx="640" cy="540" rx="420" ry="240" fill="rgba(251, 191, 36, 0.14)"/>
        <!-- Campfire -->
        \${this.renderCampfire(640, 520)}
        <!-- Predator eyes pushed outside the dome -->
        \${this.renderPredatorEyes(120, 500)}
        \${this.renderPredatorEyes(1120, 510)}
      \`;
      actorsHtml = this.renderCharacter(450, 480, pose, expr, 1.05);

    } else if (bgType.includes('medieval') || bgType.includes('dorveille') || bgType.includes('candle') || bgType.includes('second_sleep')) {
      // Medieval timber bedroom with candle on table & diamond mullion window
      bgHtml = \`
        <rect width="1280" height="720" fill="#1E1B18"/>
        <!-- Timber Beams -->
        <rect x="0" y="0" width="1280" height="50" fill="#451A03" stroke="#000" stroke-width="4"/>
        <line x1="0" y1="560" x2="1280" y2="560" stroke="#000" stroke-width="4.5"/>
        <!-- Gothic Stone Window showing Crescent Moon -->
        <path d="M 880 360 L 880 200 Q 940 130 1000 200 L 1000 360 Z" fill="#0F172A" stroke="#78350F" stroke-width="5"/>
        <path d="M 940 180 Q 955 195 945 220 Q 930 205 940 180 Z" fill="#FDE047"/>
        <!-- Medieval Bed Box -->
        <rect x="220" y="440" width="500" height="120" rx="6" fill="#78350F" stroke="#000" stroke-width="4.5"/>
        <!-- Bedside Table with Tallow Candle -->
        <rect x="740" y="470" width="100" height="90" rx="4" fill="#92400E" stroke="#000" stroke-width="3"/>
        <rect x="785" y="445" width="14" height="25" fill="#FEF3C7" stroke="#000" stroke-width="2"/>
        <circle cx="792" cy="435" r="8" fill="#F59E0B"/>
        <circle cx="792" cy="435" r="4" fill="#FEF08A"/>
      \`;
      actorsHtml = this.renderCharacter(500, 420, pose, expr, 1.05);

    } else if (bgType.includes('lab') || bgType.includes('wehr') || bgType.includes('edison') || bgType.includes('eeg')) {
      // Modern / Historical Laboratory: scientific monitors, beakers, test equipment
      bgHtml = \`
        <rect width="1280" height="720" fill="#F8FAFC"/>
        <line x1="0" y1="560" x2="1280" y2="560" stroke="#CBD5E1" stroke-width="4"/>
        <!-- Lab Whiteboards / Monitors -->
        <rect x="180" y="140" width="380" height="220" rx="10" fill="#0F172A" stroke="#334155" stroke-width="5"/>
        <!-- EEG Waveforms on screen -->
        <path d="M 210 250 L 260 250 L 280 200 L 300 290 L 320 230 L 350 250 L 420 250 L 440 180 L 460 310 L 480 250 L 530 250" stroke="#22C55E" stroke-width="3.5" fill="none"/>
        <text x="220" y="180" font-family="'JetBrains Mono', monospace" font-size="18" fill="#38BDF8">EEG POLYSOMNOGRAM // NIH</text>
        <text x="220" y="320" font-family="'JetBrains Mono', monospace" font-size="16" fill="#A855F7">PHASE 1: DEEP SLEEP | INTERVAL: CALM</text>
        <!-- Lab Table with Beakers -->
        <rect x="820" y="440" width="320" height="120" rx="6" fill="#E2E8F0" stroke="#000" stroke-width="3.5"/>
        <path d="M 880 440 L 910 400 L 920 400 L 920 380 L 900 380 L 900 400 L 860 440 Z" fill="#A7F3D0" stroke="#000" stroke-width="2.5"/>
        <path d="M 970 440 L 990 390 L 1020 390 L 1040 440 Z" fill="#FDE68A" stroke="#000" stroke-width="2.5"/>
      \`;
      actorsHtml = this.renderCharacter(680, 440, pose, expr, 1.05);

    } else if (bgType.includes('diagram') || bgType.includes('brain') || bgType.includes('pineal') || bgType.includes('retina')) {
      // Anatomical / Explanatory Diagram background
      bgHtml = \`
        <rect width="1280" height="720" fill="#0F172A"/>
        <line x1="0" y1="560" x2="1280" y2="560" stroke="#1E293B" stroke-width="4"/>
        <!-- Glowing Brain Diagram -->
        <g transform="translate(320, 260)">
          <ellipse cx="0" cy="0" rx="140" ry="110" fill="#1E293B" stroke="#60A5FA" stroke-width="4"/>
          <!-- Brain Gyri Waves -->
          <path d="M -80 -40 Q -40 -80 0 -50 Q 40 -90 80 -40 Q 110 10 70 50 Q 0 80 -60 50 Z" fill="none" stroke="#93C5FD" stroke-width="4"/>
          <!-- Glowing Suprachiasmatic Nucleus / Pineal -->
          <circle cx="10" cy="15" r="18" fill="#F59E0B" stroke="#FEF08A" stroke-width="3"/>
          <!-- Signal Waves -->
          <circle cx="10" cy="15" r="35" fill="none" stroke="#F59E0B" stroke-width="2" stroke-dasharray="4 4"/>
          <circle cx="10" cy="15" r="55" fill="none" stroke="#F59E0B" stroke-width="1.5" stroke-dasharray="4 4"/>
          <text x="-90" y="150" font-family="'Arial', sans-serif" font-weight="bold" font-size="20" fill="#FBBF24">CIRCADIAN MASTER CLOCK</text>
        </g>
      \`;
      actorsHtml = this.renderCharacter(860, 440, pose, expr, 1.05);

    } else {
      // Classic Ancient Savanna Night / Dusk (The iconic Zenn visual world)
      bgHtml = \`
        <rect width="1280" height="720" fill="#1B2E58"/>
        <!-- Golden Crescent Moon -->
        <circle cx="340" cy="140" r="50" fill="#FEF08A" stroke="#000" stroke-width="4"/>
        <circle cx="365" cy="130" r="45" fill="#1B2E58"/>
        <!-- Earth Ground -->
        <rect y="560" width="1280" height="160" fill="#78350F"/>
        <line x1="0" y1="560" x2="1280" y2="560" stroke="#000" stroke-width="4.5"/>
        <!-- Hand-drawn grass tufts -->
        <path d="M 120 560 L 128 535 L 138 560 L 145 530 L 155 560" stroke="#000" stroke-width="3" fill="none"/>
        <path d="M 450 560 L 458 540 L 468 560 L 475 532 L 485 560" stroke="#000" stroke-width="3" fill="none"/>
        <path d="M 850 560 L 858 535 L 868 560 L 878 528 L 888 560" stroke="#000" stroke-width="3" fill="none"/>
        <path d="M 1120 560 L 1128 538 L 1138 560 L 1146 534 L 1154 560" stroke="#000" stroke-width="3" fill="none"/>
        <!-- Predator eyes in darkness -->
        \${this.renderPredatorEyes(240, 280)}
        \${this.renderPredatorEyes(890, 310)}
        \${this.renderPredatorEyes(1040, 440)}
      \`;
      actorsHtml = this.renderCharacter(640, 440, pose, expr, 1.05);
    }

    return \`<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720" width="1280" height="720">
  <!-- Dynamic Hand-Drawn Comic Scene (Beat #\${beatIndex}) -->
  \${bgHtml}
  <!-- Characters & Interactive Props -->
  \${actorsHtml}
</svg>
\`;
  }
}

module.exports = new HandDrawnComicEngine();
`;

fs.writeFileSync(targetPath, code, 'utf8');
console.log('✅ Full Hand-Drawn Comic Engine written to:', targetPath);
