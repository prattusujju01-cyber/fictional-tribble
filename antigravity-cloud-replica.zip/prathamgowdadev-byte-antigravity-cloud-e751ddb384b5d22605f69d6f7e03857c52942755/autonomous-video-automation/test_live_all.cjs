async function verify() {
  console.log("Testing live Vercel deployments...");
  const endpoints = [
    { name: "Telegram Webhook Gateway", url: "https://asura-system.vercel.app/api/telegram_webhook" },
    { name: "Car Detailing (Architectural Exports)", url: "https://asura-system.vercel.app/api/serve_project?slug=architectural-exports-in-sion-west" },
    { name: "Dental Clinic (All Smiles)", url: "https://asura-system.vercel.app/api/serve_project?slug=all-smiles-dental-clinic-bangalore" },
    { name: "Dining / BYOB (Gurgaon)", url: "https://asura-system.vercel.app/api/serve_project?slug=byob-restaurant-experience-in-gurgaon" },
    { name: "Aesthetic Clinic (Skin Secrets)", url: "https://asura-system.vercel.app/api/serve_project?slug=skin-secrets-in-edappally-cochin-kochi" },
    { name: "Real Estate (Hyderabad)", url: "https://asura-system.vercel.app/api/serve_project?slug=hyderabad-real-estate-hyderabad" }
  ];

  for (const ep of endpoints) {
    try {
      const glue = ep.url.includes("?") ? "&" : "?";
      const res = await fetch(ep.url + glue + "_t=" + Date.now());
      const text = await res.text();
      const hasGSAP = text.includes("ScrollTrigger");
      const hasLucide = text.includes("lucide");
      const hasNeoClinic = text.toLowerCase().includes("neo-clinic") || text.includes('data-target="15">0<');
      const hasReraForCar = ep.name.includes("Car") && text.includes("RERA");
      
      console.log("--- " + ep.name + " ---");
      console.log("Status:", res.status, "| Length:", text.length);
      if (ep.url.includes("serve_project")) {
        console.log("GSAP:", hasGSAP, "| Lucide:", hasLucide, "| Neo-Clinic:", hasNeoClinic, "| Erroneous RERA:", hasReraForCar);
      } else {
        console.log("Response sample:", text.slice(0, 100));
      }
    } catch (e) {
      console.error("Error on " + ep.name + ":", e.message);
    }
  }
}

verify();
