const { spawn } = require('child_process');
const fs = require('fs');
const path = require('path');

const port = process.argv[2] || 4988;
console.log(`Starting Cloudflare Open-Source Tunnel for localhost:${port}...`);

const logPath = path.join(__dirname, 'tunnel.log');
const outStream = fs.createWriteStream(logPath, { flags: 'w' });

const tunnel = spawn('cloudflared', ['tunnel', '--url', `http://localhost:${port}`]);

tunnel.stdout.pipe(outStream);
tunnel.stderr.pipe(outStream);

let foundUrl = false;

tunnel.stderr.on('data', data => {
  const text = data.toString();
  const match = text.match(/https:\/\/[a-zA-Z0-9-]+\.trycloudflare\.com/);
  if (match && !foundUrl) {
    foundUrl = true;
    const liveUrl = match[0];
    console.log('\n================================================================');
    console.log('🌐 LIVE CUSTOM DOMAIN TUNNEL ACTIVE (OPEN-SOURCE CLOUDFLARED)!');
    console.log(`🔗 Public HTTPS URL: ${liveUrl}`);
    console.log(`🎬 Dashboard URL: ${liveUrl}/dashboard/hermes-story-dashboard.html`);
    console.log(`📁 Video Download: ${liveUrl}/assets/exports/egypt_documentary_master.mp4`);
    console.log('================================================================\n');

    fs.writeFileSync(path.join(__dirname, 'live_domain.txt'), `${liveUrl}\n${liveUrl}/dashboard/hermes-story-dashboard.html\n`, 'utf8');
  }
});

tunnel.on('close', code => {
  console.log(`Tunnel process exited with code ${code}`);
});
