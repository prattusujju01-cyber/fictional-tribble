const fs = require('fs');
const path = require('path');

const ASURA_ROOT = path.join('C:', 'Users', 'WINDOWS', '.gemini', 'antigravity', 'scratch', 'asura-system');
const AGENTS_ROOT = path.join(ASURA_ROOT, '.agents');

function ensureDir(dir) {
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
}

const SKILLS = {
  'frontend-design': {
    name: 'frontend-design',
    description: 'Anthropic official frontend design intelligence. Eradicates generic "AI slop", enforces deliberate aesthetic intent, custom typography scales, and distinctive token hierarchies.',
    content: `---
name: frontend-design
description: Anthropic official frontend design intelligence. Eradicates generic "AI slop", enforces deliberate aesthetic intent, custom typography scales, and distinctive token hierarchies.
---

# FRONTEND DESIGN INTELLIGENCE // ANTI-SLOP STANDARD

## 1. Core Principle: Deliberate Aesthetic Intent
Never generate generic "AI template" websites. Every website must have an unmistakable, intentional personality tailored to its niche:
- **Zero "Default Tailwind" Slop:** No generic purple/indigo gradients on pure white cards.
- **Zero Inter Font Default:** Always pair distinctive typography (e.g. Syne, Plus Jakarta Sans, Fraunces, Cinzel, JetBrains Mono).
- **Surface Elevation Hierarchy:** Dark mode websites should not be flat black; use layered obsidian levels (#050709, #08090C, #12141A, #1A1D24) with 1px hairline translucent borders (rgba(255,255,255,0.08)).

## 2. Design Token System
- **Spacing:** Strict mathematical scale (4px, 8px, 16px, 24px, 32px, 48px, 64px, 96px).
- **Contrast:** Strict WCAG AAA compliance. All primary text must have at least 7:1 contrast ratio against the background.
- **Color Discipline (60-30-10 Rule):**
  - 60% Dominant Base (e.g. Pitch Obsidian Void)
  - 30% Structural Secondary (e.g. Deep Charcoal / Glass Surface)
  - 10% High-Voltage Accent (e.g. Electric Emerald #00FF66, Cyan Neon #00F0FF, Radiant Champagne #D4AF37).
`
  },

  'ui-ux-pro-max': {
    name: 'ui-ux-pro-max',
    description: 'Design intelligence with 50+ UI paradigms (Bento Grids, Glassmorphism, Brutalism, Neumorphism), curated typography pairings, and industry color palettes.',
    content: `---
name: ui-ux-pro-max
description: Design intelligence with 50+ UI paradigms (Bento Grids, Glassmorphism, Brutalism, Neumorphism), curated typography pairings, and industry color palettes.
---

# UI / UX PRO MAX // DESIGN BRAIN TRUST

## 1. Top 5 High-Converting Visual Archetypes
1. **Interactive Bento Grid:**
   - Asymmetric multi-card layouts (2x2, 3x2, feature-lead).
   - Dynamic micro-visuals in each bento cell (live charts, mini toggles, animated metrics).
2. **Ultra-Luxury Dark Obsidian:**
   - Deep rich blacks (#06080A), satin glass surfaces, subtle radial ambient glow, and metallic accents.
3. **Cybernetic FinTech / Web3:**
   - Monospace data readouts, real-time ticker feeds, holographic glow, cryptographic glyphs.
4. **Minimalist Architectural Editorial:**
   - High-contrast serif headlines (Playfair Display, Cinzel), generous negative space, refined photography.
5. **Modern Neo-SaaS:**
   - Clear value propositions, interactive live preview sandboxes, friction-free CTA buttons, social proof carousels.

## 2. Curated Typography Pairings
- **FinTech / Web3:** Display: Syne (800) + Body: JetBrains Mono / Plus Jakarta Sans.
- **Luxury / Real Estate:** Display: Cinzel (700) / Playfair Display + Body: Inter Tight.
- **Medical / Wellness:** Display: Plus Jakarta Sans (700) + Body: Inter.
`
  },

  'design-taste-frontend': {
    name: 'design-taste-frontend',
    description: 'Aesthetic checklist, micro-interaction state matrices, and tactile feedback guidelines ensuring professional commercial polish.',
    content: `---
name: design-taste-frontend
description: Aesthetic checklist, micro-interaction state matrices, and tactile feedback guidelines ensuring professional commercial polish.
---

# DESIGN TASTE & TACTILE INTERACTION MATRIX

## 1. The Interactive State Requirement
Every clickable or interactive element MUST feature distinct, buttery-smooth feedback states:
- **Default:** Crisp border, refined typography, subtle shadow.
- **Hover:** GPU-accelerated lift (transform: translateY(-2px)), border illumination, and glow expansion.
- **Active / Pressed:** Quick snap down (transform: scale(0.97)).
- **Focus-Visible:** Distinct high-visibility focus ring (outline: 2px solid #00F0FF; outline-offset: 2px).

## 2. Pre-Flight Quality Checklist
- [ ] Are headings punchy, benefit-driven, and devoid of cliché marketing fluff?
- [ ] Is there zero horizontal overflow on mobile screens (360px - 414px)?
- [ ] Are primary CTA buttons immediately obvious within 3 seconds of page load?
- [ ] Does every card have smooth border transitions on hover?
`
  },

  'shadcn-ui-mcp': {
    name: 'shadcn-ui-mcp',
    description: 'Accessible UI component primitives (Dialog, Dropdown, Sheet, Accordion, Tooltip, Navigation Menu) styled with Tailwind CSS.',
    content: `---
name: shadcn-ui-mcp
description: Accessible UI component primitives (Dialog, Dropdown, Sheet, Accordion, Tooltip, Navigation Menu) styled with Tailwind CSS.
---

# SHADCN / UI COMPONENT PROTOCOL

## 1. Core Component Primitives
When synthesizing modern web applications, integrate Shadcn-style components:
- **Modals / Dialogs:** Accessible backdrop with smooth opacity transition.
- **Tabs:** Animated pill switchers toggling active view panels.
- **Badges:** Small font-mono border tags for status indicators.
- **Cards:** Glassmorphic containers with header, description, content, and action footer.
`
  },

  'magic-mcp-21st': {
    name: 'magic-mcp-21st',
    description: '21st.dev Magic component engine for generating animated hero sections, dynamic bento grids, SVGL brand assets, and interactive UI blocks.',
    content: `---
name: magic-mcp-21st
description: 21st.dev Magic component engine for generating animated hero sections, dynamic bento grids, SVGL brand assets, and interactive UI blocks.
---

# 21ST.DEV MAGIC UI ARCHITECTURE

## 1. Magic Component Catalog
- **Animated Beam / Grid Background:** Kinetic glowing grid lines and moving particle beams behind heroes.
- **Interactive Bento Showcase:** Multi-layered cells with hover tilt and dynamic content.
- **Marquee Logomark Ticker:** Seamless, infinite horizontal loop of institutional client logos.
- **Shimmer Button:** Glowing reflective shimmer sweep across primary conversion buttons.
`
  },

  'vercel-react-best-practices': {
    name: 'vercel-react-best-practices',
    description: 'Vercel Labs performance optimization standards: zero-waterfall loading, bundle size minimization, and instant client rendering.',
    content: `---
name: vercel-react-best-practices
description: Vercel Labs performance optimization standards: zero-waterfall loading, bundle size minimization, and instant client rendering.
---

# VERCEL REACT BEST PRACTICES // PERFORMANCE STANDARDS

## 1. Eliminate Waterfalls
- Never chain dependent sequential API requests. Trigger all data fetching in parallel (Promise.all).
- Pre-render static markup and hydrate interactivity progressively.

## 2. Bundle Size Optimization
- Use native modern browser APIs where possible (Web Audio, Canvas 2D, IntersectionObserver) before importing heavy libraries.
- For heavy libraries (Three.js, Chart.js), load asynchronously via CDN or dynamic imports.

## 3. Core Web Vitals
- LCP (Largest Contentful Paint) < 1.2s: Optimize hero typography and critical CSS.
- CLS (Cumulative Layout Shift) = 0: Explicit width/height on all images, iframes, and canvas elements.
`
  },

  'vercel-react-native-skills': {
    name: 'vercel-react-native-skills',
    description: 'Universal responsive layouts, Expo Router file-based architecture, touch ergonomics, and mobile-first fluid grids.',
    content: `---
name: vercel-react-native-skills
description: Universal responsive layouts, Expo Router file-based architecture, touch ergonomics, and mobile-first fluid grids.
---

# UNIVERSAL RESPONSIVE ARCHITECTURE (REACT NATIVE & EXPO STANDARDS)

## 1. Mobile Touch Ergonomics
- All tap targets must be at least 44px x 44px to guarantee error-free mobile navigation.
- Use mobile drawer menus (bottom sheets / sliding navbars) for screens under 768px.

## 2. Fluid Layout System
- Mobile-first CSS media queries: w-full sm:w-1/2 lg:w-1/3.
- Fluid typography that scales seamlessly from phones to 4K displays.
`
  },

  'gsap-master': {
    name: 'gsap-master',
    description: 'GreenSock Animation Platform: ScrollTrigger timelines, scrubbed parallax, staggered text reveals, and continuous motion loops.',
    content: `---
name: gsap-master
description: GreenSock Animation Platform: ScrollTrigger timelines, scrubbed parallax, staggered text reveals, and continuous motion loops.
---

# GSAP ANIMATION ORCHESTRATION

## 1. Essential GSAP Patterns
Staggered fade & slide in:
\`\`\`javascript
gsap.from(".bento-card", {
  duration: 0.8,
  y: 40,
  opacity: 0,
  stagger: 0.15,
  ease: "power3.out"
});
\`\`\`
`
  },

  'motion-framer': {
    name: 'motion-framer',
    description: 'Framer Motion physics: natural spring dynamics, gesture interactions, layout animations, and modal enter/exit transitions.',
    content: `---
name: motion-framer
description: Framer Motion physics: natural spring dynamics, gesture interactions, layout animations, and modal enter/exit transitions.
---

# FRAMER MOTION PHYSICS

## 1. Spring Physics Standard
Use realistic spring values rather than linear easing:
\`\`\`javascript
const springTransition = {
  type: "spring",
  stiffness: 350,
  damping: 25,
  mass: 0.8
};
\`\`\`
`
  },

  'convex-create-component': {
    name: 'convex-create-component',
    description: 'Convex reactive real-time backend architecture: modular schemas, live queries, serverless mutations, and instant lead capture.',
    content: `---
name: convex-create-component
description: Convex reactive real-time backend architecture: modular schemas, live queries, serverless mutations, and instant lead capture.
---

# CONVEX REACTIVE BACKEND & DATA ARCHITECTURE

## 1. Schema Definition Pattern (convex/schema.ts)
\`\`\`typescript
import { defineSchema, defineTable } from "convex/server";
import { v } from "convex/values";

export default defineSchema({
  leads: defineTable({
    name: v.string(),
    email: v.string(),
    requirements: v.string(),
    status: v.string(),
    createdAt: v.number()
  })
});
\`\`\`
`
  }
};

function installSkills() {
  const asuraSkillsDir = path.join(ASURA_ROOT, 'skills');
  const agentsSkillsDir = path.join(AGENTS_ROOT, 'skills');

  ensureDir(asuraSkillsDir);
  ensureDir(agentsSkillsDir);

  for (const key of Object.keys(SKILLS)) {
    const skill = SKILLS[key];
    const dir1 = path.join(asuraSkillsDir, key);
    const dir2 = path.join(agentsSkillsDir, key);
    ensureDir(dir1);
    ensureDir(dir2);

    fs.writeFileSync(path.join(dir1, 'SKILL.md'), skill.content, 'utf8');
    fs.writeFileSync(path.join(dir2, 'SKILL.md'), skill.content, 'utf8');
    console.log('[SKILL OK] Installed: ' + key);
  }
}

function installMcpConfig() {
  const mcpConfig = {
    mcpServers: {
      "shadcn-ui": {
        command: "npx",
        args: ["-y", "shadcn@latest", "mcp"],
        description: "Official Shadcn UI component registry search, preview, and extraction server."
      },
      "magic-mcp-21st": {
        command: "npx",
        args: ["-y", "@21st-dev/magic-mcp"],
        env: {
          API_KEY: process.env.MAGIC_MCP_API_KEY || "public_preview"
        },
        description: "21st.dev Magic MCP: AI component generator, animated Tailwind blocks, and SVGL brand assets."
      }
    },
    modelConfigurations: {
      "gemini-3.6-flash": {
        provider: "google",
        functionCalling: true,
        toolMode: "auto",
        temperature: 0.2
      },
      "openai-form": {
        provider: "openai",
        responseFormat: { type: "json_object" },
        temperature: 0.2
      }
    }
  };

  fs.writeFileSync(path.join(ASURA_ROOT, 'mcp_config.json'), JSON.stringify(mcpConfig, null, 2), 'utf8');
  ensureDir(AGENTS_ROOT);
  fs.writeFileSync(path.join(AGENTS_ROOT, 'mcp_config.json'), JSON.stringify(mcpConfig, null, 2), 'utf8');
  console.log('[MCP OK] Installed mcp_config.json in asura-system and .agents');
}

console.log('Installing Asura 10-Skill & MCP Architecture...');
installSkills();
installMcpConfig();
console.log('All skills and MCP configurations installed successfully.');
