const WebSocket = require('ws');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const TRUSTED_TOKEN = '6A5AA1D4EAFF4E9FB37E23D68491D6F4';
const SEC_VERSION = '1-130.0.2849.68';

function generateSecMsGec() {
  let ts = Date.now() / 1000;
  ts += 11644473600;
  ts -= ts % 300;
  ts *= 1e7;
  const str = ts.toFixed(0) + TRUSTED_TOKEN;
  return crypto.createHash('sha256').update(str, 'ascii').digest('hex').toUpperCase();
}

function generateMuid() {
  return crypto.randomBytes(16).toString('hex').toUpperCase();
}

async function synthesizeVoice(text, voiceShort = 'en-US-ChristopherNeural', outputPath = './assets/audio/test_christopher.mp3') {
  const connectionId = crypto.randomBytes(16).toString('hex');
  const secMsGec = generateSecMsGec();
  const muid = generateMuid();

  const url = `wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1?TrustedClientToken=${TRUSTED_TOKEN}&ConnectionId=${connectionId}&Sec-MS-GEC=${secMsGec}&Sec-MS-GEC-Version=${SEC_VERSION}`;

  const dir = path.dirname(outputPath);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });

  return new Promise((resolve, reject) => {
    const ws = new WebSocket(url, {
      headers: {
        'Pragma': 'no-cache',
        'Cache-Control': 'no-cache',
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/130.0.0.0 Safari/537.36 Edg/130.0.0.0',
        'Origin': 'chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold',
        'Cookie': `muid=${muid};`
      }
    });

    const audioChunks = [];

    ws.on('open', () => {
      // 1. Send speech.config
      const config = {
        context: {
          synthesis: {
            audio: {
              metadataoptions: { sentenceBoundaryEnabled: 'false', wordBoundaryEnabled: 'false' },
              outputFormat: 'audio-24khz-48kbitrate-mono-mp3'
            }
          }
        }
      };
      ws.send(`X-Timestamp:${new Date().toISOString()}\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n${JSON.stringify(config)}`);

      // 2. Send SSML request
      // Format: Microsoft Server Speech Text to Speech Voice (en-US, ChristopherNeural)
      const parts = voiceShort.split('-');
      const locale = parts[0] + '-' + parts[1];
      const name = parts[2];
      const fullName = `Microsoft Server Speech Text to Speech Voice (${locale}, ${name})`;

      const ssml = `<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'><voice name='${fullName}'><prosody rate='+0%' pitch='+0Hz'>${text}</prosody></voice></speak>`;
      const requestId = crypto.randomBytes(16).toString('hex');
      const msg = `X-RequestId:${requestId}\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:${new Date().toISOString()}Z\r\nPath:ssml\r\n\r\n${ssml}`;
      ws.send(msg);
    });

    ws.on('message', (data, isBinary) => {
      if (!isBinary) {
        const textData = data.toString('utf8');
        if (textData.includes('Path:turn.end')) {
          ws.close();
          const finalBuf = Buffer.concat(audioChunks);
          fs.writeFileSync(outputPath, finalBuf);
          resolve({
            outputPath,
            bytes: finalBuf.length,
            voice: voiceShort
          });
        }
      } else {
        const headerLen = data.readUInt16BE(0);
        const audioData = data.subarray(headerLen + 2);
        audioChunks.push(audioData);
      }
    });

    ws.on('error', (err) => {
      reject(err);
    });

    setTimeout(() => {
      ws.close();
      if (audioChunks.length > 0) {
        const finalBuf = Buffer.concat(audioChunks);
        fs.writeFileSync(outputPath, finalBuf);
        resolve({ outputPath, bytes: finalBuf.length, voice: voiceShort });
      } else {
        reject(new Error('Voice synthesis timeout'));
      }
    }, 15000);
  });
}

synthesizeVoice("Tonight, when you flip a light switch in your bedroom, you literally don't think twice about it. But for 99.9% of human history, that switch didn't exist.", "en-US-ChristopherNeural")
  .then(res => {
    console.log("🎉 SUCCESS! Human Neural Voice Synthesized!");
    console.log("File:", res.outputPath, "Size:", Math.round(res.bytes / 1024), "KB", "Voice:", res.voice);
  })
  .catch(err => console.error("Error:", err));
