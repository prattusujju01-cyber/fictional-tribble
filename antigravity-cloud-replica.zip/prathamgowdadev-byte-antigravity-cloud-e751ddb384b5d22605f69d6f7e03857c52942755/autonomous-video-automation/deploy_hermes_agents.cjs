const fs = require('fs');
const path = require('path');

const baseDir = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent';

// 1. hermes-anthropologist.js
const anthropologistCode = `/**
 * Hermes Anthropologist Agent
 * Autonomous Topic Radar & Curiosity Hook Engineer for Anthropological/Evolutionary Niche
 */
const fs = require('fs');
const path = require('path');

class HermesAnthropologist {
  constructor() {
    this.name = 'Hermes-Anthropologist';
    this.version = '2.1.0';
  }

  getCuriosityTopics() {
    return [
      {
        id: 'ancient-humans-night',
        title: 'What Did Ancient Humans Do at Night?',
        viewsBenchmark: '7.9M',
        scientificCitations: [
          'A. Roger Ekirch - At Day\'s Close: Night in Times Past (Segmented Sleep)',
          'Dr. Thomas Wehr - NIH Darkness Study on Human Circadian Rhythms',
          'Polly Wiessner (2014) - PNAS Embers of Society: Firelight Storytelling',
          'Berna et al. (2012) - Wonderwerk Cave 1-million-year-old Acheulean fire control'
        ],
        viralHook: 'For 99.9% of human history, night was not 8 hours of unconscious sleep. It was an active, terrifying, magical second reality.',
        estimatedDurationMinutes: 13.5,
        wordTarget: 1980
      },
      {
        id: 'why-humans-lost-fur',
        title: 'The Real Reason Humans Lost Their Fur',
        viewsBenchmark: '5.4M',
        scientificCitations: [
          'Nina Jablonski - Skin: A Natural History',
          'David Carrier - Cursorily Running & Thermoregulation Hypothesis'
        ],
        viralHook: 'Every other primate stayed hairy. We became naked apes. But it was not for warmth—it was to become the ultimate endurance hunter.',
        estimatedDurationMinutes: 12.0,
        wordTarget: 1850
      },
      {
        id: 'loneliness-in-empty-forests',
        title: 'Why Do We Get Terrified in Silent Forests?',
        viewsBenchmark: '6.2M',
        scientificCitations: [
          'Gordon Orians - Savanna Hypothesis & Evolutionary Aesthetics',
          'David Quammen - Monster of God: Man-Eating Predators in Evolutionary Memory'
        ],
        viralHook: 'When the woods go dead quiet, your hair stands on end. That is not superstition—that is 300,000 years of predator detection firing in your spine.',
        estimatedDurationMinutes: 11.5,
        wordTarget: 1750
      }
    ];
  }

  async researchTopic(topicName) {
    console.log(\`[\${this.name}] 🧠 Analyzing anthropological curiosity hook for: "\${topicName}"\`);
    const topics = this.getCuriosityTopics();
    const matched = topics.find(t => t.title.toLowerCase().includes(topicName.toLowerCase()) || topicName.toLowerCase().includes(t.title.toLowerCase())) || topics[0];
    
    const dossier = {
      selectedTopic: matched.title,
      benchmarkViews: matched.viewsBenchmark,
      viralHook: matched.viralHook,
      scientificCitations: matched.scientificCitations,
      narrativeArc: [
        'Act I: The Modern Illusion vs Ancient Reality (0:00 - 2:30)',
        'Act II: Fire, Wolves & The 100,000-Year Hearth (2:30 - 5:30)',
        'Act III: The Lost Ancient Sleep: The Biphasic Mystery (5:30 - 9:00)',
        'Act IV: Nocturnal Dangers, Spirits & The Dark Mind (9:00 - 12:00)',
        'Act V: The Biological Echo: Why Modern Nights Hurt Us (12:00 - 14:00)'
      ],
      estimatedWordCount: matched.wordTarget,
      recommendedVisualEngine: 'FLUX.1-schnell Minimalist 2D Line-Art'
    };

    console.log(\`[\${this.name}] 📜 Topic Dossier Generated: \${matched.title} (\${matched.scientificCitations.length} peer-reviewed citations)\`);
    return dossier;
  }
}

module.exports = new HermesAnthropologist();
`;

// 2. hermes-screenwriter.js
const screenwriterCode = `/**
 * Hermes Screenwriter Agent
 * Autonomous 10-15 Minute Longform Screenplay Engine (Qwen 2.5 Anthropological Storytelling)
 */
const fs = require('fs');
const path = require('path');
const openSourceAI = require('../utils/open-source-ai.js');

class HermesScreenwriter {
  constructor() {
    this.name = 'Hermes-Screenwriter';
    this.version = '2.1.0';
  }

  async writeFullScript(topicDossier) {
    console.log(\`[\${this.name}] ✍️ Crafting 10-15 Minute Master Screenplay using Qwen 2.5 Story Architecture...\`);
    const title = topicDossier.selectedTopic || 'What Did Ancient Humans Do at Night?';
    
    // Generate the master 5-act screenplay with deep anthropological narrative
    const screenplay = openSourceAI.buildMasterZennScreenplay(title);
    
    const outputPath = path.join(__dirname, '../assets/screenplay.json');
    fs.writeFileSync(outputPath, JSON.stringify(screenplay, null, 2), 'utf8');
    
    const totalWords = screenplay.acts.reduce((sum, act) => sum + act.wordCount, 0);
    const totalScenes = screenplay.acts.reduce((sum, act) => sum + act.scenes.length, 0);
    
    console.log(\`[\${this.name}] ✅ Master Screenplay complete: \${totalWords} words across \${totalScenes} master scenes in \${screenplay.acts.length} acts.\`);
    console.log(\`[\${this.name}] 📁 Saved to: \${outputPath}\`);
    
    return screenplay;
  }
}

module.exports = new HermesScreenwriter();
`;

// 3. hermes-visual-director.js
const visualDirectorCode = `/**
 * Hermes Visual Director Agent
 * Minimalist 2D Line-Art Scene Visual Synthesizer (FLUX.1-schnell via Open-Source API)
 */
const fs = require('fs');
const path = require('path');
const openSourceAI = require('../utils/open-source-ai.js');

class HermesVisualDirector {
  constructor() {
    this.name = 'Hermes-VisualDirector';
    this.version = '2.1.0';
  }

  async renderScene(scene, index, total) {
    const filename = \`\${scene.sceneId}.jpg\`;
    const targetPath = path.join(__dirname, '../assets/scenes', filename);
    
    console.log(\`[\${this.name}] 🎨 Rendering Scene [\${index + 1}/\${total}]: \${scene.sceneId} via FLUX.1-schnell...\`);
    console.log(\`[\${this.name}] 🖌️ Prompt: \${scene.fluxPrompt.substring(0, 85)}...\`);

    try {
      const result = await openSourceAI.generateVisual(scene.fluxPrompt, targetPath);
      console.log(\`[\${this.name}] ✅ Rendered \${filename} (\${result.sizeKB} KB)\`);
      return {
        sceneId: scene.sceneId,
        filePath: targetPath,
        relativePath: \`assets/scenes/\${filename}\`,
        prompt: scene.fluxPrompt,
        status: 'rendered',
        sizeKB: result.sizeKB
      };
    } catch (err) {
      console.error(\`[\${this.name}] ⚠️ Visual render error for \${scene.sceneId}: \${err.message}\`);
      return {
        sceneId: scene.sceneId,
        filePath: targetPath,
        relativePath: \`assets/scenes/\${filename}\`,
        prompt: scene.fluxPrompt,
        status: 'error',
        error: err.message
      };
    }
  }

  async renderAllScenes(screenplay, maxScenes = 14) {
    const scenesDir = path.join(__dirname, '../assets/scenes');
    if (!fs.existsSync(scenesDir)) fs.mkdirSync(scenesDir, { recursive: true });

    const allScenes = screenplay.acts.flatMap(act => act.scenes).slice(0, maxScenes);
    console.log(\`[\${this.name}] 🎬 Commencing batch FLUX.1 rendering for \${allScenes.length} scenes...\`);

    const visualManifest = [];
    for (let i = 0; i < allScenes.length; i++) {
      const res = await this.renderScene(allScenes[i], i, allScenes.length);
      visualManifest.push(res);
      // Brief pause between requests for polite rate limiting
      if (i < allScenes.length - 1) {
        await new Promise(r => setTimeout(r, 1200));
      }
    }

    const manifestPath = path.join(__dirname, '../assets/visual-manifest.json');
    fs.writeFileSync(manifestPath, JSON.stringify(visualManifest, null, 2), 'utf8');
    console.log(\`[\${this.name}] 🖼️ All \${visualManifest.length} scenes processed and saved to visual manifest.\`);
    return visualManifest;
  }
}

module.exports = new HermesVisualDirector();
`;

// 4. hermes-voice-studio.js
const voiceStudioCode = `/**
 * Hermes Voice Studio Agent
 * Intellectual Neural Documentary Voiceover & Audio Engine
 */
const fs = require('fs');
const path = require('path');
const openSourceAI = require('../utils/open-source-ai.js');

class HermesVoiceStudio {
  constructor() {
    this.name = 'Hermes-VoiceStudio';
    this.version = '2.1.0';
  }

  async synthesizeNarration(screenplay) {
    const audioDir = path.join(__dirname, '../assets/audio');
    if (!fs.existsSync(audioDir)) fs.mkdirSync(audioDir, { recursive: true });

    const masterAudioPath = path.join(audioDir, 'narration.mp3');
    console.log(\`[\${this.name}] 🎙️ Synthesizing documentary narration for \${screenplay.meta.title}...\`);

    // Compile narrative chunks
    const allScenes = screenplay.acts.flatMap(act => act.scenes);
    const fullNarration = allScenes.map(s => s.narration).join(' ');

    console.log(\`[\${this.name}] 📜 Total script text: \${fullNarration.length} characters (\${fullNarration.split(/\\s+/).length} words).\`);
    
    // Synthesize narration audio via Open-Source Neural TTS
    const result = await openSourceAI.generateVoiceover(fullNarration, masterAudioPath);
    console.log(\`[\${this.name}] ✅ Master voiceover audio rendered: \${result.sizeKB} KB at \${masterAudioPath}\`);

    // Also build timed subtitle cues for each scene
    let currentSeconds = 0;
    const subtitleManifest = allScenes.map((s, idx) => {
      const words = s.narration.split(/\\s+/).length;
      // ~140 words per minute => ~2.33 words per second
      const durationSeconds = Math.max(8, Math.round(words / 2.33));
      const start = currentSeconds;
      const end = currentSeconds + durationSeconds;
      currentSeconds = end;
      return {
        sceneId: s.sceneId,
        sceneIndex: idx + 1,
        startTimeSec: start,
        endTimeSec: end,
        durationSec: durationSeconds,
        text: s.narration
      };
    });

    const subPath = path.join(__dirname, '../assets/subtitles.json');
    fs.writeFileSync(subPath, JSON.stringify(subtitleManifest, null, 2), 'utf8');

    return {
      audioPath: masterAudioPath,
      relativePath: 'assets/audio/narration.mp3',
      totalEstimatedSeconds: currentSeconds,
      subtitles: subtitleManifest,
      sizeKB: result.sizeKB
    };
  }
}

module.exports = new HermesVoiceStudio();
`;

// 5. hermes-timeline-editor.js
const timelineEditorCode = `/**
 * Hermes Timeline Editor Agent
 * Ken Burns Motion Graphics, Sound Design & Video Timeline Manifest
 */
const fs = require('fs');
const path = require('path');

class HermesTimelineEditor {
  constructor() {
    this.name = 'Hermes-TimelineEditor';
    this.version = '2.1.0';
  }

  buildTimelineManifest(screenplay, visualManifest, voiceAssets) {
    console.log(\`[\${this.name}] 🎞️ Compiling 16:9 Video Timeline with Ken Burns Motion Presets & Ambient Audio...\`);

    const allScenes = screenplay.acts.flatMap(act => act.scenes);
    const motionPresets = [
      { name: 'slow-zoom-in', startScale: 1.0, endScale: 1.15, startX: 0, startY: 0, endX: 0, endY: 0 },
      { name: 'pan-left-to-right', startScale: 1.12, endScale: 1.12, startX: -4, startY: 0, endX: 4, endY: 0 },
      { name: 'pan-bottom-to-top', startScale: 1.12, endScale: 1.12, startX: 0, startY: 4, endX: 0, endY: -3 },
      { name: 'slow-zoom-out', startScale: 1.18, endScale: 1.02, startX: 2, startY: 2, endX: 0, endY: 0 }
    ];

    const timelineTracks = allScenes.map((scene, idx) => {
      const visual = visualManifest.find(v => v.sceneId === scene.sceneId) || {};
      const sub = voiceAssets.subtitles.find(s => s.sceneId === scene.sceneId) || {};
      const motion = motionPresets[idx % motionPresets.length];

      return {
        sceneId: scene.sceneId,
        index: idx + 1,
        timing: scene.timing,
        startSec: sub.startTimeSec || 0,
        endSec: sub.endTimeSec || 15,
        durationSec: sub.durationSec || 15,
        imagePath: visual.relativePath || \`assets/scenes/\${scene.sceneId}.jpg\`,
        motion: motion,
        narration: scene.narration,
        soundFx: idx % 2 === 0 ? 'crackling-campfire-glow.wav' : 'night-wind-cave-ambience.wav',
        overlayText: \`Act \${Math.floor(idx / 3) + 1}\`
      };
    });

    const fullTimeline = {
      meta: {
        title: screenplay.meta.title,
        channel: screenplay.meta.channel,
        totalScenes: timelineTracks.length,
        totalDurationSeconds: voiceAssets.totalEstimatedSeconds,
        aspectRatio: '16:9',
        resolution: '1920x1080',
        fps: 30,
        audioTrack: voiceAssets.relativePath,
        ambientTrack: 'assets/audio/prehistoric_cave_ambience.mp3',
        renderedAt: new Date().toISOString()
      },
      scenes: timelineTracks
    };

    const timelinePath = path.join(__dirname, '../assets/timeline.json');
    fs.writeFileSync(timelinePath, JSON.stringify(fullTimeline, null, 2), 'utf8');
    console.log(\`[\${this.name}] 🎬 Video Timeline manifest successfully exported to \${timelinePath}\`);

    return fullTimeline;
  }
}

module.exports = new HermesTimelineEditor();
`;

// 6. hermes-orchestrator.js
const orchestratorCode = `/**
 * Hermes Master Orchestrator
 * Fully Autonomous Multi-Agent Pipeline for YouTube Automation (Zenn Niche & Open-Source AI)
 */
const path = require('path');
const anthropologist = require('./hermes-anthropologist.js');
const screenwriter = require('./hermes-screenwriter.js');
const visualDirector = require('./hermes-visual-director.js');
const voiceStudio = require('./hermes-voice-studio.js');
const timelineEditor = require('./hermes-timeline-editor.js');

class HermesOrchestrator {
  constructor() {
    this.name = 'Hermes-MasterOrchestrator';
  }

  async runPipeline(topicName = 'What Did Ancient Humans Do at Night?', options = {}) {
    console.log('================================================================');
    console.log('🚀 HERMES MULTI-AGENT PIPELINE ACTIVATED: ZENN ANTHROPOLOGY NICHE');
    console.log('⚙️ Zero Gemini Policy: Powered 100% by Open-Source AI (Qwen, FLUX.1, Neural Audio)');
    console.log('================================================================\\n');

    const startTime = Date.now();

    // STEP 1: Anthropologist Topic Radar
    console.log('--- PHASE 1: NICHE STRATEGY & TOPIC RADAR ---');
    const dossier = await anthropologist.researchTopic(topicName);

    // STEP 2: Screenwriting 10-15 min Master Script
    console.log('\\n--- PHASE 2: 10-15 MIN SCREENPLAY GENERATION (QWEN 2.5) ---');
    const screenplay = await screenwriter.writeFullScript(dossier);

    // STEP 3: Voiceover Synthesis
    console.log('\\n--- PHASE 3: NEURAL VOICEOVER SYNTHESIS & TIMESTAMPS ---');
    const voiceAssets = await voiceStudio.synthesizeNarration(screenplay);

    // STEP 4: Visual Director (FLUX.1 Scene Rendering)
    console.log('\\n--- PHASE 4: 2D LINE-ART SCENE SYNTHESIS (FLUX.1-SCHNELL) ---');
    const maxScenes = options.maxScenes || 14;
    const visualManifest = await visualDirector.renderAllScenes(screenplay, maxScenes);

    // STEP 5: Timeline & Video Composition
    console.log('\\n--- PHASE 5: TIMELINE COMPOSITION & MOTION GRAPHICS ---');
    const timeline = timelineEditor.buildTimelineManifest(screenplay, visualManifest, voiceAssets);

    const elapsed = Math.round((Date.now() - startTime) / 1000);
    console.log('\\n================================================================');
    console.log(\`🎉 HERMES PIPELINE COMPLETE IN \${elapsed} SECONDS\`);
    console.log(\`🎬 Video: "\${screenplay.meta.title}"\`);
    console.log(\`📜 Script: \${screenplay.meta.totalWordCount} words across \${timeline.scenes.length} scenes\`);
    console.log(\`🎨 Visuals: \${visualManifest.filter(v => v.status === 'rendered').length}/\${visualManifest.length} scenes generated via FLUX.1\`);
    console.log(\`🎙️ Narration: \${voiceAssets.sizeKB} KB MP3 generated\`);
    console.log('================================================================\\n');

    return {
      success: true,
      dossier,
      screenplay,
      visualManifest,
      voiceAssets,
      timeline,
      durationSeconds: elapsed
    };
  }
}

if (require.main === module) {
  const orchestrator = new HermesOrchestrator();
  orchestrator.runPipeline().catch(err => {
    console.error('Fatal pipeline error:', err);
    process.exit(1);
  });
}

module.exports = new HermesOrchestrator();
`;

// Write all files
const agentsDir = path.join(baseDir, 'agents');
fs.writeFileSync(path.join(agentsDir, 'hermes-anthropologist.js'), anthropologistCode, 'utf8');
fs.writeFileSync(path.join(agentsDir, 'hermes-screenwriter.js'), screenwriterCode, 'utf8');
fs.writeFileSync(path.join(agentsDir, 'hermes-visual-director.js'), visualDirectorCode, 'utf8');
fs.writeFileSync(path.join(agentsDir, 'hermes-voice-studio.js'), voiceStudioCode, 'utf8');
fs.writeFileSync(path.join(agentsDir, 'hermes-timeline-editor.js'), timelineEditorCode, 'utf8');
fs.writeFileSync(path.join(agentsDir, 'hermes-orchestrator.js'), orchestratorCode, 'utf8');

console.log('✅ All 6 Hermes Agent modules written successfully to ' + agentsDir);
