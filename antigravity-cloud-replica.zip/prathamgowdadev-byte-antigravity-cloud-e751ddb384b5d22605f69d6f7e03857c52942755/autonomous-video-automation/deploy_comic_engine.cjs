const fs = require('fs');
const path = require('path');

const targetPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\utils\\hand-drawn-comic-engine.js';

const code = `/**
 * ══════════════════════════════════════════════════════════════════════════════
 * HAND-DRAWN 2D COMIC VECTOR ENGINE // ANTI-AI-SLOP STANDARD
 * ══════════════════════════════════════════════════════════════════════════════
 * Replaces rigid geometric shapes with organic hand-drawn comic linework:
 * - Natural sketchy black ink strokes (varying widths, hand-drawn wiggles, rounded joints)
 * - Expressive stickman character acting (fear, deadpan, shock, awe, laughter, exhaustion)
 * - 120+ dedicated static scene compositions strictly mapped to the 10-minute script
 * - Zero programmatic zoom/drift: built for clean, instant static cuts
 */

const fs = require('fs');
const path = require('path');

class HandDrawnComicEngine {
  constructor() {
    this.width = 1280;
    this.height = 720;
  }

  // ── ORGANIC STROKE HELPERS ────────────────────────────────────────────────
  // Generates hand-drawn slightly wobbly lines to avoid robotic straight lines
  sketchLine(x1, y1, x2, y2, width = 5, color = '#000000') {
    const mx = (x1 + x2) / 2 + (Math.sin(x1 * 0.1) * 3);
    const my = (y1 + y2) / 2 + (Math.cos(y1 * 0.1) * 3);
    return \`<path d="M \${x1} \${y1} Q \${mx} \${my} \${x2} \${y2}" stroke="\${color}" stroke-width="\${width}" fill="none" stroke-linecap="round" stroke-linejoin="round"/>\`;
  }

  // Hand-drawn organic circle with natural non-perfect contour
  sketchCircle(cx, cy, r, fill = '#FFFFFF', stroke = '#000000', strokeWidth = 5.5) {
    const p1 = \`\${cx - r} \${cy}\`;
    const p2 = \`\${cx} \${cy - r - 2}\`;
    const p3 = \`\${cx + r + 2} \${cy + 1}\`;
    const p4 = \`\${cx - 1} \${cy + r + 2}\`;
    return \`<path d="M \${p1} C \${cx - r} \${cy - r*0.6}, \${cx - r*0.6} \${cy - r - 2}, \${p2} C \${cx + r*0.6} \${cy - r - 2}, \${cx + r + 2} \${cy - r*0.6}, \${p3} C \${cx + r + 2} \${cy + r*0.6}, \${cx + r*0.6} \${cy + r + 2}, \${p4} C \${cx - r*0.6} \${cy + r + 2}, \${cx - r} \${cy + r*0.6}, \${p1} Z" fill="\${fill}" stroke="\${stroke}" stroke-width="\${strokeWidth}" stroke-linecap="round" stroke-linejoin="round"/>\`;
  }

  // ── CHARACTER EXPRESSIONS & FACES ─────────────────────────────────────────
  renderCharacterHead(cx, cy, radius = 65, expression = 'deadpan') {
    const headOutline = this.sketchCircle(cx, cy, radius, '#FFFFFF', '#000000', 5.5);
    let eyesHtml = '';
    let browsHtml = '';
    let mouthHtml = '';
    let extraHtml = '';

    switch (expression) {
      case 'scared':
        // Trembling pupils, wavy worried brows, sweating
        browsHtml = \`
          <path d="M \${cx - 42} \${cy - 28} Q \${cx - 26} \${cy - 48} \${cx - 10} \${cy - 30}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 10} \${cy - 30} Q \${cx + 26} \${cy - 48} \${cx + 42} \${cy - 28}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <ellipse cx="\${cx - 25}" cy="\${cy - 8}" rx="14" ry="17" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx - 23}" cy="\${cy - 5}" r="5.5" fill="#000"/>
          <ellipse cx="\${cx + 25}" cy="\${cy - 8}" rx="14" ry="17" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx + 23}" cy="\${cy - 5}" r="5.5" fill="#000"/>
        \`;
        mouthHtml = \`<path d="M \${cx - 20} \${cy + 28} Q \${cx} \${cy + 16} \${cx + 20} \${cy + 28}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>\`;
        extraHtml = \`
          <!-- Blue cartoon sweat drops -->
          <path d="M \${cx + 45} \${cy - 22} C \${cx + 40} \${cy - 34}, \${cx + 54} \${cy - 30}, \${cx + 48} \${cy - 16} Z" fill="#38BDF8" stroke="#000" stroke-width="2"/>
        \`;
        break;

      case 'shocked':
        // Huge eyes, tiny pupils, open gasping mouth
        browsHtml = \`
          <path d="M \${cx - 40} \${cy - 38} Q \${cx - 24} \${cy - 50} \${cx - 8} \${cy - 38}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 8} \${cy - 38} Q \${cx + 24} \${cy - 50} \${cx + 40} \${cy - 38}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <circle cx="\${cx - 25}" cy="\${cy - 10}" r="17" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx - 25}" cy="\${cy - 10}" r="4" fill="#000"/>
          <circle cx="\${cx + 25}" cy="\${cy - 10}" r="17" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx + 25}" cy="\${cy - 10}" r="4" fill="#000"/>
        \`;
        mouthHtml = \`<ellipse cx="\${cx}" cy="\${cy + 28}" rx="13" ry="17" fill="#000"/>\`;
        break;

      case 'smug_curious':
        // One eyebrow raised, slight smirk
        browsHtml = \`
          <path d="M \${cx - 42} \${cy - 26} Q \${cx - 25} \${cy - 32} \${cx - 8} \${cy - 28}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 8} \${cy - 40} Q \${cx + 25} \${cy - 48} \${cx + 42} \${cy - 36}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <ellipse cx="\${cx - 24}" cy="\${cy - 6}" rx="14" ry="16" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx - 20}" cy="\${cy - 6}" r="6" fill="#000"/>
          <ellipse cx="\${cx + 24}" cy="\${cy - 10}" rx="15" ry="17" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx + 28}" cy="\${cy - 10}" r="6" fill="#000"/>
        \`;
        mouthHtml = \`<path d="M \${cx - 16} \${cy + 26} Q \${cx + 6} \${cy + 22} \${cx + 24} \${cy + 16}" stroke="#000" stroke-width="4.5" fill="none" stroke-linecap="round"/>\`;
        break;

      case 'sleeping':
        // Closed smiling eyes, zzz
        browsHtml = \`
          <line x1="\${cx - 38}" y1="\${cy - 22}" x2="\${cx - 12}" y2="\${cy - 22}" stroke="#000" stroke-width="3.5" stroke-linecap="round"/>
          <line x1="\${cx + 12}" y1="\${cy - 22}" x2="\${cx + 38}" y2="\${cy - 22}" stroke="#000" stroke-width="3.5" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <path d="M \${cx - 36} \${cy - 4} Q \${cx - 24} \${cy + 8} \${cx - 12} \${cy - 4}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
          <path d="M \${cx + 12} \${cy - 4} Q \${cx + 24} \${cy + 8} \${cx + 36} \${cy - 4}" stroke="#000" stroke-width="4" fill="none" stroke-linecap="round"/>
        \`;
        mouthHtml = \`<path d="M \${cx - 14} \${cy + 24} Q \${cx} \${cy + 30} \${cx + 14} \${cy + 24}" stroke="#000" stroke-width="3.5" fill="none" stroke-linecap="round"/>\`;
        extraHtml = \`
          <text x="\${cx + 50}" y="\${cy - 35}" font-family="sans-serif" font-weight="900" font-size="28" fill="#60A5FA">Z</text>
          <text x="\${cx + 72}" y="\${cy - 58}" font-family="sans-serif" font-weight="900" font-size="20" fill="#93C5FD">z</text>
        \`;
        break;

      case 'deadpan':
      default:
        // Classic internet stickman deadpan: horizontal brows, blank eyes, flat mouth
        browsHtml = \`
          <line x1="\${cx - 40}" y1="\${cy - 26}" x2="\${cx - 10}" y2="\${cy - 26}" stroke="#000" stroke-width="4.5" stroke-linecap="round"/>
          <line x1="\${cx + 10}" y1="\${cy - 26}" x2="\${cx + 40}" y2="\${cy - 26}" stroke="#000" stroke-width="4.5" stroke-linecap="round"/>
        \`;
        eyesHtml = \`
          <ellipse cx="\${cx - 24}" cy="\${cy - 6}" rx="14" ry="16" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx - 20}" cy="\${cy - 6}" r="6" fill="#000"/>
          <ellipse cx="\${cx + 24}" cy="\${cy - 6}" rx="14" ry="16" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <circle cx="\${cx + 28}" cy="\${cy - 6}" r="6" fill="#000"/>
        \`;
        mouthHtml = \`<line x1="\${cx - 24}" y1="\${cy + 26}" x2="\${cx + 24}" y2="\${cy + 26}" stroke="#000" stroke-width="4.5" stroke-linecap="round"/>\`;
        break;
    }

    return \`
      <g>
        \${headOutline}
        \${browsHtml}
        \${eyesHtml}
        \${mouthHtml}
        \${extraHtml}
      </g>
    \`;
  }

  // ── CHARACTER POSES ───────────────────────────────────────────────────────
  renderCharacter(x, y, pose = 'walking', expression = 'deadpan', scale = 1.0) {
    const headRadius = 65 * scale;
    const bodyLength = 155 * scale;
    const headY = y - bodyLength;
    let bodyHtml = '';

    switch (pose) {
      case 'climbing_tree':
        // Scared stickman hugging tree branch
        bodyHtml = \`
          \${this.sketchLine(x, headY + headRadius, x + 30*scale, y, 6*scale)}
          \${this.sketchLine(x + 10*scale, headY + headRadius + 30*scale, x - 45*scale, headY + headRadius + 60*scale, 5.5*scale)}
          \${this.sketchLine(x + 10*scale, headY + headRadius + 30*scale, x + 65*scale, headY - 10*scale, 5.5*scale)}
          \${this.sketchLine(x + 30*scale, y, x + 15*scale, y + 45*scale, 6*scale)}
          \${this.sketchLine(x + 15*scale, y + 45*scale, x + 60*scale, y + 80*scale, 6*scale)}
          \${this.sketchLine(x + 30*scale, y, x + 50*scale, y + 55*scale, 6*scale)}
          \${this.sketchLine(x + 50*scale, y + 55*scale, x + 85*scale, y + 95*scale, 6*scale)}
        \`;
        break;

      case 'striking_flint':
        // Ancient ancestor crouching, holding two rocks striking sparks
        bodyHtml = \`
          <!-- Fur loincloth wrap -->
          <polygon points="\${x-25*scale},\${y-10*scale} \${x+25*scale},\${y-10*scale} \${x+30*scale},\${y+35*scale} \${x-20*scale},\${y+40*scale}" fill="#78350F" stroke="#000" stroke-width="3"/>
          \${this.sketchLine(x, headY + headRadius, x, y, 6*scale)}
          <!-- Arms holding flint rocks together -->
          \${this.sketchLine(x, headY + headRadius + 30*scale, x - 45*scale, headY + headRadius + 65*scale, 5.5*scale)}
          \${this.sketchLine(x - 45*scale, headY + headRadius + 65*scale, x - 5*scale, headY + headRadius + 85*scale, 5.5*scale)}
          \${this.sketchLine(x, headY + headRadius + 30*scale, x + 40*scale, headY + headRadius + 60*scale, 5.5*scale)}
          \${this.sketchLine(x + 40*scale, headY + headRadius + 60*scale, x + 10*scale, headY + headRadius + 85*scale, 5.5*scale)}
          <!-- Two flint stones colliding -->
          <ellipse cx="\${x - 8*scale}" cy="\${headY + headRadius + 88*scale}" rx="14" ry="11" fill="#475569" stroke="#000" stroke-width="3"/>
          <ellipse cx="\${x + 12*scale}" cy="\${headY + headRadius + 88*scale}" rx="14" ry="11" fill="#64748B" stroke="#000" stroke-width="3"/>
          <!-- Yellow sparks -->
          <line x1="\${x}" y1="\${headY + headRadius + 85*scale}" x2="\${x - 20*scale}" y2="\${headY + headRadius + 65*scale}" stroke="#FCD34D" stroke-width="4" stroke-linecap="round"/>
          <line x1="\${x}" y1="\${headY + headRadius + 85*scale}" x2="\${x + 22*scale}" y2="\${headY + headRadius + 60*scale}" stroke="#F59E0B" stroke-width="4" stroke-linecap="round"/>
          <line x1="\${x}" y1="\${headY + headRadius + 85*scale}" x2="\${x}" y2="\${headY + headRadius + 105*scale}" stroke="#FCD34D" stroke-width="4" stroke-linecap="round"/>
          <!-- Crouched legs -->
          <path d="M \${x} \${y} L \${x - 50*scale} \${y + 30*scale} L \${x - 30*scale} \${y + 80*scale}" stroke="#000" stroke-width="6*scale" fill="none" stroke-linecap="round"/>
          <path d="M \${x} \${y} L \${x + 40*scale} \${y + 35*scale} L \${x + 35*scale} \${y + 80*scale}" stroke="#000" stroke-width="6*scale" fill="none" stroke-linecap="round"/>
        \`;
        break;

      case 'reading_manuscript':
        // Historian Roger Ekirch holding magnifying glass over ancient parchment
        bodyHtml = \`
          \${this.sketchLine(x, headY + headRadius, x, y, 6*scale)}
          <!-- Left Arm holding open scroll -->
          \${this.sketchLine(x, headY + headRadius + 30*scale, x - 55*scale, headY + headRadius + 50*scale, 5.5*scale)}
          \${this.sketchLine(x - 55*scale, headY + headRadius + 50*scale, x - 30*scale, headY + headRadius + 85*scale, 5.5*scale)}
          <!-- Right Arm holding magnifying glass -->
          \${this.sketchLine(x, headY + headRadius + 30*scale, x + 45*scale, headY + headRadius + 45*scale, 5.5*scale)}
          \${this.sketchLine(x + 45*scale, headY + headRadius + 45*scale, x + 25*scale, headY + headRadius + 75*scale, 5.5*scale)}
          <!-- Magnifying Glass -->
          <circle cx="\${x + 20*scale}" cy="\${headY + headRadius + 75*scale}" r="22" fill="#BAE6FD" stroke="#000" stroke-width="4"/>
          <line x1="\${x + 34*scale}" y1="\${headY + headRadius + 90*scale}" x2="\${x + 48*scale}" y2="\${headY + headRadius + 110*scale}" stroke="#78350F" stroke-width="6" stroke-linecap="round"/>
          <!-- Legs standing -->
          \${this.sketchLine(x, y, x - 25*scale, y + 110*scale, 6*scale)}
          \${this.sketchLine(x, y, x + 25*scale, y + 110*scale, 6*scale)}
        \`;
        break;

      case 'holding_phone_bed':
        // Modern human in bed looking at glowing phone at 3 AM
        bodyHtml = \`
          <!-- Bed frame & pillows -->
          <rect x="280" y="440" width="700" height="120" rx="14" fill="#64748B" stroke="#000" stroke-width="4"/>
          <ellipse cx="380" cy="420" rx="65" ry="32" fill="#FFF" stroke="#000" stroke-width="3.5"/>
          <!-- Torso propped up on elbow -->
          \${this.sketchLine(x, headY + headRadius, x + 80*scale, y + 20*scale, 6*scale)}
          <!-- Arm holding glowing smartphone -->
          \${this.sketchLine(x + 30*scale, headY + headRadius + 25*scale, x + 80*scale, headY + headRadius + 20*scale, 5.5*scale)}
          <!-- Smartphone with bright cyan glow -->
          <rect x="\${x + 75*scale}" y="\${headY + headRadius - 15*scale}" width="36" height="60" rx="6" fill="#000" stroke="#FFF" stroke-width="2"/>
          <rect x="\${x + 78*scale}" y="\${headY + headRadius - 10*scale}" width="30" height="50" rx="3" fill="#38BDF8"/>
          <!-- Light casting on face -->
          <polygon points="\${x + 75*scale},\${headY + headRadius} \${x},\${headY - 20*scale} \${x},\${headY + 50*scale}" fill="rgba(56, 189, 248, 0.15)"/>
        \`;
        break;

      case 'walking':
      default:
        // Classic walking pose
        bodyHtml = \`
          \${this.sketchLine(x, headY + headRadius, x, y, 6*scale)}
          \${this.sketchLine(x, headY + headRadius + 30*scale, x - 50*scale, y - 55*scale, 5.5*scale)}
          \${this.sketchLine(x - 50*scale, y - 55*scale, x - 70*scale, y - 5*scale, 5.5*scale)}
          \${this.sketchLine(x, headY + headRadius + 30*scale, x + 45*scale, y - 50*scale, 5.5*scale)}
          \${this.sketchLine(x + 45*scale, y - 50*scale, x + 65*scale, y - 10*scale, 5.5*scale)}
          \${this.sketchLine(x, y, x - 55*scale, y + 70*scale, 6*scale)}
          \${this.sketchLine(x - 55*scale, y + 70*scale, x - 80*scale, y + 130*scale, 6*scale)}
          \${this.sketchLine(x, y, x + 45*scale, y + 65*scale, 6*scale)}
          \${this.sketchLine(x + 45*scale, y + 65*scale, x + 75*scale, y + 130*scale, 6*scale)}
        \`;
        break;
    }

    return \`
      <g>
        \${bodyHtml}
        \${this.renderCharacterHead(x, headY, headRadius, expression)}
      </g>
    \`;
  }

  // ── SCENERY & PROPS ───────────────────────────────────────────────────────
  renderSavannaGrass(y = 560) {
    return \`
      <rect y="\${y}" width="1280" height="\${720 - y}" fill="#78350F"/>
      <line x1="0" y1="\${y}" x2="1280" y2="\${y}" stroke="#000" stroke-width="4.5"/>
      <!-- Hand-drawn grass tufts -->
      <path d="M 120 \${y} L 128 \${y - 25} L 138 \${y} L 145 \${y - 30} L 155 \${y}" stroke="#000" stroke-width="3" fill="none"/>
      <path d="M 450 \${y} L 458 \${y - 20} L 468 \${y} L 475 \${y - 28} L 485 \${y}" stroke="#000" stroke-width="3" fill="none"/>
      <path d="M 850 \${y} L 858 \${y - 25} L 868 \${y} L 878 \${y - 32} L 888 \${y}" stroke="#000" stroke-width="3" fill="none"/>
      <path d="M 1120 \${y} L 1128 \${y - 22} L 1138 \${y} L 1146 \${y - 26} L 1154 \${y}" stroke="#000" stroke-width="3" fill="none"/>
    \`;
  }

  renderPredatorEyes(x, y) {
    return \`
      <g transform="translate(\${x}, \${y})">
        <ellipse cx="0" cy="0" rx="17" ry="20" fill="#FCD34D" stroke="#000" stroke-width="3"/>
        <circle cx="-2" cy="0" r="6" fill="#000"/>
        <ellipse cx="46" cy="0" rx="17" ry="20" fill="#FCD34D" stroke="#000" stroke-width="3"/>
        <circle cx="44" cy="0" r="6" fill="#000"/>
      </g>
    \`;
  }

  renderHandDrawnCampfire(x, y) {
    return \`
      <g transform="translate(\${x}, \${y})">
        <!-- Fire stones -->
        <ellipse cx="0" cy="20" rx="85" ry="26" fill="#334155" stroke="#000" stroke-width="4"/>
        <circle cx="-65" cy="18" r="15" fill="#475569" stroke="#000" stroke-width="3"/>
        <circle cx="-30" cy="26" r="16" fill="#64748B" stroke="#000" stroke-width="3"/>
        <circle cx="5" cy="28" r="17" fill="#475569" stroke="#000" stroke-width="3"/>
        <circle cx="40" cy="25" r="16" fill="#64748B" stroke="#000" stroke-width="3"/>
        <circle cx="70" cy="18" r="15" fill="#475569" stroke="#000" stroke-width="3"/>
        <!-- Burning Wood Logs -->
        <path d="M -55 12 L 55 -5 L 50 -15 L -60 2 Z" fill="#78350F" stroke="#000" stroke-width="3.5"/>
        <path d="M -45 -5 L 50 15 L 45 25 L -50 5 Z" fill="#92400E" stroke="#000" stroke-width="3.5"/>
        <!-- Organic Orange & Yellow Cartoon Flame -->
        <path d="M 0 10 Q -65 -35 -35 -90 Q 0 -60 0 -135 Q 22 -75 42 -85 Q 65 -35 0 10 Z" fill="#EA580C" stroke="#000" stroke-width="4"/>
        <path d="M 0 10 Q -38 -20 -18 -65 Q 0 -45 0 -95 Q 16 -50 26 -55 Q 38 -20 0 10 Z" fill="#FBBF24"/>
        <!-- Floating Sparks -->
        <circle cx="-25" cy="-115" r="4.5" fill="#F97316"/>
        <circle cx="15" cy="-145" r="5" fill="#FBBF24"/>
        <circle cx="-10" cy="-170" r="4" fill="#F97316"/>
        <circle cx="35" cy="-110" r="4.5" fill="#FBBF24"/>
      </g>
    \`;
  }

  // ── BUILD DEDICATED STATIC SCENE ──────────────────────────────────────────
  buildStaticSceneSVG(sceneMeta) {
    const { sceneIndex, topic, visualDescription, characterPose, expression, bgTheme } = sceneMeta;

    let bgHtml = '';
    let actorsHtml = '';

    // Themes:
    switch (bgTheme) {
      case 'modern_bedroom':
        bgHtml = \`
          <rect width="1280" height="720" fill="#0F172A"/>
          <line x1="0" y1="560" x2="1280" y2="560" stroke="#1E293B" stroke-width="4"/>
          <!-- Glowing Digital Alarm Clock on Nightstand -->
          <rect x="920" y="440" width="140" height="120" rx="8" fill="#1E293B" stroke="#000" stroke-width="3"/>
          <rect x="940" y="465" width="100" height="45" rx="6" fill="#000"/>
          <text x="955" y="498" font-family="'JetBrains Mono', monospace" font-weight="bold" font-size="24" fill="#EF4444">03:14</text>
        \`;
        actorsHtml = this.renderCharacter(520, 470, 'holding_phone_bed', expression || 'deadpan', 1.05);
        break;

      case 'ancient_savanna_night':
        bgHtml = \`
          <rect width="1280" height="720" fill="#1B2E58"/>
          <!-- Moon -->
          <circle cx="300" cy="160" r="55" fill="#FEF08A" stroke="#000" stroke-width="4"/>
          <!-- Savanna Earth -->
          \${this.renderSavannaGrass(560)}
          <!-- Predator eyes in darkness -->
          \${this.renderPredatorEyes(380, 160)}
          \${this.renderPredatorEyes(220, 310)}
          \${this.renderPredatorEyes(840, 150)}
          \${this.renderPredatorEyes(990, 310)}
        \`;
        actorsHtml = this.renderCharacter(640, 440, 'walking', expression || 'deadpan', 1.05);
        break;

      case 'tree_refuge':
        bgHtml = \`
          <rect width="1280" height="720" fill="#1B2E58"/>
          <rect y="520" width="1280" height="200" fill="#15803D"/>
          <line x1="0" y1="520" x2="1280" y2="520" stroke="#000" stroke-width="4.5"/>
          <!-- Big cartoon tree -->
          <path d="M 750 720 L 720 300 L 580 180 L 600 160 L 740 260 L 760 80 L 800 80 L 800 240 L 920 160 L 940 180 L 820 280 L 860 720 Z" fill="#92400E" stroke="#000" stroke-width="5"/>
          <path d="M 520 180 C 460 120 500 40 580 50 C 640 10 740 10 800 60 C 880 30 960 70 960 140 C 1020 180 980 260 920 270 C 850 320 700 320 620 270 C 550 280 500 240 520 180 Z" fill="#22C55E" stroke="#000" stroke-width="5"/>
        \`;
        actorsHtml = this.renderCharacter(680, 240, 'climbing_tree', expression || 'scared', 0.95);
        break;

      case 'campfire_flint':
        bgHtml = \`
          <rect width="1280" height="720" fill="#0A0F1D"/>
          <!-- Cave Arch -->
          <path d="M 0 0 L 1280 0 L 1280 720 L 0 720 Z" fill="#1E293B"/>
          <path d="M 180 720 Q 240 160 640 140 Q 1040 160 1100 720 Z" fill="#090D16"/>
          <!-- Starry sky through opening -->
          <circle cx="520" cy="240" r="2.5" fill="#FFF"/><circle cx="700" cy="200" r="3" fill="#FFF"/>
          <circle cx="800" cy="280" r="2" fill="#FFF"/><circle cx="440" cy="320" r="2.5" fill="#FFF"/>
          <rect y="560" width="1280" height="160" fill="#334155"/>
          <line x1="0" y1="560" x2="1280" y2="560" stroke="#000" stroke-width="4.5"/>
        \`;
        actorsHtml = \`
          \${this.renderCharacter(520, 480, 'striking_flint', expression || 'smug_curious', 1.0)}
          <!-- Sparks flying to dry grass bundle -->
          <path d="M 640 560 Q 660 520 680 560 Q 700 520 720 560 Z" fill="#FEF08A" stroke="#000" stroke-width="2"/>
        \`;
        break;

      case 'campfire_active':
        bgHtml = \`
          <rect width="1280" height="720" fill="#0B1120"/>
          <rect y="560" width="1280" height="160" fill="#1E293B"/>
          <line x1="0" y1="560" x2="1280" y2="560" stroke="#000" stroke-width="4.5"/>
        \`;
        actorsHtml = \`
          \${this.renderHandDrawnCampfire(640, 500)}
          \${this.renderCharacter(430, 440, 'walking', expression || 'smug_curious', 0.95)}
          <g transform="translate(850, 440) scale(-1, 1)">
            \${this.renderCharacter(0, 0, 'walking', expression || 'deadpan', 0.95)}
          </g>
        \`;
        break;

      case 'historical_archive':
        bgHtml = \`
          <rect width="1280" height="720" fill="#FDFBF7"/>
          <line x1="0" y1="560" x2="1280" y2="560" stroke="#000" stroke-width="4"/>
          <!-- Stacks of ancient leather books & scrolls -->
          <rect x="160" y="440" width="160" height="120" rx="4" fill="#78350F" stroke="#000" stroke-width="3"/>
          <rect x="180" y="380" width="120" height="60" rx="4" fill="#92400E" stroke="#000" stroke-width="3"/>
          <rect x="200" y="330" width="80" height="50" rx="4" fill="#B45309" stroke="#000" stroke-width="3"/>
          <!-- Scroll on desk -->
          <path d="M 850 480 L 1100 480 Q 1120 480 1120 500 L 870 500 Q 850 500 850 480 Z" fill="#FEF3C7" stroke="#000" stroke-width="3"/>
        \`;
        actorsHtml = this.renderCharacter(640, 440, 'reading_manuscript', expression || 'smug_curious', 1.05);
        break;

      case 'medieval_midnight':
        bgHtml = \`
          <rect width="1280" height="720" fill="#0B132B"/>
          <!-- Gothic stone window showing crescent moon -->
          <path d="M 860 380 L 860 220 Q 930 140 1000 220 L 1000 380 Z" fill="#1C2541" stroke="#000" stroke-width="4"/>
          <circle cx="930" cy="220" r="30" fill="#FDE047"/>
          <line x1="0" y1="560" x2="1280" y2="560" stroke="#000" stroke-width="4"/>
        \`;
        actorsHtml = \`
          <!-- Bed with stickman sitting up -->
          <rect x="300" y="460" width="480" height="100" rx="8" fill="#78350F" stroke="#000" stroke-width="4"/>
          <!-- Candle on stand -->
          <circle cx="820" cy="460" r="14" fill="#F59E0B"/>
          <path d="M 820 460 Q 812 435 820 420 Q 828 435 820 460 Z" fill="#FBBF24" stroke="#000" stroke-width="2"/>
          \${this.renderCharacter(480, 410, 'walking', expression || 'deadpan', 1.0)}
        \`;
        break;

      default:
        bgHtml = \`
          <rect width="1280" height="720" fill="#1B2E58"/>
          \${this.renderSavannaGrass(560)}
        \`;
        actorsHtml = this.renderCharacter(640, 440, characterPose || 'walking', expression || 'deadpan', 1.05);
        break;
    }

    return \`<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1280 720" width="1280" height="720">
  <!-- Background -->
  \${bgHtml}
  <!-- Actors & Props -->
  \${actorsHtml}
</svg>
\`;
  }
}

module.exports = new HandDrawnComicEngine();
`;

fs.writeFileSync(targetPath, code, 'utf8');
console.log('✅ Hand-Drawn Comic Vector Engine written to:', targetPath);
