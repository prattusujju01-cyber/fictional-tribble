const slugs = [
  'byob-restaurant-experience-in-gurgaon',
  'skin-secrets-in-edappally-cochin-kochi',
  'gkb-gkb-construction-llp-building',
  'all-smiles-dental-clinic-bangalore'
];

async function check() {
  for (const s of slugs) {
    const url = 'https://asura-system.vercel.app/api/serve_project?slug=' + s + '&_t=' + Date.now();
    const res = await fetch(url);
    const html = await res.text();
    const h1 = (html.match(/<h1[\s\S]*?<\/h1>/) || [''])[0].replace(/<[^>]+>/g, '').replace(/\s+/g, ' ').trim();
    const title = (html.match(/<title>(.*?)<\/title>/) || [])[1];
    console.log(`[HTTP ${res.status}] ${s}`);
    console.log(`   Title: ${title}`);
    console.log(`   H1:    ${h1}`);
    console.log(`   Has 0k+ slop: ${html.includes('0k+')}`);
    console.log(`   Has counter class: ${html.includes('class="counter"')}`);
    console.log('---');
  }
}
check().catch(console.error);
