const fs = require('fs');
const path = require('path');

const screenplayPath = 'C:/Users/WINDOWS/.gemini/antigravity/scratch/youtube-automation-agent/assets/screenplay.json';
const screenplay = JSON.parse(fs.readFileSync(screenplayPath, 'utf8'));

const condensedNarrations = [
  // Act 1: The Heretic Prince (Scenes 1-25)
  "In 1350 BC, ancient Egypt was ruled by history's wealthiest, most corrupt religious monopoly.",
  "The priests of Amun-Ra secretly controlled seventy percent of all imperial land and wealth.",
  "They demanded a monthly subscription for your soul, promising salvation only to the rich.",
  "Pharaoh Amenhotep the Third threw lavish banquets while corrupt priests ran the state.",
  "His athletic older son, Thutmose, was groomed to keep the golden dynasty rolling.",
  "Then Thutmose died of a sudden fever, leaving the throne to an outcast prince.",
  "Prince Amenhotep the Fourth was a frail scholar with a bizarre, elongated skull.",
  "He ignored lion hunting, spending entire days staring unblinkingly at the desert sun.",
  "The arrogant priests chuckled, believing this eccentric boy would be an easy puppet.",
  "At his coronation, priests held out their palms, demanding their customary royal bribe.",
  "Instead, the young Pharaoh glared in ice-cold silence, refusing to give them a coin.",
  "He walked out onto the high stone balcony and dropped a historic bombshell.",
  "The animal-headed gods are fake, and your greedy priesthood is officially fired today.",
  "He unveiled the Aten: not a statue, but the radiant physical sun disc itself.",
  "Every sunbeam ended in a hand holding life directly to the people below.",
  "The sun shines on everyone for free—no priests, no temples, and no taxes.",
  "Overnight, he froze all temple bank accounts, stripping the priests of their fortune.",
  "Furious priests retreated into shadowy crypts, whispering treason and plotting royal assassination.",
  "Realizing Thebes was hopelessly corrupt, the Pharaoh decided to make a clean break.",
  "He legally changed his name to Akhenaten: The Living Spirit of the Sun.",
  "Then he dispatched royal strike teams across Egypt, armed with heavy bronze chisels.",
  "Climbing fifty-foot scaffolds, workers scraped the name of Amun off every public obelisk.",
  "They smashed sacred animal statues in city squares, shattering centuries of religious power.",
  "Commoners watched in stunned disbelief as ancient gods fell without any heavenly retribution.",
  "Akhenaten announced his grand decree: leaving Thebes forever to build an untouchable utopia.",

  // Act 2: The Sun City Rises (Scenes 26-50)
  "In Year Five, Akhenaten ordered thirty thousand citizens to pack their entire lives.",
  "Hundreds of royal cedar barges set sail north along the sunlit Nile River.",
  "He literally relocated the entire Egyptian government into the middle of the desert.",
  "They stopped at a desolate limestone crescent where no human had ever lived.",
  "Akhenaten saw the dawn sun rise perfectly inside a natural mountain notch.",
  "He fell to his knees, founding Akhetaten: The Horizon of the Sun Disc.",
  "He carved sixteen colossal thirty-foot stone billboards into the surrounding mountain cliffs.",
  "On these cliffs, he took an oath never to leave his new city.",
  "To build a capital for fifty thousand people overnight required radical engineering genius.",
  "Architects invented the Talatat block—the world's very first standardized modular sandstone brick.",
  "Weighing only one hundred pounds, each stone was easily carried by one man.",
  "Working like a modern assembly line, builders erected a magnificent city in three years.",
  "A massive four-lane Royal Road stretched four miles through the city center.",
  "The Great Temple of the Aten was built completely open, without any roof.",
  "The Great Palace sparkled with white limestone courtyards and blinding gold-leaf ceremonial gates.",
  "A monumental covered sky-bridge crossed the avenue, keeping royal feet above the crowds.",
  "Spacious suburban districts housed thousands of skilled sculptors, painters, and royal stonemasons.",
  "Engineers drilled deep into bedrock, tapping cold Nile aquifers to supply fresh water.",
  "They planted desert gardens, date palms, and blooming lotus ponds in the sand.",
  "Foreign merchants arrived from Greece and Babylon, selling olive oil, silver, and jewels.",
  "Each morning at dawn, bronze trumpets summoned thousands of citizens to roofless worship.",
  "Altars groaned beneath thousands of roasted ducks, fresh bread, and sweet desert figs.",
  "After the sun touched the offerings, food was distributed freely to all people.",
  "Akhenaten gazed across his gleaming metropolis, convinced his golden empire would endure forever.",
  "Yet in old Thebes, disgraced priests and angry generals were quietly sharpening their blades.",

  // Act 3: The Golden Heresy (Scenes 51-75)
  "For fifteen centuries, Pharaohs were always depicted as flawless, muscular, god-like supermen.",
  "Akhenaten banned ancient photoshop, commanding royal artists to paint his real physical flaws.",
  "He appeared with a drooping belly, narrow shoulders, and a sharp, elongated jawline.",
  "He shattered royal taboos by showing affectionate moments kissing his wife in public.",
  "Queen Nefertiti was not a quiet trophy, but a powerful royal co-ruler.",
  "She wore a unique tall blue crown modeled after the Pharaoh's war helmet.",
  "Carvings even depict Nefertiti steering war chariots and smiting foreign enemies with maces.",
  "Every afternoon, the royal couple raced down the avenue in gleaming gold chariots.",
  "Lightweight and aerodynamic, these gold-plated chariots were the luxury sports cars of antiquity.",
  "At the palace Window of Appearances, the royal family greeted ecstatic gathered crowds.",
  "Akhenaten showered his faithful ministers with heavy gold collars thrown from the balcony.",
  "Master sculptor Thutmose mixed fine gypsum, carving the iconic painted bust of Nefertiti.",
  "Palace walls erupted with vibrant nature frescoes of leaping calves and fluttering marshbirds.",
  "Akhenaten composed the Great Hymn to the Aten, praising life and radiant light.",
  "Six young princesses laughed and played in palace gardens with pet monkeys and puppies.",
  "Women and children stood at the front lines of every single open-air ceremony.",
  "Diplomats from the Aegean, Babylon, and Assyria brought gifts of ivory and cedar.",
  "Nightly banquets ran until dawn with strumming golden harps and flowing red wine.",
  "Blinded by his utopian dream, the Pharaoh believed universal peace had finally arrived.",
  "While the King wrote nature poetry, the outside empire was rapidly falling apart.",
  "Akhenaten dismissed pleading generals with rambling philosophical lectures about sunlight and peace.",
  "General Horemheb watched in fury as decades of hard-won northern conquests slipped away.",
  "The military budget was funneled into temple limestone, starving soldiers of weapons and rations.",
  "Loyal frontier allies realized the Pharaoh in his desert bubble had abandoned them.",
  "Inside Amarna, life was idyllic, but the surrounding Near East was catching fire.",

  // Act 4: The Fall & The Forgotten (Scenes 76-100)
  "Archaeologists uncovered hundreds of baked clay tablets: the frantic, desperate Amarna Letters.",
  "Frontier kings sent panicked messages pleading for immediate archers against invading barbarian armies.",
  "King Rib-Hadda of Byblos begged: 'I am caged like a bird, save us!'",
  "Akhenaten ignored their pleas, quietly shelving the clay tablets in dark storage rooms.",
  "The ferocious Hittite army swept south with heavy iron chariots, crushing Egyptian garrisons.",
  "Fortified northern frontier cities burned, destroying three generations of hard-won Egyptian empire.",
  "Then a catastrophic plague struck Amarna, carried home by retreating frontier military units.",
  "Heartbroken, the royal couple buried three of their young daughters in rock tombs.",
  "Around Year Fourteen, Queen Nefertiti mysteriously vanished from all written historical records.",
  "Sick and isolated, Akhenaten spent his final days coughing in darkened palace chambers.",
  "In Year Seventeen, the thirty-five-year-old rebel king died, ending his radiant revolution.",
  "In total secrecy, panicked attendants buried his body inside a barren desert canyon.",
  "Nine-year-old Prince Tutankhaten was placed upon the colossal, heavy golden royal throne.",
  "Priests and generals gave the terrified child an ultimatum: renounce your father or die.",
  "The boy surrendered, changing his name to Tutankhamun and restoring the ancient gods.",
  "The government proclaimed the Restoration Decree, branding Akhenaten a cursed, criminal heretic.",
  "Tutankhamun ordered thirty thousand residents to immediately evacuate Amarna and return south.",
  "Desert winds howled through abandoned temples as shifting sands swallowed the ghost city.",
  "Pharaoh Horemheb seized the throne, launching a campaign to erase Akhenaten from history.",
  "Soldiers swung sledgehammers, smashing the lifelike statues of Akhenaten into jagged gravel.",
  "Stonemasons chipped his royal cartouche off temple walls, deleting his name for eternity.",
  "Amarna was dismantled stone by stone, its talatat blocks buried under new temples.",
  "Royal scribes scrubbed his seventeen-year reign completely from the official king lists.",
  "Yet the burying of Amarna preserved its treasures as a pristine 3,300-year time capsule.",
  "Today, the erased rebel is the most famous, revolutionary Pharaoh in human history."
];

console.log('Condensed narration scenes count:', condensedNarrations.length);
let totalWords = 0;
condensedNarrations.forEach((text, i) => {
  const wc = text.trim().split(/\s+/).length;
  totalWords += wc;
  screenplay.scenes[i].narration = text;
});

console.log('Total words:', totalWords);
console.log('Average words per scene:', (totalWords / 100).toFixed(1));
console.log('Estimated duration at 142 wpm:', (totalWords / 142).toFixed(2), 'minutes (~' + Math.floor((totalWords / 142) * 60) + 's)');

fs.writeFileSync(screenplayPath, JSON.stringify(screenplay, null, 2), 'utf8');
console.log('✅ assets/screenplay.json updated successfully!');
