const fs = require('fs');
const path = require('path');

const TARGET_DIR = path.join('C:', 'Users', 'WINDOWS', '.gemini', 'antigravity', 'scratch', 'youtube-automation-agent');

async function downloadRepo() {
  console.log('Fetching file tree from darkzOGx/youtube-automation-agent...');
  const treeUrl = 'https://api.github.com/repos/darkzOGx/youtube-automation-agent/git/trees/master?recursive=1';
  const res = await fetch(treeUrl, {
    headers: { 'User-Agent': 'Mozilla/5.0' }
  });

  if (res.status !== 200) {
    console.error('Failed to fetch tree:', res.status, await res.text());
    return;
  }

  const data = await res.json();
  const tree = data.tree || [];
  console.log(`Found ${tree.length} items in repository.`);

  let downloaded = 0;
  for (const item of tree) {
    const fullPath = path.join(TARGET_DIR, item.path);
    if (item.type === 'tree') {
      fs.mkdirSync(fullPath, { recursive: true });
    } else if (item.type === 'blob') {
      fs.mkdirSync(path.dirname(fullPath), { recursive: true });
      try {
        const rawUrl = `https://raw.githubusercontent.com/darkzOGx/youtube-automation-agent/master/${item.path}`;
        const fileRes = await fetch(rawUrl);
        if (fileRes.status === 200) {
          const buffer = Buffer.from(await fileRes.arrayBuffer());
          fs.writeFileSync(fullPath, buffer);
          downloaded++;
          if (downloaded % 10 === 0 || downloaded === tree.filter(t => t.type === 'blob').length) {
            console.log(`Downloaded ${downloaded} files...`);
          }
        }
      } catch (err) {
        console.error(`Failed to download ${item.path}:`, err.message);
      }
    }
  }

  console.log(`✅ Successfully cloned darkzOGx/youtube-automation-agent (${downloaded} files) to: ${TARGET_DIR}`);
}

downloadRepo();
