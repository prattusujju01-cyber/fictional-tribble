const fs = require('fs');
const path = require('path');
const assert = require('assert');

console.log('════════════════════════════════════════════════════════════');
console.log('    VERIFYING MYSTERIOUS CRYPTO LOTTERY & ADMIN SANCTUM     ');
console.log('════════════════════════════════════════════════════════════');

let passed = 0;
let failed = 0;

function runTest(name, fn) {
  try {
    fn();
    console.log(`  [PASS] ${name}`);
    passed++;
  } catch (e) {
    console.error(`  [FAIL] ${name}: ${e.message}`);
    failed++;
  }
}

const baseDir = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system';
const indexHtml = fs.readFileSync(path.join(baseDir, 'projects/crypto-lottery/index.html'), 'utf8');
const adminHtml = fs.readFileSync(path.join(baseDir, 'projects/crypto-lottery/admin.html'), 'utf8');

console.log('\n--- 1. Testing Removal of 70% and 30% from Public UI ---');

runTest('Zero visible occurrences of 70% in public HTML tags', () => {
  const stripped = indexHtml.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<!--[\s\S]*?-->/g, '');
  assert.strictEqual(stripped.includes('70%'), false, 'Found visible 70% in HTML');
});

runTest('Zero visible occurrences of 30% in public HTML tags', () => {
  const stripped = indexHtml.replace(/<script[\s\S]*?<\/script>/gi, '').replace(/<!--[\s\S]*?-->/g, '');
  assert.strictEqual(stripped.includes('30%'), false, 'Found visible 30% in HTML');
});

runTest('Hero section displays SOL currency with on-chain pool', () => {
  assert.ok(indexHtml.includes('heroSolAmount'), 'Must have heroSolAmount element');
  assert.ok(indexHtml.includes('SOLANA PRIZE VAULT'), 'Must have SOLANA PRIZE VAULT badge');
  assert.ok(indexHtml.includes('Calculated from Admin Treasury Solana reserve'), 'Must state calculation source');
});

console.log('\n--- 2. Testing Mysterious Look & Aesthetic ---');

runTest('Contains mysterious occult obsidian void theme (#020406)', () => {
  assert.ok(indexHtml.includes('#020406'), 'Must contain obsidian void background #020406');
  assert.ok(indexHtml.includes('sigil-ring-cw'), 'Must contain rotating arcane sigil ring animation');
  assert.ok(indexHtml.includes('mystic-mist'), 'Must contain ethereal smoky mist animation');
});

runTest('Contains esoteric glyphs and ancient cipher typography', () => {
  assert.ok(indexHtml.includes('⟐'), 'Must contain arcane glyph ⟐');
  assert.ok(indexHtml.includes('SANCTUM'), 'Must reference SANCTUM in navigation');
});

console.log('\n--- 3. Testing Procedural Web Audio Ambient Soundtrack ---');

runTest('Contains Web Audio procedural MysticAudio engine', () => {
  assert.ok(indexHtml.includes('const MysticAudio = {'), 'Must define MysticAudio engine');
  assert.ok(indexHtml.includes('droneOsc1'), 'Must synthesize sub-bass drone oscillator');
  assert.ok(indexHtml.includes('droneOsc2'), 'Must synthesize binaural detune oscillator');
  assert.ok(indexHtml.includes('playEerieChime'), 'Must schedule esoteric harmonic chimes');
  assert.ok(indexHtml.includes('audioVisualizerCanvas'), 'Must have audio visualizer canvas');
});

runTest('Contains ambient music toggle and invitation banner', () => {
  assert.ok(indexHtml.includes('toggleMysticAudio'), 'Must have toggle function');
  assert.ok(indexHtml.includes('audioInviteBanner'), 'Must have ambient audio invitation banner');
});

console.log('\n--- 4. Testing Solana 70% Admin Pool Engine ---');

runTest('Contains fetchAdminSolanaBalance connecting to Solana RPC', () => {
  assert.ok(indexHtml.includes('fetchAdminSolanaBalance'), 'Must have fetchAdminSolanaBalance');
  assert.ok(indexHtml.includes('https://api.mainnet-beta.solana.com'), 'Must query Solana Mainnet RPC');
  assert.ok(indexHtml.includes('0.70'), 'Must calculate 70% of Admin Solana balance');
});

console.log('\n--- 5. Testing Dedicated Admin Page (admin.html) ---');

runTest('admin.html exists and contains PIN authentication barrier', () => {
  assert.ok(adminHtml.length > 1000, 'admin.html must be populated');
  assert.ok(adminHtml.includes('authGate'), 'Must have auth gate modal');
  assert.ok(adminHtml.includes('asura2026'), 'Must support admin access PIN');
});

runTest('admin.html has space to upload receiver key (drag-drop & paste)', () => {
  assert.ok(adminHtml.includes('dropZone'), 'Must have drag & drop zone for keypair file');
  assert.ok(adminHtml.includes('receiverKeyInput'), 'Must have textarea for pasting receiver key');
  assert.ok(adminHtml.includes('validateAndSaveReceiverKey'), 'Must validate key format');
  assert.ok(adminHtml.includes('UPLOAD RECEIVER KEY'), 'Must have UPLOAD RECEIVER KEY section');
});

runTest('admin.html has Admin Solana Wallet & 70% Prize Pool calculator', () => {
  assert.ok(adminHtml.includes('adminSolanaAddressInput'), 'Must have admin wallet address input');
  assert.ok(adminHtml.includes('calcPoolSol'), 'Must calculate 70% prize pool allocation');
  assert.ok(adminHtml.includes('calcTotalSol'), 'Must inspect total admin SOL');
  assert.ok(adminHtml.includes('fetchAdminSolanaBalanceOnChain'), 'Must query on-chain balance');
});

console.log('\n════════════════════════════════════════════════════════════');
console.log(`TOTAL TESTS: ${passed + failed} | PASSED: ${passed} | FAILED: ${failed}`);
console.log('════════════════════════════════════════════════════════════');

if (failed > 0) process.exit(1);
