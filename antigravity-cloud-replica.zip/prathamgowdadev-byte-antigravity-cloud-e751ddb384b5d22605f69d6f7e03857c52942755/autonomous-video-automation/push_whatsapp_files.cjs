const fs = require('fs');
const path = require('path');

const CONFIG = {
  GITHUB_TOKEN: process.env.GITHUB_TOKEN || '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',
  REPO_OWNER: 'prathamgowda194-pixel',
  REPO_NAME: 'asura-system'
};

const FILES_TO_PUSH = [
  'whatsapp_config.json',
  'api/whatsapp.js',
  'scripts/whatsapp_engine.cjs',
  'scripts/whatsapp_bot_runner.cjs',
  'scripts/test_whatsapp_bot.cjs'
];

async function getFileSha(remotePath) {
  const url = `https://api.github.com/repos/${CONFIG.REPO_OWNER}/${CONFIG.REPO_NAME}/contents/${remotePath}`;
  try {
    const res = await fetch(url, {
      headers: {
        'Authorization': `Bearer ${CONFIG.GITHUB_TOKEN}`,
        'User-Agent': 'Node.js/GitHub-Sync'
      }
    });
    if (res.status === 200) {
      const data = await res.json();
      return data.sha;
    }
  } catch (e) {}
  return null;
}

async function uploadFile(localPath) {
  const fullPath = path.join('C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\asura-system', localPath);
  if (!fs.existsSync(fullPath)) {
    console.error(`File missing: ${fullPath}`);
    return;
  }

  const content = fs.readFileSync(fullPath).toString('base64');
  const remotePath = localPath.replace(/\\/g, '/');
  const sha = await getFileSha(remotePath);

  const payload = {
    message: `feat(whatsapp): deploy automated whatsapp bot & webhook [${remotePath}]`,
    content,
    branch: 'main'
  };
  if (sha) payload.sha = sha;

  const url = `https://api.github.com/repos/${CONFIG.REPO_OWNER}/${CONFIG.REPO_NAME}/contents/${remotePath}`;
  const res = await fetch(url, {
    method: 'PUT',
    headers: {
      'Authorization': `Bearer ${CONFIG.GITHUB_TOKEN}`,
      'Content-Type': 'application/json',
      'User-Agent': 'Node.js/GitHub-Sync'
    },
    body: JSON.stringify(payload)
  });

  if (res.status === 200 || res.status === 201) {
    console.log(`[SYNC OK] Pushed ${remotePath} to GitHub main.`);
  } else {
    const text = await res.text();
    console.error(`[SYNC FAIL] ${remotePath}: ${res.status} - ${text}`);
  }
}

async function main() {
  for (const f of FILES_TO_PUSH) {
    await uploadFile(f);
  }
  console.log('Finished pushing all WhatsApp automation files.');
}

main().catch(console.error);
