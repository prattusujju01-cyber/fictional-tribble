import re

# Read app.py
with open("app.py", "r", encoding="utf-8") as f:
    content = f.read()

# Verify existing markers
marker_orb = '    # ── TESLA ORB + WEBSPEECH INTERFACE ─────────────────────────────────────────'
marker_end_center = '# ──────────────────────────────────────────────────────────────────────────────\n# RIGHT PANEL: LIVE SYSTEM LOGS & TELEMETRY'

if marker_orb not in content or marker_end_center not in content:
    print("ERROR: Markers not found in app.py!")
    exit(1)

# Split col_center content
pre_orb = content.split(marker_orb)[0]
after_center = marker_end_center + content.split(marker_end_center)[1]

# Extract the existing builder body (from marker_orb to marker_end_center)
builder_body = marker_orb + content.split(marker_orb)[1].split(marker_end_center)[0]

# Indent builder_body by 4 spaces for 'with tab_builder:'
indented_builder = []
for line in builder_body.splitlines():
    if line.strip():
        indented_builder.append("    " + line)
    else:
        indented_builder.append("")
indented_builder_str = "\n".join(indented_builder)

# Construct Hunter Tab & Portfolio Tab
tabs_header = '''    tab_builder, tab_hunter, tab_portfolio = st.tabs([
        "⚡ ASURA BUILDER // CLIENT PLATFORM GENERATOR",
        "🎯 ASURA HUNTER // 24/7 TELEGRAM LEAD RADAR",
        "📁 CLIENT ASSET PORTFOLIO"
    ])

    with tab_builder:
'''

hunter_tab_code = '''
    with tab_hunter:
        H("""
        <div class="gl1" style="padding:16px 20px;margin-bottom:14px;">
        <div style="display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
            <div>
                <span class="t-over" style="color:#38bdf8;">AUTONOMOUS LEAD RADAR // MULTI-SOURCE SCRAPER</span>
                <h3 style="font-family:'Orbitron',sans-serif;font-size:18px;font-weight:800;color:#ffffff;margin-top:2px;">
                    ASURA HUNTER 24/7 // TELEGRAM MATRIX
                </h3>
            </div>
            <div style="display:flex;align-items:center;gap:8px;">
                <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#34d399;box-shadow:0 0 10px #34d399;"></span>
                <span style="font-family:'JetBrains Mono',monospace;font-size:11px;font-weight:700;color:#34d399;">@Asura_Hunter_bot ONLINE</span>
            </div>
        </div>
        <p style="font-size:12px;color:#94a3b8;margin-top:6px;line-height:1.5;">
            Autonomously searches for businesses <b>without websites</b> across all target niches, extracts verified business names, phone numbers, and locations, generates bespoke live prototypes via <b>Gemini 3.6 Flash</b>, and sends 1-click pitch cards directly to your Telegram.
        </p>
        </div>
        """)

        # Telegram Pairing Card & Test Ping
        bot_instance = TelegramBot(os.environ.get("TELEGRAM_BOT_TOKEN", "8909145509:AAF8UhbWxPR5JGt8ddcAd9D1gqZ3L13ZuAo")) if TelegramBot else None
        active_subs = bot_instance.get_subscribers() if bot_instance else []

        h_col1, h_col2 = st.columns([2.5, 1.5])
        with h_col1:
            sub_count = len(active_subs)
            sub_status = f"🟢 <b>{sub_count} Device(s) Paired</b>" if sub_count > 0 else "⚠️ <b>No Devices Paired Yet</b>"
            st.markdown(f"""
            <div style="background:rgba(255,255,255,0.03);border:1px solid rgba(255,255,255,0.08);border-radius:12px;padding:12px 16px;">
                <div style="font-size:11px;font-family:monospace;color:#94a3b8;margin-bottom:4px;">TELEGRAM DISPATCH STATUS</div>
                <div style="font-size:13px;color:#f8fafc;margin-bottom:4px;">{sub_status}</div>
                <div style="font-size:11px;color:#64748b;">
                    Open Telegram, search <b><a href="https://t.me/Asura_Hunter_bot" target="_blank" style="color:#38bdf8;">@Asura_Hunter_bot</a></b>, and press <b>Start</b> to link your phone.
                </div>
            </div>
            """, unsafe_allow_html=True)
        with h_col2:
            if st.button("⚡ Send Test Telegram Ping", use_container_width=True):
                if bot_instance:
                    test_lead = {
                        "name": "Apex Precision Dental",
                        "niche": "Cosmetic & Family Dentistry",
                        "city": "Miami, FL",
                        "phone": "(305) 555-0199",
                        "email": "dr.vance@apexprecisiondental.com",
                        "address": "Brickell Avenue, Miami, FL 33131",
                        "rating": "4.9",
                        "reviews": "128",
                        "hasWebsite": False
                    }
                    sample_proto = "https://asura-system.vercel.app/projects/apex-precision-dental/index.html"
                    cnt = bot_instance.send_lead_card(test_lead, sample_proto)
                    log_message(f"Telegram dispatcher: test ping broadcasted to {cnt} subscriber(s).", "telegram")
                    st.success(f"Dispatched test lead alert to {cnt} subscriber(s) on Telegram!")
                    st.rerun()

        # Hunter Scanner Controls
        st.markdown("<div style='margin-top:14px;margin-bottom:8px;font-size:11px;font-family:monospace;letter-spacing:0.08em;color:#38bdf8;'>DIRECT RADAR HUNT VECTOR</div>", unsafe_allow_html=True)
        
        niche_names = [
            "All Niches (Multi-Vector)",
            "Dental Clinic",
            "Fitness & Gym",
            "Medical Spa",
            "Roofing Contractor",
            "Plumbing Services",
            "HVAC & AC Repair",
            "Licensed Electrician",
            "Landscaping & Tree Service",
            "Restaurant & Bistro",
            "Hair Salon & Barbershop",
            "Law Firm & Attorney",
            "Auto Detailing & Repair",
            "Painting Contractor",
            "Chiropractic & Physical Therapy",
            "Pet Grooming & Veterinary",
            "Commercial Cleaning Services"
        ]

        c_col1, c_col2 = st.columns(2)
        with c_col1:
            selected_niche_display = st.selectbox("Select Target Business Niche:", niche_names, index=0)
        with c_col2:
            target_city_input = st.text_input("Target City / Metro Area:", value="Miami, FL")

        h_btn1, h_btn2 = st.columns(2)
        with h_btn1:
            launch_hunt = st.button("🚀 Launch Autonomous Hunt (Generate & Deploy Prototype)", use_container_width=True)
        with h_btn2:
            sweep_all = st.button("⚡ Sweep All 16 Niches in Parallel", use_container_width=True)

        if launch_hunt:
            with st.spinner(f"Scanning '{selected_niche_display}' in '{target_city_input}' for businesses without websites..."):
                log_message(f"Radar: initiating search for {selected_niche_display} in {target_city_input}...", "hunter")
                if hunter_engine:
                    matched_niche = None
                    if "All" not in selected_niche_display:
                        for n in hunter_engine.TARGET_NICHES:
                            if n["name"] == selected_niche_display:
                                matched_niche = n
                                break
                    
                    found_count = 0
                    if matched_niche:
                        leads = hunter_engine.hunt_leads_for_niche(matched_niche, target_city_input, limit=2)
                        for l in leads:
                            log_message(f"Radar: found '{l['name']}' ({l['phone']}) - compiling bespoke prototype...", "hunter")
                            hunter_engine.process_lead(l)
                            found_count += 1
                    else:
                        for n in hunter_engine.TARGET_NICHES[:3]:
                            leads = hunter_engine.hunt_leads_for_niche(n, target_city_input, limit=1)
                            for l in leads:
                                hunter_engine.process_lead(l)
                                found_count += 1
                    
                    st.success(f"Sweep complete! Found, synthesized prototypes, and alerted Telegram for {found_count} leads.")
                    log_message(f"Radar sweep complete: {found_count} leads processed.", "success")
                    st.rerun()

        if sweep_all:
            with st.spinner(f"Executing high-yield sweep across all 16 business niches in {target_city_input}..."):
                if hunter_engine:
                    total_p = 0
                    for n in hunter_engine.TARGET_NICHES:
                        leads = hunter_engine.hunt_leads_for_niche(n, target_city_input, limit=1)
                        for l in leads:
                            hunter_engine.process_lead(l)
                            total_p += 1
                            time.sleep(2)
                    st.success(f"All 16 Niches Swept! {total_p} live prototypes generated and dispatched to Telegram.")
                    st.rerun()

        # Discovered Leads Deck
        st.markdown("<div style='margin-top:20px;margin-bottom:10px;font-size:11px;font-family:monospace;letter-spacing:0.08em;color:#34d399;'>LIVE DISCOVERED LEADS & OUTREACH MATRIX</div>", unsafe_allow_html=True)
        
        saved_leads = []
        leads_path = os.path.join("data", "hunter_leads.json")
        if os.path.exists(leads_path):
            try:
                with open(leads_path, "r", encoding="utf-8") as f:
                    saved_leads = json.load(f)
            except Exception:
                pass

        if saved_leads:
            for l_idx, lead in enumerate(saved_leads):
                l_name = lead.get("name", "Local Business")
                l_niche = lead.get("niche", "Service")
                l_city = lead.get("city", "USA")
                l_phone = lead.get("phone", "No phone")
                l_rating = lead.get("rating", "4.8")
                l_proto = lead.get("prototypeUrl", "")
                l_slug = lead.get("slug", "")

                clean_d = "".join(c for c in l_phone if c.isdigit())
                if len(clean_d) == 10:
                    clean_d = "1" + clean_d

                wa_pitch = urllib.parse.quote(
                    f"Hi {l_name}! I noticed your business has great customer ratings, "
                    f"but doesn't currently have an official website. "
                    f"I built a custom live website prototype for you to see: {l_proto} . Would you like to claim it?"
                )

                st.markdown(f"""
                <div style="background:rgba(255,255,255,0.02);border:1px solid rgba(255,255,255,0.08);border-radius:14px;padding:16px;margin-bottom:12px;">
                    <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px;">
                        <div>
                            <span style="display:inline-block;padding:2px 8px;border-radius:4px;background:rgba(56,189,248,0.15);color:#38bdf8;font-size:10px;font-family:monospace;font-weight:700;margin-bottom:6px;">{l_niche.upper()}</span>
                            <div style="font-size:15px;font-weight:700;color:#ffffff;">{l_name}</div>
                            <div style="font-size:12px;color:#94a3b8;margin-top:2px;">📍 {l_city} &nbsp;|&nbsp; 📞 <code style="color:#38bdf8;">{l_phone}</code> &nbsp;|&nbsp; ⭐ {l_rating} ★</div>
                        </div>
                        <div style="text-align:right;">
                            <span style="display:inline-block;padding:3px 10px;border-radius:6px;background:rgba(239,68,68,0.15);border:1px solid rgba(239,68,68,0.3);color:#f87171;font-size:10px;font-family:monospace;font-weight:700;">
                                ❌ NO WEBSITE
                            </span>
                        </div>
                    </div>
                </div>
                """, unsafe_allow_html=True)

                lead_btn_c1, lead_btn_c2, lead_btn_c3 = st.columns([1.5, 1.5, 1.2])
                with lead_btn_c1:
                    if l_proto:
                        st.markdown(f"""
                        <a href="{l_proto}" target="_blank" style="
                            display:block;text-align:center;padding:8px 12px;border-radius:8px;
                            background:linear-gradient(135deg, #059669 0%, #10b981 100%);
                            color:#ffffff;font-size:11px;font-weight:700;text-decoration:none;
                        ">🌐 Open Live Prototype ↗</a>
                        """, unsafe_allow_html=True)
                with lead_btn_c2:
                    if clean_d:
                        st.markdown(f"""
                        <a href="https://wa.me/{clean_d}?text={wa_pitch}" target="_blank" style="
                            display:block;text-align:center;padding:8px 12px;border-radius:8px;
                            background:linear-gradient(135deg, #0284c7 0%, #38bdf8 100%);
                            color:#ffffff;font-size:11px;font-weight:700;text-decoration:none;
                        ">💬 WhatsApp Pitch (1-Click)</a>
                        """, unsafe_allow_html=True)
                with lead_btn_c3:
                    if st.button("⚡ Edit in Builder", key=f"edit_lead_{l_idx}", use_container_width=True):
                        st.session_state.selected_project_slug = l_slug
                        st.session_state.target_niche_val = f"Update website for {l_name} ({l_niche}): "
                        st.rerun()
        else:
            st.info("No leads discovered yet. Launch an autonomous hunt above to extract clients without websites!")

    with tab_portfolio:
        H("""
        <div class="gl1" style="padding:16px 20px;margin-bottom:14px;">
        <div class="t-over" style="color:#a78bfa;">CLIENT ASSET REPOSITORY // LIVE VERCEL DIRECTORY</div>
        <h3 style="font-family:'Orbitron',sans-serif;font-size:18px;font-weight:800;color:#ffffff;margin-top:2px;">
            DEPLOYED PRODUCTION PLATFORMS
        </h3>
        <p style="font-size:12px;color:#94a3b8;margin-top:6px;">
            All client websites deployed on Vercel edge networks. Select any project to make iterative edits or export the HTML production bundle.
        </p>
        </div>
        """)

        all_projs = list_available_projects()
        if all_projs:
            for p in all_projs:
                p_col1, p_col2, p_col3 = st.columns([2.2, 1.3, 1.5])
                with p_col1:
                    st.markdown(f"**`{p['slug']}`**")
                    st.caption(f"[Live on Vercel ↗]({p['url']})")
                with p_col2:
                    if st.button(f"Edit Site", key=f"port_edit_{p['slug']}", use_container_width=True):
                        st.session_state.selected_project_slug = p['slug']
                        st.session_state.target_niche_val = f"Update {p['slug']} website: "
                        st.rerun()
                with p_col3:
                    p_path = os.path.join("projects", p['slug'], "index.html")
                    p_html = ""
                    if os.path.exists(p_path):
                        try:
                            with open(p_path, "r", encoding="utf-8", errors="ignore") as pf:
                                p_html = pf.read()
                        except Exception:
                            pass
                    if p_html:
                        st.download_button(
                            label="Export .html",
                            data=p_html,
                            file_name=f"{p['slug']}_index.html",
                            mime="text/html",
                            key=f"port_dl_{p['slug']}",
                            use_container_width=True
                        )
                    else:
                        st.caption("Active in Cloud")
        else:
            st.info("No sub-projects detected yet. Generate a website to see it cataloged here!")
'''

new_app_content = pre_orb + tabs_header + indented_builder_str + "\n" + hunter_tab_code + "\n\n" + after_center

with open("app.py", "w", encoding="utf-8") as f:
    f.write(new_app_content)

print("SUCCESS: app.py updated with Builder, Hunter, and Portfolio tabs!")
