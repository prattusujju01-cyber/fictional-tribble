/**
 * ══════════════════════════════════════════════════════════════════════════════
 * HERMES SCREENWRITER // GLOBAL 2D HISTORICAL DOCUMENTARY SYSTEM
 * ══════════════════════════════════════════════════════════════════════════════
 * Narrative Architect for High-Retention Historical Documentaries (Genius History Style):
 * - 24 Core Synchronized Scenes across 5 Chronological Chapters (10–12 Minutes)
 * - 108 Dedicated Visual Beats timed for rapid visual cuts (~5.5s per cut)
 * - Compelling, dramatic, authoritative voiceover narration
 * - Standalone 2D Image Prompts for every scene using the exact prompt formula
 * - 3 High-CTR YouTube Thumbnail Concepts with bold text overlays
 */

const fs = require('fs');
const path = require('path');
const historyBuilder = require('../utils/historical-screenplay-builder.js');

class HermesScreenwriter {
  constructor() {
    this.name = 'Hermes-Screenwriter';
    this.version = '6.0.0';
  }

  async writeFullScript(topicDossier) {
    console.log(`[${this.name}] ✍️ Crafting 24-Scene / 108-Beat Historical Documentary Screenplay for "${topicDossier.title}"...`);
    
    // Build master 24-scene / 108-beat historical screenplay
    const screenplay = historyBuilder.buildHistoricalDocumentaryScreenplay(topicDossier);
    
    const outputPath = path.join(__dirname, '../assets/screenplay.json');
    fs.writeFileSync(outputPath, JSON.stringify(screenplay, null, 2), 'utf8');
    
    console.log(`[${this.name}] ✅ Master Screenplay generated: 24 scenes, ${screenplay.beats.length} visual cuts (${screenplay.meta.formattedDuration})`);
    console.log(`[${this.name}] 📁 Saved to: ${outputPath}`);
    
    return screenplay;
  }
}

module.exports = new HermesScreenwriter();
