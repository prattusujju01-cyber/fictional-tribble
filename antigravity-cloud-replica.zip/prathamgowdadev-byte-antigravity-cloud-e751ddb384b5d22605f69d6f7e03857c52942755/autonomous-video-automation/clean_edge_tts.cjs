const fs = require('fs');
const path = require('path');

const srcPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\utils\\edge_tts_internal\\dist\\index.mjs';
const outPath = 'C:\\Users\\WINDOWS\\.gemini\\antigravity\\scratch\\youtube-automation-agent\\utils\\clean-edge-tts.mjs';

let code = fs.readFileSync(srcPath, 'utf8');

// Replace external dependency imports with built-ins or exact paths
code = code.replace('import{HttpsProxyAgent as S0}from"https-proxy-agent";', 'class S0 {};');
code = code.replace('import{HttpsProxyAgent as N0}from"https-proxy-agent";', 'class N0 {};');
code = code.replace('import F0 from"ws";', 'import F0 from "file:///C:/Users/WINDOWS/.gemini/antigravity/scratch/node_modules/ws/index.js";');
code = code.replace('import{v4 as E0}from"uuid";', 'import * as cryptoUtil from "crypto"; const E0 = () => cryptoUtil.randomUUID();');
code = code.replace('import o from"axios";', 'const o = { get: async (url, opts) => { const res = await fetch(url, { headers: opts.headers }); return { status: res.status, headers: Object.fromEntries(res.headers.entries()), data: await res.json().catch(() => ({})) }; } };');

fs.writeFileSync(outPath, code, 'utf8');
console.log('✅ Clean Edge TTS written with direct ws import to:', outPath);
