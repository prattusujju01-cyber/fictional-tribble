# Antigravity Codespaces Pro (v5.0.8) — Antigravity 2.0 UI Extension

Enterprise multi-account GitHub Codespaces manager ported from `nirbhay-hiwse.antigravity-codespaces-5.0.8.vsix` to a native **Antigravity 2.0 UI Extension Plugin**.

## Features

- **Multi-Account Discovery & Switching**: Automatically detects local GitHub CLI (`gh`) accounts and supports Personal Access Tokens (`ghp_...` / `github_pat_...`) across multiple GitHub accounts.
- **Full Container Lifecycle Control**: Start, Stop, Rebuild (Cached or Full Clean Rebuild), Create, and Delete GitHub Codespaces directly from the Antigravity 2.0 side pane.
- **Zero-CLI Direct REST Engine + CLI Fallback**: Communicates directly with the GitHub REST API (`https://api.github.com`) for sub-second container listing, start, stop, creation, and deletion, with automatic fallback to `gh` CLI.
- **Automatic `~/.ssh/config` Sync & Hardening**: Generates deduplicated, injection-safe `Host cs.<name>` entries with `ServerAliveInterval` and `ServerAliveCountMax` keepalives to prevent WebSocket drops during AI agent sessions.
- **SSH Latency Probe & System Doctor**: Built-in environment diagnostics (`gh` CLI, OpenSSH client, account scopes) and live round-trip SSH tunnel latency testing.
- **Agent Integration**: Send Codespace connection context, SSH commands, or troubleshooting requests directly to your active Antigravity conversation in one click.
