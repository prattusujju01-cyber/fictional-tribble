// Antigravity Codespaces Pro (v5.0.8) — Native Antigravity 2.0 Sidecar Backend
// Ported from nirbhay-hiwse.antigravity-codespaces-5.0.8.vsix

import { execFile, execSync } from 'node:child_process';
import { chmodSync, copyFileSync, existsSync, mkdirSync, readFileSync, renameSync, writeFileSync } from 'node:fs';
import { homedir, platform, release } from 'node:os';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { Response, SidecarApp } from 'sidecar_sdk';

const HERE = dirname(fileURLToPath(import.meta.url));
const DATA_DIR = process.env.ANTIGRAVITY_EXECUTABLE_DATA_DIR || join(HERE, '.data');
const STATE_FILE = join(DATA_DIR, 'codespaces-state.json');
const STARTED_AT = Date.now();

const SSH_DIR = join(homedir(), '.ssh');
const SSH_CONFIG_PATH = join(SSH_DIR, 'config');
const GITHUB_API_BASE = 'https://api.github.com';
const API_HEADERS = {
  'Accept': 'application/vnd.github+json',
  'X-GitHub-Api-Version': '2022-11-28',
  'User-Agent': 'Antigravity-Codespaces-Pro'
};

// ---------------------------------------------------------------------------
// Utilities (ported from src/utils.js)
// ---------------------------------------------------------------------------

function friendlyError(err) {
  if (!err) return 'Unknown error occurred.';
  let msg = typeof err === 'string' ? err : (err.message || String(err));
  if (msg.includes('Flag shorthand -r has been deprecated')) {
    msg = msg.replace(/Flag shorthand -r has been deprecated[^\n]*\n?/g, '').trim();
  }
  if (msg.includes('needs the "codespace" scope') || msg.includes('Must have admin rights to Repository') || msg.includes('lack the "codespace"')) {
    return 'GitHub account is missing the "codespace" permission. Run "gh auth refresh -h github.com -s codespace" in terminal or sign in with a PAT.';
  }
  if (msg.includes('error getting machine type') || msg.includes('no terminal')) {
    return 'Could not determine Codespace machine type in non-interactive mode. Please specify a machine tier.';
  }
  if (msg.includes('not recognized') || msg.includes('ENOENT') || msg.includes('command not found')) {
    return 'GitHub CLI (gh) is not installed or not found in system PATH. Install gh CLI or authenticate using a Personal Access Token (PAT).';
  }
  if (msg.includes('authentication') || msg.includes('Bad credentials') || msg.includes('401')) {
    return 'GitHub authentication expired or token is invalid. Please sign in again.';
  }
  if (msg.includes('not found') || msg.includes('404')) {
    return 'Codespace not found for this account. Verify ownership at github.com/codespaces or switch active GitHub account.';
  }
  if (msg.includes('timed out while waiting for the codespace to start') || msg.includes('timed out while waiting')) {
    return 'The container is still booting — cold starts can take up to a minute. Press Start, wait for RUNNING, then retry.';
  }
  if (msg.includes('failed to start SSH server') || (msg.includes('SSH server') && msg.includes('check if'))) {
    return 'No SSH server inside the container. Add "ghcr.io/devcontainers/features/sshd:1" to devcontainer.json features and rebuild.';
  }
  if (msg.includes('255') || msg.includes('closed unexpectedly') || msg.includes('Connection closed')) {
    return 'SSH tunnel dropped unexpectedly. Ensure the machine is RUNNING and that your active gh CLI account owns it.';
  }
  if (msg.includes('rate limit') || msg.includes('rate_limit') || msg.includes('abuse')) {
    return 'GitHub API rate limit reached. Wait a few minutes, then refresh.';
  }
  if (msg.includes('billing') || msg.includes('quota') || msg.includes('exceeded')) {
    return 'GitHub Codespaces spending or quota limit reached. Check your GitHub billing settings.';
  }
  if (msg.includes('403') && (msg.includes('denied') || msg.includes('forbidden') || msg.includes('scope'))) {
    return 'GitHub access denied (HTTP 403). Check that your token has Codespaces permissions and billing enabled.';
  }
  if (msg.includes('EAI_AGAIN') || msg.includes('ENOTFOUND') || msg.includes('ECONNREFUSED') || msg.includes('network') || msg.includes('fetch failed')) {
    return 'Network unreachable. Check your internet connection, proxy, or corporate firewall.';
  }
  if (msg.includes('Timed out') || msg.includes('timed out')) {
    return 'Operation timed out. The cloud container may still be working — please try again in a few moments.';
  }
  return msg.length > 300 ? msg.slice(0, 300) + '…' : msg;
}

function runCommand(cmd, args = [], timeoutMs = 15000, options = {}) {
  return new Promise((resolve, reject) => {
    const spawnOpts = { windowsHide: true, ...options };
    let child;
    try {
      child = execFile(cmd, args, { ...spawnOpts, timeout: timeoutMs }, (err, stdout, stderr) => {
        if (!err) return resolve((stdout || '').trim());
        const detail = (stderr || '').trim() || (stdout || '').trim() || err.message || '';
        const killed = err.killed || err.signal === 'SIGTERM';
        const timedOut = killed || /timed out|ETIMEDOUT/i.test(err.message || '');
        if (timedOut) {
          return reject(new Error(`Timed out (${timeoutMs / 1000}s): ${cmd} ${(args || []).join(' ')}${detail ? ` — ${detail}` : ''}`));
        }
        reject(new Error(detail || `Command failed with exit code ${err.code}`));
      });
    } catch (spawnErr) {
      reject(spawnErr);
      return;
    }
    const guard = setTimeout(() => {
      try {
        if (child && !child.killed && child.exitCode === null) child.kill('SIGTERM');
      } catch {}
    }, timeoutMs + 2000);
    if (guard.unref) guard.unref();
    const clear = () => clearTimeout(guard);
    child.on('exit', clear);
    child.on('error', clear);
  });
}

// ---------------------------------------------------------------------------
// Persistent State Store
// ---------------------------------------------------------------------------

const DEFAULT_SETTINGS = {
  autoSyncSSHOnStartup: true,
  serverAliveInterval: 30,
  serverAliveCountMax: 10,
  defaultRemoteFolder: '/workspaces/${repo}'
};

function loadState() {
  if (!existsSync(STATE_FILE)) {
    return { activeAccount: '', pats: {}, settings: { ...DEFAULT_SETTINGS } };
  }
  try {
    const raw = JSON.parse(readFileSync(STATE_FILE, 'utf8'));
    return {
      activeAccount: typeof raw.activeAccount === 'string' ? raw.activeAccount : '',
      pats: (raw.pats && typeof raw.pats === 'object') ? raw.pats : {},
      settings: { ...DEFAULT_SETTINGS, ...(raw.settings || {}) }
    };
  } catch (err) {
    console.error(`Failed to read state file ${STATE_FILE}:`, err.message);
    return { activeAccount: '', pats: {}, settings: { ...DEFAULT_SETTINGS } };
  }
}

function saveState(state) {
  mkdirSync(DATA_DIR, { recursive: true });
  writeFileSync(STATE_FILE, JSON.stringify(state, null, 2), 'utf8');
}

// ---------------------------------------------------------------------------
// SSH Manager (ported from src/sshManager.js)
// ---------------------------------------------------------------------------

const CS_NAME_ALLOWLIST = /^[a-zA-Z0-9][a-zA-Z0-9_-]*$/;

function getSshConfigPath() {
  return process.env.ANTIGRAVITY_SSH_CONFIG || SSH_CONFIG_PATH;
}

function sanitizeCsName(name) {
  const s = String(name || '').trim();
  if (!CS_NAME_ALLOWLIST.test(s) || s.length > 128) {
    throw new Error(`Refusing to write SSH config for unexpected Codespace name: ${JSON.stringify(s.slice(0, 60))}`);
  }
  return s;
}

function escapeRegExp(s) {
  return String(s).replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

function purgeLegacyBlocks(cfgText) {
  let cfg = String(cfgText || '');
  let removedBlocks = 0;
  let removedKeys = 0;

  const isMarker = (l) => /^\s*#\s*(END_)?CS_ENTRY:/.test(l);
  const isEndMarker = (l) => /^\s*#\s*END_CS_ENTRY:/.test(l);
  const isHost = (l) => /^\s*Host\s+/i.test(l);
  const lines = cfg.split(/\r?\n/);
  const out = [];
  let i = 0;
  while (i < lines.length) {
    if (isMarker(lines[i]) && !isEndMarker(lines[i])) {
      const startName = lines[i].trim().replace(/^#\s*CS_ENTRY:\s*/, '').split(/\s/)[0];
      const wantEnd = `# END_CS_ENTRY:${startName}`;
      let k = i + 1;
      while (k < lines.length && lines[k].trim() !== wantEnd) k++;
      if (k < lines.length) {
        while (i <= k) out.push(lines[i++]);
        continue;
      }
      out.push(lines[i++]);
      continue;
    }
    if (isHost(lines[i])) {
      let j = i + 1;
      while (j < lines.length && !isHost(lines[j]) && !isMarker(lines[j])) j++;
      const block = lines.slice(i, j).join('\n');
      if (/ProxyCommand.*\bgh(\.exe)?["']?\s+cs\s+ssh\b/i.test(block)) {
        removedBlocks++;
        if (out.length && /^#\s*CS_ENTRY:/.test(out[out.length - 1].trim())) out.pop();
        i = j;
        continue;
      }
    }
    out.push(lines[i]);
    i++;
  }
  cfg = out.join('\n').replace(/\n{4,}/g, '\n\n\n');
  return { cfg, removedBlocks, removedKeys };
}

function cleanSshConfigFile() {
  try {
    const sshConfigPath = getSshConfigPath();
    if (!existsSync(sshConfigPath)) return { cleaned: true, removedBlocks: 0, removedKeys: 0 };
    const original = readFileSync(sshConfigPath, 'utf8');
    const { cfg, removedBlocks, removedKeys } = purgeLegacyBlocks(original);
    if (!removedBlocks && !removedKeys) return { cleaned: true, removedBlocks: 0, removedKeys: 0 };
    try {
      copyFileSync(sshConfigPath, `${sshConfigPath}.pre-cleanup.bak`);
    } catch {}
    const tmpPath = `${sshConfigPath}.tmp`;
    writeFileSync(tmpPath, cfg, 'utf8');
    try { chmodSync(tmpPath, 0o600); } catch {}
    renameSync(tmpPath, sshConfigPath);
    return { cleaned: true, removedBlocks, removedKeys };
  } catch (err) {
    console.error('SSH config cleanup error:', err);
    return { cleaned: false, removedBlocks: 0, removedKeys: 0 };
  }
}

let _ghExeCache = null;
function _findGhExecutableUncached() {
  const plat = process.platform;
  try {
    const checkCmd = plat === 'win32' ? 'where.exe gh 2>nul' : 'which gh 2>/dev/null';
    const result = execSync(checkCmd, { encoding: 'utf8', stdio: ['pipe', 'pipe', 'ignore'] }).trim();
    const firstPath = result.split(/\r?\n/)[0].trim();
    if (firstPath && existsSync(firstPath)) return firstPath;
  } catch {}

  if (plat === 'win32') {
    const winCandidates = [
      join(homedir(), '.local', 'bin', 'gh.exe'),
      'C:\\Program Files\\GitHub CLI\\gh.exe',
      join(process.env.ProgramFiles || 'C:\\Program Files', 'GitHub CLI', 'gh.exe'),
      join(process.env['ProgramFiles(x86)'] || 'C:\\Program Files (x86)', 'GitHub CLI', 'gh.exe'),
      join(process.env.LOCALAPPDATA || '', 'Programs', 'GitHub CLI', 'gh.exe'),
      join(homedir(), 'scoop', 'shims', 'gh.exe'),
      'C:\\ProgramData\\chocolatey\\bin\\gh.exe'
    ];
    for (const p of winCandidates) {
      if (p && existsSync(p)) return p;
    }
    return 'gh.exe';
  }

  if (plat === 'darwin') {
    const macCandidates = ['/opt/homebrew/bin/gh', '/usr/local/bin/gh', join(homedir(), '.local/bin/gh')];
    for (const p of macCandidates) {
      if (p && existsSync(p)) return p;
    }
    return 'gh';
  }

  const linuxCandidates = ['/usr/bin/gh', '/usr/local/bin/gh', '/snap/bin/gh', join(homedir(), '.local/bin/gh')];
  for (const p of linuxCandidates) {
    if (p && existsSync(p)) return p;
  }
  return 'gh';
}

function findGhExecutable() {
  if (!_ghExeCache || (_ghExeCache === 'gh.exe' || _ghExeCache === 'gh') || !existsSync(_ghExeCache)) {
    _ghExeCache = _findGhExecutableUncached();
  }
  return _ghExeCache;
}

function ensureSSHConfigEntry(cs, account, settings = DEFAULT_SETTINGS) {
  const safeName = sanitizeCsName(cs && cs.name);
  try {
    const sshConfigPath = getSshConfigPath();
    const sshDir = dirname(sshConfigPath);
    if (!existsSync(sshDir)) {
      mkdirSync(sshDir, { recursive: true, mode: 0o700 });
    }

    const safeAccount = (account || cs.account || 'default').replace(/[^a-zA-Z0-9_-]/g, '-');
    const repoFull = String(cs.repository || '');
    const repoParts = repoFull.split('/').filter(Boolean);
    const ownerShort = (repoParts.length >= 2 ? repoParts[0] : '').replace(/[^a-zA-Z0-9_-]/g, '-').toLowerCase();
    const repoShort = ((cs.repository || cs.name).split('/').pop() || 'workspace').replace(/[^a-zA-Z0-9_-]/g, '-');
    const aliasBase = ownerShort ? `cs-${safeAccount}-${ownerShort}-${repoShort}` : `cs-${safeAccount}-${repoShort}`;
    const aliasLower = aliasBase.toLowerCase();
    const aliasExact = aliasBase;
    const exactHost = `cs.${safeName}`;

    const ghExe = findGhExecutable();
    const normalizedGhExe = ghExe.replace(/\\/g, '/');

    let cfg = existsSync(sshConfigPath) ? readFileSync(sshConfigPath, 'utf8') : '';
    const blockId = `# CS_ENTRY:${safeName}`;
    const endMarker = `# END_CS_ENTRY:${safeName}`;

    let aliveInterval = 30;
    let aliveMax = 10;
    const rawInterval = Number(settings.serverAliveInterval ?? 30);
    const rawMax = Number(settings.serverAliveCountMax ?? 10);
    if (Number.isFinite(rawInterval)) aliveInterval = Math.min(300, Math.max(5, Math.trunc(rawInterval)));
    if (Number.isFinite(rawMax)) aliveMax = Math.min(100, Math.max(1, Math.trunc(rawMax)));

    const autoKeyPath = join(SSH_DIR, 'codespaces.auto').replace(/\\/g, '/');
    const identityLine = existsSync(join(SSH_DIR, 'codespaces.auto'))
      ? `  IdentityFile "${autoKeyPath}"\n`
      : '';
    const proxyExe = normalizedGhExe.includes(' ') ? `"${normalizedGhExe}"` : normalizedGhExe;
    const nullHosts = process.platform === 'win32' ? 'NUL' : '/dev/null';

    const newBlock = `
${blockId}
Host ${exactHost} ${aliasLower} ${aliasExact} ${safeName}
  User codespace
  ProxyCommand ${proxyExe} cs ssh -c ${safeName} --stdio
${identityLine}  UserKnownHostsFile ${nullHosts}
  StrictHostKeyChecking no
  LogLevel quiet
  ServerAliveInterval ${aliveInterval}
  ServerAliveCountMax ${aliveMax}
  TCPKeepAlive yes
${endMarker}
`;

    const newFormatRegex = new RegExp(`\\n*${escapeRegExp(blockId)}[\\s\\S]*?${escapeRegExp(endMarker)}[^\\n]*`, 'g');
    cfg = cfg.replace(newFormatRegex, '');
    if (cfg.includes(blockId)) {
      const legacyRegex = new RegExp(`\\n*${escapeRegExp(blockId)}[\\s\\S]*?TCPKeepAlive yes[^\\n]*`, 'g');
      cfg = cfg.replace(legacyRegex, '');
    }

    cfg = cfg.trim() + '\n\n' + newBlock.trim() + '\n';
    const tmpPath = sshConfigPath + '.tmp';
    try {
      if (existsSync(sshConfigPath)) {
        copyFileSync(sshConfigPath, sshConfigPath + '.bak');
      }
    } catch {}
    writeFileSync(tmpPath, cfg, 'utf8');
    try { chmodSync(tmpPath, 0o600); } catch {}
    renameSync(tmpPath, sshConfigPath);

    return {
      hostAlias: exactHost,
      aliasShort: aliasLower,
      sshCommand: `ssh ${exactHost}`,
      ghSshCommand: `gh cs ssh -c ${safeName}`,
      sshConfigPath
    };
  } catch (err) {
    console.error('SSH config generation error:', err);
    return {
      hostAlias: `cs.${safeName}`,
      aliasShort: safeName,
      sshCommand: `ssh cs.${safeName}`,
      ghSshCommand: `gh cs ssh -c ${safeName}`,
      sshConfigPath: getSshConfigPath()
    };
  }
}

async function testSshTunnel(csName, token) {
  const safeName = sanitizeCsName(csName);
  const ghExe = findGhExecutable();
  const envOpts = token ? { env: { ...process.env, GH_TOKEN: token } } : {};
  const start = Date.now();
  await runCommand(ghExe, ['cs', 'ssh', '-c', safeName, '--', 'echo', 'ping_ok'], 20000, envOpts);
  return Date.now() - start;
}

// ---------------------------------------------------------------------------
// Auth Manager (ported from src/authManager.js)
// ---------------------------------------------------------------------------

class AuthManager {
  constructor() {
    this._tokenCache = new Map();
    this._patValidity = new Map();
    const state = loadState();
    this._activeAccount = state.activeAccount || '';
    this._accounts = [];
  }

  clearCache() {
    this._tokenCache.clear();
    this._patValidity.clear();
    this._accounts = [];
  }

  getActiveAccount() {
    return this._activeAccount;
  }

  _syncGhHostsYml(state) {
    try {
      const pats = state.pats || {};
      const accounts = Object.keys(pats);
      if (accounts.length === 0) return;
      const active = (state.activeAccount && pats[state.activeAccount]) ? state.activeAccount : accounts[0];
      const activeToken = pats[active];
      const ghDir = process.platform === 'win32'
        ? join(process.env.APPDATA || join(homedir(), 'AppData', 'Roaming'), 'GitHub CLI')
        : join(homedir(), '.config', 'gh');
      mkdirSync(ghDir, { recursive: true });
      const usersLines = accounts.map(acc => `        ${acc}:\n            oauth_token: ${pats[acc]}`).join('\n');
      const yaml = `github.com:\n    oauth_token: ${activeToken}\n    user: ${active}\n    git_protocol: https\n    users:\n${usersLines}\n`;
      writeFileSync(join(ghDir, 'hosts.yml'), yaml, 'utf8');
    } catch (err) {
      console.warn('Could not sync gh hosts.yml:', err.message);
    }
  }

  setActiveAccount(account) {
    this._activeAccount = account || '';
    const state = loadState();
    state.activeAccount = this._activeAccount;
    saveState(state);
    this._syncGhHostsYml(state);
  }

  getSettings() {
    return loadState().settings;
  }

  updateSettings(partial) {
    const state = loadState();
    state.settings = { ...state.settings, ...partial };
    saveState(state);
    return state.settings;
  }

  async verifyPat(token) {
    let res;
    try {
      res = await fetch(`${GITHUB_API_BASE}/user`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Accept': 'application/vnd.github+json',
          'User-Agent': 'Antigravity-Codespaces'
        },
        signal: AbortSignal.timeout(8000)
      });
    } catch {
      throw new Error('GitHub is unreachable. Check your internet connection, proxy, or firewall.');
    }
    if (res.status === 429) {
      throw new Error('GitHub API rate limit reached. Wait a few minutes and try again.');
    }
    if (!res.ok) return null;
    try {
      return await res.json();
    } catch {
      return null;
    }
  }

  async savePat(rawPat) {
    const cleanPat = String(rawPat || '').trim();
    if (!cleanPat || (!cleanPat.startsWith('ghp_') && !cleanPat.startsWith('github_pat_') && !cleanPat.startsWith('gho_'))) {
      throw new Error('Token must begin with ghp_, github_pat_, or gho_');
    }
    const user = await this.verifyPat(cleanPat);
    if (!user || !user.login) {
      throw new Error('Invalid Personal Access Token. Could not authenticate with GitHub.');
    }
    const state = loadState();
    state.pats[user.login] = cleanPat;
    state.activeAccount = user.login;
    saveState(state);
    this._syncGhHostsYml(state);

    this._activeAccount = user.login;
    this._tokenCache.set(user.login, cleanPat);
    this._patValidity.set(user.login, Date.now());
    return user.login;
  }

  async logout(account) {
    const state = loadState();
    if (account) {
      this._tokenCache.delete(account);
      this._patValidity.delete(account);
      delete state.pats[account];
      if (this._activeAccount === account) {
        this._activeAccount = '';
        state.activeAccount = '';
      }
    } else {
      this._tokenCache.clear();
      this._patValidity.clear();
      state.pats = {};
      this._activeAccount = '';
      state.activeAccount = '';
    }
    saveState(state);
  }

  async getAccounts() {
    const discovered = [];
    const seenNames = new Set();
    const state = loadState();

    // 1. Check Stored PATs
    const patEntries = Object.entries(state.pats || {});
    for (const [storedLogin, storedPat] of patEntries) {
      if (!storedPat || seenNames.has(storedLogin)) continue;
      const validity = this._patValidity.get(storedLogin);
      if (validity && (Date.now() - validity < 10 * 60 * 1000)) {
        discovered.push({ account: storedLogin, type: 'pat', active: false, hasCodespaceScope: true });
        seenNames.add(storedLogin);
        this._tokenCache.set(storedLogin, storedPat);
        continue;
      }
      try {
        const userRes = await this.verifyPat(storedPat);
        const login = (userRes && userRes.login) ? userRes.login : storedLogin;
        if (!seenNames.has(login)) {
          discovered.push({ account: login, type: 'pat', active: false, hasCodespaceScope: true });
          seenNames.add(login);
          this._tokenCache.set(login, storedPat);
          this._patValidity.set(login, Date.now());
        }
      } catch {
        discovered.push({ account: storedLogin, type: 'pat', active: false, hasCodespaceScope: true });
        seenNames.add(storedLogin);
        this._tokenCache.set(storedLogin, storedPat);
      }
    }

    // 2. Check Local GitHub CLI (if installed)
    let cliActive = '';
    try {
      const ghExe = findGhExecutable();
      const rawStatus = await new Promise((resolve) => {
        execFile(ghExe, ['auth', 'status'], { timeout: 7000, windowsHide: true }, (err, stdout, stderr) => {
          resolve((stdout || '') + '\n' + (stderr || ''));
        });
      });

      const accountBlocks = rawStatus.split(/Logged in to /i).slice(1);
      for (const block of accountBlocks) {
        const nameMatch = block.match(/github\.com account ([A-Za-z0-9_\-.]+)/i);
        if (!nameMatch) continue;
        const acc = nameMatch[1];
        const isActive = /Active account:\s*true/i.test(block);
        const hasCodespaceScope = /Token scopes:[^\n]*'codespace'/i.test(block);

        if (isActive) cliActive = acc;
        if (!seenNames.has(acc)) {
          discovered.push({
            account: acc,
            type: 'cli',
            active: isActive,
            hasCodespaceScope
          });
          seenNames.add(acc);
        }
      }

      if (!this._activeAccount && cliActive) {
        this._activeAccount = cliActive;
      }
    } catch {}

    if (!this._activeAccount && discovered.length > 0) {
      this._activeAccount = cliActive && discovered.some(a => a.account === cliActive)
        ? cliActive
        : discovered[0].account;
    }

    for (const item of discovered) {
      item.active = (item.account === this._activeAccount);
    }

    this._accounts = discovered;
    return discovered;
  }

  async getToken(account) {
    const target = account || this._activeAccount;
    if (!target) return null;

    if (this._tokenCache.has(target)) {
      return this._tokenCache.get(target);
    }

    const state = loadState();
    if (state.pats && state.pats[target]) {
      this._tokenCache.set(target, state.pats[target]);
      return state.pats[target];
    }

    try {
      const ghExe = findGhExecutable();
      const raw = await runCommand(ghExe, ['auth', 'token', '-u', target], 6000);
      const cleanToken = (raw || '').split(/\s+/)[0].trim();
      if (cleanToken && cleanToken.length > 10 && !/error|timed out/i.test(cleanToken)) {
        this._tokenCache.set(target, cleanToken);
        return cleanToken;
      }
    } catch {}

    return null;
  }
}

// ---------------------------------------------------------------------------
// GitHub API Client (ported from src/githubApi.js)
// ---------------------------------------------------------------------------

class GithubApi {
  constructor(authManager) {
    this._authManager = authManager;
    this._csCache = new Map();
    this._metaCache = new Map();
    this._portsCache = new Map();
  }

  clearCache() {
    this._csCache.clear();
    this._metaCache.clear();
    this._portsCache.clear();
  }

  static get TTL_CS() { return 30 * 1000; }
  static get TTL_META() { return 60 * 1000; }
  static get TTL_PORTS() { return 15 * 1000; }

  _csKey(account) {
    const resolved = account || (this._authManager && this._authManager.getActiveAccount()) || 'default';
    return `cs:${resolved}`;
  }

  _scopedKey(account, name) {
    const resolved = account || (this._authManager && this._authManager.getActiveAccount()) || '';
    return `${resolved}:${name}`;
  }

  _getFresh(map, key, ttl) {
    const entry = map.get(key);
    if (!entry) return undefined;
    if (Date.now() - entry.at > ttl) {
      map.delete(key);
      return undefined;
    }
    return entry.data;
  }

  _setFresh(map, key, data) {
    map.set(key, { data, at: Date.now() });
  }

  _invalidateCs(account) {
    this._csCache.delete(this._csKey(account));
  }

  async _fetchAllPages(baseUrl, token, maxPages = 5) {
    const out = [];
    for (let page = 1; page <= maxPages; page++) {
      const sep = baseUrl.includes('?') ? '&' : '?';
      const res = await fetch(`${baseUrl}${sep}per_page=100&page=${page}`, {
        headers: { ...API_HEADERS, 'Authorization': `Bearer ${token}` }
      });
      if (res.status === 401) throw new Error('GitHub authentication expired or token is invalid. Please sign in again.');
      if (res.status === 429) throw new Error('GitHub API rate limit reached. Wait a few minutes, then refresh.');
      if (!res.ok) return { items: out, incomplete: true, status: res.status };
      const data = await res.json();
      const items = Array.isArray(data) ? data : (data.codespaces || []);
      out.push(...items);
      if (items.length < 100) break;
    }
    return { items: out, incomplete: false, status: 200 };
  }

  async listCodespaces(account) {
    let restErr = null;
    const cacheKey = this._csKey(account);
    const cached = this._getFresh(this._csCache, cacheKey, GithubApi.TTL_CS);
    if (cached !== undefined) return cached;

    const token = await this._authManager.getToken(account);

    if (token) {
      try {
        const { items, incomplete, status } = await this._fetchAllPages(`${GITHUB_API_BASE}/user/codespaces`, token, 5);
        if (!incomplete) {
          const list = items.map(cs => ({
            name: cs.name,
            displayName: cs.display_name || cs.name,
            repository: cs.repository ? cs.repository.full_name : '',
            gitStatus: {
              ref: cs.git_status?.ref || '',
              ahead: cs.git_status?.ahead || 0,
              behind: cs.git_status?.behind || 0,
              hasUncommittedChanges: cs.git_status?.has_uncommitted_changes || false,
              hasUnpushedChanges: cs.git_status?.has_unpushed_changes || false
            },
            state: cs.state,
            lastUsedAt: cs.last_used_at,
            machineName: cs.machine?.name || '',
            machineDisplayName: cs.machine?.display_name || '2 vCPU, 8 GB RAM',
            location: cs.location || '',
            idleTimeoutMinutes: cs.idle_timeout_minutes || 30,
            webUrl: `https://github.com/codespaces/${cs.name}`,
            account: account
          }));

          this.sortCodespaces(list);
          this._setFresh(this._csCache, cacheKey, list);
          return list;
        }
        restErr = new Error(status === 403
          ? 'Access denied (HTTP 403). The account token may lack the "codespace" OAuth permission.'
          : `GitHub REST API returned HTTP ${status}`);
      } catch (err) {
        if (/authentication expired|rate limit/i.test(err.message || '')) throw err;
        restErr = err;
      }
    }

    try {
      const ghExe = findGhExecutable();
      const envOpts = token ? { env: { ...process.env, GH_TOKEN: token } } : {};
      const raw = await runCommand(ghExe, [
        'codespace', 'list',
        '--json', 'name,displayName,repository,gitStatus,state,lastUsedAt,machineName'
      ], 12000, envOpts);

      const list = JSON.parse(raw || '[]').map(c => ({
        ...c,
        webUrl: `https://github.com/codespaces/${c.name}`,
        account
      }));
      this.sortCodespaces(list);
      this._setFresh(this._csCache, cacheKey, list);
      return list;
    } catch (cliErr) {
      throw GithubApi.buildListError(account, restErr, cliErr);
    }
  }

  static buildListError(account, restErr, cliErr) {
    const who = account || 'active account';
    const raw = `${restErr?.message || ''} ${cliErr?.message || ''}`.trim();
    if (/needs the "codespace" scope|Must have admin rights|lack the "codespace"/i.test(raw)) {
      return new Error(`Account "${who}" is missing the "codespace" permission. Run "gh auth refresh -h github.com -s codespace" or authenticate with a PAT.`);
    }
    const cause = restErr?.message || cliErr?.message || 'unknown error';
    return new Error(`Couldn't load Codespaces for "${who}": ${cause}`);
  }

  sortCodespaces(list) {
    list.sort((a, b) => {
      if (a.state === 'Available' && b.state !== 'Available') return -1;
      if (b.state === 'Available' && a.state !== 'Available') return 1;
      const ta = new Date(b.lastUsedAt || 0).getTime();
      const tb = new Date(a.lastUsedAt || 0).getTime();
      if (Number.isFinite(ta) && Number.isFinite(tb)) return ta - tb;
      return 0;
    });
  }

  async startCodespace(name, account) {
    const token = await this._authManager.getToken(account);
    if (token) {
      try {
        const res = await fetch(`${GITHUB_API_BASE}/user/codespaces/${encodeURIComponent(name)}/start`, {
          method: 'POST',
          headers: { ...API_HEADERS, 'Authorization': `Bearer ${token}` }
        });
        if (res.ok || res.status === 409) {
          this._invalidateCs(account);
          return true;
        }
        if (res.status === 401) {
          throw new Error('GitHub authentication expired or token is invalid. Please sign in again.');
        }
      } catch (err) {
        if (/authentication expired/i.test(err.message || '')) throw err;
      }
    }

    const ghExe = findGhExecutable();
    const envOpts = token ? { env: { ...process.env, GH_TOKEN: token } } : {};
    await runCommand(ghExe, ['api', '-X', 'POST', `/user/codespaces/${encodeURIComponent(name)}/start`], 120000, envOpts);
    this._invalidateCs(account);
    return true;
  }

  async stopCodespace(name, account) {
    const token = await this._authManager.getToken(account);
    if (token) {
      try {
        const res = await fetch(`${GITHUB_API_BASE}/user/codespaces/${encodeURIComponent(name)}/stop`, {
          method: 'POST',
          headers: { ...API_HEADERS, 'Authorization': `Bearer ${token}` }
        });
        if (res.ok || res.status === 409) {
          this._invalidateCs(account);
          return true;
        }
        if (res.status === 401) {
          throw new Error('GitHub authentication expired or token is invalid. Please sign in again.');
        }
      } catch (err) {
        if (/authentication expired/i.test(err.message || '')) throw err;
      }
    }

    const ghExe = findGhExecutable();
    const envOpts = token ? { env: { ...process.env, GH_TOKEN: token } } : {};
    await runCommand(ghExe, ['codespace', 'stop', '-c', name], 30000, envOpts);
    this._invalidateCs(account);
    return true;
  }

  async deleteCodespace(name, account) {
    const token = await this._authManager.getToken(account);
    if (token) {
      try {
        const res = await fetch(`${GITHUB_API_BASE}/user/codespaces/${encodeURIComponent(name)}`, {
          method: 'DELETE',
          headers: { ...API_HEADERS, 'Authorization': `Bearer ${token}` }
        });
        if (res.ok || res.status === 204) {
          this._invalidateCs(account);
          return true;
        }
        if (res.status === 401) {
          throw new Error('GitHub authentication expired or token is invalid. Please sign in again.');
        }
      } catch (err) {
        if (/authentication expired/i.test(err.message || '')) throw err;
      }
    }

    const ghExe = findGhExecutable();
    const envOpts = token ? { env: { ...process.env, GH_TOKEN: token } } : {};
    await runCommand(ghExe, ['codespace', 'delete', '-c', name, '--force'], 30000, envOpts);
    this._invalidateCs(account);
    return true;
  }

  async rebuildCodespace(name, account, full = false) {
    const token = await this._authManager.getToken(account);
    const ghExe = findGhExecutable();
    const envOpts = token ? { env: { ...process.env, GH_TOKEN: token } } : {};
    const args = ['codespace', 'rebuild', '-c', name, ...(full ? ['--full'] : [])];
    await runCommand(ghExe, args, 180000, envOpts);
    this._invalidateCs(account);
    return true;
  }

  async fetchPorts(name, account) {
    const cacheKey = this._scopedKey(account, name);
    const cached = this._getFresh(this._portsCache, cacheKey, GithubApi.TTL_PORTS);
    if (cached !== undefined) return cached;

    const token = await this._authManager.getToken(account);
    try {
      const ghExe = findGhExecutable();
      const envOpts = token ? { env: { ...process.env, GH_TOKEN: token } } : {};
      const raw = await runCommand(ghExe, ['codespace', 'ports', '-c', name, '--json', 'sourcePort,label,visibility,browseUrl'], 7000, envOpts);
      const parsed = JSON.parse(raw || '[]');
      const p = Array.isArray(parsed) ? parsed : [];
      this._setFresh(this._portsCache, cacheKey, p);
      return p;
    } catch {
      return [];
    }
  }

  async fetchMeta(name, account) {
    const cacheKey = this._scopedKey(account, name);
    const cached = this._getFresh(this._metaCache, cacheKey, GithubApi.TTL_META);
    if (cached !== undefined) return cached;

    const token = await this._authManager.getToken(account);
    if (token) {
      try {
        const res = await fetch(`${GITHUB_API_BASE}/user/codespaces/${encodeURIComponent(name)}`, {
          headers: { ...API_HEADERS, 'Authorization': `Bearer ${token}` }
        });
        if (res.ok) {
          const cs = await res.json();
          const m = {
            displayName: cs.display_name || cs.name,
            name: cs.name,
            repository: cs.repository?.full_name || '',
            state: cs.state,
            machineDisplayName: cs.machine?.display_name || cs.machine?.name || '2 vCPU, 8 GB RAM',
            machineName: cs.machine?.name || '',
            createdAt: cs.created_at,
            lastUsedAt: cs.last_used_at,
            idleTimeoutMinutes: cs.idle_timeout_minutes || 30,
            location: cs.location || '',
            account: account
          };
          this._setFresh(this._metaCache, cacheKey, m);
          return m;
        }
      } catch {}
    }

    return {};
  }

  async fetchUserRepos(account) {
    const token = await this._authManager.getToken(account);
    if (token) {
      try {
        const { items, incomplete } = await this._fetchAllPages(`${GITHUB_API_BASE}/user/repos?sort=updated`, token, 3);
        if (!incomplete || items.length > 0) {
          return items.map(r => ({
            name: r.name,
            nameWithOwner: r.full_name,
            isPrivate: r.private,
            description: r.description || ''
          }));
        }
      } catch (err) {
        if (/authentication expired|rate limit/i.test(err.message || '')) throw err;
      }
    }

    try {
      const ghExe = findGhExecutable();
      const envOpts = token ? { env: { ...process.env, GH_TOKEN: token } } : {};
      const raw = await runCommand(ghExe, [
        'repo', 'list', '--limit', '200',
        '--json', 'name,nameWithOwner,isPrivate,description'
      ], 12000, envOpts);
      const parsed = JSON.parse(raw || '[]');
      return Array.isArray(parsed) ? parsed : [];
    } catch {
      return [];
    }
  }

  static normalizeRepoInput(repo) {
    const cleanRepo = (repo || '').trim()
      .replace(/^https?:\/\/github\.com\//i, '')
      .replace(/^git@github\.com:/i, '')
      .replace(/\.git$/i, '')
      .replace(/^\/+|\/+$/g, '');
    const parts = cleanRepo.split('/').filter(Boolean);
    if (parts.length < 2) return { owner: '', repoName: '', cleanRepo };
    const [owner, repoName] = parts;
    if (!/^[a-zA-Z0-9_.-]+$/.test(owner) || !/^[a-zA-Z0-9_.-]+$/.test(repoName)) {
      return { owner: '', repoName: '', cleanRepo };
    }
    return { owner, repoName, cleanRepo: `${owner}/${repoName}` };
  }

  async createCodespace(repo, branch, account, machine = '') {
    const token = await this._authManager.getToken(account);
    const { owner, repoName, cleanRepo } = GithubApi.normalizeRepoInput(repo);
    if (!owner || !repoName) {
      throw new Error('Enter a repository in owner/repo format (e.g. octocat/Hello-World).');
    }
    const cleanBranch = (branch || '').trim();
    const chosenMachine = (machine || '').trim();

    if (token) {
      try {
        const body = {};
        if (cleanBranch) body.ref = cleanBranch;
        if (chosenMachine) body.machine = chosenMachine;
        const res = await fetch(`${GITHUB_API_BASE}/repos/${owner}/${repoName}/codespaces`, {
          method: 'POST',
          headers: {
            ...API_HEADERS,
            'Authorization': `Bearer ${token}`,
            'Content-Type': 'application/json'
          },
          body: JSON.stringify(body)
        });
        if (res.ok) {
          const newCs = await res.json();
          this._invalidateCs(account);
          return newCs.name;
        }
        const errJson = await res.json().catch(() => ({}));
        const apiMsg = errJson.message || `HTTP ${res.status}`;
        if (res.status === 401) throw new Error('GitHub authentication expired or token is invalid. Please sign in again.');
        if (res.status === 403) throw new Error(`Codespace creation denied (403): ${apiMsg}`);
        if (res.status === 404) throw new Error(`Repository "${cleanRepo}" not found or not accessible.`);
        if (res.status === 422) throw new Error(`Invalid parameters for "${cleanRepo}": ${apiMsg}`);
      } catch (err) {
        if (/authentication expired|owner\/repo format|creation denied|not found|Invalid parameters/i.test(err.message || '')) throw err;
      }
    }

    const ghExe = findGhExecutable();
    const envOpts = token ? { env: { ...process.env, GH_TOKEN: token } } : {};
    const args = ['codespace', 'create', '-R', cleanRepo, '--default-permissions'];
    if (cleanBranch) args.push('-b', cleanBranch);
    args.push('-m', chosenMachine || 'basicLinux32gb');

    try {
      const result = await runCommand(ghExe, args, 120000, envOpts);
      this._invalidateCs(account);
      return result;
    } catch (cliErr) {
      if (cliErr.message && cliErr.message.includes('basicLinux32gb')) {
        const retryArgs = ['codespace', 'create', '-R', cleanRepo, '--default-permissions'];
        if (cleanBranch) retryArgs.push('-b', cleanBranch);
        const retryResult = await runCommand(ghExe, retryArgs, 120000, envOpts);
        this._invalidateCs(account);
        return retryResult;
      }
      throw cliErr;
    }
  }
}

// ---------------------------------------------------------------------------
// System Doctor (ported from src/systemDoctor.js)
// ---------------------------------------------------------------------------

async function diagnoseEnvironment(authManager) {
  const plat = process.platform;
  const ghPath = findGhExecutable();
  let ghInstalled = false;
  let ghVersion = '';

  let ghPathExists = false;
  try { ghPathExists = existsSync(ghPath); } catch {}

  if (ghPathExists || ghPath === 'gh.exe' || ghPath === 'gh') {
    await new Promise((resolve) => {
      execFile(ghPath, ['--version'], { timeout: 4000, windowsHide: true }, (err, stdout) => {
        if (!err && stdout) {
          ghInstalled = true;
          const match = stdout.match(/gh version ([^\s]+)/);
          ghVersion = match ? match[1] : 'installed';
        }
        resolve();
      });
    });
  }

  let hasOpenSsh = false;
  await new Promise((resolve) => {
    const cmd = plat === 'win32' ? 'where.exe' : 'which';
    execFile(cmd, ['ssh'], { timeout: 3000, windowsHide: true }, (err) => {
      if (!err) hasOpenSsh = true;
      resolve();
    });
  });

  const accounts = await authManager.getAccounts();
  return {
    platform: `${platform()} ${release()}`,
    osPlatform: plat,
    node: process.version,
    uptimeSeconds: Math.round((Date.now() - STARTED_AT) / 1000),
    ghInstalled,
    ghVersion,
    ghPath,
    hasOpenSsh,
    sshConfigPath: getSshConfigPath(),
    hasAccounts: accounts.length > 0,
    accountCount: accounts.length
  };
}

// ---------------------------------------------------------------------------
// Sidecar Server Setup
// ---------------------------------------------------------------------------

const authManager = new AuthManager();
const githubApi = new GithubApi(authManager);
const app = new SidecarApp();

const readLocal = (name) => readFileSync(join(HERE, name), 'utf8');

app.page('/', () => readLocal('index.html'));
app.page('/app.js', () => readLocal('app.js'));
app.api('/styles.css', () => new Response(readLocal('styles.css'), { contentType: 'text/css' }), 'GET');

function jsonError(err, status = 400) {
  return new Response(JSON.stringify({ error: friendlyError(err), rawError: err?.message || String(err) }), {
    contentType: 'application/json',
    status
  });
}

async function buildBootstrapPayload(forceRefresh = false) {
  if (forceRefresh) {
    authManager.clearCache();
    githubApi.clearCache();
  }
  const diagnostics = await diagnoseEnvironment(authManager);
  const accounts = await authManager.getAccounts();
  const activeAccount = authManager.getActiveAccount() || (accounts[0]?.account ?? '');
  const settings = authManager.getSettings();

  let codespaces = [];
  let listError = null;
  if (activeAccount) {
    try {
      codespaces = await githubApi.listCodespaces(activeAccount);
    } catch (err) {
      listError = friendlyError(err);
    }
  }

  return {
    diagnostics,
    accounts,
    activeAccount,
    codespaces,
    settings,
    listError
  };
}

app.api('/api/bootstrap', async (data) => {
  try {
    return await buildBootstrapPayload(data?.refresh === 'true' || data?.refresh === true);
  } catch (err) {
    return jsonError(err, 500);
  }
}, 'GET');

app.api('/api/refresh', async () => {
  try {
    return await buildBootstrapPayload(true);
  } catch (err) {
    return jsonError(err, 500);
  }
}, 'POST');

app.api('/api/auth/pat', async (data) => {
  try {
    const login = await authManager.savePat(data?.pat);
    githubApi.clearCache();
    const payload = await buildBootstrapPayload(false);
    return { login, ...payload };
  } catch (err) {
    return jsonError(err, 400);
  }
}, 'POST');

app.api('/api/auth/switch', async (data) => {
  try {
    const target = String(data?.account || '').trim();
    if (!target) throw new Error('Account name is required.');
    authManager.setActiveAccount(target);
    const payload = await buildBootstrapPayload(false);
    return payload;
  } catch (err) {
    return jsonError(err, 400);
  }
}, 'POST');

app.api('/api/auth/logout', async (data) => {
  try {
    await authManager.logout(data?.account);
    githubApi.clearCache();
    return await buildBootstrapPayload(false);
  } catch (err) {
    return jsonError(err, 400);
  }
}, 'POST');

app.api('/api/codespaces/start', async (data) => {
  try {
    const name = String(data?.name || '').trim();
    const account = String(data?.account || authManager.getActiveAccount() || '').trim();
    if (!name) throw new Error('Codespace name is required.');
    await githubApi.startCodespace(name, account);
    return await buildBootstrapPayload(false);
  } catch (err) {
    return jsonError(err, 400);
  }
}, 'POST');

app.api('/api/codespaces/stop', async (data) => {
  try {
    const name = String(data?.name || '').trim();
    const account = String(data?.account || authManager.getActiveAccount() || '').trim();
    if (!name) throw new Error('Codespace name is required.');
    await githubApi.stopCodespace(name, account);
    return await buildBootstrapPayload(false);
  } catch (err) {
    return jsonError(err, 400);
  }
}, 'POST');

app.api('/api/codespaces/rebuild', async (data) => {
  try {
    const name = String(data?.name || '').trim();
    const account = String(data?.account || authManager.getActiveAccount() || '').trim();
    const full = Boolean(data?.full);
    if (!name) throw new Error('Codespace name is required.');
    await githubApi.rebuildCodespace(name, account, full);
    return await buildBootstrapPayload(false);
  } catch (err) {
    return jsonError(err, 400);
  }
}, 'POST');

app.api('/api/codespaces/delete', async (data) => {
  try {
    const name = String(data?.name || '').trim();
    const account = String(data?.account || authManager.getActiveAccount() || '').trim();
    if (!name) throw new Error('Codespace name is required.');
    await githubApi.deleteCodespace(name, account);
    return await buildBootstrapPayload(false);
  } catch (err) {
    return jsonError(err, 400);
  }
}, 'POST');

app.api('/api/codespaces/create', async (data) => {
  try {
    const repo = String(data?.repo || '').trim();
    const branch = String(data?.branch || '').trim();
    const machine = String(data?.machine || '').trim();
    const account = String(data?.account || authManager.getActiveAccount() || '').trim();
    const createdName = await githubApi.createCodespace(repo, branch, account, machine);
    const payload = await buildBootstrapPayload(false);
    return { createdName, ...payload };
  } catch (err) {
    return jsonError(err, 400);
  }
}, 'POST');

app.api('/api/codespaces/meta', async (data) => {
  try {
    const name = String(data?.name || '').trim();
    const account = String(data?.account || authManager.getActiveAccount() || '').trim();
    if (!name) throw new Error('Codespace name is required.');
    const [meta, ports] = await Promise.all([
      githubApi.fetchMeta(name, account),
      githubApi.fetchPorts(name, account)
    ]);
    const entry = ensureSSHConfigEntry(
      { name, repository: meta.repository || data?.repository || '' },
      account,
      authManager.getSettings()
    );
    return { name, meta, ports, ssh: entry };
  } catch (err) {
    return jsonError(err, 400);
  }
}, 'GET');

app.api('/api/repos', async (data) => {
  try {
    const account = String(data?.account || authManager.getActiveAccount() || '').trim();
    const repos = await githubApi.fetchUserRepos(account);
    return { account, repos };
  } catch (err) {
    return jsonError(err, 400);
  }
}, 'GET');

app.api('/api/ssh/sync', async () => {
  try {
    const cleaned = cleanSshConfigFile();
    const accounts = await authManager.getAccounts();
    const settings = authManager.getSettings();
    let syncedCount = 0;
    const entries = [];
    const failedAccounts = [];

    await Promise.all(accounts.map(async (acc) => {
      try {
        const list = await githubApi.listCodespaces(acc.account);
        for (const cs of list) {
          const entry = ensureSSHConfigEntry(cs, acc.account, settings);
          entries.push({ codespace: cs.name, account: acc.account, ...entry });
          syncedCount++;
        }
      } catch (err) {
        failedAccounts.push(`${acc.account} (${friendlyError(err)})`);
      }
    }));

    return {
      syncedCount,
      removedBlocks: cleaned.removedBlocks || 0,
      sshConfigPath: getSshConfigPath(),
      entries,
      failedAccounts
    };
  } catch (err) {
    return jsonError(err, 400);
  }
}, 'POST');

app.api('/api/ssh/entry', async (data) => {
  try {
    const name = String(data?.name || '').trim();
    const repository = String(data?.repository || '').trim();
    const account = String(data?.account || authManager.getActiveAccount() || '').trim();
    if (!name) throw new Error('Codespace name is required.');
    const entry = ensureSSHConfigEntry({ name, repository }, account, authManager.getSettings());
    return entry;
  } catch (err) {
    return jsonError(err, 400);
  }
}, 'POST');

app.api('/api/ssh/test', async (data) => {
  try {
    const name = String(data?.name || '').trim();
    const account = String(data?.account || authManager.getActiveAccount() || '').trim();
    if (!name) throw new Error('Codespace name is required.');
    const token = await authManager.getToken(account);
    const latencyMs = await testSshTunnel(name, token);
    return { name, account, latencyMs, healthy: true };
  } catch (err) {
    return jsonError(err, 400);
  }
}, 'POST');

app.api('/api/settings', async (data) => {
  try {
    const updated = authManager.updateSettings({
      autoSyncSSHOnStartup: Boolean(data?.autoSyncSSHOnStartup),
      serverAliveInterval: Math.min(300, Math.max(5, Number(data?.serverAliveInterval) || 30)),
      serverAliveCountMax: Math.min(100, Math.max(1, Number(data?.serverAliveCountMax) || 10)),
      defaultRemoteFolder: String(data?.defaultRemoteFolder || '/workspaces/${repo}').trim()
    });
    return { settings: updated };
  } catch (err) {
    return jsonError(err, 400);
  }
}, 'POST');

// Startup background SSH auto-sync
setTimeout(async () => {
  try {
    const settings = authManager.getSettings();
    if (settings.autoSyncSSHOnStartup) {
      cleanSshConfigFile();
      const accounts = await authManager.getAccounts();
      await Promise.all(accounts.map(async (acc) => {
        try {
          const list = await githubApi.listCodespaces(acc.account);
          list.forEach(cs => ensureSSHConfigEntry(cs, acc.account, settings));
        } catch {}
      }));
    }
  } catch {}
}, 1500);

app.run();
