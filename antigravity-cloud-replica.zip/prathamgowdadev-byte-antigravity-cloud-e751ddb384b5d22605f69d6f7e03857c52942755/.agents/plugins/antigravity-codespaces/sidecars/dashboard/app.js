// Antigravity Codespaces Pro (v5.0.8) — Frontend Sidecar Logic
// Communicates with main.mjs via window.sidecar.fetch and integrates with the
// active Antigravity conversation via window.sidecar.agent.

const sidecar = window.sidecar;
const $ = (id) => document.getElementById(id);

const SVG_ICONS = {
  ok: `<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><circle cx="8" cy="8" r="7.5" fill="#2ea043"/><path d="M4.5 8.2L6.8 10.5L11.5 5.8" stroke="#ffffff" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`,
  warn: `<svg width="15" height="15" viewBox="0 0 16 16" fill="none"><path d="M8 1.8L15 14H1L8 1.8Z" fill="#d29922"/><path d="M8 6V9.5" stroke="#ffffff" stroke-width="1.6" stroke-linecap="round"/><circle cx="8" cy="11.8" r="0.8" fill="#ffffff"/></svg>`,
  repo: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20"/><path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z"/></svg>`,
  branch: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><line x1="6" y1="3" x2="6" y2="15"/><circle cx="18" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><path d="M18 9a9 9 0 0 1-9 9"/></svg>`,
  server: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>`,
  clock: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><polyline points="12 6 12 12 16 14"/></svg>`,
  play: `<svg width="12" height="12" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>`,
  stop: `<svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor"><rect x="4" y="4" width="16" height="16" rx="2"/></svg>`,
  term: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="4 17 10 11 4 5"/><line x1="12" y1="19" x2="20" y2="19"/></svg>`,
  zap: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/></svg>`,
  wrench: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>`,
  globe: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>`,
  trash: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><polyline points="3 6 5 6 21 6"/><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"/></svg>`,
  info: `<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="16" x2="12" y2="12"/><line x1="12" y1="8" x2="12.01" y2="8"/></svg>`
};

let state = {
  accounts: [],
  activeAccount: '',
  codespaces: [],
  diagnostics: {},
  settings: {},
  filter: 'all',
  search: '',
  expandedMeta: new Map()
};

let toastTimer;
function toast(message, isError = false) {
  const el = $('toast');
  el.textContent = message;
  el.classList.toggle('error', isError);
  el.hidden = false;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { el.hidden = true; }, 3500);
}

function showErrorBanner(msg) {
  if (!msg) {
    $('error-banner').hidden = true;
    return;
  }
  $('error-banner-text').textContent = msg;
  $('error-banner').hidden = false;
}

function escapeHtml(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function formatRelativeTime(dateStr) {
  if (!dateStr) return 'N/A';
  const time = new Date(dateStr).getTime();
  if (!Number.isFinite(time)) return 'N/A';
  const diffMs = Date.now() - time;
  if (diffMs < 0) return 'just now';
  const m = Math.floor(diffMs / 60000);
  const h = Math.floor(m / 60);
  const d = Math.floor(h / 24);
  if (m < 1) return 'just now';
  if (m < 60) return `${m}m ago`;
  if (h < 24) return `${h}h ago`;
  return `${d}d ago`;
}

async function callApi(path, { method = 'GET', body } = {}) {
  const fetchFn = (sidecar && sidecar.fetch) ? sidecar.fetch.bind(sidecar) : window.fetch.bind(window);
  const res = await fetchFn(path, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body)
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `${res.status} ${res.statusText}`);
  }
  return data;
}

function applyPayload(data) {
  state.accounts = Array.isArray(data.accounts) ? data.accounts : [];
  state.activeAccount = data.activeAccount || '';
  state.codespaces = Array.isArray(data.codespaces) ? data.codespaces : [];
  state.diagnostics = data.diagnostics || {};
  state.settings = data.settings || {};
  showErrorBanner(data.listError || null);
  renderAll();
}

function renderDoctor() {
  const d = state.diagnostics || {};
  $('doc-icon-gh').innerHTML = d.ghInstalled ? SVG_ICONS.ok : SVG_ICONS.warn;
  $('doc-sub-gh').textContent = d.ghInstalled ? `v${d.ghVersion} (${d.ghPath})` : 'Not detected in PATH';

  $('doc-icon-ssh').innerHTML = d.hasOpenSsh ? SVG_ICONS.ok : SVG_ICONS.warn;
  $('doc-sub-ssh').textContent = d.hasOpenSsh ? 'Available in PATH' : 'OpenSSH missing';

  $('doc-icon-auth').innerHTML = d.hasAccounts ? SVG_ICONS.ok : SVG_ICONS.warn;
  $('doc-sub-auth').textContent = d.hasAccounts ? `${d.accountCount} account(s) connected` : 'Sign in required';

  if (sidecar && sidecar.conversationId && (!d.ghInstalled || !d.hasOpenSsh)) {
    $('btn-ask-agent-doctor').hidden = false;
  } else {
    $('btn-ask-agent-doctor').hidden = true;
  }
}

function renderSettingsForm() {
  const s = state.settings || {};
  $('set-alive-interval').value = s.serverAliveInterval ?? 30;
  $('set-alive-max').value = s.serverAliveCountMax ?? 10;
  $('set-remote-folder').value = s.defaultRemoteFolder || '/workspaces/${repo}';
  $('set-autosync').checked = s.autoSyncSSHOnStartup !== false;
}

function renderAccountsAndStats() {
  if (state.accounts.length === 0) {
    $('toolbar-section').hidden = true;
    $('welcome-section').hidden = false;
    $('codespaces-container').innerHTML = '';
    return;
  }

  $('welcome-section').hidden = true;
  $('toolbar-section').hidden = false;

  const select = $('account-select');
  select.innerHTML = state.accounts.map(acc => {
    const selected = acc.account === state.activeAccount ? 'selected' : '';
    const badge = acc.type === 'pat' ? 'PAT' : 'gh CLI';
    return `<option value="${escapeHtml(acc.account)}" ${selected}>${escapeHtml(acc.account)} (${badge})</option>`;
  }).join('');

  const total = state.codespaces.length;
  const online = state.codespaces.filter(c => c.state === 'Available').length;
  const stopped = total - online;

  $('stat-total').textContent = `${total} Total`;
  $('stat-online').textContent = `${online} Running`;
  $('stat-stopped').textContent = `${stopped} Stopped`;
}

function getFilteredCodespaces() {
  return state.codespaces.filter(cs => {
    const isOnline = cs.state === 'Available';
    if (state.filter === 'online' && !isOnline) return false;
    if (state.filter === 'stopped' && isOnline) return false;
    if (state.search) {
      const q = state.search.toLowerCase();
      const hay = `${cs.displayName || ''} ${cs.name || ''} ${cs.repository || ''} ${cs.gitStatus?.ref || ''}`.toLowerCase();
      if (!hay.includes(q)) return false;
    }
    return true;
  });
}

function renderCodespaces() {
  if (state.accounts.length === 0) return;

  const container = $('codespaces-container');
  const filtered = getFilteredCodespaces();

  if (filtered.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <strong>No matching GitHub Codespaces found</strong>
        <span>Click "New" in the top bar to provision a cloud container or adjust your search filter.</span>
      </div>
    `;
    return;
  }

  container.innerHTML = filtered.map(cs => {
    const isOnline = cs.state === 'Available';
    const dirty = cs.gitStatus?.hasUncommittedChanges || cs.gitStatus?.hasUnpushedChanges;
    const details = state.expandedMeta.get(cs.name);
    const safeName = escapeHtml(cs.name);
    const safeAccount = escapeHtml(cs.account || state.activeAccount);
    const safeDisplay = escapeHtml(cs.displayName || cs.name);
    const safeRepo = escapeHtml(cs.repository || cs.name);
    const safeBranch = escapeHtml(cs.gitStatus?.ref || 'main');
    const safeMachine = escapeHtml(cs.machineDisplayName || cs.machineName || '2 vCPU, 8 GB RAM');

    let detailsHtml = '';
    if (details) {
      const sshAlias = escapeHtml(details.ssh?.hostAlias || `cs.${cs.name}`);
      const sshCmd = escapeHtml(details.ssh?.sshCommand || `ssh cs.${cs.name}`);
      const ghCmd = escapeHtml(details.ssh?.ghSshCommand || `gh cs ssh -c ${cs.name}`);
      const ports = Array.isArray(details.ports) ? details.ports : [];
      const portsHtml = ports.length
        ? ports.map(p => `<span class="stat-pill">Port ${escapeHtml(p.sourcePort)} (${escapeHtml(p.visibility || 'private')})</span>`).join(' ')
        : `<span class="brand-subtitle">No active forwarded ports detected.</span>`;

      detailsHtml = `
        <div class="cs-details-drawer">
          <div><strong>SSH Host Alias (synced to ~/.ssh/config):</strong> <code>${sshAlias}</code></div>
          <div class="code-snippet">
            <span>${sshCmd}</span>
            <button type="button" class="secondary sm" data-action="copy-text" data-text="${sshCmd}">Copy SSH</button>
          </div>
          <div class="code-snippet">
            <span>${ghCmd}</span>
            <button type="button" class="secondary sm" data-action="copy-text" data-text="${ghCmd}">Copy gh CLI</button>
          </div>
          <div><strong>Forwarded Ports:</strong> ${portsHtml}</div>
        </div>
      `;
    }

    return `
      <article class="cs-card ${isOnline ? 'online' : ''}" data-cs-name="${safeName}">
        <div class="cs-top">
          <div class="cs-title-group">
            <div class="cs-title-row">
              <span class="status-dot ${isOnline ? 'online' : ''}"></span>
              <span class="cs-name">${safeDisplay}</span>
              <span class="status-badge ${isOnline ? 'online' : ''}">${isOnline ? 'Running' : escapeHtml(cs.state || 'Stopped')}</span>
            </div>
            <div class="cs-meta-row">
              <span class="meta-chip">${SVG_ICONS.repo} ${safeRepo}</span>
              <span class="meta-chip">${SVG_ICONS.branch} ${safeBranch}</span>
              ${dirty ? `<span class="meta-chip dirty">Uncommitted/Unpushed changes</span>` : ''}
              <span class="meta-chip">${SVG_ICONS.server} ${safeMachine}</span>
              <span class="meta-chip">${SVG_ICONS.clock} ${formatRelativeTime(cs.lastUsedAt)}</span>
            </div>
          </div>
        </div>

        <div class="cs-actions">
          <div class="cs-actions-left">
            <button type="button" class="sm" data-action="connect-agent" data-name="${safeName}" data-account="${safeAccount}" data-repo="${safeRepo}">
              ${SVG_ICONS.term}
              <span>Connect via Agent</span>
            </button>
            ${isOnline
              ? `<button type="button" class="secondary sm" data-action="stop" data-name="${safeName}" data-account="${safeAccount}">
                   ${SVG_ICONS.stop}
                   <span>Stop</span>
                 </button>`
              : `<button type="button" class="secondary sm" data-action="start" data-name="${safeName}" data-account="${safeAccount}">
                   ${SVG_ICONS.play}
                   <span>Turn ON</span>
                 </button>`
            }
            <button type="button" class="secondary sm" data-action="test-ssh" data-name="${safeName}" data-account="${safeAccount}">
              ${SVG_ICONS.zap}
              <span>Test SSH</span>
            </button>
          </div>

          <div class="cs-actions-right">
            <button type="button" class="ghost sm" data-action="toggle-meta" data-name="${safeName}" data-account="${safeAccount}" data-repo="${safeRepo}" title="Inspect SSH &amp; Ports">
              ${SVG_ICONS.info}
              <span>SSH &amp; Ports</span>
            </button>
            <button type="button" class="ghost sm" data-action="open-web" data-url="https://github.com/codespaces/${safeName}" title="Open in Browser">
              ${SVG_ICONS.globe}
              <span>Web</span>
            </button>
            <button type="button" class="ghost sm" data-action="rebuild" data-name="${safeName}" data-account="${safeAccount}" title="Rebuild Container">
              ${SVG_ICONS.wrench}
            </button>
            <button type="button" class="ghost sm" data-action="delete" data-name="${safeName}" data-account="${safeAccount}" title="Delete Codespace">
              ${SVG_ICONS.trash}
            </button>
          </div>
        </div>
        ${detailsHtml}
      </article>
    `;
  }).join('');
}

function renderAll() {
  renderDoctor();
  renderSettingsForm();
  renderAccountsAndStats();
  renderCodespaces();
}

// ---------------------------------------------------------------------------
// Actions
// ---------------------------------------------------------------------------

async function bootstrap(forceRefresh = false) {
  try {
    const data = forceRefresh
      ? await callApi('/api/refresh', { method: 'POST' })
      : await callApi('/api/bootstrap');
    applyPayload(data);
    if (forceRefresh) toast('Codespaces refreshed');
  } catch (err) {
    toast(`Load failed: ${err.message}`, true);
  }
}

async function handleSavePat(inputId) {
  const val = $(inputId).value.trim();
  if (!val) {
    toast('Enter a GitHub Personal Access Token (ghp_... or github_pat_...)', true);
    return;
  }
  try {
    toast('Verifying token with GitHub…');
    const data = await callApi('/api/auth/pat', { method: 'POST', body: { pat: val } });
    $(inputId).value = '';
    $('inline-pat-box').hidden = true;
    applyPayload(data);
    toast(`Signed in as ${data.login}`);
  } catch (err) {
    toast(err.message, true);
  }
}

async function handleConnectViaAgent(name, account, repository) {
  try {
    const entry = await callApi('/api/ssh/entry', {
      method: 'POST',
      body: { name, account, repository }
    });
    const prompt = `Connect to my GitHub Codespace "${name}" (repo: ${repository || name}, account: ${account}) using SSH host "${entry.hostAlias}" (configured in ~/.ssh/config) or "${entry.ghSshCommand}", and check its workspace status.`;
    if (sidecar && sidecar.conversationId) {
      await sidecar.agent.sendMessage(prompt);
      toast(`Sent SSH connection task for ${name} to active conversation`);
    } else if (sidecar && sidecar.agent) {
      await sidecar.agent.startConversation(prompt);
      toast(`Started new conversation connected to ${name}`);
    } else {
      await navigator.clipboard.writeText(entry.sshCommand);
      toast(`Copied SSH command: ${entry.sshCommand}`);
    }
  } catch (err) {
    toast(err.message, true);
  }
}

async function handleCardAction(e) {
  const btn = e.target.closest('button[data-action]');
  if (!btn) return;

  const action = btn.dataset.action;
  const name = btn.dataset.name;
  const account = btn.dataset.account || state.activeAccount;
  const repo = btn.dataset.repo || '';

  if (action === 'copy-text') {
    await navigator.clipboard.writeText(btn.dataset.text || '');
    toast(`Copied: ${btn.dataset.text}`);
    return;
  }

  if (action === 'open-web') {
    window.open(btn.dataset.url, '_blank', 'noopener');
    return;
  }

  if (action === 'connect-agent') {
    await handleConnectViaAgent(name, account, repo);
    return;
  }

  if (action === 'toggle-meta') {
    if (state.expandedMeta.has(name)) {
      state.expandedMeta.delete(name);
      renderCodespaces();
      return;
    }
    btn.disabled = true;
    try {
      const data = await callApi(`/api/codespaces/meta?name=${encodeURIComponent(name)}&account=${encodeURIComponent(account)}&repository=${encodeURIComponent(repo)}`);
      state.expandedMeta.set(name, data);
      renderCodespaces();
    } catch (err) {
      toast(err.message, true);
    } finally {
      btn.disabled = false;
    }
    return;
  }

  if (action === 'start') {
    btn.disabled = true;
    toast(`Starting ${name}…`);
    try {
      const data = await callApi('/api/codespaces/start', { method: 'POST', body: { name, account } });
      applyPayload(data);
      toast(`${name} is starting`);
    } catch (err) {
      toast(err.message, true);
      btn.disabled = false;
    }
    return;
  }

  if (action === 'stop') {
    btn.disabled = true;
    toast(`Stopping ${name}…`);
    try {
      const data = await callApi('/api/codespaces/stop', { method: 'POST', body: { name, account } });
      applyPayload(data);
      toast(`Stopped ${name}`);
    } catch (err) {
      toast(err.message, true);
      btn.disabled = false;
    }
    return;
  }

  if (action === 'test-ssh') {
    btn.disabled = true;
    toast(`Probing SSH tunnel to ${name}…`);
    try {
      const res = await callApi('/api/ssh/test', { method: 'POST', body: { name, account } });
      toast(`SSH tunnel healthy! Roundtrip latency: ${res.latencyMs}ms`);
    } catch (err) {
      toast(`SSH test failed: ${err.message}`, true);
    } finally {
      btn.disabled = false;
    }
    return;
  }

  if (action === 'rebuild') {
    btn.disabled = true;
    toast(`Triggering container rebuild for ${name}…`);
    try {
      const data = await callApi('/api/codespaces/rebuild', { method: 'POST', body: { name, account, full: false } });
      applyPayload(data);
      toast(`Rebuild started for ${name}`);
    } catch (err) {
      toast(err.message, true);
    } finally {
      btn.disabled = false;
    }
    return;
  }

  if (action === 'delete') {
    if (btn.dataset.confirming !== 'true') {
      btn.dataset.confirming = 'true';
      btn.classList.add('danger');
      btn.innerHTML = '<span>Confirm?</span>';
      setTimeout(() => {
        if (btn.isConnected) {
          btn.dataset.confirming = 'false';
          btn.classList.remove('danger');
          btn.innerHTML = SVG_ICONS.trash;
        }
      }, 3500);
      return;
    }
    btn.disabled = true;
    toast(`Deleting ${name}…`);
    try {
      const data = await callApi('/api/codespaces/delete', { method: 'POST', body: { name, account } });
      applyPayload(data);
      toast(`Deleted ${name}`);
    } catch (err) {
      toast(err.message, true);
      btn.disabled = false;
    }
  }
}

async function openCreateDrawer() {
  const drawer = $('create-drawer');
  drawer.hidden = !drawer.hidden;
  if (drawer.hidden || !state.activeAccount) return;

  const sel = $('create-repo-select');
  sel.innerHTML = `<option value="">Loading repositories for ${escapeHtml(state.activeAccount)}…</option>`;
  try {
    const data = await callApi(`/api/repos?account=${encodeURIComponent(state.activeAccount)}`);
    const repos = Array.isArray(data.repos) ? data.repos : [];
    sel.innerHTML = `<option value="">Select a repository (${repos.length} available)…</option>` +
      repos.map(r => `<option value="${escapeHtml(r.nameWithOwner)}">${escapeHtml(r.nameWithOwner)} (${r.isPrivate ? 'Private' : 'Public'})</option>`).join('');
  } catch {
    sel.innerHTML = `<option value="">Enter owner/repo manually on the right</option>`;
  }
}

// ---------------------------------------------------------------------------
// Event Wiring
// ---------------------------------------------------------------------------

function init() {
  $('btn-refresh').addEventListener('click', () => bootstrap(true));
  $('btn-dismiss-error').addEventListener('click', () => showErrorBanner(null));

  $('btn-welcome-pat-save').addEventListener('click', () => handleSavePat('welcome-pat-input'));
  $('btn-inline-pat-save').addEventListener('click', () => handleSavePat('inline-pat-input'));

  $('btn-toggle-add-pat').addEventListener('click', () => {
    $('inline-pat-box').hidden = !$('inline-pat-box').hidden;
  });

  $('account-select').addEventListener('change', async (e) => {
    try {
      const data = await callApi('/api/auth/switch', { method: 'POST', body: { account: e.target.value } });
      applyPayload(data);
      toast(`Switched active account to ${e.target.value}`);
    } catch (err) {
      toast(err.message, true);
    }
  });

  $('btn-logout-account').addEventListener('click', async () => {
    if (!state.activeAccount) return;
    try {
      const removed = state.activeAccount;
      const data = await callApi('/api/auth/logout', { method: 'POST', body: { account: removed } });
      applyPayload(data);
      toast(`Signed out of ${removed}`);
    } catch (err) {
      toast(err.message, true);
    }
  });

  $('search-input').addEventListener('input', (e) => {
    state.search = e.target.value.trim();
    renderCodespaces();
  });

  document.querySelectorAll('.filter-tab').forEach(tab => {
    tab.addEventListener('click', () => {
      document.querySelectorAll('.filter-tab').forEach(t => t.classList.remove('active'));
      tab.classList.add('active');
      state.filter = tab.dataset.filter || 'all';
      renderCodespaces();
    });
  });

  $('btn-open-create').addEventListener('click', openCreateDrawer);
  $('btn-close-create').addEventListener('click', () => { $('create-drawer').hidden = true; });
  $('create-repo-select').addEventListener('change', (e) => {
    if (e.target.value) $('create-repo-input').value = e.target.value;
  });

  $('btn-submit-create').addEventListener('click', async () => {
    const repo = $('create-repo-input').value.trim() || $('create-repo-select').value.trim();
    const branch = $('create-branch-input').value.trim();
    const machine = $('create-machine-select').value.trim();
    if (!repo) {
      toast('Select or enter a repository in owner/repo format', true);
      return;
    }
    const btn = $('btn-submit-create');
    btn.disabled = true;
    toast(`Provisioning Codespace for ${repo}…`);
    try {
      const data = await callApi('/api/codespaces/create', {
        method: 'POST',
        body: { repo, branch, machine, account: state.activeAccount }
      });
      $('create-drawer').hidden = true;
      applyPayload(data);
      toast(`Created Codespace: ${data.createdName}`);
    } catch (err) {
      toast(err.message, true);
    } finally {
      btn.disabled = false;
    }
  });

  $('btn-toggle-settings').addEventListener('click', () => {
    $('settings-drawer').hidden = !$('settings-drawer').hidden;
  });
  $('btn-close-settings').addEventListener('click', () => { $('settings-drawer').hidden = true; });

  $('btn-save-settings').addEventListener('click', async () => {
    try {
      const res = await callApi('/api/settings', {
        method: 'POST',
        body: {
          serverAliveInterval: Number($('set-alive-interval').value),
          serverAliveCountMax: Number($('set-alive-max').value),
          defaultRemoteFolder: $('set-remote-folder').value.trim(),
          autoSyncSSHOnStartup: $('set-autosync').checked
        }
      });
      state.settings = res.settings;
      $('settings-drawer').hidden = true;
      toast('Saved SSH & startup settings');
    } catch (err) {
      toast(err.message, true);
    }
  });

  $('btn-sync-ssh').addEventListener('click', async () => {
    const btn = $('btn-sync-ssh');
    btn.disabled = true;
    toast('Syncing Codespaces into ~/.ssh/config…');
    try {
      const res = await callApi('/api/ssh/sync', { method: 'POST' });
      toast(`Synced ${res.syncedCount} Codespace entry(s) to ${res.sshConfigPath}`);
    } catch (err) {
      toast(err.message, true);
    } finally {
      btn.disabled = false;
    }
  });

  $('btn-ask-agent-doctor').addEventListener('click', async () => {
    if (sidecar && sidecar.conversationId) {
      await sidecar.agent.sendMessage('Please check my local GitHub CLI (gh) and OpenSSH installation so I can use SSH tunnels with Antigravity Codespaces Pro.');
      toast('Sent environment setup request to the agent');
    }
  });

  $('codespaces-container').addEventListener('click', handleCardAction);

  bootstrap(false);
}

init();
