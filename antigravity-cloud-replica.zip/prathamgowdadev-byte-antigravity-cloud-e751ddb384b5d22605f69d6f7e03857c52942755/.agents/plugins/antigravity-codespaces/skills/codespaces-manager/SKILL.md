---
name: codespaces-manager
description: Manage GitHub Codespaces across multiple accounts, sync ~/.ssh/config ProxyCommand entries, test SSH tunnel latency, and open the Antigravity Codespaces Pro sidecar dashboard.
---

# Antigravity Codespaces Pro Skill

Use this skill whenever the user asks to manage, connect to, start, stop, rebuild, or troubleshoot GitHub Codespaces or SSH tunnels in Antigravity 2.0.

## Sidecar UI Panel

This plugin provides an interactive side pane UI extension (`antigravity-codespaces/dashboard`).
You can surface a one-click pill in chat to open the Codespaces Pro dashboard in the right auxiliary pane:

```markdown
[Codespaces Pro](sidecar://antigravity-codespaces/dashboard/)
```

## Key Capabilities

1. **Multi-Account GitHub Codespaces Management**:
   - Discovers accounts from both stored Personal Access Tokens (`%USERPROFILE%\.gemini\antigravity\sidecar_data\antigravity-codespaces\dashboard\data\codespaces-state.json`) and local GitHub CLI (`gh auth status`).
   - Supports direct GitHub REST API (`https://api.github.com/user/codespaces`) with automatic fallback to `gh codespace` CLI commands.
2. **SSH Config Synchronization (`~/.ssh/config`)**:
   - Maintains clean, deduplicated `# CS_ENTRY:<codespace-name>` blocks in `~/.ssh/config` using `gh cs ssh -c "<name>" --stdio` ProxyCommand and configurable `ServerAliveInterval` / `ServerAliveCountMax` keepalives.
