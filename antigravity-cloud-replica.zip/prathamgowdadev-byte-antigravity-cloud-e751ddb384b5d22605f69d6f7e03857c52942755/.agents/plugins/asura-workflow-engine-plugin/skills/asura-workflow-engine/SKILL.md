---
name: asura-workflow-engine
description: >-
  The master Asura 3D website automation workflow and blueprint. Use whenever the user requests
  building, developing, or replicating websites with 3D scroll animations, video-to-scroll canvas scrubbing,
  luxury kinetic motion, and anti-AI-slop design standards.
---

# ASURA SOVEREIGN 3D WEBSITE AUTOMATION WORKFLOW
## Unified Architecture, Kinetic Mechanics & Anti-AI-Slop Engineering Protocol

---

### 1. Unified Architecture & Doctrine
**Doctrine: "Cinema First, Web Second"**
Every website built through the Asura pipeline rejects static, generic web design. Web pages are constructed as interactive cinematic journeys with tactile physics, continuous momentum scrolling, and zero AI slop.

```mermaid
flowchart TD
    Reference["User Brief / Video / URL Reference"] --> Analysis["Artistic Deconstruction (Aesthetic, Palette, Kinetics)"]
    Analysis --> FramePipe["Video / Canvas Frame Pipeline (Numbered JPG Sequence)"]
    FramePipe --> CoreEngine["Asura Core Engine (GSAP + Lenis + Canvas / Three.js)"]
    CoreEngine --> AntiSlop["Anti-AI-Slop Filter (Zero Emojis, Bespoke SVGs, Luxury Typography)"]
    AntiSlop --> EdgeDeploy["Atomic Git Tree & Vercel Edge CDN Deployment"]
    EdgeDeploy --> Verification["Automated Chrome DevTools QA Audit (0 Errors, 60fps)"]
```

---

### 2. Strict Anti-AI-Slop Mandate (Compulsory Non-Negotiables)
1. **STRICTLY ZERO UNICODE EMOJIS**:
   - Never use raw unicode emojis (`✨`, `🎉`, `📍`, `📅`, `🔔`, `🚀`, `🪷`, `🎺`, `🍃`, etc.) in the user interface.
   - Every single icon must be rendered as an authentic inline SVG vector (Lucide icons, Feather, or custom paths) with explicit `width`, `height`, and inline styling:
     ```html
     <svg width="18" height="18" style="width: 18px; height: 18px; min-width: 18px; min-height: 18px;" class="w-4 h-4 text-[#D4AF37]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
       <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z"></path>
     </svg>
     ```
2. **ZERO FLAT COLOR / NEO-CLINIC MONOTONY**:
   - Never use flat `#000000` or plain `#ffffff` backgrounds.
   - Enforce atmospheric brand-hue washes, radial glow gradients, and blurred backdrop image layers (`filter: blur(52px) saturate(1.25); opacity: 0.35`).
3. **EDITORIAL TYPOGRAPHIC HIERARCHY**:
   - Pair an expressive, authentic display typeface (Cinzel Decorative, Playfair Display, Cormorant Garamond, Syne, Fraunces) with a razor-sharp geometric sans-serif (Inter Tight, Plus Jakarta Sans, Montserrat) and technical monospace telemetry badges.
4. **DETERMINISTIC ASSET RESOLUTION**:
   - Every single `<img>` tag must include an immediate high-resolution fail-safe fallback:
     ```html
     <img src="./assets/model_hero.jpg" onerror="this.onerror=null; this.src='https://images.unsplash.com/photo-1568772585407-9361f9bf3a87?q=80&w=2070&auto=format&fit=crop';" alt="Model Hero" class="w-full h-full object-cover">
     ```

---

### 3. The Supreme 14 Mechanics Library

#### Mechanic 1: Pin-Parallax Sheets ("Cocoon" Pattern)
Use for intro chapters where content sheets slide over fixed background media.
```css
.pinwrap { position: relative; }
.pin { position: sticky; top: 0; height: 100vh; z-index: 0; overflow: hidden; }
.sheet { position: relative; z-index: 2; background: var(--surface-bg); border-top: 1px solid var(--border-color); }
```

#### Mechanic 2: Full-Viewport Photo Chapters ("FLOWERS/SIM" Pattern)
Sticky media background with negative margin foreground interactive cards.
```css
.ch { position: relative; }
.ch .bg { position: sticky; top: 0; height: 100vh; z-index: 0; overflow: hidden; }
.ch .fl { position: relative; z-index: 2; margin-top: -100vh; }
.scene { min-height: 100vh; padding: 0 4vw; display: flex; align-items: flex-end; }
```

#### Mechanic 3: Gradient Seam Fades
Never let sections end abruptly. Implement smooth gradient feathering across transitions.
```css
.seam-bottom {
  position: absolute; bottom: 0; left: 0; width: 100%; height: 24vh;
  background: linear-gradient(to top, var(--bg-dark), transparent);
  pointer-events: none; z-index: 10;
}
```

#### Mechanic 4: Brand-Hue Washes
Create atmospheric depth with blurred ambient backplates.
```html
<div class="relative overflow-hidden bg-[#0A0B0E]">
  <div class="absolute -inset-[20%] pointer-events-none opacity-30 filter blur-[60px] saturate-150">
    <img src="./assets/hero.jpg" class="w-full h-full object-cover">
  </div>
  <div class="relative z-10">...content...</div>
</div>
```

#### Mechanic 5: Apple-Style Scroll-Linked Canvas Scrubber
Scrub numbered image frames (`001.jpg` to `300.jpg`) smoothly on an HTML5 canvas pinned via GSAP ScrollTrigger.
```javascript
const canvas = document.getElementById("hero-canvas");
const ctx = canvas.getContext("2d");
const images = [];
const sequence = { frame: 0 };
const TOTAL_FRAMES = 300;

function setCanvasDimensions() {
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = window.innerWidth * dpr;
  canvas.height = window.innerHeight * dpr;
  ctx.scale(dpr, dpr);
}

function renderFrame(index) {
  const img = images[index];
  if (!img || !img.complete || !img.naturalWidth) return;
  const w = window.innerWidth, h = window.innerHeight;
  ctx.clearRect(0, 0, w, h);
  const imgAspect = img.naturalWidth / img.naturalHeight;
  const canvasAspect = w / h;
  let dw = w, dh = w / imgAspect, dx = 0, dy = (h - dh) / 2;
  if (canvasAspect <= imgAspect) {
    dh = h; dw = h * imgAspect; dx = (w - dw) / 2; dy = 0;
  }
  ctx.drawImage(img, dx, dy, dw, dh);
}

gsap.to(sequence, {
  frame: TOTAL_FRAMES - 1,
  ease: "none",
  scrollTrigger: {
    trigger: "#hero-stage",
    start: "top top",
    end: () => `+=${Math.min(window.innerHeight * 1.5, 1400)}`,
    pin: true,
    scrub: 0.5,
    onUpdate: () => renderFrame(Math.round(sequence.frame))
  }
});
```

#### Mechanic 6: Horizontal Ride (Down -> Right -> Down)
Sticky horizontal scroll track mapped to vertical page scroll progress.

#### Mechanic 7: Cinematic Entrance System (IntersectionObserver / GSAP)
All elements fade and slide in dynamically with staggered delays.

#### Mechanic 8: Editorial Headers & Giant Wordmark Footers
Transparent fixed header with `mix-blend-mode: difference` and oversized stroked wordmark in footer.

#### Mechanic 9: 3D Pinned Real Estate Deck & Lighting Shift (ERA Pattern)
Day/night interactive lighting blend, SVG hotspot pins with radar rings, and 3D floorplan deck.

#### Mechanic 10: Bento Intelligence Grid
Modular technical telemetry cards displaying real-time responsive specs.

#### Mechanic 11: 3D Perspective Card Tilt (React Bits / Aceternity Physics)
Mouse-tracking 3D tilt responding to cursor coordinates with dynamic specular reflections:
```javascript
card.addEventListener("mousemove", (e) => {
  const rect = card.getBoundingClientRect();
  const x = e.clientX - rect.left - rect.width / 2;
  const y = e.clientY - rect.top - rect.height / 2;
  const rotX = (y / (rect.height / 2)) * -12;
  const rotY = (x / (rect.width / 2)) * 12;
  card.style.transform = `perspective(1200px) rotateX(${rotX}deg) rotateY(${rotY}deg) scale3d(1.02, 1.02, 1.02)`;
});
```

#### Mechanic 12: Lenis Momentum Inertia Scrolling
60fps momentum inertia synchronized directly with GSAP ticker:
```javascript
const lenis = new Lenis({ duration: 1.2, smoothWheel: true });
gsap.ticker.add((time) => lenis.raf(time * 1000));
gsap.ticker.lagSmoothing(0);
```

#### Mechanic 13: Floating State Docks (Cult UI Pattern)
Glassmorphic floating control pills with active state indicators and tactile switches.

#### Mechanic 14: Exploded Subsystem Cutaway (Deconstruction Scrub)
Scroll-linked mechanical explosion revealing engine, frame, suspension, and braking subsystems.

---

### 4. Video-to-Scroll Frame Extraction Guide
When the user provides a video or zip of frames:
1. Extract frames using ffmpeg / ezgif:
   `ffmpeg -i input.mp4 -vf "fps=30,scale=1920:-1" frames/ezgif-frame-%03d.jpg`
2. Preload frames asynchronously with progressive loading counters.
3. Show immediate high-res backdrop fallback so user never encounters a blank black screen.
4. Keep ScrollTrigger pin height proportional (`window.innerHeight * 1.3`) to prevent trapped scroll locks.

---

### 5. Deterministic Verification & Delivery Checklist
Before delivering any website:
- [ ] 0 unicode emojis in the UI (all verified as SVGs).
- [ ] 0 unhandled console errors in Chrome DevTools.
- [ ] 0 broken image icons (100% of images verified with `complete: true` and `naturalWidth > 0`).
- [ ] Fluid scrolling from top to bottom without pinning traps.
- [ ] Verified responsive layout at 1440px desktop, 768px tablet, and 375px mobile.
- [ ] Edge deployed and live on Vercel with HTTP 200 OK.
