# Asura Sovereign 3D Website Automation Rules

- **Cinema First, Web Second**: Prohibit static, lifeless website headers. Every hero section must implement an interactive media experience: 60fps pinned HTML5 canvas sequence (Apple-style frame scrubbing), pinned HTML5 video scrub with Lerp smoothing, or multi-layer parallax projection.
- **Strict Anti-AI-Slop Mandate**:
  - **Zero Unicode Emojis**: Under NO circumstances render raw unicode emojis on websites. Every icon must be an authentic, cleanly styled SVG vector (Lucide / bespoke SVG) with explicit `width`, `height`, and inline CSS dimensions to prevent layout shifts.
  - **Zero Flat Hex / Neo-Clinic Monotony**: Never use pure flat black (`#000000`) or generic template grays. Implement rich brand-hue washes, blurred ambient backlight layers (`filter: blur(50px)`), and subtle metallic/glass borders (`border border-white/10`).
  - **Editorial Typographic Precision**: Combine expressive display typography (Playfair, Cinzel, Cormorant, Syne) with ultra-crisp modern sans-serif body copy and monospace telemetry tags.
- **Physics-Driven Motion Protocol**:
  - **Lenis Momentum Smoothing**: Every page must initialize a butter-smooth `Lenis` momentum inertia instance synchronized with GSAP ScrollTrigger.
  - **3D Card Tilt & Specular Sheen**: Cards and showcases must implement interactive 3D perspective mouse physics (`perspective: 1200px`, `transform-style: preserve-3d`) with dynamic radial-gradient glare tracking cursor coordinates.
  - **Fluid Scroll Pinning**: Calibrate pinned scroll tracks proportionally (never exceed natural scroll ratios; keep scrub tracks responsive and unblocked).
- **Deterministic Edge Asset Integrity**:
  - Every `<img>` tag must include an immediate high-resolution fail-safe CDN fallback (`onerror="this.onerror=null; this.src='https://images.unsplash.com/...';"`).
  - Web Audio synthesizers or pre-buffered audio must provide graceful fallbacks with zero unhandled 404 network failures.
  - All interactive buttons must have explicit focus rings, hover lift, active scale feedback, and accessible labels.
