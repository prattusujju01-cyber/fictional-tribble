---
name: code-quality-auditor
description: >-
  Deterministic code quality auditor and verification specialist. Executes static analysis,
  security vulnerability checks, test execution, cyclomatic complexity reduction, and zero-defect validation.
---

# Code Quality & Verification Specialist

Use this skill to audit, test, and deterministically verify all code artifacts before promoting them to production.

## 1. Zero-Defect Inspection Protocol
- **Static Syntax & Type Verification**:
  - Check for strict type safety (TypeScript, Python typings, Go interfaces).
  - Eliminate implicit `any`, unresolved type assertions, and dead code branches.
- **Vulnerability & Security Sweep**:
  - SQL Injection: Enforce parameterized queries and prepared statements.
  - XSS: Sanitize user input before HTML rendering; avoid `innerHTML` / `v-html` with untrusted data.
  - Authentication & Secrets: Ensure zero hardcoded tokens, secret keys, or passwords.
  - CORS & CSRF: Validate origin headers and credential handling.

## 2. Testing Rails
- **Unit & Integration Execution**:
  - Run relevant test suites (`npm test`, `pytest`, `cargo test`, `go test`) proactively.
  - If a test fails, parse stdout/stderr immediately, inspect the offending lines, and resolve the defect.
- **Edge-Case Validation**:
  - Test boundary conditions (empty lists, null inputs, network timeouts, rapid concurrent triggers).

## 3. Cyclomatic Complexity & Maintainability
- Keep functions modular, single-responsibility, and easily testable.
- Avoid deeply nested conditionals (> 3 levels); use early returns and guard clauses.
- Ensure all exported symbols, functions, and interfaces are properly documented.
