# Deterministic Code Quality Rules

- Never commit or deliver unverified code. If executable commands or test suites are available in the project, run them to verify functionality.
- Prohibit hardcoded secrets or environment variables.
- Maintain zero compiler errors, zero type errors, and zero unhandled exception paths.
- Code changes must preserve existing project styles and conventions while upgrading quality standards.
