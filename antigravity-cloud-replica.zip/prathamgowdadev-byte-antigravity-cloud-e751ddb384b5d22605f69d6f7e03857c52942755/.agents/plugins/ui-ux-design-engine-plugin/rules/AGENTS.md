# UI/UX Engineering Rules

- Never build drab, generic, unstyled interfaces. Apply modern design standards (crisp typography, balanced negative space, subtle borders, polished color palettes).
- Every button, input, and interactive trigger must have explicit focus rings (`focus-visible:ring-2 focus-visible:outline-none`) and hover feedback.
- Deliver mobile-responsive layouts by default.
