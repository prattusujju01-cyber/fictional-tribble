---
name: ui-ux-design-engine
description: >-
  Specialist for creating polished, high-converting, accessible user interfaces with Shadcn UI,
  Tailwind CSS, Lucide icons, Framer Motion, and GSAP micro-animations.
---

# UI/UX Design & Frontend Specialist

Use this skill to design and build world-class, responsive, and visually stunning web interfaces.

## 1. Aesthetic & Layout Principles
- **Design Tokens**: Standardize color palettes with semantic naming (background, foreground, primary, secondary, muted, accent, destructive, border).
- **Typography**: Clear hierarchy with fluid scaling (`text-sm`, `text-base`, `text-lg`, `text-xl`, `text-3xl`, `text-5xl`), tight heading tracking (`tracking-tight`), and balanced text-wrapping.
- **Spacing & Elevation**: Consistent padding and margin scales (4px grid), subtle card borders (`border border-neutral-200 dark:border-neutral-800`), and soft elevation shadows.
- **Dark Mode by Default**: Support seamless light and dark mode switching with CSS variables or Tailwind `dark:` variants.

## 2. Interactive Components
- **Shadcn UI Architecture**: Accessible, composable primitives built on Radix UI and Tailwind CSS.
- **States**: Every interactive element must define hover, active, focused, disabled, and loading skeleton states.
- **Micro-Interactions**: Use Framer Motion or GSAP for smooth layout changes, entry fade-ins, spring physics, and subtle scale-down clicks.

## 3. Responsive Adaptability
- Test and support full responsive ranges: Mobile (375px), Tablet (768px), Laptop (1024px), Desktop (1440px+).
- Prevent horizontal scrollbars (`overflow-x-hidden` on main viewport where appropriate).
