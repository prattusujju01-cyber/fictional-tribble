---
name: modern-web-guidance
description: >-
  Curated expert guidance on modern web platform APIs: View Transitions, Container Queries,
  Popover API, Native Dialogs, CSS Anchor Positioning, :has(), :user-invalid, Subgrid, and INP optimization.
---

# Modern Web Platform Specialist

Use modern, high-performance, accessible, and native web platform features over legacy, bloated JavaScript libraries.

## 1. Native UI & Components
- **Native `<dialog>` & Popover API**: Use native `<dialog>` for modal/non-modal dialogs (`showModal()`, `close()`) and `popover="auto"` or `popover="manual"` for menus and tooltips. Avoid heavy custom overlay libraries.
- **CSS Anchor Positioning**: Anchor floating elements (tooltips, dropdowns) to target elements natively with `anchor-name` and `position-anchor`.
- **Light Dismiss**: Use standard platform dismiss behaviors (`closedby="any"` / `popover="auto"`).

## 2. Modern CSS & Layout
- **`:has()` Selector**: Use parent styling based on child states or descendant existence without extra JavaScript event listeners.
- **Container Queries**: Use `@container (min-width: ...)` for component-driven responsive design rather than relying solely on viewport media queries.
- **Subgrid**: Align nested grid tracks with parent grids using `grid-template-columns: subgrid`.
- **Modern Form States**: Use `:user-valid` and `:user-invalid` for friendly validation states that only trigger after user interaction.
- **Dynamic Field Sizing**: Use `field-sizing: content` on inputs/textareas for automatic dimension adaptation.

## 3. Smooth Transitions & Performance
- **View Transitions API**: Use `document.startViewTransition()` for fluid page or component state transitions.
- **Scroll-Driven Animations**: Use `animation-timeline: scroll()` or `view()` for GPU-accelerated scroll animations without JS scroll listeners.
- **Long Tasks & INP**: Break heavy synchronous computations using `scheduler.yield()` or `requestAnimationFrame()` to protect the main thread and guarantee responsive INP.
