# Modern Web Guidance Rules

- Default to native HTML5/CSS3 APIs before introducing 3rd party JavaScript libraries for basic UI behavior (dialogs, popovers, smooth accordions).
- Implement responsive styling with mobile-first container queries and modern flex/grid layouts.
- Prevent layout thrashing and maintain high Core Web Vitals (LCP < 2.5s, INP < 200ms, CLS < 0.1).
