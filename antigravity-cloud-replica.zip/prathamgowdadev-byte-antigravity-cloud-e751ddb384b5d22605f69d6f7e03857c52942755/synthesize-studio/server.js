// server.js
// Asura-Hermes Autonomous eBook Intelligence System
// 500 INR ($5.21 USD) Pricing, Autonomous Marketing Orchestra, Dedicated Telegram Sales Bot

import express from "express";
import cors from "cors";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

import { TrendScoutAgent } from "./agents/trendScout.js";
import { KnowledgeEngineAgent } from "./agents/knowledgeEngine.js";
import { ArchitectAgent } from "./agents/architect.js";
import { GhostwriterAgent } from "./agents/ghostwriter.js";
import { OpenHiggsfieldVisualAgent } from "./agents/openHiggsfield.js";
import { LaunchpadAgent } from "./agents/launchpad.js";
import { ExportEngineAgent } from "./agents/exportEngine.js";
import { McpToolHub } from "./agents/mcpHub.js";
import { HermesAgentEngine } from "./agents/hermesEngine.js";
import { ContinuousTrainingEngine } from "./agents/continuousTrainer.js";
import { GumroadConnectorAgent } from "./agents/gumroadConnector.js";
import { HermesMarketingOrchestra } from "./agents/marketingOrchestra.js";
import { EbookTelegramBot } from "./agents/ebookTelegramBot.js";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3730;

// Directories
const uploadsDir = path.join(__dirname, "uploads");
const dataDir = path.join(__dirname, "data");
if (!fs.existsSync(uploadsDir)) fs.mkdirSync(uploadsDir, { recursive: true });
if (!fs.existsSync(dataDir)) fs.mkdirSync(dataDir, { recursive: true });

// Setup multer
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const cleanName = file.originalname.replace(/[^a-zA-Z0-9.-]/g, "_");
    cb(null, `${Date.now()}-${cleanName}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 30 * 1024 * 1024 }
});

// Middleware
app.use(cors());
app.use(express.json({ limit: "25mb" }));
app.use(express.urlencoded({ extended: true, limit: "25mb" }));
app.use(express.static(path.join(__dirname, "public")));
app.use("/uploads", express.static(uploadsDir));

// Initialize Engines
const mcpHub = new McpToolHub();
const hermesEngine = new HermesAgentEngine();
const trendScout = new TrendScoutAgent();
const knowledgeEngine = new KnowledgeEngineAgent(uploadsDir);
const architect = new ArchitectAgent();
const ghostwriter = new GhostwriterAgent();
const visualStylist = new OpenHiggsfieldVisualAgent();
const launchpad = new LaunchpadAgent();
const exportEngine = new ExportEngineAgent();
const continuousTrainer = new ContinuousTrainingEngine(dataDir);
const gumroadConnector = new GumroadConnectorAgent();
const marketingOrchestra = new HermesMarketingOrchestra();
const telegramBot = new EbookTelegramBot();

// State
let appSettings = {
  provider: "builtin",
  apiKey: "",
  model: "NousResearch/Hermes-3-FunctionCalling",
  gumroadToken: "",
  telegramToken: "",
  telegramChatId: "",
  priceInr: 500,
  priceUsd: 5.21
};

let currentBook = null;
function loadBookFromDisk() {
  try {
    const currentPath = path.join(dataDir, "current-ebook.json");
    const samplePath = path.join(dataDir, "sample-ebook.json");
    if (fs.existsSync(currentPath)) {
      currentBook = JSON.parse(fs.readFileSync(currentPath, "utf8"));
    } else if (fs.existsSync(samplePath)) {
      currentBook = JSON.parse(fs.readFileSync(samplePath, "utf8"));
    }
  } catch (e) {
    console.warn("Could not load book from disk:", e.message);
  }
}
loadBookFromDisk();

// ================= API ROUTES =================

// 1. Live Internet Trends
app.get("/api/trends", (req, res) => {
  const category = req.query.category || "All";
  const niches = trendScout.getTrendingNiches(category);
  res.json({ success: true, count: niches.length, niches });
});

app.post("/api/trends/search", async (req, res) => {
  const { query } = req.body;
  if (!query) return res.status(400).json({ error: "Query is required" });
  try {
    const liveResults = await mcpHub.executeTool("search_internet", { query });
    const evaluation = trendScout.analyzeCustomTopic(query);
    res.json({ success: true, liveResults, evaluation });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 2. Continuous 24/7 Training Telemetry
app.get("/api/training/status", (req, res) => {
  const status = continuousTrainer.getStatus();
  res.json({ success: true, status });
});

// 3. Reference Ingestion
app.get("/api/references", (req, res) => {
  const summary = knowledgeEngine.getReferencesSummary();
  res.json({ success: true, summary, references: knowledgeEngine.references });
});

app.post("/api/upload", upload.array("files", 10), (req, res) => {
  if (!req.files || req.files.length === 0) return res.status(400).json({ error: "No files uploaded" });
  const processed = req.files.map(f => knowledgeEngine.addUploadedFile(f));
  const summary = knowledgeEngine.getReferencesSummary();
  res.json({ success: true, uploaded: processed, summary });
});

app.delete("/api/references/:filename", (req, res) => {
  knowledgeEngine.deleteReference(req.params.filename);
  res.json({ success: true, summary: knowledgeEngine.getReferencesSummary() });
});

// 4. Autonomous Synthesis (Hermes Engine)
app.post("/api/generate-full-book", async (req, res) => {
  try {
    const { topic, nicheId, tone, targetAudience, theme = "asura-titanium", priceInr = 500, priceUsd = 5.21 } = req.body;
    let niche = null;
    if (nicheId) niche = trendScout.getTrendingNiches().find(n => n.id === nicheId);
    const refContext = knowledgeEngine.getReferencesSummary();

    const book = await hermesEngine.runAutonomousSynthesis({
      topic,
      niche,
      tone,
      targetAudience,
      price: priceUsd,
      theme,
      referenceContext: refContext
    });

    book.priceInr = priceInr;
    book.priceUsd = priceUsd;

    // Generate Marketing Assets via Hermes Marketing Orchestra
    book.marketing = marketingOrchestra.generateCompleteMarketingCampaign({
      bookTitle: book.title,
      bookSubtitle: book.subtitle,
      category: book.category,
      chapters: book.chapters,
      priceInr,
      priceUsd
    });

    currentBook = book;
    fs.writeFileSync(path.join(dataDir, "current-ebook.json"), JSON.stringify(book, null, 2), "utf8");

    // Dispatch Launch Alert to Dedicated Telegram Bot
    await telegramBot.sendLaunchAlert({
      title: book.title,
      priceInr,
      priceUsd,
      chaptersCount: book.chapters.length,
      url: `https://gumroad.com/l/${book.title.toLowerCase().replace(/[^a-z0-9]/g, "-").slice(0, 25)}`
    });

    res.json({ success: true, book });
  } catch (err) {
    console.error("Synthesis error:", err);
    res.status(500).json({ error: err.message });
  }
});

// 5. Autonomous Marketing Orchestra
app.post("/api/marketing/generate", (req, res) => {
  try {
    const book = currentBook;
    if (!book) return res.status(404).json({ error: "No active book available" });
    const marketing = marketingOrchestra.generateCompleteMarketingCampaign({
      bookTitle: book.title,
      bookSubtitle: book.subtitle,
      category: book.category,
      chapters: book.chapters,
      priceInr: appSettings.priceInr,
      priceUsd: appSettings.priceUsd
    });
    book.marketing = marketing;
    res.json({ success: true, marketing });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// 6. Dedicated Telegram Sales Bot Endpoints
app.get("/api/telegram/alerts", (req, res) => {
  res.json({ success: true, ...telegramBot.getAlertsLog() });
});

app.post("/api/telegram/test-ping", async (req, res) => {
  const { token, chatId } = req.body;
  if (token) telegramBot.setCredentials(token, chatId);
  const result = await telegramBot.sendTestPing(token, chatId);
  res.json({ success: true, result });
});

app.post("/api/telegram/config", (req, res) => {
  const { token, chatId } = req.body;
  if (token) appSettings.telegramToken = token;
  if (chatId) appSettings.telegramChatId = chatId;
  telegramBot.setCredentials(token, chatId);
  res.json({ success: true, message: "Telegram bot configured" });
});

// 7. Gumroad Store Publisher & Webhooks
app.get("/api/gumroad/products", (req, res) => {
  res.json({ success: true, products: gumroadConnector.getPublishedProducts() });
});

app.post("/api/gumroad/credentials", (req, res) => {
  const { token } = req.body;
  gumroadConnector.setAccessToken(token);
  appSettings.gumroadToken = token;
  res.json({ success: true, message: "Gumroad token updated", hasToken: !!token });
});

app.post("/api/gumroad/publish", async (req, res) => {
  try {
    const targetTitle = currentBook?.title || "Digital Asset";
    const targetDesc = currentBook?.launchPackage?.salesPageCopy || currentBook?.subtitle || "Implementation guide.";
    const targetPrice = appSettings.priceUsd || 5.21;

    const result = await gumroadConnector.publishProduct({
      title: targetTitle,
      description: targetDesc,
      price: targetPrice,
      customPermalink: targetTitle.toLowerCase().replace(/[^a-z0-9]/g, "-").slice(0, 25),
      tags: ["500 inr", "digital playbook", "systems"],
      chaptersCount: currentBook?.chapters?.length || 7
    });

    res.json(result);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Gumroad Live Webhook Receiver (and Simulator)
app.post(["/api/gumroad-webhook", "/api/gumroad/simulate-sale"], async (req, res) => {
  try {
    const body = req.body || {};
    const title = body.product_name || currentBook?.title || "THE FACELESS WEALTH MACHINE";
    const buyerEmail = body.email || `buyer_${Math.floor(Math.random()*9000)+1000}@gmail.com`;
    const priceUsd = body.price ? (body.price / 100) : 5.21;
    const priceInr = 500;

    const alert = await telegramBot.sendSaleAlert({
      title,
      amountInr: priceInr,
      amountUsd: priceUsd,
      buyerEmail
    });

    res.json({ success: true, message: "Sale recorded and dispatched to Telegram bot", alert });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// 8. Book State & Storage
app.get("/api/book/current", (req, res) => {
  if (!currentBook) loadBookFromDisk();
  res.json({ success: true, book: currentBook });
});

app.post("/api/book/reset-sample", (req, res) => {
  try {
    const samplePath = path.join(dataDir, "sample-ebook.json");
    if (fs.existsSync(samplePath)) {
      currentBook = JSON.parse(fs.readFileSync(samplePath, "utf8"));
      currentBook.priceInr = 500;
      currentBook.priceUsd = 5.21;
      fs.writeFileSync(path.join(dataDir, "current-ebook.json"), JSON.stringify(currentBook, null, 2), "utf8");
      return res.json({ success: true, message: "Sample publication restored", book: currentBook });
    }
  } catch (e) {
    console.error(e);
  }
  res.status(500).json({ error: "Could not reset sample book" });
});

app.post("/api/book/save", (req, res) => {
  const { book } = req.body;
  if (!book) return res.status(400).json({ error: "Book payload required" });
  currentBook = book;
  fs.writeFileSync(path.join(dataDir, "current-ebook.json"), JSON.stringify(book, null, 2), "utf8");
  res.json({ success: true, message: "Book saved successfully" });
});

// 9. Multi-Format Exporter
app.get("/api/export/html", (req, res) => {
  if (!currentBook) return res.status(404).send("No book available to export");
  const html = exportEngine.generatePrintableHtml({
    title: currentBook.title,
    subtitle: currentBook.subtitle,
    author: currentBook.author,
    category: currentBook.category,
    chapters: currentBook.chapters,
    coverSvg: currentBook.coverSvg
  });
  res.setHeader("Content-Type", "text/html; charset=utf-8");
  res.send(html);
});

app.get("/api/export/markdown", (req, res) => {
  if (!currentBook) return res.status(404).send("No book available to export");
  const md = exportEngine.generateMarkdown({
    title: currentBook.title,
    subtitle: currentBook.subtitle,
    author: currentBook.author,
    category: currentBook.category,
    chapters: currentBook.chapters
  });
  res.setHeader("Content-Disposition", `attachment; filename="${currentBook.title.replace(/[^a-zA-Z0-9]/g, "_")}.md"`);
  res.setHeader("Content-Type", "text/markdown; charset=utf-8");
  res.send(md);
});

app.get("/api/export/json", (req, res) => {
  if (!currentBook) return res.status(404).json({ error: "No book available to export" });
  res.setHeader("Content-Disposition", `attachment; filename="${currentBook.title.replace(/[^a-zA-Z0-9]/g, "_")}_bundle.json"`);
  res.json(currentBook);
});

// 10. Settings
app.get("/api/settings", (req, res) => {
  res.json({
    success: true,
    provider: appSettings.provider,
    hasApiKey: !!appSettings.apiKey,
    model: appSettings.model,
    hasGumroadToken: !!appSettings.gumroadToken,
    hasTelegramToken: !!appSettings.telegramToken,
    priceInr: appSettings.priceInr,
    priceUsd: appSettings.priceUsd
  });
});

app.post("/api/settings", (req, res) => {
  const { provider, apiKey, model, gumroadToken, telegramToken, telegramChatId } = req.body;
  if (provider) appSettings.provider = provider;
  if (apiKey !== undefined) appSettings.apiKey = apiKey;
  if (model) appSettings.model = model;
  if (gumroadToken !== undefined) {
    appSettings.gumroadToken = gumroadToken;
    gumroadConnector.setAccessToken(gumroadToken);
  }
  if (telegramToken !== undefined) {
    appSettings.telegramToken = telegramToken;
    telegramBot.setCredentials(telegramToken, telegramChatId);
  }
  res.json({ success: true, message: "Settings updated" });
});

export default app;

if (process.env.NODE_ENV !== "production" || !process.env.VERCEL) {
  app.listen(PORT, () => {
    console.log(`[ASURA-HERMES] System online on http://localhost:${PORT}`);
  });
}