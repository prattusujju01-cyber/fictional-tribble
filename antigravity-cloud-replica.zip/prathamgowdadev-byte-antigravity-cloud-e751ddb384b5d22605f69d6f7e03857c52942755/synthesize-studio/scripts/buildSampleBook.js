import fs from "fs";
import { ArchitectAgent } from "../agents/architect.js";
import { GhostwriterAgent } from "../agents/ghostwriter.js";
import { OpenHiggsfieldVisualAgent } from "../agents/openHiggsfield.js";
import { LaunchpadAgent } from "../agents/launchpad.js";

async function main() {
  const arch = new ArchitectAgent();
  const ghost = new GhostwriterAgent();
  const stylist = new OpenHiggsfieldVisualAgent();
  const launch = new LaunchpadAgent();

  const title = "THE FACELESS WEALTH MACHINE";
  const subtitle = "Building a $373/Day Digital Asset Empire with Autonomous AI";
  const category = "AI & Digital Products";

  const outline = await arch.generateOutline({
    topic: "Faceless AI Media Empires and Automated Digital Products",
    niche: {
      category,
      audience: "Aspiring entrepreneurs, creators, remote workers seeking passive digital income without showing their face"
    },
    tone: "Authoritative, Punchy & Practical"
  });

  // Assign pristine title & subtitle
  outline.title = title;
  outline.subtitle = subtitle;

  console.log("Synthesizing 7 deep actionable chapters...");
  const chaptersWithContent = [];
  for (const ch of outline.chapters) {
    const content = await ghost.generateChapter({
      chapter: ch,
      bookTitle: outline.title,
      bookSubtitle: outline.subtitle,
      tone: outline.tone
    });
    chaptersWithContent.push({
      ...ch,
      content
    });
  }

  const coverSvg = stylist.generateCoverSvg({
    title: outline.title,
    subtitle: outline.subtitle,
    category: outline.category,
    theme: "cyber-obsidian"
  });

  const launchPackage = launch.generateCommercialPackage({
    bookTitle: outline.title,
    bookSubtitle: outline.subtitle,
    category: outline.category,
    chapters: chaptersWithContent,
    targetAvatar: outline.targetAvatar,
    price: 37
  });

  const sampleBook = {
    id: "sample-book-live",
    createdAt: new Date().toISOString(),
    title: outline.title,
    subtitle: outline.subtitle,
    author: "Autonomous Studio Masterclass",
    category: outline.category,
    tone: outline.tone,
    targetAvatar: outline.targetAvatar,
    uniqueMechanism: outline.uniqueMechanism,
    chapters: chaptersWithContent,
    coverSvg,
    launchPackage,
    settings: {
      theme: "cyber-obsidian",
      price: 37
    }
  };

  fs.writeFileSync("data/sample-ebook.json", JSON.stringify(sampleBook, null, 2), "utf8");
  fs.writeFileSync("data/current-ebook.json", JSON.stringify(sampleBook, null, 2), "utf8");
  console.log("SAMPLE EBOOK REGENERATED: " + title);
}

main().catch(err => {
  console.error(err);
  process.exit(1);
});
