// public/app.js
// Asura-Hermes Autonomous eBook Intelligence Studio
// INR 500 ($5.21 USD) Pricing, Autonomous Marketing Orchestra, Dedicated Telegram Sales Bot
// STRICT ZERO EMOJIS ENFORCEMENT

class AsuraHermesApp {
  constructor() {
    this.currentBook = null;
    this.selectedNiche = null;
    this.activeChapterIdx = 0;
    this.isEditing = false;
    this.trainingInterval = null;
    this.alertsInterval = null;

    this.init();
  }

  async init() {
    this.initTeslaOrbCanvas();
    this.bindEvents();
    if (window.lucide) lucide.createIcons();

    await this.loadTrends();
    await this.loadReferences();
    await this.loadCurrentBook();
    await this.loadTrainingStatus();
    await this.loadTelegramAlerts();
    await this.loadSettings();

    // Auto-poll background telemetry
    this.trainingInterval = setInterval(() => this.loadTrainingStatus(), 15000);
    this.alertsInterval = setInterval(() => this.loadTelegramAlerts(), 8000);
  }

  // --- TeslaOrb Neural Visualizer ---
  initTeslaOrbCanvas() {
    const canvas = document.getElementById("tesla-orb-canvas");
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    let t = 0;

    const draw = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Neural wave 1: Cyan harmonic
      ctx.beginPath();
      ctx.strokeStyle = "rgba(0, 229, 255, 0.75)";
      ctx.lineWidth = 1.4;
      for (let x = 0; x < canvas.width; x++) {
        const y = 18 + Math.sin(x * 0.09 + t * 1.5) * 6 * Math.sin(x * 0.02 + t * 0.6);
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Neural wave 2: Crimson counter-phase
      ctx.beginPath();
      ctx.strokeStyle = "rgba(255, 23, 68, 0.45)";
      ctx.lineWidth = 1.1;
      for (let x = 0; x < canvas.width; x++) {
        const y = 18 + Math.cos(x * 0.07 - t * 1.2) * 5 * Math.sin(x * 0.03 + t * 0.4);
        if (x === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
      }
      ctx.stroke();

      // Neural Core Pulse
      const coreX = 65 + Math.sin(t * 1.8) * 26;
      const coreY = 18 + Math.cos(t * 1.8) * 4;
      const rad = 4 + Math.sin(t * 3.5) * 1.8;

      const grad = ctx.createRadialGradient(coreX, coreY, 0, coreX, coreY, rad * 3);
      grad.addColorStop(0, "rgba(0, 229, 255, 0.95)");
      grad.addColorStop(0.4, "rgba(255, 23, 68, 0.6)");
      grad.addColorStop(1, "rgba(0, 0, 0, 0)");

      ctx.fillStyle = grad;
      ctx.beginPath();
      ctx.arc(coreX, coreY, rad * 3, 0, Math.PI * 2);
      ctx.fill();

      t += 0.035;
      requestAnimationFrame(draw);
    };
    draw();
  }

  bindEvents() {
    // Top Tabs Navigation
    document.querySelectorAll(".nav-btn[data-tab]").forEach(btn => {
      btn.addEventListener("click", () => {
        this.switchTab(btn.dataset.tab);
      });
    });

    // Marketing Subtabs Navigation
    document.querySelectorAll(".nav-btn[data-msub]").forEach(btn => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".nav-btn[data-msub]").forEach(b => b.classList.remove("active"));
        document.querySelectorAll(".marketing-subpane").forEach(p => p.style.display = "none");
        btn.classList.add("active");
        const target = document.getElementById(btn.dataset.msub);
        if (target) target.style.display = "block";
      });
    });

    // Gumroad Subtabs Navigation
    document.querySelectorAll(".nav-btn[data-gsub]").forEach(btn => {
      btn.addEventListener("click", () => {
        document.querySelectorAll(".nav-btn[data-gsub]").forEach(b => b.classList.remove("active"));
        document.querySelectorAll(".gumroad-subpane").forEach(p => p.style.display = "none");
        btn.classList.add("active");
        const target = document.getElementById(btn.dataset.gsub);
        if (target) target.style.display = "block";
      });
    });

    // Category Filter
    const catFilter = document.getElementById("niche-category-filter");
    if (catFilter) {
      catFilter.addEventListener("change", (e) => {
        this.loadTrends(e.target.value);
      });
    }

    // Dropzone for Reference Hub
    const dropzone = document.getElementById("ref-dropzone");
    const fileInput = document.getElementById("ref-file-input");
    if (dropzone && fileInput) {
      dropzone.addEventListener("dragover", (e) => {
        e.preventDefault();
        dropzone.style.borderColor = "var(--cyan-core)";
        dropzone.style.background = "rgba(0, 229, 255, 0.06)";
      });
      dropzone.addEventListener("dragleave", () => {
        dropzone.style.borderColor = "rgba(0, 229, 255, 0.3)";
        dropzone.style.background = "rgba(0, 229, 255, 0.02)";
      });
      dropzone.addEventListener("drop", (e) => {
        e.preventDefault();
        dropzone.style.borderColor = "rgba(0, 229, 255, 0.3)";
        dropzone.style.background = "rgba(0, 229, 255, 0.02)";
        if (e.dataTransfer.files.length) {
          this.uploadReferenceFiles(e.dataTransfer.files);
        }
      });
      fileInput.addEventListener("change", (e) => {
        if (e.target.files.length) {
          this.uploadReferenceFiles(e.target.files);
        }
      });
    }
  }

  switchTab(tabId) {
    document.querySelectorAll(".nav-btn[data-tab]").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".tab-pane").forEach(p => p.classList.remove("active"));

    const activeBtn = document.querySelector(`.nav-btn[data-tab="${tabId}"]`);
    if (activeBtn) activeBtn.classList.add("active");

    const activePane = document.getElementById(tabId);
    if (activePane) activePane.classList.add("active");

    if (window.lucide) lucide.createIcons();

    if (tabId === "tab-marketing" && this.currentBook?.marketing) {
      this.renderMarketingCampaign(this.currentBook.marketing);
    }
    if (tabId === "tab-telegram") {
      this.loadTelegramAlerts();
    }
  }

  // --- TAB 1: Live Internet Trends ---
  async loadTrends(category = "All") {
    try {
      const res = await fetch(`/api/trends?category=${encodeURIComponent(category)}`);
      const data = await res.json();
      if (!data.success) return;

      const container = document.getElementById("niche-grid-container");
      if (!container) return;

      container.innerHTML = data.niches.map(n => `
        <div class="niche-card" onclick="app.selectNiche('${n.id}')">
          <div class="niche-card-header">
            <span class="niche-category">${n.category}</span>
            <span class="badge badge-emerald">SCORE ${n.opportunityScore}/100</span>
          </div>
          <div class="niche-title">${n.title}</div>
          <div class="niche-desc">${n.description}</div>
          <div style="background: #060910; border: 1px solid var(--border-dim); border-radius: var(--radius-sm); padding: 10px; margin: 12px 0;">
            <div class="mono" style="font-size: 10px; color: var(--text-dim); text-transform: uppercase;">PRICING & REVENUE TARGET</div>
            <div style="display: flex; justify-content: space-between; align-items: baseline; margin-top: 4px;">
              <span class="mono" style="font-size: 13px; font-weight: 700; color: var(--emerald-core);">${n.targetPriceInr}</span>
              <span class="mono" style="font-size: 11px; color: var(--cyan-core);">${n.targetDailySales}</span>
            </div>
          </div>
          <div style="display: flex; justify-content: space-between; align-items: center; border-top: 1px solid var(--border-dim); padding-top: 10px; margin-top: 10px;">
            <span class="mono" style="font-size: 11px; color: var(--amber-core); font-weight: 600;">${n.dailyRevenueProjection}</span>
            <button class="btn-core" style="padding: 4px 10px; font-size: 11px;" onclick="event.stopPropagation(); app.lockNicheAndGoToStudio('${n.id}')">
              Lock Niche
            </button>
          </div>
        </div>
      `).join("");

      if (window.lucide) lucide.createIcons();
    } catch (e) {
      console.error("Trends fetch error:", e);
    }
  }

  async executeLiveInternetSearch() {
    const input = document.getElementById("live-search-input");
    const query = input ? input.value.trim() : "";
    if (!query) return;

    const feedback = document.getElementById("live-search-feedback");
    const list = document.getElementById("live-search-results-list");
    feedback.style.display = "block";
    list.innerHTML = `<span class="mono" style="color: var(--cyan-core);">[CRAWLING INTERNET SIGNALS] Fetching live search queries and buyer intent data for "${query}"...</span>`;

    try {
      const res = await fetch("/api/trends/search", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query })
      });
      const data = await res.json();
      if (data.success) {
        list.innerHTML = `
          <div style="margin-bottom: 8px;">
            <strong>Live Search Signal:</strong> ${data.liveResults.organicSummary}<br />
            <strong>Estimated Search Volume:</strong> <span class="mono" style="color: var(--cyan-core);">${data.liveResults.estimatedMonthlySearches}</span> &bull; 
            <strong>Buyer Intent:</strong> <span class="mono" style="color: var(--emerald-core);">${data.liveResults.buyerIntent}</span>
          </div>
          <div style="background: #060910; border: 1px solid var(--border-dim); padding: 10px; border-radius: var(--radius-sm); margin-top: 8px;">
            <strong>Opportunity Score:</strong> ${data.evaluation.opportunityScore}/100 | 
            <strong>Recommended Title:</strong> "${data.evaluation.suggestedTitle}" | 
            <button class="btn-core" style="padding: 3px 8px; font-size: 11px; margin-left: 10px;" onclick="app.setCustomTopic('${data.evaluation.suggestedTitle.replace(/'/g, "\\'")}')">
              Use Title in Studio
            </button>
          </div>
        `;
      }
    } catch (e) {
      list.innerHTML = `<span style="color: var(--crimson-core);">Crawler error: ${e.message}</span>`;
    }
  }

  selectNiche(nicheId) {
    this.selectedNiche = nicheId;
    this.lockNicheAndGoToStudio(nicheId);
  }

  async lockNicheAndGoToStudio(nicheId) {
    this.selectedNiche = nicheId;
    const res = await fetch("/api/trends");
    const data = await res.json();
    const niche = data.niches?.find(n => n.id === nicheId);

    const display = document.getElementById("studio-niche-display");
    const customTopicInput = document.getElementById("custom-topic-input");

    if (niche && display) {
      display.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center;">
          <div>
            <strong>[LOCKED] ${niche.title}</strong><br />
            <span style="font-size: 11px; color: var(--text-dim);">${niche.category} &bull; ${niche.targetPriceInr} &bull; Goal: ${niche.targetDailySales}</span>
          </div>
          <button class="btn-core btn-secondary" style="padding: 2px 8px; font-size: 10px;" onclick="app.clearLockedNiche()">Change</button>
        </div>
      `;
      if (customTopicInput && !customTopicInput.value) {
        customTopicInput.value = niche.title;
      }
    }

    this.switchTab("tab-studio");
  }

  clearLockedNiche() {
    this.selectedNiche = null;
    const display = document.getElementById("studio-niche-display");
    if (display) display.textContent = "No niche locked. Pick one from Radar or enter custom topic below.";
  }

  setCustomTopic(title) {
    const input = document.getElementById("custom-topic-input");
    if (input) input.value = title;
    this.switchTab("tab-studio");
  }

  // --- TAB 2: Hermes Studio Execution ---
  async triggerFullSynthesis() {
    const customTopic = document.getElementById("custom-topic-input").value.trim();
    const audience = document.getElementById("target-audience-input").value.trim();
    const tone = document.getElementById("editorial-tone-select").value;
    const theme = document.getElementById("cover-theme-select").value;

    if (!customTopic && !this.selectedNiche) {
      alert("Please enter a book topic or select a niche from the Radar tab.");
      return;
    }

    const btn = document.getElementById("btn-start-synthesis");
    const tag = document.getElementById("terminal-agent-tag");
    btn.disabled = true;
    btn.innerHTML = `<i data-lucide="loader-2" class="spin"></i> SYNTHESIZING COMPLETE EBOOK...`;

    this.logTerminal("HERMES CRAWLER", `Validating demand signals and real-time competitor angles for "${customTopic || 'Selected Niche'}"...`);

    setTimeout(() => {
      this.logTerminal("HERMES ARCHITECT", "Formulating 7-chapter execution roadmap and micro-ticket conversion hooks...");
    }, 900);

    setTimeout(() => {
      this.logTerminal("HERMES GHOSTWRITER", "Synthesizing 7 dense, practical non-fiction chapters (INR 500 calibration)...");
    }, 2000);

    try {
      const res = await fetch("/api/generate-full-book", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          topic: customTopic,
          nicheId: this.selectedNiche,
          tone,
          targetAudience: audience,
          theme,
          priceInr: 500,
          priceUsd: 5.21
        })
      });

      const data = await res.json();
      if (data.success) {
        this.currentBook = data.book;
        this.logTerminal("OPEN HIGGSFIELD", `Synthesized 3D technical cover art (${theme}) with zero emojis.`);
        this.logTerminal("MARKETING ORCHESTRA", "Generated viral short-form scripts, Twitter thread, Reddit drops, and bio funnels.");
        this.logTerminal("TELEGRAM DISPATCH", "Sent launch alert notification to dedicated eBook Telegram bot.");
        this.logTerminal("SYSTEM", "Full eBook creation finished successfully. Ready for reader inspection & Gumroad launch.");

        this.renderEditorialReader(this.currentBook);
        this.renderGumroadPublisher(this.currentBook.launchPackage);
        if (this.currentBook.marketing) {
          this.renderMarketingCampaign(this.currentBook.marketing);
        }
        await this.loadTelegramAlerts();

        // Switch to reader
        setTimeout(() => this.switchTab("tab-reader"), 800);
      } else {
        throw new Error(data.error || "Synthesis failed");
      }
    } catch (err) {
      this.logTerminal("ERROR", `Synthesis execution aborted: ${err.message}`);
      alert("Synthesis error: " + err.message);
    } finally {
      btn.disabled = false;
      btn.innerHTML = `<i data-lucide="zap"></i> EXECUTE AUTONOMOUS SYNTHESIS`;
      if (window.lucide) lucide.createIcons();
    }
  }

  logTerminal(agent, msg) {
    const box = document.getElementById("terminal-window");
    if (!box) return;

    const time = new Date().toLocaleTimeString();
    const div = document.createElement("div");
    div.className = "terminal-line";
    div.innerHTML = `
      <span class="t-time">[${time}]</span>
      <span class="t-tag">[${agent}]</span>
      <span>${msg}</span>
    `;
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
  }

  // --- TAB 3: Marketing Bot Orchestra ---
  async generateMarketingAssets() {
    try {
      this.logTerminal("MARKETING ORCHESTRA", "Generating high-converting viral assets across 4 channels...");
      const res = await fetch("/api/marketing/generate", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        if (this.currentBook) this.currentBook.marketing = data.marketing;
        this.renderMarketingCampaign(data.marketing);
        this.logTerminal("MARKETING ORCHESTRA", "Campaign generated successfully!");
      }
    } catch (e) {
      alert("Failed to generate marketing assets: " + e.message);
    }
  }

  renderMarketingCampaign(m) {
    if (!m) return;

    // 1. Short-form Video Scripts
    const videoContainer = document.getElementById("m-video-container");
    const scripts = m.videoScripts || m.shortFormVideoScripts || [];
    if (videoContainer && scripts.length > 0) {
      videoContainer.innerHTML = scripts.map((v, i) => `
        <div class="marketing-card">
          <div class="marketing-tag" style="color: var(--cyan-core);">VIDEO SCRIPT #${i + 1} // ${v.platform || v.targetPlatform || 'REELS / TIKTOK'}</div>
          <div style="background: #040810; border: 1px solid var(--border-dim); border-radius: var(--radius-sm); padding: 10px; margin-bottom: 12px;">
            <span class="mono" style="font-size: 10px; color: var(--amber-core); font-weight: 700;">3-SECOND HOOK:</span>
            <div style="font-size: 14px; font-weight: 700; color: #FFFFFF; margin-top: 3px;">"${v.hook}"</div>
          </div>
          <div style="font-size: 12px; color: var(--text-dim); margin-bottom: 10px;">
            <strong style="color: var(--text-secondary);">Visual Concept:</strong> ${v.sceneDirection || v.visualConcept || 'B-Roll demonstration'}
          </div>
          <div style="background: #020408; border: 1px solid var(--border-dim); border-radius: var(--radius-sm); padding: 12px; font-size: 13px; line-height: 1.6; color: #CBD5E1; margin-bottom: 10px; white-space: pre-wrap;">${v.scriptBody || v.spokenScript || ''}</div>
        </div>
      `).join("");
    }

    // 2. Twitter Thread
    const twitterContainer = document.getElementById("m-twitter-container");
    const thread = m.twitterThread || m.twitterAuthorityThread || [];
    if (twitterContainer && Array.isArray(thread) && thread.length > 0) {
      twitterContainer.innerHTML = thread.map((tweetText, idx) => `
        <div class="marketing-card" style="margin-bottom: 12px; ${idx === thread.length - 1 ? 'border-color: var(--border-bright);' : ''}">
          <div class="marketing-tag" style="color: ${idx === 0 ? 'var(--cyan-core)' : idx === thread.length - 1 ? 'var(--emerald-core)' : 'var(--text-dim)'};">
            ${idx === 0 ? 'THREAD HOOK' : idx === thread.length - 1 ? 'CONVERSION CTA' : `TWEET ${idx + 1}/${thread.length}`}
          </div>
          <div style="font-size: 14px; font-weight: ${idx === 0 || idx === thread.length - 1 ? '600' : '400'}; color: #FFFFFF; line-height: 1.6; white-space: pre-wrap;">${tweetText}</div>
        </div>
      `).join("");
    }

    // 3. Reddit / Community Value Posts
    const redditContainer = document.getElementById("m-reddit-container");
    const cp = m.communityPost;
    if (redditContainer && cp) {
      redditContainer.innerHTML = `
        <div class="marketing-card">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
            <span class="marketing-tag" style="color: var(--amber-core);">TARGET COMMUNITIES: ${cp.targetSubreddits}</span>
            <span class="mono" style="font-size: 11px; color: var(--emerald-core);">HIGH VALUE ORGANIC DROP</span>
          </div>
          <div style="font-size: 15px; font-weight: 700; color: #FFFFFF; margin-bottom: 12px;">${cp.title}</div>
          <pre style="background: #020408; border: 1px solid var(--border-dim); border-radius: var(--radius-sm); padding: 16px; font-family: 'Inter', sans-serif; font-size: 13px; line-height: 1.7; white-space: pre-wrap; color: #CBD5E1; margin-bottom: 12px;">${cp.body}</pre>
        </div>
      `;
    }

    // 4. Bio Funnel
    const bioContainer = document.getElementById("m-bio-container");
    const bf = m.bioFunnel;
    if (bioContainer && bf) {
      bioContainer.innerHTML = `
        <div class="marketing-card">
          <div class="marketing-tag" style="color: var(--cyan-core);">INSTAGRAM / TIKTOK BIO COPY</div>
          <pre style="background: #020408; border: 1px solid var(--border-dim); border-radius: var(--radius-sm); padding: 14px; font-family: 'Inter', sans-serif; font-size: 13.5px; line-height: 1.6; white-space: pre-wrap; color: #E2E8F0; margin-bottom: 14px;">${bf.instagramBio}</pre>
          <div class="marketing-tag" style="color: var(--amber-core); margin-top: 18px;">TWITTER / X PROFILE BIO</div>
          <pre style="background: #020408; border: 1px solid var(--border-dim); border-radius: var(--radius-sm); padding: 14px; font-family: 'Inter', sans-serif; font-size: 13.5px; line-height: 1.6; white-space: pre-wrap; color: #E2E8F0; margin-bottom: 14px;">${bf.twitterBio}</pre>
        </div>

        <div class="marketing-card">
          <div class="marketing-tag" style="color: var(--emerald-core);">EMAIL LAUNCH / BROADCAST ANCHOR</div>
          <pre style="background: #020408; border: 1px solid var(--border-dim); border-radius: var(--radius-sm); padding: 14px; font-family: 'Inter', sans-serif; font-size: 13px; line-height: 1.6; white-space: pre-wrap; color: #CBD5E1; margin-bottom: 14px;">${bf.emailLaunchHeader}</pre>
          <div class="mono" style="font-size: 11px; color: var(--text-dim); margin-bottom: 4px;">TARGET CHECKOUT PERMALINK:</div>
          <div class="mono" style="font-size: 12px; color: var(--cyan-core);">https://gumroad.com/l/${(this.currentBook?.title || "ebook").toLowerCase().replace(/[^a-z0-9]/g, "-").slice(0, 25)}</div>
        </div>
      `;
    }

    if (window.lucide) lucide.createIcons();
  }

  // --- TAB 4: Gumroad Publisher ---
  async publishToGumroad() {
    if (!this.currentBook) {
      alert("No active eBook to publish. Synthesize or restore an eBook first.");
      return;
    }

    try {
      this.logTerminal("GUMROAD", "Calling Gumroad API to package product listing...");
      const res = await fetch("/api/gumroad/publish", {
        method: "POST",
        headers: { "Content-Type": "application/json" }
      });
      const data = await res.json();

      if (data.success) {
        const p = data.product;
        this.logTerminal("GUMROAD", `Product packaged! Mode: ${data.mode}. Live Link: ${p.url}`);

        const alertBox = document.getElementById("gumroad-publish-alert");
        const alertBody = document.getElementById("gumroad-alert-body");
        alertBox.style.display = "block";
        alertBody.innerHTML = `
          Product <strong>"${p.name}"</strong> (INR 500 / $5.21 USD) is packaged and ready.<br />
          <strong>Store Checkout URL:</strong> <a href="${p.url}" target="_blank" style="color: var(--cyan-core); text-decoration: underline;">${p.url}</a><br />
          <span style="color: var(--text-dim); font-size: 12px;">${p.message}</span>
        `;
      }
    } catch (e) {
      this.logTerminal("GUMROAD", `Publishing error: ${e.message}`);
    }
  }

  async simulateGumroadSale() {
    try {
      this.logTerminal("GUMROAD SIMULATOR", "Simulating incoming customer purchase for INR 500 ($5.21 USD)...");
      const res = await fetch("/api/gumroad/simulate-sale", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          product_name: this.currentBook?.title || "THE FACELESS WEALTH MACHINE",
          price: 521,
          email: `customer_${Math.floor(Math.random()*9000)+1000}@gmail.com`
        })
      });
      const data = await res.json();
      if (data.success) {
        this.logTerminal("TELEGRAM DISPATCH", "Dispatched live sale alert to dedicated eBook Telegram bot!");
        await this.loadTelegramAlerts();
        this.switchTab("tab-telegram");
      }
    } catch (e) {
      alert("Error simulating sale: " + e.message);
    }
  }

  renderGumroadPublisher(pkg) {
    if (!pkg) return;

    const copyView = document.getElementById("gumroad-copy-view");
    if (copyView) copyView.textContent = pkg.salesPageCopy;

    const emailsView = document.getElementById("gumroad-emails-view");
    if (emailsView && pkg.emailSequence) {
      emailsView.innerHTML = pkg.emailSequence.map(e => `
        <div style="background: #060910; border: 1px solid var(--border-dim); padding: 16px; border-radius: var(--radius-sm);">
          <div class="mono" style="font-size: 11px; color: var(--amber-core); font-weight: 700; margin-bottom: 4px;">DAY ${e.day} // ${e.preview}</div>
          <div style="font-size: 14px; font-weight: 700; color: #FFFFFF; margin-bottom: 10px;">Subject: ${e.subject}</div>
          <pre style="font-family: 'Inter', sans-serif; font-size: 13.5px; white-space: pre-wrap; color: #CBD5E1; line-height: 1.6;">${e.body}</pre>
        </div>
      `).join("");
    }

    const mathView = document.getElementById("gumroad-math-view");
    if (mathView && pkg.revenueBlueprint) {
      const rb = pkg.revenueBlueprint;
      mathView.innerHTML = `
        <div class="mono" style="font-size: 14px; font-weight: 700; color: var(--amber-core); margin-bottom: 12px;">INR 35,500/DAY ($370/DAY) UNIT ECONOMICS</div>
        <p style="font-size: 13.5px; color: var(--text-secondary); margin-bottom: 18px;">Monthly Projected Cashflow: <strong style="color: #FFFFFF;">${rb.targetMonthlyRevenue}</strong></p>
        
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px; font-size: 13.5px;">
          <thead>
            <tr style="background: #030508; text-align: left;">
              <th style="padding: 10px; border: 1px solid var(--border-dim); color: #FFFFFF;">Tier</th>
              <th style="padding: 10px; border: 1px solid var(--border-dim); color: #FFFFFF;">Price</th>
              <th style="padding: 10px; border: 1px solid var(--border-dim); color: #FFFFFF;">Daily Sales</th>
              <th style="padding: 10px; border: 1px solid var(--border-dim); color: #FFFFFF;">Daily Total</th>
            </tr>
          </thead>
          <tbody>
            ${rb.pricingMatrix.map(t => `
              <tr>
                <td style="padding: 10px; border: 1px solid var(--border-dim); color: #E2E8F0;">${t.tier}</td>
                <td class="mono" style="padding: 10px; border: 1px solid var(--border-dim); color: var(--cyan-core);">${t.price}</td>
                <td class="mono" style="padding: 10px; border: 1px solid var(--border-dim); color: var(--amber-core); font-weight: 700;">${t.dailySalesRequired}</td>
                <td class="mono" style="padding: 10px; border: 1px solid var(--border-dim); color: var(--emerald-core); font-weight: 700;">${t.dailyTotal}</td>
              </tr>
            `).join("")}
          </tbody>
        </table>
      `;
    }
  }

  // --- TAB 5: Dedicated Telegram Sales Bot Monitor ---
  async loadTelegramAlerts() {
    try {
      const res = await fetch("/api/telegram/alerts");
      const data = await res.json();
      if (!data.success) return;

      const feed = document.getElementById("telegram-alerts-feed");
      if (!feed) return;

      const logs = data.logs || data.alerts || [];

      if (logs.length === 0) {
        feed.innerHTML = `
          <div style="color: var(--text-dim); text-align: center; padding: 24px; font-size: 13px;">
            No alerts logged yet. Click "Trigger Test Sale Alert" or "Send Test Ping to Bot" above.
          </div>
        `;
        return;
      }

      feed.innerHTML = logs.map(a => {
        const typeLower = (a.type || "sale").toLowerCase();
        let borderStyle = "border-left: 3px solid var(--emerald-core);";
        let badgeColor = "var(--emerald-core)";
        if (typeLower.includes("launch")) {
          borderStyle = "border-left: 3px solid var(--cyan-core);";
          badgeColor = "var(--cyan-core)";
        } else if (typeLower.includes("test")) {
          borderStyle = "border-left: 3px solid var(--amber-core);";
          badgeColor = "var(--amber-core)";
        }

        return `
          <div class="telegram-alert-card" style="${borderStyle}">
            <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 6px;">
              <span style="color: ${badgeColor}; font-weight: 700;">
                [${a.type}] ${a.simulated ? '(STAGING SIMULATION)' : '(LIVE DISPATCH)'}
              </span>
              <span style="color: var(--text-dim); font-size: 11px;">${new Date(a.timestamp).toLocaleTimeString()}</span>
            </div>
            <pre style="font-family: 'JetBrains Mono', monospace; font-size: 12px; white-space: pre-wrap; color: #F1F5F9; line-height: 1.5; margin: 0;">${a.text}</pre>
          </div>
        `;
      }).join("");
    } catch (e) {
      console.warn("Alerts fetch error:", e);
    }
  }


  async sendTelegramTestPing() {
    const token = document.getElementById("telegram-token-input")?.value.trim();
    const chatId = document.getElementById("telegram-chat-id-input")?.value.trim();

    try {
      this.logTerminal("TELEGRAM BOT", "Sending test ping to dedicated eBook bot...");
      const res = await fetch("/api/telegram/test-ping", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, chatId })
      });
      const data = await res.json();
      if (data.success) {
        this.logTerminal("TELEGRAM BOT", `Ping dispatched. Success: ${data.result.success}`);
        await this.loadTelegramAlerts();
        alert(data.result.success ? "Test ping sent to your Telegram bot!" : `Ping simulated (Token not live): ${data.result.error}`);
      }
    } catch (e) {
      alert("Failed to send ping: " + e.message);
    }
  }

  async saveTelegramConfig() {
    const token = document.getElementById("telegram-token-input").value.trim();
    const chatId = document.getElementById("telegram-chat-id-input").value.trim();

    try {
      const res = await fetch("/api/telegram/config", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token, chatId })
      });
      const data = await res.json();
      if (data.success) {
        alert("Dedicated eBook Telegram bot configured successfully!");
        this.logTerminal("TELEGRAM BOT", "Credentials configured.");
      }
    } catch (e) {
      alert("Error saving telegram config: " + e.message);
    }
  }

  // --- TAB 6: Editorial Reader & Exporter ---
  async loadCurrentBook() {
    try {
      const res = await fetch("/api/book/current");
      const data = await res.json();
      if (data.success && data.book) {
        this.currentBook = data.book;
        this.renderEditorialReader(this.currentBook);
        this.renderGumroadPublisher(this.currentBook.launchPackage);
        if (this.currentBook.marketing) {
          this.renderMarketingCampaign(this.currentBook.marketing);
        }
      }
    } catch (e) {
      console.error(e);
    }
  }

  async resetFlagshipBook() {
    try {
      const res = await fetch("/api/book/reset-sample", { method: "POST" });
      const data = await res.json();
      if (data.success) {
        this.currentBook = data.book;
        this.renderEditorialReader(this.currentBook);
        this.renderGumroadPublisher(this.currentBook.launchPackage);
        if (this.currentBook.marketing) {
          this.renderMarketingCampaign(this.currentBook.marketing);
        }
        alert("Flagship sample publication restored successfully.");
      }
    } catch (e) {
      alert("Error restoring sample: " + e.message);
    }
  }

  renderEditorialReader(book) {
    if (!book) return;

    const titleEl = document.getElementById("reader-title");
    const subEl = document.getElementById("reader-sub");
    const coverEl = document.getElementById("cover-svg-display");
    const tocEl = document.getElementById("toc-button-list");

    if (titleEl) titleEl.textContent = book.title;
    if (subEl) subEl.textContent = book.subtitle;
    if (coverEl && book.coverSvg) coverEl.innerHTML = book.coverSvg;

    if (tocEl && book.chapters) {
      tocEl.innerHTML = book.chapters.map((ch, idx) => `
        <button class="toc-btn ${idx === this.activeChapterIdx ? 'active' : ''}" onclick="app.selectChapter(${idx})">
          <span class="toc-btn-num">CHAPTER ${ch.number}</span>
          <span style="font-size: 12.5px; font-weight: 600; text-overflow: ellipsis; overflow: hidden; white-space: nowrap;">${ch.title}</span>
        </button>
      `).join("");
    }

    this.selectChapter(this.activeChapterIdx);
  }

  selectChapter(idx) {
    if (!this.currentBook?.chapters || !this.currentBook.chapters[idx]) return;
    this.activeChapterIdx = idx;

    document.querySelectorAll(".toc-btn").forEach((b, i) => {
      b.classList.toggle("active", i === idx);
    });

    const ch = this.currentBook.chapters[idx];
    const lbl = document.getElementById("active-chapter-label");
    const view = document.getElementById("chapter-formatted-view");
    const area = document.getElementById("chapter-raw-textarea");

    if (lbl) lbl.textContent = `CHAPTER ${ch.number} // ${ch.title.toUpperCase()}`;

    if (view) {
      let formatted = ch.content || "";
      formatted = formatted
        .replace(/^### (.*$)/gim, "<h3>$1</h3>")
        .replace(/^## (.*$)/gim, "<h2>$1</h2>")
        .replace(/^# (.*$)/gim, "<h1>$1</h1>")
        .replace(/^\> (.*$)/gim, "<blockquote>$1</blockquote>")
        .replace(/\*\*(.*?)\*\*/gim, "<strong>$1</strong>")
        .replace(/\*(.*?)\*/gim, "<em>$1</em>")
        .replace(/\n\n/g, "<p></p>")
        .replace(/\n/g, "<br />");
      view.innerHTML = formatted;
    }

    if (area) area.value = ch.content || "";
  }

  toggleChapterEditor() {
    this.isEditing = !this.isEditing;
    const view = document.getElementById("chapter-formatted-view");
    const area = document.getElementById("chapter-raw-textarea");
    const btnToggle = document.getElementById("btn-toggle-editor");
    const btnSave = document.getElementById("btn-save-chapter");

    if (this.isEditing) {
      view.style.display = "none";
      area.style.display = "block";
      btnSave.style.display = "inline-flex";
      btnToggle.innerHTML = `<i data-lucide="x"></i> Cancel`;
    } else {
      view.style.display = "block";
      area.style.display = "none";
      btnSave.style.display = "none";
      btnToggle.innerHTML = `<i data-lucide="edit-2"></i> Edit Chapter`;
    }
    if (window.lucide) lucide.createIcons();
  }

  async saveActiveChapter() {
    if (!this.currentBook?.chapters || !this.currentBook.chapters[this.activeChapterIdx]) return;
    const area = document.getElementById("chapter-raw-textarea");
    this.currentBook.chapters[this.activeChapterIdx].content = area.value;

    try {
      await fetch("/api/book/save", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ book: this.currentBook })
      });
      this.toggleChapterEditor();
      this.selectChapter(this.activeChapterIdx);
      alert("Chapter updated successfully.");
    } catch (e) {
      alert("Failed to save chapter: " + e.message);
    }
  }

  exportPdf() {
    window.open("/api/export/html", "_blank");
  }

  exportMarkdown() {
    window.location.href = "/api/export/markdown";
  }

  exportJson() {
    window.location.href = "/api/export/json";
  }

  // --- TAB 7: 24/7 Training Telemetry ---
  async loadTrainingStatus() {
    try {
      const res = await fetch("/api/training/status");
      const data = await res.json();
      if (!data.success) return;

      const s = data.status;
      const cycEl = document.getElementById("stat-cycles");
      const upEl = document.getElementById("stat-uptime");

      if (cycEl) cycEl.textContent = s.totalCycles.toLocaleString();
      if (upEl) upEl.textContent = `${s.uptimeHours} HOURS`;

      const botGrid = document.getElementById("bot-roster-grid");
      if (botGrid && s.bots) {
        botGrid.innerHTML = s.bots.map(b => {
          const pct = Math.min(100, Math.round((b.xp / (b.level * 2000)) * 100));
          return `
            <div class="bot-card">
              <div class="bot-card-header">
                <span class="bot-name">${b.name}</span>
                <span class="bot-level">LVL ${b.level}</span>
              </div>
              <div class="bot-spec">${b.specialization}</div>
              <div class="mono" style="font-size: 10px; color: var(--text-dim); display: flex; justify-content: space-between; margin-bottom: 4px;">
                <span>EXP: ${b.xp.toLocaleString()} XP</span>
                <span>${pct}%</span>
              </div>
              <div class="xp-bar-bg">
                <div class="xp-bar-fill" style="width: ${pct}%;"></div>
              </div>
            </div>
          `;
        }).join("");
      }

      const cycleLog = document.getElementById("training-cycle-log");
      if (cycleLog && s.recentCycles) {
        cycleLog.innerHTML = s.recentCycles.map(c => `
          <div class="mono" style="font-size: 11.5px; padding: 6px 0; border-bottom: 1px solid rgba(255,255,255,0.04); display: flex; justify-content: space-between;">
            <div>
              <span style="color: var(--cyan-core);">[CYCLE ${c.cycle}]</span>
              <span style="color: #FFFFFF; margin-left: 8px;">${c.topic}</span>
              <span style="color: var(--text-dim); margin-left: 8px;">(+${c.tokensAdded} tokens)</span>
            </div>
            <div style="color: var(--emerald-core);">${c.gain}</div>
          </div>
        `).join("");
      }
    } catch (e) {
      console.warn("Training status error:", e);
    }
  }

  // --- TAB 8: Reference Hub ---
  async loadReferences() {
    try {
      const res = await fetch("/api/references");
      const data = await res.json();
      if (!data.success) return;

      const detailsEl = document.getElementById("ref-status-details");
      if (detailsEl) detailsEl.textContent = data.summary.summary;

      const grid = document.getElementById("ref-items-grid");
      if (!grid) return;

      if (!data.references.length) {
        grid.innerHTML = `
          <div style="grid-column: 1 / -1; color: var(--text-dim); font-size: 13px; text-align: center; padding: 24px;">
            No custom files uploaded yet. Drag and drop assets above to train semantic vectors.
          </div>
        `;
        return;
      }

      grid.innerHTML = data.references.map(r => `
        <div style="background: #080C14; border: 1px solid var(--border-dim); border-radius: var(--radius-sm); padding: 12px; display: flex; gap: 12px; align-items: center;">
          ${r.type === 'image' 
            ? `<img src="${r.url}" style="width: 44px; height: 44px; object-fit: cover; border-radius: 3px;" alt="Asset" />`
            : `<div class="mono" style="width: 44px; height: 44px; background: rgba(0,229,255,0.1); color: var(--cyan-core); display: flex; align-items: center; justify-content: center; font-weight: 700;">DOC</div>`
          }
          <div style="flex: 1; overflow: hidden;">
            <div style="font-size: 13px; font-weight: 600; color: #FFFFFF; text-overflow: ellipsis; overflow: hidden; white-space: nowrap;">${r.originalName}</div>
            <div class="mono" style="font-size: 10px; color: var(--text-dim); margin-top: 2px;">${(r.size/1024).toFixed(1)} KB &bull; ${r.type.toUpperCase()}</div>
          </div>
          <button onclick="app.deleteReference('${r.filename}')" style="background: none; border: none; color: var(--crimson-core); cursor: pointer; padding: 4px;">
            <i data-lucide="trash-2" style="width: 14px; height: 14px;"></i>
          </button>
        </div>
      `).join("");

      if (window.lucide) lucide.createIcons();
    } catch (e) {
      console.error(e);
    }
  }

  async uploadReferenceFiles(files) {
    const fd = new FormData();
    for (let i = 0; i < files.length; i++) fd.append("files", files[i]);

    try {
      this.logTerminal("KNOWLEDGE INTAKE", `Ingesting ${files.length} reference file(s)...`);
      const res = await fetch("/api/upload", { method: "POST", body: fd });
      const data = await res.json();
      if (data.success) {
        this.logTerminal("KNOWLEDGE INTAKE", `Indexed ${data.uploaded.length} assets into semantic vector memory.`);
        await this.loadReferences();
      }
    } catch (e) {
      this.logTerminal("SYSTEM", `Upload failure: ${e.message}`);
    }
  }

  async deleteReference(filename) {
    try {
      await fetch(`/api/references/${filename}`, { method: "DELETE" });
      await this.loadReferences();
      this.logTerminal("KNOWLEDGE INTAKE", `Reference ${filename} removed from vector index.`);
    } catch (e) {
      console.error(e);
    }
  }

  // --- TAB 9: Settings ---
  async loadSettings() {
    try {
      const res = await fetch("/api/settings");
      const data = await res.json();
      if (data.success) {
        const provSelect = document.getElementById("settings-provider-select");
        if (provSelect) provSelect.value = data.provider;
        const tag = document.getElementById("header-telegram-tag");
        if (tag) {
          tag.textContent = data.hasTelegramToken ? "TELEGRAM LIVE" : "MONITOR READY";
          tag.style.color = data.hasTelegramToken ? "var(--emerald-core)" : "var(--amber-core)";
        }
      }
    } catch (e) {
      console.error(e);
    }
  }

  async savePlatformSettings() {
    const provider = document.getElementById("settings-provider-select").value;
    const apiKey = document.getElementById("settings-api-key-input").value;
    const gumroadToken = document.getElementById("settings-gumroad-token-input").value;

    try {
      await fetch("/api/settings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ provider, apiKey, gumroadToken })
      });
      await this.loadSettings();
      alert("Settings and credentials updated successfully.");
    } catch (e) {
      alert("Failed to save settings: " + e.message);
    }
  }
}

// Instantiate App
window.app = new AsuraHermesApp();
