﻿// agents/hermesEngine.js
// Nous Hermes Reasoning & Function-Calling Orchestrator
// Connects to McpToolHub and coordinates the Asura multi-agent workflow with zero emojis

import { McpToolHub } from "./mcpHub.js";
import { OpenHiggsfieldVisualAgent } from "./openHiggsfield.js";
import { ArchitectAgent } from "./architect.js";
import { GhostwriterAgent } from "./ghostwriter.js";
import { LaunchpadAgent } from "./launchpad.js";

export class HermesAgentEngine {
  constructor() {
    this.name = "Hermes Agent Core";
    this.model = "NousResearch/Hermes-3-FunctionCalling";
    this.mcpHub = new McpToolHub();
    this.visualAgent = new OpenHiggsfieldVisualAgent();
    this.architect = new ArchitectAgent();
    this.ghostwriter = new GhostwriterAgent();
    this.launchpad = new LaunchpadAgent();
  }

  async runAutonomousSynthesis({ topic, niche, tone, targetAudience, price = 37, theme = "asura-titanium", referenceContext = null, onProgress }) {
    const notify = (bot, message) => {
      if (onProgress) onProgress({ bot, message, timestamp: new Date().toISOString() });
    };

    // 1. Tool Call: search_internet for live intelligence
    notify("Hermes Internet Crawler", `Executing MCP Tool: search_internet("${topic}"). Querying real-time market signals...`);
    const internetData = await this.mcpHub.executeTool("search_internet", { query: topic });
    notify("Hermes Internet Crawler", `Retrieved ${internetData.resultsCount} live market signals from ${internetData.source}.`);

    // 2. Synthesize Outline & Hooks
    notify("Hermes Architect", `Synthesizing market positioning, asymmetric leverage mechanism, and 7-chapter architecture...`);
    const outline = await this.architect.generateOutline({
      topic,
      niche,
      tone: tone || "Authoritative & Action-Oriented",
      targetAudience,
      referenceContext
    });

    // 3. Deep Ghostwriting loop with zero emojis
    notify("Hermes Ghostwriter", `Generating 7 high-density practical chapters with empirical blueprints...`);
    const chaptersWithContent = [];
    for (let i = 0; i < outline.chapters.length; i++) {
      const ch = outline.chapters[i];
      notify("Hermes Ghostwriter", `Drafting Chapter ${ch.number}: "${ch.title}" [Framework: ${ch.framework}]...`);
      const content = await this.ghostwriter.generateChapter({
        chapter: ch,
        bookTitle: outline.title,
        bookSubtitle: outline.subtitle,
        tone: outline.tone,
        targetAudience: outline.targetAvatar.profile,
        referenceContext
      });
      chaptersWithContent.push({
        ...ch,
        content
      });
    }

    // 4. Open Higgsfield Visual Generation
    notify("Open Higgsfield Studio", `Synthesizing high-precision SVG vector cover art and 3D digital product mockup (${theme})...`);
    const coverSvg = this.visualAgent.generateCoverSvg({
      title: outline.title,
      subtitle: outline.subtitle,
      author: outline.author,
      category: outline.category,
      theme
    });

    // 5. Commercial Launchpad ($373/day blueprint)
    notify("Hermes Commercial Bot", `Formulating Gumroad sales copy, 5-day email campaign, and 10 viral video scripts...`);
    const launchPackage = this.launchpad.generateCommercialPackage({
      bookTitle: outline.title,
      bookSubtitle: outline.subtitle,
      category: outline.category,
      chapters: chaptersWithContent,
      targetAvatar: outline.targetAvatar,
      price
    });

    notify("Hermes Core", `Autonomous synthesis complete. Product packaged and ready for Gumroad deployment.`);

    return {
      id: "hermes-" + Date.now(),
      createdAt: new Date().toISOString(),
      title: outline.title,
      subtitle: outline.subtitle,
      author: outline.author,
      category: outline.category,
      tone: outline.tone,
      targetAvatar: outline.targetAvatar,
      uniqueMechanism: outline.uniqueMechanism,
      chapters: chaptersWithContent,
      coverSvg,
      launchPackage,
      internetIntel: internetData,
      settings: { theme, price }
    };
  }
}
