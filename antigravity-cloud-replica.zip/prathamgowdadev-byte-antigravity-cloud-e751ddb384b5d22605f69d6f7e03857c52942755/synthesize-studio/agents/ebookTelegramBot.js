﻿// agents/ebookTelegramBot.js
// Dedicated Telegram Sales & Tracking Engine for Asura-Hermes eBooks
// Separate from the client-hunter bot. Zero emojis.

export class EbookTelegramBot {
  constructor() {
    this.name = "Asura eBook Sales Tracker";
    this.botToken = "";
    this.chatId = "";
    this.alertsLog = [];
    this.dailySalesTotalInr = 0;
    this.dailySalesCount = 0;
    this.dailyTargetSales = 71; // 71 * 500 = 35,500 INR (~$370 USD)
  }

  setCredentials(token, chatId) {
    if (token) this.botToken = token.trim();
    if (chatId) this.chatId = chatId.trim();
  }

  async sendLaunchAlert({ title, priceInr = 500, priceUsd = 5.21, chaptersCount = 7, url }) {
    const text = [
      `[ASURA-HERMES NOTIFICATION // NEW EBOOK LAUNCHED]`,
      `-------------------------------------------------`,
      `TITLE: ${title}`,
      `PRICE: ${priceInr} INR ($${priceUsd} USD)`,
      `STRUCTURE: ${chaptersCount} Dense Chapters + Blueprints`,
      `COMMERCIAL URL: ${url || "https://gumroad.com/l/your-product"}`,
      `STATUS: Live for Public Purchasing`,
      `TIMESTAMP: ${new Date().toISOString()}`
    ].join("\n");

    const record = {
      type: "LAUNCH",
      title,
      timestamp: new Date().toISOString(),
      text,
      delivered: false
    };

    if (this.botToken && this.chatId) {
      try {
        const res = await fetch(`https://api.telegram.org/bot${this.botToken}/sendMessage`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chat_id: this.chatId, text })
        });
        const data = await res.json();
        record.delivered = data.ok === true;
      } catch (err) {
        record.error = err.message;
      }
    } else {
      record.simulated = true;
      record.delivered = true;
    }

    this.alertsLog.unshift(record);
    return record;
  }

  async sendSaleAlert({ title, amountInr = 500, amountUsd = 5.21, buyerEmail = "customer@domain.com" }) {
    this.dailySalesCount += 1;
    this.dailySalesTotalInr += amountInr;
    const progressPct = ((this.dailySalesCount / this.dailyTargetSales) * 100).toFixed(1);

    const text = [
      `[SALE NOTIFICATION // GUMROAD REVENUE STREAM]`,
      `-------------------------------------------------`,
      `PRODUCT: ${title}`,
      `REVENUE: +${amountInr} INR (+$${amountUsd} USD) [100% PROFIT]`,
      `BUYER: ${buyerEmail}`,
      `TODAY'S TOTAL: ${this.dailySalesTotalInr.toLocaleString()} INR (${this.dailySalesCount}/${this.dailyTargetSales} Sales)`,
      `DAILY GOAL PROGRESS: ${progressPct}% TOWARDS 35,500 INR ($373/DAY)`,
      `TIMESTAMP: ${new Date().toISOString()}`
    ].join("\n");

    const record = {
      type: "SALE",
      title,
      amountInr,
      buyerEmail,
      timestamp: new Date().toISOString(),
      text,
      delivered: false
    };

    if (this.botToken && this.chatId) {
      try {
        const res = await fetch(`https://api.telegram.org/bot${this.botToken}/sendMessage`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chat_id: this.chatId, text })
        });
        const data = await res.json();
        record.delivered = data.ok === true;
      } catch (err) {
        record.error = err.message;
      }
    } else {
      record.simulated = true;
      record.delivered = true;
    }

    this.alertsLog.unshift(record);
    return record;
  }

  async sendTestPing(customToken, customChatId) {
    const token = customToken || this.botToken;
    const chat = customChatId || this.chatId;

    const testText = [
      `[ASURA-HERMES TEST PING // TELEGRAM BOT ONLINE]`,
      `-------------------------------------------------`,
      `STATUS: Dedicated eBook Sales Bot Active`,
      `TARGET DAILY REVENUE: 35,500 INR ($373/DAY)`,
      `UNIT PRICE: 500 INR ($5.21 USD)`,
      `ZERO-EMOJI ENFORCEMENT: VERIFIED`,
      `TIMESTAMP: ${new Date().toISOString()}`
    ].join("\n");

    if (token && chat) {
      try {
        const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ chat_id: chat, text: testText })
        });
        const data = await res.json();
        return { success: data.ok === true, mode: "LIVE_TELEGRAM", data };
      } catch (e) {
        return { success: false, error: e.message };
      }
    }

    // Staging simulation
    const simulatedRecord = {
      type: "TEST_PING",
      timestamp: new Date().toISOString(),
      text: testText,
      simulated: true,
      delivered: true,
      note: "Test ping validated in Staging Mode. Enter token to stream to your phone."
    };
    this.alertsLog.unshift(simulatedRecord);
    return { success: true, mode: "STAGED_SIMULATION", record: simulatedRecord };
  }

  getAlertsLog() {
    return {
      dailyCount: this.dailySalesCount,
      dailyTotalInr: this.dailySalesTotalInr,
      dailyTarget: this.dailyTargetSales,
      logs: this.alertsLog
    };
  }
}