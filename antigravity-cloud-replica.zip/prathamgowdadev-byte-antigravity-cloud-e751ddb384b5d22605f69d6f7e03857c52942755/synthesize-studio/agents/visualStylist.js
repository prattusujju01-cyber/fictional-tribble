// agents/visualStylist.js
// Generates luxury 3D book cover mockups, SVG vector cover art, and visual brand assets

export class VisualStylistAgent {
  constructor() {
    this.name = "Visual Stylist Bot";
    this.role = "Cover Designer, 3D Mockup Architect & Brand Packaging";
  }

  generateCoverSvg({ title, subtitle, author = "Autonomous Studio Masterclass", category = "High-Performance Systems", theme = "cyber-obsidian" }) {
    // Theme palette mappings
    const themes = {
      "cyber-obsidian": {
        bgStart: "#0A0D14",
        bgEnd: "#161B26",
        accent: "#FF2A5F",
        secondary: "#8B5CF6",
        badgeBg: "rgba(255, 42, 95, 0.15)",
        badgeText: "#FF5C85"
      },
      "neon-violet": {
        bgStart: "#0D0A1A",
        bgEnd: "#1D1636",
        accent: "#9333EA",
        secondary: "#3B82F6",
        badgeBg: "rgba(147, 51, 234, 0.2)",
        badgeText: "#C084FC"
      },
      "gold-luxury": {
        bgStart: "#14120B",
        bgEnd: "#262113",
        accent: "#EAB308",
        secondary: "#F59E0B",
        badgeBg: "rgba(234, 179, 8, 0.15)",
        badgeText: "#FDE047"
      },
      "emerald-matrix": {
        bgStart: "#071712",
        bgEnd: "#0E2E24",
        accent: "#10B981",
        secondary: "#06B6D4",
        badgeBg: "rgba(16, 185, 129, 0.15)",
        badgeText: "#6EE7B7"
      }
    };

    const t = themes[theme] || themes["cyber-obsidian"];
    const safeTitle = (title || "THE ASYMMETRIC WEALTH MACHINE").toUpperCase();
    const safeSubtitle = subtitle || "The Complete Field Manual to Autonomous Cashflow";

    // Split title for multi-line impact if long
    const words = safeTitle.split(" ");
    let line1 = safeTitle;
    let line2 = "";
    if (words.length > 3) {
      const mid = Math.ceil(words.length / 2);
      line1 = words.slice(0, mid).join(" ");
      line2 = words.slice(mid).join(" ");
    }

    return `
<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 600 900" width="100%" height="100%" class="ebook-cover-svg">
  <defs>
    <linearGradient id="bgGrad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="${t.bgStart}"/>
      <stop offset="60%" stop-color="${t.bgEnd}"/>
      <stop offset="100%" stop-color="#05070B"/>
    </linearGradient>
    <linearGradient id="accentGrad" x1="0%" y1="0%" x2="100%" y2="0%">
      <stop offset="0%" stop-color="${t.accent}"/>
      <stop offset="100%" stop-color="${t.secondary}"/>
    </linearGradient>
    <radialGradient id="glowEffect" cx="50%" cy="30%" r="60%">
      <stop offset="0%" stop-color="${t.accent}" stop-opacity="0.35"/>
      <stop offset="70%" stop-color="${t.secondary}" stop-opacity="0.05"/>
      <stop offset="100%" stop-color="transparent" stop-opacity="0"/>
    </radialGradient>
    <filter id="dropshadow" x="-10%" y="-10%" width="120%" height="120%">
      <feDropShadow dx="0" dy="12" stdDeviation="16" flood-color="#000000" flood-opacity="0.8"/>
    </filter>
  </defs>

  <!-- Background Base -->
  <rect width="600" height="900" fill="url(#bgGrad)"/>
  <rect width="600" height="900" fill="url(#glowEffect)"/>

  <!-- Left Spine Edge Highlight -->
  <rect x="0" y="0" width="18" height="900" fill="#ffffff" opacity="0.08"/>
  <line x1="18" y1="0" x2="18" y2="900" stroke="#000000" stroke-width="2" opacity="0.6"/>

  <!-- Futuristic Tech Grid Accents -->
  <g opacity="0.15">
    <line x1="40" y1="60" x2="560" y2="60" stroke="#ffffff" stroke-width="1" stroke-dasharray="6,6"/>
    <line x1="40" y1="840" x2="560" y2="840" stroke="#ffffff" stroke-width="1" stroke-dasharray="6,6"/>
    <circle cx="560" cy="60" r="4" fill="${t.accent}"/>
    <circle cx="40" cy="840" r="4" fill="${t.secondary}"/>
  </g>

  <!-- Header Category Badge -->
  <g transform="translate(60, 100)">
    <rect width="220" height="34" rx="17" fill="${t.badgeBg}" stroke="${t.accent}" stroke-width="1"/>
    <text x="110" y="22" fill="${t.badgeText}" font-family="system-ui, -apple-system, sans-serif" font-size="12" font-weight="700" letter-spacing="2" text-anchor="middle">
      ${category.toUpperCase()}
    </text>
  </g>

  <!-- Edition Stamp -->
  <text x="540" y="122" fill="#8E9AA8" font-family="system-ui, sans-serif" font-size="11" font-weight="600" letter-spacing="2" text-anchor="end">
    EDITION 1.0 // 2026
  </text>

  <!-- Geometric Emblem / Shield -->
  <g transform="translate(300, 260)">
    <polygon points="0,-75 65,-37 65,37 0,75 -65,37 -65,-37" fill="none" stroke="url(#accentGrad)" stroke-width="3" opacity="0.9"/>
    <polygon points="0,-50 43,-25 43,25 0,50 -43,25 -43,-25" fill="none" stroke="${t.accent}" stroke-width="1.5" opacity="0.4"/>
    <circle cx="0" cy="0" r="14" fill="url(#accentGrad)"/>
    <path d="M-15 0 L15 0 M0 -15 L0 15" stroke="#ffffff" stroke-width="2"/>
  </g>

  <!-- Main Title Area -->
  <g transform="translate(300, 470)" text-anchor="middle">
    <text x="0" y="0" fill="#FFFFFF" font-family="system-ui, -apple-system, sans-serif" font-size="34" font-weight="900" letter-spacing="1.5" filter="url(#dropshadow)">
      ${line1}
    </text>
    ${line2 ? `<text x="0" y="44" fill="url(#accentGrad)" font-family="system-ui, -apple-system, sans-serif" font-size="32" font-weight="900" letter-spacing="1.5">${line2}</text>` : ''}
  </g>

  <!-- Subtitle -->
  <foreignObject x="60" y="${line2 ? '540' : '510'}" width="480" height="90">
    <div xmlns="http://www.w3.org/1999/xhtml" style="color: #94A3B8; font-family: system-ui, sans-serif; font-size: 15px; line-height: 1.5; text-align: center; font-weight: 400;">
      ${safeSubtitle}
    </div>
  </foreignObject>

  <!-- Divider Line -->
  <line x1="180" y1="640" x2="420" y2="640" stroke="url(#accentGrad)" stroke-width="2" stroke-linecap="round"/>

  <!-- Proof / Guarantee Seal -->
  <g transform="translate(300, 710)" text-anchor="middle">
    <rect x="-140" y="-18" width="280" height="36" rx="6" fill="#111522" stroke="#2D3748" stroke-width="1"/>
    <text x="0" y="5" fill="#E2E8F0" font-family="system-ui, sans-serif" font-size="12" font-weight="600" letter-spacing="1">
      // COMPLETE IMPLEMENTATION SYSTEM //
    </text>
  </g>

  <!-- Author / Signature Footer -->
  <g transform="translate(300, 800)" text-anchor="middle">
    <text x="0" y="0" fill="#64748B" font-family="system-ui, sans-serif" font-size="11" font-weight="600" letter-spacing="3">
      ARCHITECTED BY
    </text>
    <text x="0" y="24" fill="#F8FAFC" font-family="system-ui, sans-serif" font-size="16" font-weight="700" letter-spacing="1">
      ${author}
    </text>
  </g>
</svg>
`.trim();
  }
}
