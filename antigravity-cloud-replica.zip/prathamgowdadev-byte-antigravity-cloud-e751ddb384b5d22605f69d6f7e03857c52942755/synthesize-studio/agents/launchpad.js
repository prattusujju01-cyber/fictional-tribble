// agents/launchpad.js
// Generates the commercial sales engine to replicate the $373/day Iman Gadzhi digital product model

export class LaunchpadAgent {
  constructor() {
    this.name = "Launchpad Bot";
    this.role = "Commercial Copywriter, Funnel Architect & Revenue Strategist";
  }

  generateCommercialPackage({ bookTitle, bookSubtitle, category, chapters, targetAvatar, price = 37 }) {
    const dailyTargetSales = Math.ceil(373 / price);
    const orderBumpPrice = 17;
    const upsellPrice = 67;

    // High converting sales copy
    const salesPageCopy = `
# SALES PAGE & GUMROAD COPY: ${bookTitle}

### [ATTENTION HEADLINE]
**"Stop Trading Hours For Chump Change: How To Deploy An Asymmetric ${category} Asset That Generates $373/Day on Autopilot—Without Recording Videos, Hiring Tech Teams, or Begging for Clients."**

---

### [THE SUB-HOOK]
*The exact, battle-tested field manual to turn knowledge into a high-converting digital cashflow machine in 30 days or less.*

---

### [THE HARD TRUTH / PROBLEM AGITATION]
Let’s cut through the noise. 

You’ve seen the influencers flashing Stripe dashboards while claiming "anyone can make passive income." But when you actually try to follow their advice, you run straight into a brick wall:
- You spend 3 weeks debating fonts and software platforms that cost hundreds a month.
- You write 80 pages of generic fluff that sounds like an encyclopedic Wikipedia dump.
- You launch to crickets because nobody taught you how to engineer *asymmetric leverage* or hook buying intent.

The brutal reality? **The traditional digital product playbook is dead.** 

If your product isn't engineered with proprietary naming, high-status packaging, and frictionless organic distribution, you're just screaming into an empty canyon.

---

### [INTRODUCING: ${bookTitle.toUpperCase()}]
*${bookSubtitle}*

This is not a theoretical university lecture. It is a ruthless, step-by-step tactical playbook designed for one singular purpose: **to help you install an automated asset that nets $373 every single day.**

---

### [WHAT IS PACKAGED INSIDE]
Here is a fraction of what you unlock the moment you get inside:

${chapters.map((ch, idx) => `
[-] **Module ${ch.number}: ${ch.title}**
  *${ch.subtitle}*
  * Master **${ch.framework}** to eliminate 90% of operational friction.
  * Tactical Blueprint: ${ch.sections ? ch.sections.slice(0, 2).join(" & ") : "Execution protocol"}.
  * Immediate Action Item: ${ch.actionItem || "Actionable deployment checklist"}.
`).join("\n")}

---

### [THE 3 BONUSES INCLUDED TODAY (FREE)]
- **Bonus #1: The $373/Day Math & Unit Economics Calculator** (Value: $47)
  *The exact spreadsheet to reverse-engineer your pricing, conversion rates, and profit margins.*
- **Bonus #2: The High-Perception 3D Mockup & Asset Swipe File** (Value: $67)
  *Plug-and-play visual assets so your product commands high-ticket status.*
- **Bonus #3: The 10-Minute Daily Sovereign Maintenance Checklist** (Value: $37)
  *How to run customer fulfillment, lead magnets, and analytics in under 20 minutes a day.*

---

### [TOTAL VALUE: $347]
**Normal Retail Price:** ~~$97~~  
**Today's Exclusive Masterclass Access:** **Just $${price}**

---

### [THE 30-DAY "ZERO RISK" IRONCLAD GUARANTEE]
Read the book. Implement the **${chapters[0]?.framework || "Core Framework"}**. If you don’t feel this is the single most actionable, high-density digital product playbook you have ever invested in, simply send a one-line email within 30 days and receive 100% of your money back. No games, no awkward interrogation.
`.trim();

    // 5-Part Email Sequence
    const emailSequence = [
      {
        day: 1,
        subject: "The linear income trap (and the $373/day shift)",
        preview: "Why working harder is the slowest route to wealth...",
        body: `Hey,\n\nMost people think earning more requires working more.\n\nThey trade 1 hour for $30. If they want $300, they need to grind for 10 exhausting hours. That is linear income—and it is a mathematical cage.\n\nIn our new release, "${bookTitle}", we break down how modern operators use asymmetric digital assets to generate $373/day without adding extra work.\n\nGrab your copy today before the launch discount expires: [Insert Link]\n\nBest,\nYour Name`
      },
      {
        day: 2,
        subject: "Case study: 0 to 11 sales in 48 hours",
        preview: "Deconstructing the mechanism behind instant conversions...",
        body: `Hey,\n\nYesterday we talked about asymmetric leverage.\n\nToday, I want to show you how a complete beginner used the "${chapters[1]?.framework || "Core Blueprint"}" to achieve 11 sales in their first 48 hours without spending a dollar on ads.\n\nInside Chapter 2 and 3 of "${bookTitle}", we lay down the exact step-by-step workflow.\n\nRead the full breakdown here: [Insert Link]\n\nBest,\nYour Name`
      },
      {
        day: 3,
        subject: "The #1 mistake that kills 95% of digital products",
        preview: "Are you making this fatal positioning error?",
        body: `Hey,\n\nWhy do high-effort books fail while simple 40-page tactical guides print $10k/month?\n\nIt comes down to one word: Positioning.\n\nIn Chapter 4 of "${bookTitle}", we reveal the High-Perception Packaging System and how to turn simple knowledge into an irresistible high-status asset.\n\nGet instant access here: [Insert Link]\n\nBest,\nYour Name`
      },
      {
        day: 4,
        subject: "Is this right for you? (Answering your top questions)",
        preview: "What if you don't have an audience or technical skills?",
        body: `Hey,\n\nI have received a ton of questions about "${bookTitle}". Here are the top 3:\n\n1. Do I need tech skills? No. The entire stack is lean and takes under 30 minutes to set up.\n2. Do I need to show my face? Not at all. This is built specifically for faceless operators.\n3. What if I don't get results? You are covered by our 30-day 100% refund guarantee.\n\nUnlock your blueprint now: [Insert Link]\n\nBest,\nYour Name`
      },
      {
        day: 5,
        subject: "FINAL CALL: The $${price} launch window closes tonight",
        preview: "Price increases at midnight sharp...",
        body: `Hey,\n\nThis is your final notice.\n\nTonight at midnight, the introductory pricing for "${bookTitle}" along with the 3 free bonuses will be locked down.\n\nIf you are ready to stop trading time for linear money and install a proven $373/day cashflow engine, this is your moment.\n\nClaim your copy right now: [Insert Link]\n\nBest,\nYour Name`
      }
    ];

    // 10 Short-Form Video Hooks & Scripts
    const viralHooks = [
      {
        hook: "If I wanted to make $373 a day starting from zero with zero followers, here is the exact 4-step blueprint I would use tonight...",
        concept: "Screen recording showing Gumroad dashboard + bullet point walkthrough of Chapter 1 & 2."
      },
      {
        hook: "Stop creating 200-page ebooks nobody reads. Do this 35-page tactical guide method instead.",
        concept: "Side-by-side comparison of thick dusty textbook vs sleek modern digital asset."
      },
      {
        hook: "The reason 95% of people fail to sell digital products is they sell 'information' instead of this one thing...",
        concept: "Breakdown of the 'Transformation Mechanism' from Chapter 4."
      },
      {
        hook: "Here is the exact math to make $10,000/month selling digital products: You only need 10 sales a day at $37.",
        concept: "Whiteboard calculation showing how achievable 10 daily sales is with organic short-form traffic."
      },
      {
        hook: "I spent 14 days building a digital product empire with AI bots. Here are the 3 tools that did 90% of the work.",
        concept: "Rapid tool showcase pointing viewers to the bio link for the complete playbook."
      },
      {
        hook: "POV: You wake up and your phone notifications are 8 new Gumroad sales while you were asleep.",
        concept: "Aesthetic morning routine with subtle notification overlay and direct call to action."
      },
      {
        hook: "Why rich entrepreneurs never trade hours for money: The secret of asymmetric leverage explained in 45 seconds.",
        concept: "Mindset breakdown referencing Chapter 1's Velocity-Leverage Matrix."
      },
      {
        hook: "Don't buy expensive courses. Here is the entire high-ticket digital product curriculum compressed into 30 seconds.",
        concept: "Fast-paced list of the 7 core pillars covered in the book."
      },
      {
        hook: "How to package your knowledge into a $37 asset even if you think you aren't an 'expert' at anything.",
        concept: "Curator vs Creator model breakdown."
      },
      {
        hook: "The 3 viral hook formulas that generate 50,000 views on TikTok without ever showing your face on camera.",
        concept: "Demonstrating the exact script templates from Chapter 5."
      }
    ];

    // The $373/day Revenue Blueprint
    const revenueBlueprint = {
      targetDailyRevenue: "$373.00",
      targetMonthlyRevenue: "$11,190.00",
      pricingMatrix: [
        {
          tier: "Core Front-End eBook",
          price: `$${price}`,
          dailySalesRequired: dailyTargetSales,
          dailyTotal: `$${dailyTargetSales * price}`
        },
        {
          tier: "Core eBook ($37) + Checkout Order Bump ($17 Template Pack)",
          price: `$54 combined`,
          dailySalesRequired: 7,
          dailyTotal: "$378.00"
        },
        {
          tier: "Core eBook ($37) + Order Bump ($17) + Backend Video Masterclass ($97)",
          price: `$151 combined average cart`,
          dailySalesRequired: 3,
          dailyTotal: "$453.00"
        }
      ],
      trafficMath: {
        dailyViewsNeeded: "1,500 - 3,000 organic views",
        clickThroughRate: "3% (45 - 90 link clicks)",
        pageConversionRate: "12% - 15% (7 - 11 buyers)",
        netOutcome: "Achieves $373+ daily consistently"
      }
    };

    return {
      salesPageCopy,
      emailSequence,
      viralHooks,
      revenueBlueprint
    };
  }
}
