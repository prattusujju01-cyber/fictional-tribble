// agents/exportEngine.js
// Compiles the synthesized eBook into clean HTML (ready for Print to PDF), Markdown, or JSON bundle

export class ExportEngineAgent {
  constructor() {
    this.name = "Export & Publisher Bot";
    this.role = "Document Formatter, Print Stylist & Multi-Format Exporter";
  }

  generatePrintableHtml({ title, subtitle, author, category, chapters, coverSvg }) {
    return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${title} - ${subtitle}</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@700;900&family=Inter:wght@300;400;500;600;700&family=Newsreader:ital,opsz,wght@0,6..72,400;0,6..72,500;1,6..72,400&display=swap');

    :root {
      --primary: #0F172A;
      --text: #1E293B;
      --muted: #64748B;
      --accent: #E11D48;
      --border: #E2E8F0;
      --card-bg: #F8FAFC;
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
    }

    body {
      font-family: 'Newsreader', serif;
      font-size: 18px;
      line-height: 1.75;
      color: var(--text);
      background: #FFFFFF;
      padding: 0;
      margin: 0;
    }

    .book-container {
      max-width: 800px;
      margin: 0 auto;
      padding: 40px 20px;
    }

    /* Cover Page */
    .cover-page {
      page-break-after: always;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      min-height: 95vh;
      text-align: center;
      padding: 40px 20px;
    }

    .cover-page svg {
      max-width: 520px;
      height: auto;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.35);
      border-radius: 8px;
    }

    /* Table of Contents */
    .toc-page {
      page-break-after: always;
      padding: 60px 0;
    }

    .toc-title {
      font-family: 'Cinzel', serif;
      font-size: 32px;
      font-weight: 900;
      letter-spacing: 2px;
      color: var(--primary);
      text-transform: uppercase;
      border-bottom: 2px solid var(--accent);
      padding-bottom: 12px;
      margin-bottom: 36px;
    }

    .toc-item {
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      padding: 14px 0;
      border-bottom: 1px dotted var(--border);
      font-family: 'Inter', sans-serif;
    }

    .toc-number {
      font-weight: 700;
      color: var(--accent);
      margin-right: 12px;
    }

    .toc-name {
      font-weight: 600;
      color: var(--primary);
    }

    /* Chapters */
    .chapter-section {
      page-break-after: always;
      padding: 50px 0 30px 0;
    }

    h1, h2, h3, h4 {
      font-family: 'Inter', sans-serif;
      color: var(--primary);
      line-height: 1.3;
    }

    h1 {
      font-family: 'Cinzel', serif;
      font-size: 32px;
      margin-top: 20px;
      margin-bottom: 10px;
      letter-spacing: 1px;
    }

    h2 {
      font-size: 24px;
      margin-top: 36px;
      margin-bottom: 16px;
    }

    h3 {
      font-size: 20px;
      margin-top: 28px;
      margin-bottom: 12px;
    }

    p {
      margin-bottom: 20px;
    }

    blockquote {
      margin: 24px 0;
      padding: 18px 24px;
      background: var(--card-bg);
      border-left: 4px solid var(--accent);
      font-style: italic;
      color: #334155;
      border-radius: 0 8px 8px 0;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin: 24px 0;
      font-family: 'Inter', sans-serif;
      font-size: 15px;
    }

    th, td {
      border: 1px solid var(--border);
      padding: 12px 16px;
      text-align: left;
    }

    th {
      background: var(--card-bg);
      font-weight: 700;
      color: var(--primary);
    }

    pre, code {
      font-family: 'Courier New', monospace;
      background: #0F172A;
      color: #38BDF8;
      border-radius: 6px;
    }

    pre {
      padding: 18px;
      overflow-x: auto;
      margin: 20px 0;
    }

    code {
      padding: 2px 6px;
      font-size: 14px;
    }

    ul, ol {
      margin-bottom: 20px;
      padding-left: 24px;
    }

    li {
      margin-bottom: 8px;
    }

    .action-box {
      background: #FFF1F2;
      border: 1px solid #FECDD3;
      border-radius: 8px;
      padding: 20px;
      margin: 28px 0;
      font-family: 'Inter', sans-serif;
    }

    .action-box h4 {
      color: #9F1239;
      margin-bottom: 10px;
    }

    @media print {
      body {
        font-size: 14pt;
        line-height: 1.6;
      }
      .book-container {
        max-width: 100%;
        padding: 0;
      }
      .no-print {
        display: none !important;
      }
      .chapter-section {
        page-break-after: always;
      }
      @page {
        margin: 2cm;
      }
    }

    .print-bar {
      position: sticky;
      top: 0;
      background: #0F172A;
      color: #FFFFFF;
      padding: 14px 24px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      z-index: 100;
      font-family: 'Inter', sans-serif;
      box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }

    .print-btn {
      background: var(--accent);
      color: white;
      border: none;
      padding: 8px 18px;
      border-radius: 6px;
      font-weight: 600;
      cursor: pointer;
      font-size: 14px;
    }
  </style>
</head>
<body>
  <div class="print-bar no-print">
    <span><strong>Synthesize Studio</strong> &bull; Print & PDF Generation View</span>
    <button class="print-btn" onclick="window.print()">[ PRINT / SAVE AS PDF ]</button>
  </div>

  <div class="book-container">
    <!-- Cover -->
    <div class="cover-page">
      ${coverSvg || `<h1>${title}</h1><h3>${subtitle}</h3>`}
    </div>

    <!-- Table of Contents -->
    <div class="toc-page">
      <div class="toc-title">Table of Contents</div>
      ${chapters.map(ch => `
        <div class="toc-item">
          <div>
            <span class="toc-number">Chapter ${ch.number}</span>
            <span class="toc-name">${ch.title}</span>
          </div>
          <div style="color: var(--muted); font-size: 14px;">${ch.subtitle ? ch.subtitle.slice(0, 45) + '...' : ''}</div>
        </div>
      `).join("")}
    </div>

    <!-- Chapter Content -->
    ${chapters.map(ch => `
      <div class="chapter-section" id="chapter-${ch.number}">
        <div class="chapter-content">
          ${this.formatMarkdownToHtml(ch.content || ch.summary || '')}
        </div>
      </div>
    `).join("")}
  </div>
</body>
</html>`;
  }

  formatMarkdownToHtml(markdown) {
    if (!markdown) return "";
    let html = markdown
      // Headers
      .replace(/^### (.*$)/gim, '<h3>$1</h3>')
      .replace(/^## (.*$)/gim, '<h2>$1</h2>')
      .replace(/^# (.*$)/gim, '<h1>$1</h1>')
      // Blockquotes
      .replace(/^\> (.*$)/gim, '<blockquote>$1</blockquote>')
      // Bold & Italic
      .replace(/\*\*\*(.*?)\*\*\*/gim, '<strong><em>$1</em></strong>')
      .replace(/\*\*(.*?)\*\*/gim, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/gim, '<em>$1</em>')
      // Code blocks
      .replace(/\`\`\`([\s\S]*?)\`\`\`/gim, '<pre><code>$1</code></pre>')
      .replace(/\`([^`]+)\`/gim, '<code>$1</code>')
      // Checkboxes
      .replace(/- \[ \] (.*$)/gim, '<li><input type="checkbox" disabled /> $1</li>')
      .replace(/- \[x\] (.*$)/gim, '<li><input type="checkbox" checked disabled /> $1</li>')
      // Lists
      .replace(/^\- (.*$)/gim, '<li>$1</li>')
      // Dividers
      .replace(/^---$/gim, '<hr style="border: 0; border-top: 1px solid #E2E8F0; margin: 32px 0;" />')
      // Paragraphs
      .split(/\n\n+/)
      .map(para => {
        para = para.trim();
        if (!para) return "";
        if (para.startsWith("<h") || para.startsWith("<blockquote") || para.startsWith("<pre") || para.startsWith("<hr") || para.startsWith("<li>") || para.startsWith("<table")) {
          return para;
        }
        return `<p>${para}</p>`;
      })
      .join("\n");

    return html;
  }

  generateMarkdown({ title, subtitle, author, category, chapters }) {
    let md = `# ${title}\n## ${subtitle}\n\n`;
    md += `*Author: ${author}*  \n`;
    md += `*Category: ${category}*  \n`;
    md += `*Compiled by Synthesize Studio*\n\n---\n\n`;

    md += `## Table of Contents\n\n`;
    chapters.forEach(ch => {
      md += `- [Chapter ${ch.number}: ${ch.title}](#chapter-${ch.number})\n`;
    });
    md += `\n---\n\n`;

    chapters.forEach(ch => {
      md += `<a id="chapter-${ch.number}"></a>\n\n`;
      md += `${ch.content || `### Chapter ${ch.number}: ${ch.title}\n\n${ch.summary}`}\n\n---\n\n`;
    });

    return md;
  }
}
