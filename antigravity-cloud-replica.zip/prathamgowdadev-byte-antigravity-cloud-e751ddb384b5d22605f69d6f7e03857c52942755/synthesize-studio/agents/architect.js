// agents/architect.js
// Synthesize Architect Bot - Generates viral book titles, hooks, buyer avatars, and chapter architectures

export class ArchitectAgent {
  constructor() {
    this.name = "Synthesize Architect Bot";
    this.role = "Lead Product Architect & Outline Engineer";
  }

  async generateOutline({ topic, niche, tone = "Authoritative & Action-Oriented", targetAudience = "", referenceContext = null, apiKey = null, provider = "builtin" }) {
    // If API key is provided and external LLM chosen, can connect to Gemini/OpenAI/Groq.
    // Built-in intelligent synthesis engine produces high-converting commercial architecture.
    
    const baseTopic = topic || (niche && niche.title) || "Autonomous AI Growth Systems";
    const audience = targetAudience || (niche && niche.audience) || "Ambitious entrepreneurs and digital operators";
    
    // Architect dynamic chapters tailored to topic
    const chapters = this.buildDynamicChapters(baseTopic, audience, tone, referenceContext);

    const titleVariants = this.generateTitleHooks(baseTopic);
    const primaryTitle = titleVariants[0].title;
    const primarySubtitle = titleVariants[0].subtitle;

    const targetAvatar = {
      profile: audience,
      coreDesire: `Achieve measurable mastery, autonomy, and recurring commercial outcomes using ${baseTopic}`,
      primaryPain: `Feeling paralyzed by conflicting advice, slow manual workflows, and lack of a structured, execution-ready system`,
      conversionTrigger: `A proven, zero-fluff blueprint with plug-and-play frameworks they can deploy in 48 hours`
    };

    return {
      title: primaryTitle,
      subtitle: primarySubtitle,
      titleAlternatives: titleVariants.slice(1),
      author: "Autonomous Studio Masterclass",
      category: niche ? niche.category : "High-Performance Systems",
      targetAvatar,
      tone,
      uniqueMechanism: `The Asymmetric Leverage Formula for ${baseTopic}`,
      totalChapters: chapters.length,
      estimatedReadingTime: `${chapters.length * 12} minutes`,
      chapters,
      referenceContextApplied: referenceContext ? referenceContext.summary : "Default High-Conversion Knowledge Vectors"
    };
  }

  generateTitleHooks(topic) {
    const clean = topic.replace(/^(the|a|an)\s+/i, "").replace(/e\s*book|guide|how\s*to|playbook/gi, "").trim();
    return [
      {
        title: `The ${clean} Playbook`,
        subtitle: `An Unfair Advantage Blueprint to Build, Scale, and Monetize in 30 Days`
      },
      {
        title: `The Faceless ${clean} Machine`,
        subtitle: `How to Generate Consistent Daily Cashflow with Zero Overhead and Autonomous Systems`
      },
      {
        title: `Architecting ${clean}`,
        subtitle: `The High-Performance Framework for Exponential Output, Autonomy, and Real Results`
      },
      {
        title: `Zero to $373/Day: ${clean} Mastery`,
        subtitle: `The Step-by-Step Tactical Protocol for Modern Digital Operators`
      }
    ];
  }

  buildDynamicChapters(topic, audience, tone, referenceContext) {
    return [
      {
        number: 1,
        title: "The Paradigm Shift: Breaking the Legacy Trap",
        subtitle: `Why traditional approaches to ${topic} are obsolete and how the top 1% engineer asymmetrical leverage`,
        summary: `Exposes why 95% of people fail at ${topic}, details the fundamental shifts in the market, and introduces the Core Leverage Framework.`,
        sections: [
          "The Anatomy of the Outdated Model",
          "The Asymmetrical Leverage Principle",
          "Deconstructing the $373/Day Unit Economics",
          "Auditing Your Current Assets and Operational Bottlenecks"
        ],
        framework: "The Velocity-Leverage Matrix",
        actionItem: "Perform the 60-minute friction audit and identify your primary high-value vector."
      },
      {
        number: 2,
        title: "The Foundation: Architecting Your Digital Core",
        subtitle: "Setting up the infrastructure, essential toolstacks, and operational foundation",
        summary: `Lays down the exact operational stack, software configurations, and automated foundation required to run without continuous friction.`,
        sections: [
          "The Lean Tech Stack: Cutting 90% of Unnecessary Software",
          "Configuring the Autonomous Workflow Hub",
          "Asset Modularization: Reusable Components and Knowledge Bases",
          "Establishing Continuous Feedback Loops"
        ],
        framework: "The Minimalist Infrastructure Protocol",
        actionItem: "Deploy the 3-tool tech stack and establish your central operational workspace."
      },
      {
        number: 3,
        title: "The Engine: High-Velocity Synthesis & Production",
        subtitle: "How to produce tier-one output in hours instead of months",
        summary: `A tactical breakdown of turning abstract concepts into polished, market-ready deliverables using autonomous multi-agent pipelines.`,
        sections: [
          "The Rapid Synthesis Pipeline (RSP)",
          "Prompt Architecture and Constraint Engineering",
          "Multi-Agent Workflow Orchestration: Research, Drafting, Refining",
          "Quality Assurance: Eliminating Generic AI Clutter"
        ],
        framework: "The Multi-Tier Content Engine",
        actionItem: "Run your first end-to-end rapid synthesis sprint using the 4-step prompt chain."
      },
      {
        number: 4,
        title: "The Packaging: Luxury Product Design & Perception Hacking",
        subtitle: "Transforming standard information into an irresistible, high-status asset",
        summary: `Why positioning beats information every single time. How to package your product with 3D mockups, proprietary terminology, and high perceived value.`,
        sections: [
          "The Psychology of Perceived Value and Status Signaling",
          "Crafting Proprietary Terminology and Signature Frameworks",
          "Visual Identity: Typography, Mockup Engineering, and Aesthetic Finish",
          "The 'Stack of Gold' Bonus Architecture"
        ],
        framework: "The High-Perception Packaging System",
        actionItem: "Design a 3D bundle mockup and assign proprietary names to your 3 core methodologies."
      },
      {
        number: 5,
        title: "The Distribution: Organic Traffic & Viral Conversion Funnels",
        subtitle: "Attracting high-intent buyers without spending a single dollar on paid ads",
        summary: `The organic distribution flywheel: leveraging short-form algorithms, Twitter/X authority threads, and frictionless landing pages.`,
        sections: [
          "The Short-Form Algorithm Hook Formula (Watch Time + Shares)",
          "The 3-Step Bio Funnel: From Casual Viewer to Paid Customer",
          "The Gumroad / Stan Store Frictionless Checkout Blueprint",
          "Automated Lead Magnet Delivery and Immediate Upsell Mechanism"
        ],
        framework: "The Organic Traffic Flywheel",
        actionItem: "Script 5 high-converting video hooks and publish your streamlined checkout page."
      },
      {
        number: 6,
        title: "The Economics: Scaling to $373/Day and Beyond",
        subtitle: "Optimizing the pricing ladder, order bumps, and backend customer lifetime value",
        summary: `Deconstructing the exact math to generate $373 every 24 hours. Creating order bumps, email sequences, and ascending value ladders.`,
        sections: [
          "The $373/Day Formula: Dissecting the Math of 10 Sales @ $37",
          "The 35% Conversion Order Bump: Checklists, Templates, and Audio Editions",
          "The 5-Day Automated Email Sales Sequence",
          "Customer Retention and Community Ascension"
        ],
        framework: "The Asymmetric Cashflow Ladder",
        actionItem: "Implement a $17 checkout order bump and set up the automated 5-day welcome sequence."
      },
      {
        number: 7,
        title: "The Autonomous Operator: Systematization, Hand-Off & Longevity",
        subtitle: "Removing yourself from daily operations to enjoy true sovereignty and scale",
        summary: `How to run the entire system on 20 minutes a day of high-level oversight using automation webhooks and autonomous assistants.`,
        sections: [
          "The 20-Minute Daily Maintenance Checklist",
          "Automating Support, Fulfillment, and Analytics",
          "Antifragility: Protecting Your Digital Product Against Market Shifts",
          "The Sovereign Manifesto: Long-Term Compounding"
        ],
        framework: "The Autonomous Operator Blueprint",
        actionItem: "Set up automated weekly metric reports and schedule your daily 20-minute operating window."
      }
    ];
  }
}
