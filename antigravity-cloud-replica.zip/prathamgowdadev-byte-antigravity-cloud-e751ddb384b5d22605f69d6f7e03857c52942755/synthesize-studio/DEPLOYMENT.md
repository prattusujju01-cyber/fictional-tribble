﻿# Hosting Asura-Hermes on Vercel via GitHub

Follow these simple steps to deploy your Asura-Hermes Autonomous Studio to Vercel:

## 1. Push to GitHub
1. Initialize a git repository (if not already done):
   ```bash
   git init
   git add .
   git commit -m "feat: Asura-Hermes autonomous studio with MCP and Gumroad engine"
   ```
2. Create a new repository on your GitHub account (e.g. `asura-hermes-studio`).
3. Link and push your code:
   ```bash
   git remote add origin https://github.com/YOUR_USERNAME/asura-hermes-studio.git
   git branch -M main
   git push -u origin main
   ```

## 2. Deploy on Vercel
1. Log in to [vercel.com](https://vercel.com).
2. Click **"Add New"** > **"Project"**.
3. Select your `asura-hermes-studio` repository from GitHub.
4. Keep the default settings (Vercel automatically detects `vercel.json`).
5. Click **"Deploy"**.

Your live URL will be ready in under 60 seconds with full serverless API execution!
