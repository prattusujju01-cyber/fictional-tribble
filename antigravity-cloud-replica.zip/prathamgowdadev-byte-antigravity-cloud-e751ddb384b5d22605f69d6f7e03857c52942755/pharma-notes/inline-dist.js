import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const distDir = path.resolve(__dirname, 'dist');
const assetsDir = path.join(distDir, 'assets');

const files = fs.readdirSync(assetsDir);
const jsFiles = files.filter(f => f.endsWith('.js'));
const cssFile = files.find(f => f.endsWith('.css'));

console.log('Found JS files:', jsFiles);
console.log('Found CSS file:', cssFile);

// Find the main entry JS (the one that's a module entry, usually named 'index-*.js')
// We need to load dependency chunks first, then the main entry last
const mainJsFile = jsFiles.find(f => f.startsWith('index-')) || jsFiles[jsFiles.length - 1];
const depJsFiles = jsFiles.filter(f => f !== mainJsFile);

console.log('Main JS entry:', mainJsFile);
console.log('Dependency chunks:', depJsFiles);

const cssCode = fs.readFileSync(path.join(assetsDir, cssFile), 'utf8');

// For the self-contained approach, we need to read the original dist/index.html
// and embed all the assets. But with multiple chunks using dynamic import(),
// inlining is tricky. Instead, let's keep the dist folder structure intact
// and just ensure all files are properly referenced.

// Read all JS content
const allJsContent = jsFiles.map(f => {
  const code = fs.readFileSync(path.join(assetsDir, f), 'utf8');
  return { name: f, code };
});

// Check if there are dynamic imports between chunks
const hasDynamicImports = allJsContent.some(j => j.code.includes('import('));

if (hasDynamicImports) {
  // Can't fully inline with dynamic imports - use the standard dist folder approach
  console.log('Dynamic imports detected - using standard dist folder approach');
  
  // Just ensure the dist/index.html is properly set up
  const originalHtml = fs.readFileSync(path.join(distDir, 'index.html'), 'utf8');
  
  // Enhance the HTML with our custom meta tags and loading screen
  const enhancedHtml = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect width=%22100%22 height=%22100%22 rx=%2225%22 fill=%22%2318181B%22/><rect x=%2220%22 y=%2220%22 width=%2260%22 height=%2260%22 rx=%2215%22 fill=%22%23D4F943%22/><text y=%2265%22 x=%2235%22 font-size=%2250%22 font-family=%22sans-serif%22 font-weight=%22900%22 fill=%22%2318181B%22>X</text></svg>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
    <meta name="theme-color" content="#18181B" />
    <meta name="mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <title>PharmaX — B.Pharm Study Notes</title>
    <meta name="description" content="PharmaX: Premium B.Pharm notes, interactive clinical diagrams, PCI curriculum for all 8 semesters, and offline study guides." />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=Kalam:wght@300;400;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" crossorigin href="./assets/${cssFile}">
  </head>
  <body class="bg-[#F4F4F6] text-[#18181B] antialiased selection:bg-[#D4F943] selection:text-black">
    <div id="root">
      <div id="app-loader" style="min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; background-color: #F4F4F6; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 24px; text-align: center;">
        <div style="width: 56px; height: 56px; border-radius: 20px; background-color: #D4F943; display: flex; align-items: center; justify-content: center; margin-bottom: 16px; box-shadow: 0 6px 25px rgba(212,249,67,0.45);">
          <span style="color: #18181B; font-weight: 900; font-size: 26px; font-family: sans-serif;">X</span>
        </div>
        <div style="font-size: 24px; font-weight: 900; letter-spacing: -0.5px; color: #09090B; display: flex; align-items: center; gap: 4px;">
          Pharma<span style="background-color: #D4F943; color: #09090B; padding: 2px 8px; border-radius: 8px; font-size: 20px;">X</span>
        </div>
        <div style="font-size: 13px; font-weight: 600; color: #71717A; margin-top: 8px;">
          Loading notes &amp; curriculum...
        </div>
      </div>
    </div>
    <script type="module" crossorigin src="./assets/${mainJsFile}"></script>
  </body>
</html>`;
  
  fs.writeFileSync(path.join(distDir, 'index.html'), enhancedHtml, 'utf8');
  console.log('Written enhanced dist/index.html! Upload the ENTIRE dist/ folder to Cloudflare.');
  console.log('Total dist files:', fs.readdirSync(distDir).length + fs.readdirSync(assetsDir).length, 'files');
} else {
  // No dynamic imports - safe to inline everything
  let combinedJs = '';
  // Load deps first, then main entry
  depJsFiles.forEach(f => {
    combinedJs += fs.readFileSync(path.join(assetsDir, f), 'utf8') + '\n';
  });
  combinedJs += fs.readFileSync(path.join(assetsDir, mainJsFile), 'utf8');

  const html = `<!doctype html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <link rel="icon" type="image/svg+xml" href="data:image/svg+xml,<svg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 100 100%22><rect width=%22100%22 height=%22100%22 rx=%2225%22 fill=%22%2318181B%22/><rect x=%2220%22 y=%2220%22 width=%2260%22 height=%2260%22 rx=%2215%22 fill=%22%23D4F943%22/><text y=%2265%22 x=%2235%22 font-size=%2250%22 font-family=%22sans-serif%22 font-weight=%22900%22 fill=%22%2318181B%22>X</text></svg>" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover" />
    <meta name="theme-color" content="#18181B" />
    <meta name="mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent" />
    <title>PharmaX — B.Pharm Study Notes</title>
    <meta name="description" content="PharmaX: Premium B.Pharm notes, interactive clinical diagrams, PCI curriculum for all 8 semesters, and offline study guides." />
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=Kalam:wght@300;400;700&display=swap" rel="stylesheet">
    <style>
${cssCode}
    </style>
  </head>
  <body class="bg-[#F4F4F6] text-[#18181B] antialiased selection:bg-[#D4F943] selection:text-black">
    <div id="root">
      <div id="app-loader" style="min-height: 100vh; display: flex; flex-direction: column; align-items: center; justify-content: center; background-color: #F4F4F6; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; padding: 24px; text-align: center;">
        <div style="width: 56px; height: 56px; border-radius: 20px; background-color: #D4F943; display: flex; align-items: center; justify-content: center; margin-bottom: 16px; box-shadow: 0 6px 25px rgba(212,249,67,0.45);">
          <span style="color: #18181B; font-weight: 900; font-size: 26px; font-family: sans-serif;">X</span>
        </div>
        <div style="font-size: 24px; font-weight: 900; letter-spacing: -0.5px; color: #09090B; display: flex; align-items: center; gap: 4px;">
          Pharma<span style="background-color: #D4F943; color: #09090B; padding: 2px 8px; border-radius: 8px; font-size: 20px;">X</span>
        </div>
        <div style="font-size: 13px; font-weight: 600; color: #71717A; margin-top: 8px;">
          Loading notes &amp; curriculum...
        </div>
      </div>
    </div>
    <script type="module">
${combinedJs.replace(/<\/script>/g, '<\\/script>')}
    </script>
  </body>
</html>`;

  fs.writeFileSync(path.join(distDir, 'index.html'), html, 'utf8');
  console.log('Successfully written self-contained index.html! Bytes:', html.length);
}
