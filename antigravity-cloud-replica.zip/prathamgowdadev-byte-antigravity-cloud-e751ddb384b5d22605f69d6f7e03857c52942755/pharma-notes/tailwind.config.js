/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        pharmablue: {
          50: '#E8F1FE',
          100: '#D2E3FC',
          500: '#1E74FD',
          600: '#0D58E2',
          700: '#0A46B5',
        }
      }
    },
  },
  plugins: [],
}
