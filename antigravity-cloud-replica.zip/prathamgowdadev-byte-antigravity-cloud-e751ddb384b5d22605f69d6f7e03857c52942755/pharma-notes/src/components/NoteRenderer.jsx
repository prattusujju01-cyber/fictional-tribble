import React, { useState } from 'react'
import { Copy, Check, Lightbulb, BookmarkCheck, FileText } from 'lucide-react'

export default function NoteRenderer({
  blocks = [],
  activeColor = '#D4F943',
  activeFont = 'font-nunito',
  fontSize = 16,
  textAlign = 'left'
}) {
  const [copiedIdx, setCopiedIdx] = useState(null)

  if (!Array.isArray(blocks) || blocks.length === 0) {
    return null
  }

  const handleCopy = (text, idx) => {
    navigator.clipboard?.writeText(text)
    setCopiedIdx(idx)
    setTimeout(() => setCopiedIdx(null), 1800)
  }

  const renderBlock = (block, index) => {
    switch (block.type) {
      case 'heading':
        return (
          <div key={index} className="pt-2 pb-1">
            <h1
              className="text-2xl sm:text-3xl font-extrabold text-zinc-950 tracking-tight flex items-center gap-2"
              style={{ textAlign }}
            >
              <span>{block.text}</span>
            </h1>
            <div className="w-12 h-1 bg-[#D4F943] rounded-full mt-2" />
          </div>
        )

      case 'subheading':
        return (
          <h2
            key={index}
            className="text-lg sm:text-xl font-bold text-zinc-900 mt-6 mb-2 tracking-tight flex items-center gap-2"
            style={{ textAlign }}
          >
            {block.text}
          </h2>
        )

      case 'italic':
        return (
          <p
            key={index}
            className="text-zinc-600 italic text-base leading-relaxed"
            style={{ textAlign, fontSize: `${fontSize}px` }}
          >
            {block.text}
          </p>
        )

      case 'diagram':
        return (
          <div key={index} className="w-full my-3 rounded-2xl bg-zinc-900 border border-zinc-800 shadow-md overflow-hidden">
            <div className="flex items-center justify-between px-4 py-2 bg-zinc-950 border-b border-zinc-800/80 text-xs font-mono text-zinc-400">
              <span className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-red-500/80 inline-block" />
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500/80 inline-block" />
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500/80 inline-block" />
                <span className="ml-2 font-sans font-semibold text-zinc-300">Pharma Diagram</span>
              </span>
              <button
                type="button"
                onClick={() => handleCopy(block.text, index)}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors"
                title="Copy diagram"
              >
                {copiedIdx === index ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-[#D4F943]" />
                    <span className="text-[11px] text-[#D4F943]">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5" />
                    <span className="text-[11px]">Copy</span>
                  </>
                )}
              </button>
            </div>
            <div className="p-4 overflow-x-auto no-scrollbar">
              <pre className="font-mono text-xs sm:text-[13px] text-zinc-200 whitespace-pre inline-block min-w-full leading-relaxed tracking-wider select-text">
                {block.text}
              </pre>
            </div>
          </div>
        )

      case 'mnemonic':
        return (
          <div
            key={index}
            className="my-3 p-4 rounded-2xl bg-pink-50/90 border border-pink-200/80 text-pink-950 shadow-sm"
          >
            <div className="flex items-start gap-2.5">
              <div className="p-1 rounded-lg bg-pink-100 text-pink-700 flex-shrink-0 mt-0.5">
                <Lightbulb className="w-4 h-4" />
              </div>
              <div>
                <span className="text-xs uppercase font-extrabold tracking-wider text-pink-700 block mb-0.5">
                  High-Yield Mnemonic
                </span>
                <p className="font-semibold text-base text-zinc-900 leading-snug">
                  {block.text}
                </p>
              </div>
            </div>
          </div>
        )

      case 'highlight':
        return (
          <div
            key={index}
            className="my-3 p-3.5 rounded-2xl border border-zinc-200/70 shadow-sm"
            style={{ backgroundColor: `${activeColor}20`, borderColor: activeColor }}
          >
            <div className="flex items-start gap-2.5">
              <div className="p-1 rounded-lg bg-white/80 text-zinc-900 flex-shrink-0 mt-0.5 shadow-xs">
                <BookmarkCheck className="w-4 h-4 text-emerald-700" />
              </div>
              <div>
                <span className="text-xs uppercase font-extrabold tracking-wider text-zinc-600 block mb-0.5">
                  Clinical Pearl
                </span>
                <p className="font-bold text-zinc-900 text-base leading-snug">
                  {block.text}
                </p>
              </div>
            </div>
          </div>
        )

      case 'list':
        return (
          <ul
            key={index}
            className="my-3 space-y-2 text-zinc-800"
            style={{ fontSize: `${fontSize}px` }}
          >
            {block.items?.map((item, itemIdx) => (
              <li key={itemIdx} className="flex items-start gap-3 pl-1">
                <span className="w-2 h-2 rounded-full bg-[#18181B] mt-2 flex-shrink-0" />
                <span className="leading-relaxed font-medium">{item}</span>
              </li>
            ))}
          </ul>
        )

      case 'table':
        return (
          <div key={index} className="w-full my-3 overflow-x-auto rounded-2xl border border-zinc-200 bg-white shadow-sm">
            <table className="w-full border-collapse text-left min-w-[280px]">
              <thead>
                <tr className="bg-zinc-100/80 border-b border-zinc-200 text-xs uppercase font-bold text-zinc-600">
                  {block.headers?.map((header, hIdx) => (
                    <th key={hIdx} className="px-4 py-3 font-semibold">
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-100 text-sm">
                {block.rows?.map((row, rIdx) => (
                  <tr key={rIdx} className="hover:bg-zinc-50/80 transition-colors">
                    {row.map((cell, cIdx) => (
                      <td key={cIdx} className="px-4 py-2.5 font-medium text-zinc-800">
                        {cIdx === 0 ? (
                          <span className="inline-flex items-center justify-center w-6 h-6 rounded-lg bg-[#D4F943] text-black font-extrabold text-xs">
                            {cell}
                          </span>
                        ) : (
                          cell
                        )}
                      </td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )

      default:
        return null
    }
  }

  return (
    <div className={`space-y-4 ${activeFont}`}>
      {blocks.map((block, index) => renderBlock(block, index))}
    </div>
  )
}
