import React from 'react'
import { Bold, Italic, Type, Quote, Link2, AlignLeft, AlignCenter, AlignRight, AlignJustify, ChevronDown, Check } from 'lucide-react'

export default function TextFormatDrawer({
  isOpen,
  onClose,
  activeColor,
  setActiveColor,
  activeFont,
  setActiveFont,
  fontSize,
  setFontSize,
  isBold,
  setIsBold,
  isItalic,
  setIsItalic,
  textAlign,
  setTextAlign
}) {
  if (!isOpen) return null

  const colors = [
    { id: 'dark', hex: '#18181B', label: 'Dark' },
    { id: 'white', hex: '#FFFFFF', border: true, label: 'White' },
    { id: 'blue', hex: '#3B82F6', label: 'Blue' },
    { id: 'teal', hex: '#06B6D4', label: 'Teal' },
    { id: 'lime', hex: '#D4F943', label: 'Lime' },
    { id: 'rainbow', rainbow: true, label: 'Custom' },
  ]

  const fonts = [
    { id: 'font-nunito', label: 'Nunito' },
    { id: 'font-sans', label: 'Plus Jakarta' },
    { id: 'font-note', label: 'Patrick Hand' },
    { id: 'font-hand', label: 'Caveat Script' },
  ]

  return (
    <div className="fixed inset-x-0 bottom-0 z-40 flex justify-center pointer-events-none">
      {/* Drawer Container */}
      <div className="w-full max-w-lg bg-[#18181B] text-white rounded-t-[2.5rem] p-5 pb-8 shadow-2xl pointer-events-auto border-t border-zinc-800 animate-slide-up">
        {/* Top Drag Handle */}
        <div 
          onClick={onClose}
          className="w-12 h-1.5 bg-zinc-600 rounded-full mx-auto mb-4 cursor-pointer hover:bg-zinc-500 transition-colors"
        />

        {/* Title */}
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-bold text-lg text-white font-sans">Text format</h3>
          <button 
            onClick={onClose}
            className="text-xs text-zinc-400 hover:text-white font-medium bg-zinc-800 px-3 py-1 rounded-full"
          >
            Done
          </button>
        </div>

        {/* Color Swatches Row (Screen 3) */}
        <div className="flex items-center gap-3.5 mb-5 pb-3 border-b border-zinc-800/80">
          {colors.map((c) => (
            <button
              key={c.id}
              onClick={() => setActiveColor(c.hex || '#D4F943')}
              className={`w-9 h-9 rounded-full flex items-center justify-center transition-transform active:scale-90 ${
                activeColor === c.hex ? 'ring-2 ring-white ring-offset-2 ring-offset-[#18181B] scale-105' : ''
              } ${c.border ? 'border border-zinc-300' : ''}`}
              style={{
                background: c.rainbow
                  ? 'conic-gradient(from 180deg at 50% 50%, #FF0000 0deg, #FFFF00 60deg, #00FF00 120deg, #00FFFF 180deg, #0000FF 240deg, #FF00FF 300deg, #FF0000 360deg)'
                  : c.hex
              }}
              aria-label={c.label}
            >
              {activeColor === c.hex && (
                <Check className={`w-4 h-4 ${c.id === 'white' || c.id === 'lime' ? 'text-black' : 'text-white'}`} />
              )}
            </button>
          ))}
        </div>

        {/* Text Style Toolbar (Bold, Italic, Type, Quote, Link) */}
        <div className="flex items-center justify-around bg-zinc-800/70 rounded-2xl p-2 mb-4">
          <button
            onClick={() => setIsBold(!isBold)}
            className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm transition-colors ${
              isBold ? 'bg-zinc-700 text-[#D4F943]' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Bold className="w-4 h-4" />
          </button>
          <button
            onClick={() => setIsItalic(!isItalic)}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
              isItalic ? 'bg-zinc-700 text-[#D4F943]' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <Italic className="w-4 h-4" />
          </button>
          <button
            className="w-10 h-10 rounded-xl flex items-center justify-center text-zinc-400 hover:text-white transition-colors"
          >
            <Type className="w-4 h-4" />
          </button>
          <button
            className="w-10 h-10 rounded-xl flex items-center justify-center text-zinc-400 hover:text-white transition-colors"
          >
            <Quote className="w-4 h-4" />
          </button>
          <button
            className="w-10 h-10 rounded-xl flex items-center justify-center text-zinc-400 hover:text-white transition-colors"
          >
            <Link2 className="w-4 h-4" />
          </button>
        </div>

        {/* Font Picker & Size Selectors (Matching Screen 3) */}
        <div className="space-y-3 mb-4">
          <div className="relative">
            <select
              value={activeFont}
              onChange={(e) => setActiveFont(e.target.value)}
              className="w-full bg-zinc-800 text-white px-4 py-3 rounded-2xl text-sm font-medium appearance-none cursor-pointer focus:outline-none focus:ring-1 focus:ring-[#D4F943]"
            >
              {fonts.map((f) => (
                <option key={f.id} value={f.id} className="bg-zinc-900 text-white">
                  {f.label}
                </option>
              ))}
            </select>
            <ChevronDown className="w-4 h-4 text-zinc-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="relative">
              <select
                className="w-full bg-zinc-800 text-white px-4 py-3 rounded-2xl text-sm font-medium appearance-none cursor-pointer focus:outline-none focus:ring-1 focus:ring-[#D4F943]"
              >
                <option>Medium</option>
                <option>Regular</option>
                <option>Bold</option>
              </select>
              <ChevronDown className="w-4 h-4 text-zinc-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>

            <div className="relative">
              <select
                value={fontSize}
                onChange={(e) => setFontSize(Number(e.target.value))}
                className="w-full bg-zinc-800 text-white px-4 py-3 rounded-2xl text-sm font-medium appearance-none cursor-pointer focus:outline-none focus:ring-1 focus:ring-[#D4F943]"
              >
                <option value={14}>14 px</option>
                <option value={16}>16 px</option>
                <option value={18}>18 px</option>
                <option value={20}>20 px</option>
              </select>
              <ChevronDown className="w-4 h-4 text-zinc-400 absolute right-4 top-1/2 -translate-y-1/2 pointer-events-none" />
            </div>
          </div>
        </div>

        {/* Alignment Row */}
        <div className="flex items-center justify-around bg-zinc-800/70 rounded-2xl p-2">
          <button
            onClick={() => setTextAlign('left')}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
              textAlign === 'left' ? 'bg-zinc-700 text-[#D4F943]' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <AlignLeft className="w-4 h-4" />
          </button>
          <button
            onClick={() => setTextAlign('center')}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
              textAlign === 'center' ? 'bg-zinc-700 text-[#D4F943]' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <AlignCenter className="w-4 h-4" />
          </button>
          <button
            onClick={() => setTextAlign('right')}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
              textAlign === 'right' ? 'bg-zinc-700 text-[#D4F943]' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <AlignRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => setTextAlign('justify')}
            className={`w-10 h-10 rounded-xl flex items-center justify-center transition-colors ${
              textAlign === 'justify' ? 'bg-zinc-700 text-[#D4F943]' : 'text-zinc-400 hover:text-white'
            }`}
          >
            <AlignJustify className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  )
}
