import React from 'react'
import { Pill, BookOpen, PenTool } from 'lucide-react'

export default function Header() {
  return (
    <header className="border-b border-[#e5e0d5] bg-paper/90 backdrop-blur px-6 py-4 flex items-center justify-between sticky top-0 z-10 shadow-sm">
      <div className="flex items-center gap-3">
        <div className="p-2 rounded-xl bg-amber-100 text-ink">
          <Pill className="w-6 h-6 text-amber-700" />
        </div>
        <div>
          <h1 className="text-3xl font-hand font-bold text-ink leading-tight">PharmaNotes</h1>
          <p className="text-xs font-note text-gray-500">Your lined notebook for pharmacy studies</p>
        </div>
      </div>
      <div className="flex items-center gap-4 text-sm font-neat">
        <span className="flex items-center gap-1.5 text-gray-700 bg-amber-50 px-3 py-1.5 rounded-lg border border-amber-200">
          <BookOpen className="w-4 h-4 text-amber-600" /> Study Guide
        </span>
        <span className="flex items-center gap-1.5 text-gray-700 bg-emerald-50 px-3 py-1.5 rounded-lg border border-emerald-200">
          <PenTool className="w-4 h-4 text-emerald-600" /> Handwritten Style
        </span>
      </div>
    </header>
  )
}
