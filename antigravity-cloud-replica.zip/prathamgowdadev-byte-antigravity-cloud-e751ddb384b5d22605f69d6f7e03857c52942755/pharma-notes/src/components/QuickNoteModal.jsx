import React, { useState } from 'react'
import { X, Type, Pen, Camera, CaseSensitive, Sliders, Check } from 'lucide-react'

export default function QuickNoteModal({ isOpen, onClose, onSaveNote }) {
  const [selectedTool, setSelectedTool] = useState('text')
  const [title, setTitle] = useState('')
  const [unit, setUnit] = useState('Unit 2: ANS Drugs')
  const [content, setContent] = useState('')
  const [savedSuccess, setSavedSuccess] = useState(false)

  if (!isOpen) return null

  const handleSave = (e) => {
    e.preventDefault()
    if (!title.trim()) return

    const newNote = {
      id: title.toLowerCase().replace(/[^a-z0-9]+/g, '-'),
      unit: unit,
      category: unit.includes('ANS') ? 'ANS Drugs' : 'Cardiovascular',
      title: title,
      subtitle: content.slice(0, 45) || 'Clinical high-yield note',
      readTime: '2 min',
      date: 'Today',
      checklist: [
        { text: title + ' core review', completed: false },
        { text: 'Memorize drug indications & contraindications', completed: false }
      ],
      content: [
        { type: 'heading', text: title.toUpperCase() },
        { type: 'italic', text: content || 'High-yield clinical pharmacological pearl.' },
        { type: 'highlight', text: `Key Focus: ${title} clinical pearls and mechanism of action.` }
      ]
    }

    if (onSaveNote) {
      onSaveNote(newNote)
    }

    setSavedSuccess(true)
    setTimeout(() => {
      setSavedSuccess(false)
      setTitle('')
      setContent('')
      onClose()
    }, 600)
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/60 backdrop-blur-sm animate-fade-in">
      <div 
        className="w-full max-w-[400px] bg-white rounded-[2.5rem] p-6 shadow-2xl relative border border-zinc-100 flex flex-col justify-between overflow-hidden animate-scale-up"
        style={{ minHeight: '620px' }}
      >
        {/* Subtle grid pattern background */}
        <div className="absolute inset-0 bg-grid-pattern opacity-60 pointer-events-none" />

        {/* Top Header */}
        <div className="relative z-10 flex items-center justify-between pb-3">
          <div className="flex items-center gap-1.5">
            <span className="text-xl font-extrabold tracking-tight text-zinc-950 font-sans">
              Pharma<span className="text-[#84B800] bg-[#D4F943] px-1.5 py-0.5 rounded-lg text-black ml-0.5">X</span>
            </span>
          </div>
          <button 
            onClick={onClose}
            className="w-9 h-9 rounded-full bg-zinc-100 hover:bg-zinc-200 flex items-center justify-center text-zinc-600 transition-colors"
            aria-label="Close modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Stylized Pencil Illustration Canvas */}
        <div className="relative z-10 my-auto py-2 flex flex-col items-center justify-center">
          <div className="w-full h-44 relative flex items-center justify-center">
            {/* SVG Pencil Drawing matching Screen 1 in reference */}
            <svg viewBox="0 0 280 180" className="w-full h-full drop-shadow-md">
              {/* Notebook ruling lines */}
              <line x1="20" y1="40" x2="260" y2="40" stroke="#E4E4E7" strokeWidth="1.5" strokeDasharray="4 4" />
              <line x1="20" y1="80" x2="260" y2="80" stroke="#E4E4E7" strokeWidth="1.5" strokeDasharray="4 4" />
              <line x1="20" y1="120" x2="260" y2="120" stroke="#E4E4E7" strokeWidth="1.5" strokeDasharray="4 4" />

              {/* Hand-drawn swirl line */}
              <path 
                d="M 40 100 C 60 70, 75 140, 95 105 C 110 80, 130 90, 150 110 L 178 120" 
                fill="none" 
                stroke="#A1A1AA" 
                strokeWidth="4" 
                strokeLinecap="round" 
              />
              <path 
                d="M 150 110 L 180 120" 
                fill="none" 
                stroke="#18181B" 
                strokeWidth="4.5" 
                strokeLinecap="round" 
              />

              {/* Orange Pencil */}
              <g transform="translate(178, 42) rotate(42)">
                {/* Pencil eraser */}
                <rect x="0" y="0" width="26" height="14" rx="4" fill="#F472B6" />
                {/* Silver ferrule ring */}
                <rect x="0" y="14" width="26" height="8" fill="#D4D4D8" />
                {/* Orange wooden body */}
                <rect x="0" y="22" width="26" height="65" fill="#F97316" />
                {/* Wood tip */}
                <polygon points="0,87 26,87 13,110" fill="#FED7AA" />
                {/* Graphite lead tip */}
                <polygon points="9,102 17,102 13,112" fill="#18181B" />
              </g>
            </svg>
          </div>

          {/* Headline with vibrant lime green highlight */}
          <div className="text-center px-3 mt-1">
            <h2 className="text-2xl sm:text-[26px] font-bold text-zinc-900 tracking-tight leading-snug">
              Start your adventure by taking notes{' '}
              <span className="bg-[#D4F943] text-black px-2 py-0.5 rounded-lg inline-block font-extrabold shadow-sm">
                right away!
              </span>
            </h2>
          </div>
        </div>

        {/* Form and Tool Drawer */}
        <div className="relative z-10 space-y-4 pt-2">
          {/* Quick Input */}
          <div className="space-y-2">
            <input 
              type="text"
              placeholder="Note title (e.g. Adrenergic Agonists)"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-4 py-2.5 rounded-2xl bg-zinc-100/90 border border-zinc-200 text-sm font-medium text-zinc-900 placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#D4F943]"
            />
            <input 
              type="text"
              placeholder="High-yield pearl or drug mechanism..."
              value={content}
              onChange={(e) => setContent(e.target.value)}
              className="w-full px-4 py-2 rounded-2xl bg-zinc-100/80 border border-zinc-200 text-xs font-medium text-zinc-900 placeholder:text-zinc-400 focus:outline-none focus:ring-2 focus:ring-[#D4F943]"
            />
          </div>

          {/* Tool Selector Pill Bar (Matching Screen 1) */}
          <div className="bg-zinc-100/90 rounded-2xl p-1.5 flex items-center justify-around border border-zinc-200/70">
            <button 
              type="button"
              onClick={() => setSelectedTool('text')}
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                selectedTool === 'text' ? 'bg-[#18181B] text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-900'
              }`}
            >
              <span className="font-bold text-sm">T</span>
            </button>
            <button 
              type="button"
              onClick={() => setSelectedTool('pencil')}
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                selectedTool === 'pencil' ? 'bg-[#18181B] text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-900'
              }`}
            >
              <Pen className="w-4 h-4" />
            </button>
            <button 
              type="button"
              onClick={() => setSelectedTool('camera')}
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                selectedTool === 'camera' ? 'bg-[#18181B] text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-900'
              }`}
            >
              <Camera className="w-4 h-4" />
            </button>
            <button 
              type="button"
              onClick={() => setSelectedTool('font')}
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                selectedTool === 'font' ? 'bg-[#18181B] text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-900'
              }`}
            >
              <CaseSensitive className="w-4 h-4" />
            </button>
            <button 
              type="button"
              onClick={() => setSelectedTool('settings')}
              className={`w-9 h-9 rounded-xl flex items-center justify-center transition-all ${
                selectedTool === 'settings' ? 'bg-[#18181B] text-white shadow-sm' : 'text-zinc-500 hover:text-zinc-900'
              }`}
            >
              <Sliders className="w-4 h-4" />
            </button>
          </div>

          {/* Action Button: Get started */}
          <button 
            type="button"
            onClick={handleSave}
            disabled={!title.trim()}
            className={`w-full py-4 rounded-full font-bold text-base transition-all flex items-center justify-center gap-2 shadow-lg ${
              savedSuccess 
                ? 'bg-emerald-600 text-white' 
                : title.trim()
                  ? 'bg-[#18181B] text-white hover:bg-black active:scale-[0.98]'
                  : 'bg-zinc-200 text-zinc-400 cursor-not-allowed'
            }`}
          >
            {savedSuccess ? (
              <>
                <Check className="w-5 h-5 text-[#D4F943]" />
                Saved to PharmaX!
              </>
            ) : (
              'Get started'
            )}
          </button>
        </div>
      </div>
    </div>
  )
}
