import React from 'react';
import { ArrowLeft, ChevronRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function HeaderBanner({
  title,
  subtitlePills = [],
  onBack,
  backTo,
  icon,
  rightAction,
  category
}) {
  const navigate = useNavigate();

  const handleBack = () => {
    if (onBack) {
      onBack();
    } else if (backTo) {
      navigate(backTo);
    } else {
      navigate(-1);
    }
  };

  return (
    <div className="relative bg-[#18181B] text-white pt-4 pb-7 px-5 rounded-b-[2.5rem] shadow-xl overflow-hidden select-none border-b border-zinc-800">
      {/* Ambient background glow matching PharmaX aesthetic */}
      <div className="absolute -top-12 -right-12 w-48 h-48 bg-[#D4F943]/10 rounded-full blur-2xl pointer-events-none" />
      <div className="absolute top-10 left-1/3 w-32 h-32 bg-[#84B800]/10 rounded-full blur-xl pointer-events-none" />

      {/* Top Bar with Back Arrow & Branding */}
      <div className="relative z-10 flex items-center justify-between pt-1 pb-3">
        <button
          onClick={handleBack}
          className="w-10 h-10 rounded-full bg-zinc-800/90 hover:bg-zinc-700 active:scale-95 flex items-center justify-center transition-all text-white border border-zinc-700 shadow-sm"
          aria-label="Go back"
        >
          <ArrowLeft className="w-5 h-5 stroke-[2.5]" />
        </button>

        <div className="flex items-center gap-1.5">
          <span className="text-xs font-bold text-zinc-400">Pharma</span>
          <span className="bg-[#D4F943] text-black text-[10px] font-black px-1.5 py-0.5 rounded-md">
            X
          </span>
        </div>

        {rightAction ? (
          <div className="flex items-center gap-2">
            {rightAction}
          </div>
        ) : (
          <div className="w-10" />
        )}
      </div>

      {/* Header Content with Optional Icon */}
      <div className="relative z-10 mt-1">
        {category && (
          <span className="text-[10px] font-extrabold uppercase tracking-widest text-[#D4F943] block mb-1">
            {category}
          </span>
        )}

        {icon && (
          <div className="mb-2 inline-block">
            {icon}
          </div>
        )}

        <h1 className="text-2xl sm:text-[26px] font-black tracking-tight text-white leading-tight font-sans">
          {title}
        </h1>

        {/* Subtitle Badges Row */}
        {subtitlePills && subtitlePills.length > 0 && (
          <div className="flex items-center gap-2 mt-3 flex-wrap">
            {subtitlePills.map((pill, idx) => (
              <span
                key={idx}
                className={`text-xs font-bold px-3 py-1 rounded-full transition-all ${
                  pill.variant === 'lime' || pill.variant === 'solid'
                    ? 'bg-[#D4F943] text-black shadow-xs font-black'
                    : pill.variant === 'transparent'
                    ? 'text-zinc-400 px-1'
                    : 'bg-zinc-800 text-zinc-200 border border-zinc-700'
                }`}
              >
                {pill.text}
              </span>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
