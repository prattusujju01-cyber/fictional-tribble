import React, { useState } from 'react';
import { 
  X, 
  Download, 
  FileText, 
  Sparkles, 
  CheckCircle,
  Loader2,
  BookOpen,
  ArrowRight,
  Zap
} from 'lucide-react';
import { getSemester1Notes } from '../data/notes_sem1';
import { generateAndDownloadPdf } from '../lib/pdfGenerator';

export default function PdfViewerModal({ isOpen, onClose, subject, unit, semester }) {
  const [isGenerating, setIsGenerating] = useState(false);
  const [isDownloaded, setIsDownloaded] = useState(false);

  if (!isOpen || !unit || !subject) return null;

  // Retrieve notes data
  const sem1Data = getSemester1Notes(subject.id, unit.unitNumber);
  const concepts = sem1Data?.concepts || [];
  const hasNotes = concepts.length > 0;

  const handleDownload = async () => {
    if (isGenerating) return;
    setIsGenerating(true);
    setIsDownloaded(false);

    try {
      await generateAndDownloadPdf(subject, unit, sem1Data);
      setIsDownloaded(true);
      // Reset after 3 seconds
      setTimeout(() => setIsDownloaded(false), 3000);
    } catch (err) {
      console.error('PDF generation failed:', err);
      alert('PDF generation failed. Please try again.');
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div 
      className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/70 backdrop-blur-sm"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div 
        className="w-full max-w-[440px] bg-white rounded-t-[2rem] sm:rounded-[2rem] shadow-2xl overflow-hidden border border-zinc-200/50 animate-slide-up"
        style={{
          animation: 'slideUp 0.3s cubic-bezier(0.16, 1, 0.3, 1)'
        }}
      >
        {/* Handle bar (mobile sheet indicator) */}
        <div className="flex justify-center pt-3 pb-1 sm:hidden">
          <div className="w-10 h-1 rounded-full bg-zinc-300" />
        </div>

        {/* Header */}
        <div className="px-5 pt-3 sm:pt-5 pb-4 flex items-start justify-between">
          <div className="flex items-center gap-3">
            {/* PDF Icon */}
            <div className="w-12 h-12 rounded-2xl bg-[#18181B] flex items-center justify-center flex-shrink-0 shadow-lg">
              <span className="text-[11px] font-black text-[#D4F943] tracking-tight">PDF</span>
            </div>
            <div>
              <span className="text-[10px] font-black uppercase tracking-wider text-[#D4F943] bg-[#18181B] px-2 py-0.5 rounded-md inline-block">
                {subject.code}
              </span>
              <h3 className="text-base font-black text-zinc-950 tracking-tight mt-1 leading-tight max-w-[250px]">
                Unit {unit.unitNumber}: {unit.title}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-full bg-zinc-100 hover:bg-zinc-200 flex items-center justify-center text-zinc-500 hover:text-zinc-800 transition-all active:scale-95 flex-shrink-0 mt-1"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content Summary Cards */}
        <div className="px-5 pb-4 space-y-2.5">
          {/* What's inside card */}
          <div className="bg-zinc-50 rounded-2xl p-4 border border-zinc-100">
            <h4 className="text-[10px] font-black uppercase tracking-wider text-zinc-400 mb-2.5">
              What's inside this PDF
            </h4>
            <div className="space-y-2">
              {[
                { icon: BookOpen, text: `${hasNotes ? concepts.length : unit.topics?.length || 0} detailed concepts with definitions`, color: 'text-blue-600' },
                { icon: Sparkles, text: 'Highlighted scoring keywords for exams', color: 'text-amber-500' },
                { icon: Zap, text: 'Visual flowcharts & reaction diagrams', color: 'text-emerald-600' },
                { icon: FileText, text: 'Predicted exam questions (2/5/10 marks)', color: 'text-purple-600' },
              ].map((item, idx) => (
                <div key={idx} className="flex items-center gap-2.5">
                  <div className={`w-6 h-6 rounded-lg bg-white border border-zinc-200 flex items-center justify-center flex-shrink-0 ${item.color}`}>
                    <item.icon className="w-3.5 h-3.5" />
                  </div>
                  <span className="text-xs font-semibold text-zinc-700">{item.text}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Notes quality badge */}
          {hasNotes && (
            <div className="bg-gradient-to-r from-emerald-50 to-teal-50 rounded-xl p-3 border border-emerald-100 flex items-center gap-2.5">
              <CheckCircle className="w-4 h-4 text-emerald-600 flex-shrink-0" />
              <span className="text-[11px] font-bold text-emerald-800">
                Exam-oriented notes ready — PCI curriculum aligned
              </span>
            </div>
          )}

          {/* Semester info */}
          <div className="flex items-center gap-2 px-1">
            <span className="text-[10px] font-bold text-zinc-400">
              {semester ? semester.name : 'Semester 1'} • {subject.name}
            </span>
          </div>
        </div>

        {/* Download Button Area */}
        <div className="px-5 pb-6 pt-1">
          {/* Main download button */}
          <button
            onClick={handleDownload}
            disabled={isGenerating}
            className={`w-full py-4 rounded-2xl font-black text-sm flex items-center justify-center gap-2.5 shadow-lg active:scale-[0.98] transition-all ${
              isDownloaded
                ? 'bg-emerald-500 text-white'
                : isGenerating
                ? 'bg-[#18181B] text-zinc-400 cursor-wait'
                : 'bg-[#18181B] hover:bg-black text-white'
            }`}
          >
            {isDownloaded ? (
              <>
                <CheckCircle className="w-5 h-5" />
                Downloaded Successfully!
              </>
            ) : isGenerating ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Generating PDF Notes...
              </>
            ) : (
              <>
                <Download className="w-5 h-5 text-[#D4F943]" />
                Download PDF Notes
                <ArrowRight className="w-4 h-4 ml-1 text-zinc-500" />
              </>
            )}
          </button>

          {/* File info */}
          <p className="text-center text-[10px] text-zinc-400 font-medium mt-2">
            {subject.code}_Unit_{unit.unitNumber}_PharmaX_Notes.pdf • Handwritten Style
          </p>
        </div>
      </div>

      {/* Slide-up animation */}
      <style>{`
        @keyframes slideUp {
          from { transform: translateY(100%); opacity: 0; }
          to { transform: translateY(0); opacity: 1; }
        }
        .animate-slide-up {
          animation: slideUp 0.3s cubic-bezier(0.16, 1, 0.3, 1);
        }
      `}</style>
    </div>
  );
}
