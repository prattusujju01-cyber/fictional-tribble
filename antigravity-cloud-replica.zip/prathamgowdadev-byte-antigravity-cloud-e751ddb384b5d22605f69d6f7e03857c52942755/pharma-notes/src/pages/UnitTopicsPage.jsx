import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowLeft, 
  Download, 
  FileText, 
  BookOpen, 
  Check, 
  Share2, 
  Sparkles,
  ArrowUpRight
} from 'lucide-react';
import { SUBJECTS_DATA, SEMESTERS_DATA } from '../data/bpharmCurriculum';
import HeaderBanner from '../components/HeaderBanner';
import PdfViewerModal from '../components/PdfViewerModal';

export default function UnitTopicsPage() {
  const { subjectId, unitNumber } = useParams();
  const navigate = useNavigate();
  const [isPdfModalOpen, setIsPdfModalOpen] = useState(false);
  const [completedTopics, setCompletedTopics] = useState({});

  const subject = SUBJECTS_DATA.find((s) => s.id === subjectId) || SUBJECTS_DATA[0];
  const semester = SEMESTERS_DATA.find((s) => s.id === subject.semId);
  
  const currentUnitNum = parseInt(unitNumber, 10) || 1;
  const unit = subject.units?.find((u) => u.unitNumber === currentUnitNum) || subject.units?.[0] || {
    unitNumber: 1,
    title: 'Unit Overview',
    topics: ['Overview of unit concepts and definitions'],
    notesSummary: 'High-yield notes summary for this unit.'
  };

  const toggleTopic = (index) => {
    setCompletedTopics((prev) => ({
      ...prev,
      [index]: !prev[index]
    }));
  };

  const completedCount = Object.values(completedTopics).filter(Boolean).length;
  const totalCount = unit.topics?.length || 1;
  const progressPercent = Math.round((completedCount / totalCount) * 100);

  return (
    <div className="min-h-screen bg-[#F4F4F6] text-[#18181B] pb-24 font-sans select-none selection:bg-[#D4F943]">
      {/* PharmaX Signature Dark Banner */}
      <HeaderBanner
        category={`${subject.code} • Unit ${unit.unitNumber}`}
        title={unit.title}
        subtitlePills={[
          { text: `${totalCount} Syllabus Topics`, variant: 'lime' },
          { text: `${progressPercent}% Completed`, variant: 'default' }
        ]}
        backTo={`/subject/${subject.id}`}
      />

      {/* Main Content Area */}
      <div className="max-w-[440px] mx-auto px-4 sm:px-5 pt-5">
        
        {/* Progress Bar in PharmaX Style */}
        <div className="bg-white rounded-2xl p-4 shadow-sm border border-zinc-100/90 mb-5">
          <div className="flex items-center justify-between text-xs font-bold mb-2">
            <span className="text-zinc-600">Unit Study Progress</span>
            <span className="text-black bg-[#D4F943] px-2 py-0.5 rounded-full text-[11px] font-black">
              {completedCount}/{totalCount} Topics
            </span>
          </div>
          <div className="w-full h-2.5 bg-zinc-100 rounded-full overflow-hidden">
            <div 
              className="h-full bg-[#18181B] transition-all duration-300 rounded-full"
              style={{ width: `${progressPercent}%` }}
            />
          </div>
        </div>

        {/* Topics Count Subheading */}
        <div className="flex items-center justify-between mb-3 px-1">
          <span className="text-xs font-black uppercase tracking-wider text-zinc-500">
            Syllabus Topics
          </span>
          <span className="text-[11px] font-bold text-zinc-400">
            Tap circle to check off
          </span>
        </div>

        {/* Topics List with Interactive Checkbox */}
        <div className="space-y-3">
          {unit.topics?.map((topic, index) => {
            const isDone = !!completedTopics[index];
            return (
              <div
                key={index}
                onClick={() => toggleTopic(index)}
                className={`bg-white rounded-2xl p-4 border transition-all cursor-pointer flex items-start gap-3.5 shadow-sm active:scale-[0.99] select-none ${
                  isDone ? 'border-zinc-300/80 bg-zinc-50/70' : 'border-zinc-100/90 hover:border-zinc-300'
                }`}
              >
                {/* Topic Checkbox / Number Badge */}
                <div
                  className={`w-7 h-7 rounded-xl flex items-center justify-center flex-shrink-0 transition-colors mt-0.5 ${
                    isDone 
                      ? 'bg-[#18181B] text-white' 
                      : 'bg-zinc-100 text-zinc-700 font-black text-xs'
                  }`}
                >
                  {isDone ? (
                    <Check className="w-4 h-4 stroke-[3]" />
                  ) : (
                    <span>{index + 1}</span>
                  )}
                </div>

                {/* Topic Description Text */}
                <p 
                  className={`text-xs sm:text-[13px] font-bold leading-snug flex-1 transition-all ${
                    isDone ? 'text-zinc-400 line-through' : 'text-zinc-900'
                  }`}
                >
                  {topic}
                </p>
              </div>
            );
          })}
        </div>

        {/* Download Notes Section in Signature PharmaX Luxury Dark Card */}
        <div className="mt-8 pt-2">
          {/* Section Heading with Lime Accent */}
          <div className="flex items-center gap-2 mb-1.5 px-1">
            <div className="w-2 h-5 bg-[#D4F943] rounded-full" />
            <h2 className="text-base font-black text-zinc-950 tracking-tight">
              Download Notes
            </h2>
          </div>
          
          <p className="text-xs text-zinc-500 font-medium mb-3 pl-3">
            Unit {unit.unitNumber} High-Yield Notes & Printable PDF
          </p>

          {/* Iconic PharmaX Dark Download Card */}
          <div
            onClick={() => setIsPdfModalOpen(true)}
            className="group bg-[#18181B] text-white rounded-[2rem] p-5 shadow-xl border border-zinc-800 hover:border-zinc-600 active:scale-[0.99] transition-all cursor-pointer flex items-center justify-between gap-3 relative overflow-hidden"
          >
            {/* Ambient subtle lime glow */}
            <div className="absolute -top-10 -right-10 w-32 h-32 bg-[#D4F943]/15 rounded-full blur-2xl pointer-events-none" />

            <div className="flex items-center gap-3.5 flex-1 min-w-0 relative z-10">
              {/* PDF Icon Badge in Neon Lime */}
              <div className="w-13 h-13 rounded-2xl bg-[#D4F943] flex items-center justify-center flex-shrink-0 group-hover:scale-105 transition-transform shadow-md">
                <span className="text-xs font-black text-black tracking-tight">
                  PDF
                </span>
              </div>

              {/* Download Details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] font-black uppercase tracking-wider text-[#D4F943]">
                    Unit {unit.unitNumber} Notes
                  </span>
                </div>
                <h3 className="text-sm sm:text-base font-black text-white tracking-tight leading-snug mt-0.5">
                  Tap to Download & Open PDF
                </h3>
                <p className="text-[11px] text-zinc-400 font-medium mt-0.5">
                  High-yield summaries, formulas & exam pearls
                </p>
              </div>
            </div>

            {/* Neon Lime Circular Download Icon */}
            <div className="w-11 h-11 rounded-full bg-[#D4F943] group-hover:bg-[#e2ff60] text-black flex items-center justify-center flex-shrink-0 transition-transform group-hover:scale-105 shadow-md relative z-10">
              <Download className="w-5 h-5 stroke-[2.5]" />
            </div>
          </div>
        </div>

        {/* Back Link */}
        <div className="mt-8 text-center">
          <button
            onClick={() => navigate(`/subject/${subject.id}`)}
            className="text-xs font-bold text-zinc-400 hover:text-zinc-700 transition-colors inline-flex items-center gap-1.5"
          >
            ← Back to All {subject.code} Units
          </button>
        </div>
      </div>

      {/* PDF Download & Preview Modal */}
      <PdfViewerModal
        isOpen={isPdfModalOpen}
        onClose={() => setIsPdfModalOpen(false)}
        subject={subject}
        unit={unit}
        semester={semester}
      />
    </div>
  );
}
