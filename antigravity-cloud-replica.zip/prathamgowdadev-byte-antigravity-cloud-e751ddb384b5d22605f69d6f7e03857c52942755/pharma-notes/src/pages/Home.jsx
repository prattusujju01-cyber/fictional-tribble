import React, { useState, useEffect } from 'react'
import { Link } from 'react-router-dom'
import { 
  Search, 
  ArrowUpRight, 
  Check, 
  MoreHorizontal, 
  FileText, 
  Lock, 
  Clock, 
  BookOpen, 
  Sparkles, 
  Mic, 
  Plus, 
  X,
  Layers,
  ChevronRight,
  Flame,
  HelpCircle,
  Lightbulb
} from 'lucide-react'
import supabase from '../lib/supabaseClient'
import { notes as fallbackNotes } from '../data/notes'
import QuickNoteModal from '../components/QuickNoteModal'

export default function Home() {
  const [notes, setNotes] = useState(fallbackNotes)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const [searchTerm, setSearchTerm] = useState('')
  const [searchOpen, setSearchOpen] = useState(false)
  const [activeTab, setActiveTab] = useState('All Notes')
  const [isQuickNoteOpen, setIsQuickNoteOpen] = useState(false)
  const [isQuizOpen, setIsQuizOpen] = useState(false)
  const [quizIdx, setQuizIdx] = useState(0)
  const [quizRevealed, setQuizRevealed] = useState(false)

  // Interactive Today review tasks (Screen 2 matching)
  const [todayTasks, setTodayTasks] = useState([
    { id: 1, text: 'Cholinergic Agonists (Pilocarpine, ACh)', done: true, slug: 'cholinergic' },
    { id: 2, text: 'Anticholinergics (Atropine SLUDGE)', done: false, slug: 'anticholinergic' },
    { id: 3, text: 'Adrenergic Antagonists (Beta Blockers)', done: false, slug: 'beta-blockers' },
  ])

  const toggleTask = (id) => {
    setTodayTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t))
    )
  }

  // Fetch from Supabase with graceful fallback
  useEffect(() => {
    let isMounted = true

    async function fetchNotes() {
      try {
        setLoading(true)
        const { data, error: fetchError } = await supabase
          .from('notes')
          .select('*')
          .order('id')

        if (fetchError) {
          console.warn('Supabase fetch notice, using fallback notes:', fetchError.message)
          if (isMounted) setNotes(fallbackNotes)
        } else if (isMounted && data && data.length > 0) {
          setNotes(data)
        } else if (isMounted) {
          setNotes(fallbackNotes)
        }
      } catch (err) {
        console.warn('Connection notice, using local notes:', err)
        if (isMounted) setNotes(fallbackNotes)
      } finally {
        if (isMounted) setLoading(false)
      }
    }

    fetchNotes()

    return () => {
      isMounted = false
    }
  }, [])

  // Categories
  const categories = [
    { name: 'All Notes', count: notes.length },
    { name: 'ANS Drugs', count: notes.filter((n) => n.unit?.includes('ANS') || n.category === 'ANS Drugs').length || 2 },
    { name: 'Cardiovascular', count: notes.filter((n) => n.unit?.includes('Cardio') || n.category === 'Cardiovascular').length || 1 },
    { name: 'Antimicrobial', count: notes.filter((n) => n.unit?.includes('Antimicrobial') || n.category === 'Antimicrobial').length || 1 },
    { name: 'Exam Pearls', count: 4 },
  ]

  // Filter notes
  const filteredNotes = notes.filter((n) => {
    const matchesSearch = !searchTerm.trim() || 
      (n.title || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (n.subtitle || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      (n.unit || '').toLowerCase().includes(searchTerm.toLowerCase())

    if (!matchesSearch) return false

    if (activeTab === 'All Notes') return true
    if (activeTab === 'ANS Drugs') return n.unit?.includes('ANS') || n.category === 'ANS Drugs'
    if (activeTab === 'Cardiovascular') return n.unit?.includes('Cardio') || n.category === 'Cardiovascular'
    if (activeTab === 'Antimicrobial') return n.unit?.includes('Antimicrobial') || n.category === 'Antimicrobial'
    if (activeTab === 'Exam Pearls') return true
    return true
  })

  // Flashcards for Quiz mode
  const flashcards = [
    { q: "What is the primary antidote for acute organophosphate poisoning?", a: "Atropine (muscarinic blockade) + Pralidoxime (reactivates AChE)." },
    { q: "Which beta blocker is cardioselective and safe in mild COPD?", a: "Metoprolol, Atenolol, or Bisoprolol (Beta-1 selective)." },
    { q: "What does the mnemonic SLUDGE stand for?", a: "Salivation, Lacrimation, Urination, Defecation, GI upset, Emesis." },
    { q: "What is the clinical use of Pilocarpine in ophthalmology?", a: "Open-angle glaucoma (constricts pupil, opens trabecular meshwork)." }
  ]

  const handleAddNewNote = (newNote) => {
    setNotes([newNote, ...notes])
  }

  return (
    <div className="min-h-screen bg-[#F4F4F6] text-[#18181B] pb-28 pt-2 font-sans selection:bg-[#D4F943]">
      <div className="max-w-[440px] mx-auto px-4 sm:px-5">
        
        {/* iOS Native Status Bar Mockup */}
        <div className="flex items-center justify-between pt-2 pb-3 px-1 text-xs font-semibold text-zinc-900 tracking-tight select-none">
          <span>9:41</span>
          <div className="w-24 h-4 bg-black rounded-full flex items-center justify-center">
            <span className="w-2.5 h-2.5 rounded-full bg-zinc-800" />
          </div>
          <div className="flex items-center gap-1.5 text-zinc-800">
            <span className="text-[10px] font-bold">5G</span>
            <div className="w-5 h-2.5 border border-zinc-800 rounded-sm p-0.5 flex items-center">
              <div className="w-full h-full bg-zinc-800 rounded-2xs" />
            </div>
          </div>
        </div>

        {/* Top Header (Screen 2: NOTEE -> PharmaX) */}
        <header className="flex items-center justify-between py-2 mb-4">
          <div className="flex items-center gap-1">
            <h1 className="text-3xl font-extrabold tracking-tight text-zinc-950 font-sans">
              Pharma<span className="text-[#84B800] bg-[#D4F943] px-2 py-0.5 rounded-xl text-black ml-0.5">X</span>
            </h1>
          </div>
          <button
            onClick={() => setSearchOpen(!searchOpen)}
            className="w-10 h-10 rounded-full bg-white border border-zinc-200/80 shadow-sm flex items-center justify-center text-zinc-700 hover:text-black hover:border-zinc-300 transition-all active:scale-95"
            aria-label="Search notes"
          >
            {searchOpen ? <X className="w-5 h-5" /> : <Search className="w-5 h-5" />}
          </button>
        </header>

        {/* Expandable Search Input */}
        {searchOpen && (
          <div className="mb-4 animate-scale-up">
            <div className="relative">
              <input
                type="text"
                autoFocus
                placeholder="Search drugs, receptors, mnemonics..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-white border border-zinc-200 rounded-2xl pl-11 pr-4 py-3 text-sm font-medium text-zinc-900 placeholder:text-zinc-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-[#D4F943]"
              />
              <Search className="w-5 h-5 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>
          </div>
        )}

        {/* Category Tabs (Horizontally Scrollable Pill Chips - Screen 2) */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-3 mb-4">
          {categories.map((cat) => {
            const isActive = activeTab === cat.name
            return (
              <button
                key={cat.name}
                onClick={() => setActiveTab(cat.name)}
                className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-semibold transition-all flex items-center gap-2 active:scale-95 ${
                  isActive
                    ? 'bg-[#18181B] text-white shadow-sm'
                    : 'bg-white text-zinc-600 border border-zinc-200/70 hover:border-zinc-300'
                }`}
              >
                <span>{cat.name}</span>
                <span
                  className={`text-xs px-2 py-0.5 rounded-full font-bold ${
                    isActive
                      ? 'bg-[#D4F943] text-black'
                      : 'bg-zinc-100 text-zinc-500'
                  }`}
                >
                  {cat.count}
                </span>
              </button>
            )
          })}
        </div>

        {/* HERO CARD: Vibrant Lime Green Card (Screen 2 Direct Match) */}
        <div className="bg-[#D4F943] rounded-[2rem] p-5 shadow-sm text-zinc-950 mb-5 relative overflow-hidden transition-transform">
          {/* Top Row: Date tag & Arrow button */}
          <div className="flex items-start justify-between mb-2">
            <div>
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-black/75 block">
                14 NOV WEDNESDAY • HIGH YIELD FOCUS
              </span>
              <h2 className="text-3xl font-extrabold tracking-tight text-black mt-0.5">
                Today
              </h2>
            </div>
            <Link
              to="/note/cholinergic"
              className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-black shadow-sm hover:scale-105 active:scale-95 transition-transform"
              aria-label="Open featured note"
            >
              <ArrowUpRight className="w-5 h-5 stroke-[2.5]" />
            </Link>
          </div>

          {/* Interactive Checklist Pills (Screen 2 items) */}
          <div className="space-y-2 mt-4">
            {todayTasks.map((task) => (
              <div
                key={task.id}
                onClick={() => toggleTask(task.id)}
                className="bg-white/95 rounded-2xl px-4 py-3 flex items-center gap-3 shadow-xs cursor-pointer hover:bg-white active:scale-[0.99] transition-all select-none"
              >
                <div
                  className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 transition-colors ${
                    task.done ? 'bg-[#18181B] text-white' : 'border-2 border-zinc-400'
                  }`}
                >
                  {task.done && <Check className="w-3 h-3 stroke-[3]" />}
                </div>
                <span
                  className={`text-sm font-semibold truncate ${
                    task.done ? 'text-zinc-500 line-through' : 'text-zinc-900'
                  }`}
                >
                  {task.text}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* BENTO GRID (Screen 2 Middle Layout Match) */}
        <div className="grid grid-cols-2 gap-3.5 mb-6">
          
          {/* Left Column Bento Card: Drugs & Receptors */}
          <div className="bg-white rounded-[2rem] p-4 shadow-sm border border-zinc-100 flex flex-col justify-between">
            <div>
              <div className="flex items-center justify-between mb-3">
                <h3 className="text-sm font-bold text-zinc-900 leading-snug">
                  Drugs & Receptors
                </h3>
                <button className="text-zinc-400 hover:text-zinc-600">
                  <MoreHorizontal className="w-4 h-4" />
                </button>
              </div>

              <div className="space-y-2.5 text-xs">
                <Link to="/note/cholinergic" className="block hover:bg-zinc-50 p-1 rounded-lg transition-colors">
                  <p className="font-bold text-zinc-900">Pilocarpine</p>
                  <p className="text-zinc-400 text-[11px]">M3 Direct Agonist</p>
                </Link>
                <Link to="/note/anticholinergic" className="block hover:bg-zinc-50 p-1 rounded-lg transition-colors">
                  <p className="font-bold text-zinc-900">Atropine</p>
                  <p className="text-zinc-400 text-[11px]">Muscarinic Blocker</p>
                </Link>
                <Link to="/note/cholinergic" className="block hover:bg-zinc-50 p-1 rounded-lg transition-colors">
                  <p className="font-bold text-zinc-900">Neostigmine</p>
                  <p className="text-zinc-400 text-[11px]">AChE Inhibitor</p>
                </Link>
                <Link to="/note/cholinergic" className="block hover:bg-zinc-50 p-1 rounded-lg transition-colors">
                  <p className="font-bold text-zinc-900">Donepezil</p>
                  <p className="text-zinc-400 text-[11px]">Alzheimer's Pearl</p>
                </Link>
              </div>
            </div>

            <div className="pt-3 border-t border-zinc-100 mt-2">
              <span className="text-[11px] font-bold text-emerald-600 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-500" /> High-Yield Tested
              </span>
            </div>
          </div>

          {/* Right Column Bento: Two Stacked Cards */}
          <div className="flex flex-col gap-3.5">
            
            {/* Top Right Card: Locked Note / Exam Pearls (Screen 2) */}
            <div 
              onClick={() => setIsQuizOpen(true)}
              className="bg-white rounded-[2rem] p-4 shadow-sm border border-zinc-100 flex flex-col items-center justify-center text-center relative cursor-pointer hover:shadow-md transition-all active:scale-[0.98]"
            >
              <span className="absolute top-3.5 right-3.5 text-zinc-400">
                <Lock className="w-3.5 h-3.5" />
              </span>

              {/* Orange Document Icon */}
              <div className="w-12 h-12 rounded-2xl bg-orange-50 border border-orange-200/80 flex items-center justify-center text-orange-500 mb-2">
                <FileText className="w-6 h-6" />
              </div>

              <span className="text-sm font-bold text-zinc-900">
                Exam Pearls
              </span>
              <span className="text-[11px] text-zinc-400 font-medium">
                Tap to Quiz
              </span>
            </div>

            {/* Bottom Right Card: Diagram Gallery (Screen 2: Art Gallery) */}
            <Link 
              to="/note/cholinergic"
              className="bg-white rounded-[2rem] p-4 shadow-sm border border-zinc-100 flex flex-col justify-between block hover:shadow-md transition-all active:scale-[0.98]"
            >
              <div className="flex items-center justify-between mb-1">
                <h4 className="text-sm font-bold text-zinc-900">
                  Diagrams
                </h4>
                <MoreHorizontal className="w-4 h-4 text-zinc-400" />
              </div>

              <div className="my-1">
                <span className="inline-block px-2 py-0.5 rounded-md bg-[#D4F943]/60 text-zinc-900 font-extrabold text-[10px]">
                  Synapse & Trees
                </span>
                <p className="text-xs font-semibold text-zinc-800 mt-1">
                  M1–M3 & SLUDGE
                </p>
                <p className="text-[11px] text-zinc-400">
                  Box-drawing ready
                </p>
              </div>

              <div className="flex items-center justify-end text-zinc-400 pt-1">
                <ChevronRight className="w-4 h-4" />
              </div>
            </Link>

          </div>
        </div>

        {/* Section Title: All Notes */}
        <div className="flex items-center justify-between mb-3 px-1">
          <h3 className="text-lg font-extrabold text-zinc-900 tracking-tight">
            Study Guides ({filteredNotes.length})
          </h3>
          <span className="text-xs font-bold text-zinc-400">
            Swipe or Tap
          </span>
        </div>

        {/* Notes Cards List */}
        {filteredNotes.length === 0 ? (
          <div className="text-center py-12 bg-white rounded-3xl p-6 border border-zinc-100 text-zinc-500 font-medium text-sm">
            No notes found for "{searchTerm}".
          </div>
        ) : (
          <div className="space-y-3.5 mb-8">
            {filteredNotes.map((n) => (
              <Link
                key={n.id}
                to={`/note/${n.id}`}
                className="bg-white rounded-[2rem] p-5 shadow-sm border border-zinc-100/90 hover:shadow-md transition-all active:scale-[0.99] block"
              >
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-2.5 py-0.5 rounded-full border border-emerald-100">
                    {n.unit}
                  </span>
                  <span className="text-xs font-semibold text-zinc-400 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" /> {n.readTime || n.read_time || '3 min'}
                  </span>
                </div>

                <h4 className="text-xl font-extrabold text-zinc-950 mt-1">
                  {n.title}
                </h4>

                <p className="text-sm font-medium text-zinc-500 mt-0.5 line-clamp-1">
                  {n.subtitle}
                </p>

                <div className="mt-3.5 pt-3 border-t border-zinc-100 flex items-center justify-between text-xs font-bold text-zinc-700">
                  <span className="flex items-center gap-1.5 text-zinc-600">
                    <BookOpen className="w-4 h-4 text-[#84B800]" />
                    Interactive Note & Diagrams
                  </span>
                  <div className="w-7 h-7 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-700 group-hover:bg-[#18181B] group-hover:text-white transition-colors">
                    <ArrowUpRight className="w-4 h-4" />
                  </div>
                </div>
              </Link>
            ))}
          </div>
        )}

      </div>

      {/* FLOATING ISLAND NAVIGATION DOCK (Exact Screen 2 Match) */}
      <div className="fixed bottom-6 left-1/2 -translate-x-1/2 z-30 pointer-events-none">
        <div className="bg-[#18181B] text-white px-3 py-2 rounded-full shadow-2xl flex items-center gap-3 border border-white/10 backdrop-blur-md pointer-events-auto">
          {/* Left: Audio / Voice button */}
          <button
            onClick={() => {
              if ('speechSynthesis' in window) {
                const utterance = new SpeechSynthesisUtterance("Welcome to PharmaX! Today's review covers Cholinergic and Anticholinergic drugs.")
                window.speechSynthesis.speak(utterance)
              }
            }}
            className="w-10 h-10 rounded-full flex items-center justify-center text-zinc-300 hover:text-white hover:bg-zinc-800 transition-colors"
            title="Read PharmaX Overview"
            aria-label="Audio read aloud"
          >
            <Mic className="w-5 h-5" />
          </button>

          {/* Center: Large Vibrant Lime Green FAB (+) */}
          <button
            onClick={() => setIsQuickNoteOpen(true)}
            className="w-12 h-12 rounded-full bg-[#D4F943] text-black font-extrabold flex items-center justify-center text-2xl shadow-lg hover:scale-105 active:scale-95 transition-all"
            title="Create Note"
            aria-label="Add new note"
          >
            <Plus className="w-6 h-6 stroke-[3]" />
          </button>

          {/* Right: AI Sparkles / Flashcards */}
          <button
            onClick={() => setIsQuizOpen(true)}
            className="w-10 h-10 rounded-full flex items-center justify-center text-zinc-300 hover:text-[#D4F943] hover:bg-zinc-800 transition-colors"
            title="Quick Flashcard Quiz"
            aria-label="Open quiz"
          >
            <Sparkles className="w-5 h-5" />
          </button>
        </div>
      </div>

      {/* Quick Note Modal (Screen 1 in Reference) */}
      <QuickNoteModal
        isOpen={isQuickNoteOpen}
        onClose={() => setIsQuickNoteOpen(false)}
        onSaveNote={handleAddNewNote}
      />

      {/* Flashcard Quiz Modal */}
      {isQuizOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm bg-white rounded-[2.5rem] p-6 shadow-2xl relative border border-zinc-100 animate-scale-up">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold uppercase tracking-wider bg-[#D4F943] px-2.5 py-1 rounded-full text-black">
                Pharma Flashcard {quizIdx + 1}/{flashcards.length}
              </span>
              <button 
                onClick={() => { setIsQuizOpen(false); setQuizRevealed(false); }}
                className="w-8 h-8 rounded-full bg-zinc-100 flex items-center justify-center text-zinc-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="my-6 min-h-[120px] flex flex-col justify-center">
              <p className="font-bold text-lg text-zinc-900 mb-3">
                {flashcards[quizIdx].q}
              </p>
              {quizRevealed && (
                <div className="p-3.5 bg-zinc-100 rounded-2xl text-sm font-semibold text-zinc-800 border-l-4 border-[#D4F943] animate-fade-in flex items-start gap-2">
                  <Lightbulb className="w-4 h-4 text-amber-500 flex-shrink-0 mt-0.5" />
                  <span>{flashcards[quizIdx].a}</span>
                </div>
              )}
            </div>

            <div className="space-y-2">
              {!quizRevealed ? (
                <button
                  onClick={() => setQuizRevealed(true)}
                  className="w-full py-3.5 rounded-full bg-[#18181B] text-white font-bold text-sm shadow-md"
                >
                  Reveal Answer
                </button>
              ) : (
                <button
                  onClick={() => {
                    setQuizRevealed(false)
                    setQuizIdx((prev) => (prev + 1) % flashcards.length)
                  }}
                  className="w-full py-3.5 rounded-full bg-[#D4F943] text-black font-extrabold text-sm shadow-md"
                >
                  Next Card →
                </button>
              )}
            </div>
          </div>
        </div>
      )}

    </div>
  )
}
