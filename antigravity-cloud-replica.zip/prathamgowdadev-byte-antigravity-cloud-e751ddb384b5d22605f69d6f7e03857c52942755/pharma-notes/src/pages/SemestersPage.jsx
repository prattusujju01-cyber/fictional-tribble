import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowUpRight, BookOpen, Layers } from 'lucide-react';
import HeaderBanner from '../components/HeaderBanner';
import { YEARS_DATA, SEMESTERS_DATA } from '../data/bpharmCurriculum';

export default function SemestersPage() {
  const { yearId } = useParams();
  const navigate = useNavigate();

  const currentYearId = parseInt(yearId, 10) || 1;
  const currentYear = YEARS_DATA.find((y) => y.id === currentYearId) || YEARS_DATA[0];

  // Filter semesters for this year
  const semesters = SEMESTERS_DATA.filter((s) => s.yearId === currentYear.id);

  return (
    <div className="min-h-screen bg-[#F4F4F6] text-[#18181B] pb-24 font-sans select-none selection:bg-[#D4F943]">
      {/* PharmaX Signature Dark Banner */}
      <HeaderBanner
        category="PCI Standard Syllabus"
        title="Semesters"
        subtitlePills={[
          { text: currentYear.name, variant: 'lime' },
          { text: `${semesters.length} Semesters Active`, variant: 'default' }
        ]}
        backTo="/bpharm"
      />

      {/* Main Content Area */}
      <div className="max-w-[440px] mx-auto px-4 sm:px-5 pt-5">
        <div className="flex items-center justify-between mb-4 px-1">
          <p className="text-xs sm:text-sm text-zinc-500 font-bold">
            Select a semester to explore subjects & notes
          </p>
          <span className="text-[11px] font-black text-black bg-[#D4F943] px-2 py-0.5 rounded-full">
            {currentYear.code}
          </span>
        </div>

        {/* Semesters Cards List in PharmaX Style */}
        <div className="space-y-4">
          {semesters.map((sem) => (
            <div
              key={sem.id}
              onClick={() => navigate(`/semester/${sem.id}`)}
              className="group bg-white rounded-[2rem] p-5 shadow-sm border border-zinc-100/90 hover:shadow-md hover:border-zinc-300 active:scale-[0.99] transition-all cursor-pointer flex items-center justify-between gap-3"
            >
              <div className="flex items-center gap-4 flex-1 min-w-0">
                {/* Book Icon Badge on Left */}
                <div className="w-14 h-14 rounded-2xl bg-[#D4F943] flex flex-col items-center justify-center flex-shrink-0 group-hover:scale-105 transition-transform shadow-xs">
                  <BookOpen className="w-6 h-6 text-black" />
                  <span className="text-[10px] font-black text-black mt-0.5 tracking-tight uppercase">
                    {sem.label}
                  </span>
                </div>

                {/* Semester Details */}
                <div className="flex-1 min-w-0">
                  <h2 className="text-lg font-black text-zinc-950 tracking-tight leading-tight group-hover:text-black transition-colors">
                    {sem.name}
                  </h2>

                  <span className="text-xs font-bold text-zinc-500 block mt-0.5">
                    {sem.subtitle}
                  </span>

                  <p className="text-[11px] text-zinc-400 font-medium line-clamp-1 mt-1 leading-snug">
                    {sem.summary}
                  </p>

                  <div className="mt-2.5 flex items-center gap-2">
                    <span className="inline-flex items-center text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-[#18181B] text-white">
                      {sem.subjectsCount} Subjects
                    </span>
                    <span className="inline-flex items-center text-[10px] font-bold px-2 py-0.5 rounded-full bg-zinc-100 text-zinc-600">
                      5 Units Each
                    </span>
                  </div>
                </div>
              </div>

              {/* PharmaX Signature Circular Arrow Button */}
              <div className="w-10 h-10 rounded-full bg-zinc-100 group-hover:bg-[#18181B] text-zinc-700 group-hover:text-white flex items-center justify-center flex-shrink-0 transition-all shadow-xs">
                <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
              </div>
            </div>
          ))}
        </div>

        {/* Back Link */}
        <div className="mt-8 text-center">
          <button
            onClick={() => navigate('/')}
            className="text-xs font-bold text-zinc-400 hover:text-zinc-700 transition-colors inline-flex items-center gap-1.5"
          >
            ← Back to All Academic Years
          </button>
        </div>
      </div>
    </div>
  );
}
