import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowUpRight, 
  BookOpen, 
  Heart, 
  FlaskConical, 
  Pill, 
  Leaf, 
  Microscope, 
  ShieldCheck, 
  BarChart3, 
  CheckCircle,
  Star
} from 'lucide-react';
import HeaderBanner from '../components/HeaderBanner';
import { YEARS_DATA, SEMESTERS_DATA, SUBJECTS_DATA } from '../data/bpharmCurriculum';

export default function SubjectsPage() {
  const { semId } = useParams();
  const navigate = useNavigate();

  const currentSemId = parseInt(semId, 10) || 1;
  const currentSemester = SEMESTERS_DATA.find((s) => s.id === currentSemId) || SEMESTERS_DATA[0];
  const currentYear = YEARS_DATA.find((y) => y.id === currentSemester.yearId) || YEARS_DATA[0];

  // Subjects for this semester
  const subjects = SUBJECTS_DATA.filter((s) => s.semId === currentSemester.id);

  const getSubjectIcon = (iconType) => {
    switch (iconType) {
      case 'heart':
        return <Heart className="w-5 h-5 text-rose-500 fill-rose-500/20" />;
      case 'flask':
        return <FlaskConical className="w-5 h-5 text-indigo-500" />;
      case 'pill':
        return <Pill className="w-5 h-5 text-zinc-900" />;
      case 'leaf':
        return <Leaf className="w-5 h-5 text-emerald-600" />;
      case 'microscope':
        return <Microscope className="w-5 h-5 text-cyan-600" />;
      case 'shield':
        return <ShieldCheck className="w-5 h-5 text-amber-600" />;
      case 'chart':
        return <BarChart3 className="w-5 h-5 text-purple-600" />;
      default:
        return <BookOpen className="w-5 h-5 text-zinc-900" />;
    }
  };

  return (
    <div className="min-h-screen bg-[#F4F4F6] text-[#18181B] pb-24 font-sans select-none selection:bg-[#D4F943]">
      {/* PharmaX Signature Dark Banner */}
      <HeaderBanner
        category={`${currentYear.name} • ${currentSemester.label}`}
        title={`${currentSemester.name} Subjects`}
        subtitlePills={[
          { text: `${subjects.length} PCI Subjects`, variant: 'lime' },
          { text: '5 Units Each', variant: 'default' }
        ]}
        backTo={`/year/${currentYear.id}`}
      />

      {/* Main Content Area */}
      <div className="max-w-[440px] mx-auto px-4 sm:px-5 pt-5">
        <div className="flex items-center justify-between mb-4 px-1">
          <p className="text-xs sm:text-sm text-zinc-500 font-bold">
            Select a subject to view units & notes
          </p>
          <span className="text-[11px] font-black text-black bg-[#D4F943] px-2 py-0.5 rounded-full">
            {currentSemester.label}
          </span>
        </div>

        {/* Subjects List in PharmaX Style */}
        <div className="space-y-3.5">
          {subjects.map((sub) => (
            <div
              key={sub.id}
              onClick={() => navigate(`/subject/${sub.id}`)}
              className="group bg-white rounded-[2rem] p-5 shadow-sm border border-zinc-100/90 hover:shadow-md hover:border-zinc-300 active:scale-[0.99] transition-all cursor-pointer flex items-center justify-between gap-3"
            >
              <div className="flex items-start gap-3.5 flex-1 min-w-0">
                {/* Subject Icon & Code Badge */}
                <div className="w-13 h-13 rounded-2xl bg-[#D4F943] flex flex-col items-center justify-center flex-shrink-0 group-hover:scale-105 transition-transform shadow-xs">
                  {getSubjectIcon(sub.iconType)}
                  <span className="text-[10px] font-black text-black uppercase tracking-wider mt-0.5">
                    {sub.code}
                  </span>
                </div>

                {/* Subject Details */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm sm:text-base font-black text-zinc-950 tracking-tight leading-snug group-hover:text-black transition-colors">
                    {sub.name}
                  </h3>

                  {/* Stats Badges Row */}
                  <div className="flex items-center gap-1.5 mt-2 flex-wrap">
                    <span className="inline-flex items-center gap-1 text-[10px] font-extrabold px-2 py-0.5 rounded-md bg-[#18181B] text-white">
                      <BookOpen className="w-3 h-3 text-[#D4F943]" />
                      {sub.chaptersCount} Units
                    </span>
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md bg-zinc-100 text-zinc-700">
                      <CheckCircle className="w-3 h-3 text-emerald-600" />
                      {sub.topicsCount} Topics
                    </span>
                    <span className="inline-flex items-center gap-1 text-[10px] font-bold px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200/50">
                      <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                      {sub.credits} Cr
                    </span>
                  </div>
                </div>
              </div>

              {/* Action Arrow */}
              <div className="w-9 h-9 rounded-full bg-zinc-100 group-hover:bg-[#18181B] text-zinc-700 group-hover:text-white flex items-center justify-center flex-shrink-0 transition-all shadow-xs">
                <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
              </div>
            </div>
          ))}
        </div>

        {/* Back Link */}
        <div className="mt-8 text-center">
          <button
            onClick={() => navigate(`/year/${currentYear.id}`)}
            className="text-xs font-bold text-zinc-400 hover:text-zinc-700 transition-colors inline-flex items-center gap-1.5"
          >
            ← Back to {currentYear.name} Semesters
          </button>
        </div>
      </div>
    </div>
  );
}
