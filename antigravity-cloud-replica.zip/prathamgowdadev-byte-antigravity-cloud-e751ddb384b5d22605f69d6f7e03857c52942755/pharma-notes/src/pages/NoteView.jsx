import React, { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { 
  ArrowLeft, 
  PenTool, 
  Highlighter, 
  Check, 
  Volume2, 
  Bookmark, 
  Share2, 
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  Sparkles
} from 'lucide-react'
import supabase from '../lib/supabaseClient'
import { notes as fallbackNotes } from '../data/notes'
import NoteRenderer from '../components/NoteRenderer'
import TextFormatDrawer from '../components/TextFormatDrawer'

export default function NoteView() {
  const { id } = useParams()
  const [note, setNote] = useState(null)
  const [notesList, setNotesList] = useState(fallbackNotes)
  const [loading, setLoading] = useState(false)
  const [bookmarked, setBookmarked] = useState(false)
  const [isSpeaking, setIsSpeaking] = useState(false)
  
  // Text format drawer states (Screen 3 in reference image)
  const [drawerOpen, setDrawerOpen] = useState(false)
  const [activeColor, setActiveColor] = useState('#D4F943') // Default lime green matching reference!
  const [activeFont, setActiveFont] = useState('font-nunito')
  const [fontSize, setFontSize] = useState(16)
  const [isBold, setIsBold] = useState(false)
  const [isItalic, setIsItalic] = useState(false)
  const [textAlign, setTextAlign] = useState('left')

  // Checklist items
  const [checklist, setChecklist] = useState([
    { text: "Direct Agonists: Pilocarpine & Bethanechol", completed: true },
    { text: "Indirect Agonists: Neostigmine & Donepezil", completed: true },
    { text: "Memorize SLUDGE toxicity signs & Atropine antidote", completed: false }
  ])

  const toggleChecklistItem = (index) => {
    setChecklist(prev => prev.map((item, i) => i === index ? { ...item, completed: !item.completed } : item))
  }

  // Load notes
  useEffect(() => {
    let isMounted = true

    async function loadData() {
      try {
        setLoading(true)
        const { data, error } = await supabase
          .from('notes')
          .select('*')
          .order('id')

        if (!error && isMounted && data && data.length > 0) {
          setNotesList(data)
          const found = data.find((n) => String(n.id) === String(id))
          if (found) setNote(found)
          else {
            const fallbackFound = fallbackNotes.find((n) => String(n.id) === String(id))
            setNote(fallbackFound || fallbackNotes[0])
          }
        } else if (isMounted) {
          setNotesList(fallbackNotes)
          const found = fallbackNotes.find((n) => String(n.id) === String(id))
          setNote(found || fallbackNotes[0])
        }
      } catch (err) {
        console.warn('Using local fallback note:', err)
        if (isMounted) {
          setNotesList(fallbackNotes)
          const found = fallbackNotes.find((n) => String(n.id) === String(id))
          setNote(found || fallbackNotes[0])
        }
      } finally {
        if (isMounted) setLoading(false)
      }
    }

    loadData()

    return () => {
      isMounted = false
    }
  }, [id])

  // Stop speech if navigating away
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel()
      }
    }
  }, [id])

  const handleSpeak = () => {
    if (!('speechSynthesis' in window)) return

    if (isSpeaking) {
      window.speechSynthesis.cancel()
      setIsSpeaking(false)
      return
    }

    const textToSpeak = `${note?.title || ''}. ${note?.subtitle || ''}. Key points: ${checklist.map(c => c.text).join('. ')}`
    const utterance = new SpeechSynthesisUtterance(textToSpeak)
    utterance.onend = () => setIsSpeaking(false)
    utterance.onerror = () => setIsSpeaking(false)
    setIsSpeaking(true)
    window.speechSynthesis.speak(utterance)
  }

  if (loading && !note) {
    return (
      <div className="min-h-screen bg-[#F4F4F6] flex items-center justify-center p-6 text-zinc-500 font-medium">
        Loading note...
      </div>
    )
  }

  const currentNote = note || fallbackNotes[0]
  const idx = notesList.findIndex((n) => String(n.id) === String(id))
  const prev = idx > 0 ? notesList[idx - 1] : null
  const next = idx >= 0 && idx < notesList.length - 1 ? notesList[idx + 1] : null

  return (
    <div className={`min-h-screen bg-[#F4F4F6] text-[#18181B] pb-32 pt-2 ${activeFont} selection:bg-[#D4F943]`}>
      <div className="max-w-[440px] mx-auto px-4 sm:px-5">
        
        {/* iOS Native Status Bar Mockup */}
        <div className="flex items-center justify-between pt-2 pb-3 px-1 text-xs font-semibold text-zinc-900 tracking-tight select-none">
          <span>9:41</span>
          <div className="w-24 h-4 bg-black rounded-full flex items-center justify-center">
            <span className="w-2.5 h-2.5 rounded-full bg-zinc-800" />
          </div>
          <div className="flex items-center gap-1.5 text-zinc-800">
            <span className="text-[10px] font-bold">5G</span>
            <div className="w-5 h-2.5 border border-zinc-800 rounded-sm p-0.5 flex items-center">
              <div className="w-full h-full bg-zinc-800 rounded-2xs" />
            </div>
          </div>
        </div>

        {/* Top Bar (Screen 3 in Reference Image) */}
        <header className="flex items-center justify-between py-2 mb-4">
          <Link
            to="/"
            className="w-10 h-10 rounded-full bg-white border border-zinc-200/80 shadow-sm flex items-center justify-center text-zinc-700 hover:text-black hover:border-zinc-300 transition-all active:scale-95"
            aria-label="Back to home"
          >
            <ChevronLeft className="w-6 h-6 stroke-[2.5]" />
          </Link>

          <div className="text-center px-2">
            <span className="text-[11px] font-bold uppercase tracking-wider text-zinc-400 block">
              {currentNote.unit || 'Unit 2: ANS Drugs'}
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleSpeak}
              className={`w-10 h-10 rounded-full border shadow-sm flex items-center justify-center transition-all active:scale-95 ${
                isSpeaking 
                  ? 'bg-[#18181B] text-[#D4F943] border-[#18181B]' 
                  : 'bg-white border-zinc-200/80 text-zinc-700 hover:text-black'
              }`}
              title="Read note aloud"
            >
              <Volume2 className="w-4 h-4" />
            </button>

            {/* Pen / Format Icon (Toggles Screen 3 "Text format" drawer) */}
            <button
              onClick={() => setDrawerOpen(!drawerOpen)}
              className={`w-10 h-10 rounded-full border shadow-sm flex items-center justify-center transition-all active:scale-95 ${
                drawerOpen 
                  ? 'bg-[#18181B] text-[#D4F943] border-[#18181B]' 
                  : 'bg-white border-zinc-200/80 text-zinc-700 hover:text-black'
              }`}
              title="Text format options"
            >
              <PenTool className="w-4 h-4" />
            </button>
          </div>
        </header>

        {/* Note Card Paper Container */}
        <main className="bg-white rounded-[2.5rem] p-6 sm:p-7 shadow-sm border border-zinc-100/90 relative animate-fade-in">
          
          {/* Note Title & Date (Screen 3: "Work / Tue, 22 Oct 24") */}
          <div className="mb-5 pb-3 border-b border-zinc-100">
            <h1 className="text-3xl sm:text-[34px] font-extrabold tracking-tight text-zinc-950 leading-tight">
              {currentNote.title}
            </h1>
            <p className="text-xs font-semibold text-zinc-400 mt-1 flex items-center gap-1.5">
              <span>{currentNote.date || 'Tue, 22 Oct 24'}</span>
              <span>•</span>
              <span>{currentNote.readTime || currentNote.read_time || '3 min'} read</span>
            </p>
          </div>

          {/* FLOATING TEXT SELECTION TOOLTIP (Exact Match to Screen 3 in Reference!) */}
          <div className="relative my-4">
            {/* Dark Bubble Context Menu with Pointer */}
            <div className="flex flex-col items-center mb-1">
              <div className="bg-[#18181B] text-white text-xs font-semibold px-3 py-1.5 rounded-xl shadow-xl flex items-center gap-3">
                <span className="cursor-pointer hover:text-[#D4F943] transition-colors">Select</span>
                <span className="w-px h-3 bg-zinc-700" />
                <span className="cursor-pointer hover:text-[#D4F943] transition-colors">Select all</span>
                <span className="text-zinc-500">›</span>
              </div>
              {/* Pointer triangle */}
              <div className="w-0 h-0 border-l-[6px] border-l-transparent border-r-[6px] border-r-transparent border-t-[6px] border-t-[#18181B]" />
            </div>

            {/* Lime Green Highlighted Key Phrase (Matching Screen 3) */}
            <p className="text-base text-zinc-800 leading-relaxed font-medium">
              <span 
                className="px-1.5 py-0.5 rounded-md font-bold text-black shadow-xs inline-block"
                style={{ backgroundColor: activeColor }}
              >
                {currentNote.subtitle || "Drugs that mimic Acetylcholine (ACh) action"}
              </span>{' '}
              and answer important clinical questions. This will help avoid diagnostic errors and delay in acute care.
            </p>
          </div>

          {/* CHECKLIST ITEMS (Direct Match to Screen 3 Checkboxes) */}
          <div className="space-y-2.5 my-5 bg-zinc-50/80 rounded-2xl p-4 border border-zinc-100">
            <span className="text-[11px] font-extrabold uppercase tracking-wider text-zinc-400 block mb-1">
              High-Yield Checklist
            </span>
            {checklist.map((item, i) => (
              <div 
                key={i}
                onClick={() => toggleChecklistItem(i)}
                className="flex items-start gap-2.5 cursor-pointer select-none group"
              >
                <div 
                  className={`w-4 h-4 rounded-md mt-0.5 flex items-center justify-center transition-colors flex-shrink-0 ${
                    item.completed ? 'bg-[#3B82F6] text-white' : 'border border-zinc-400 bg-white'
                  }`}
                >
                  {item.completed && <Check className="w-3 h-3 stroke-[3]" />}
                </div>
                <span className={`text-xs font-semibold leading-snug transition-colors ${
                  item.completed ? 'text-zinc-900' : 'text-zinc-500'
                }`}>
                  {item.text}
                </span>
              </div>
            ))}
          </div>

          {/* Render Full Structured Blocks (Classification Tree, SLUDGE Table, Synapse Diagram) */}
          <NoteRenderer 
            blocks={currentNote.content} 
            activeColor={activeColor}
            activeFont={activeFont}
            fontSize={fontSize}
            textAlign={textAlign}
          />

        </main>

        {/* Previous & Next Floating Navigation */}
        <div className="flex items-center justify-between gap-3 mt-6">
          {prev ? (
            <Link
              to={`/note/${prev.id}`}
              className="flex-1 bg-white border border-zinc-200/80 rounded-2xl px-4 py-3 text-xs font-bold text-zinc-800 shadow-sm flex items-center justify-center gap-2 hover:border-zinc-300 active:scale-95 transition-all"
            >
              <ChevronLeft className="w-4 h-4" />
              <span className="truncate">Prev: {prev.title}</span>
            </Link>
          ) : (
            <div className="flex-1" />
          )}

          {next ? (
            <Link
              to={`/note/${next.id}`}
              className="flex-1 bg-[#18181B] text-white rounded-2xl px-4 py-3 text-xs font-bold shadow-md flex items-center justify-center gap-2 hover:bg-black active:scale-95 transition-all"
            >
              <span className="truncate">Next: {next.title}</span>
              <ChevronRight className="w-4 h-4 text-[#D4F943]" />
            </Link>
          ) : (
            <div className="flex-1" />
          )}
        </div>

      </div>

      {/* TEXT FORMAT DRAWER (Screen 3 in Reference Image) */}
      <TextFormatDrawer
        isOpen={drawerOpen}
        onClose={() => setDrawerOpen(false)}
        activeColor={activeColor}
        setActiveColor={setActiveColor}
        activeFont={activeFont}
        setActiveFont={setActiveFont}
        fontSize={fontSize}
        setFontSize={setFontSize}
        isBold={isBold}
        setIsBold={setIsBold}
        isItalic={isItalic}
        setIsItalic={setIsItalic}
        textAlign={textAlign}
        setTextAlign={setTextAlign}
      />
    </div>
  )
}
