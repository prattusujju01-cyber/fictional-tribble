import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Search, 
  ArrowRight, 
  Bookmark, 
  Clock, 
  X, 
  ChevronRight,
  Download,
  Play,
  FileText,
  BookOpen,
  ExternalLink
} from 'lucide-react';
import { SUBJECTS_DATA, SEMESTERS_DATA } from '../data/bpharmCurriculum';
import PdfViewerModal from '../components/PdfViewerModal';

export default function YearsPage() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [activeSlide, setActiveSlide] = useState(0);
  const [bookmarkedIds, setBookmarkedIds] = useState({});
  const [selectedResource, setSelectedResource] = useState(null);
  const [pdfModalConfig, setPdfModalConfig] = useState({
    isOpen: false,
    subject: null,
    unit: null,
    semester: null
  });

  const toggleBookmark = (e, id) => {
    e.stopPropagation();
    setBookmarkedIds((prev) => ({ ...prev, [id]: !prev[id] }));
  };

  // Popular Subjects matching the exact 2x4 grid in reference design
  const popularSubjects = [
    {
      id: 'mathematics',
      lines: ['Mathematics'],
      route: '/subject/bp106rmt',
      icon: (
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B2B65" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
          <rect x="4" y="2" width="16" height="20" rx="2.5" />
          <rect x="7" y="5" width="10" height="4" rx="1" />
          <circle cx="8" cy="13" r="0.8" fill="#1B2B65" />
          <circle cx="12" cy="13" r="0.8" fill="#1B2B65" />
          <circle cx="16" cy="13" r="0.8" fill="#1B2B65" />
          <circle cx="8" cy="17" r="0.8" fill="#1B2B65" />
          <circle cx="12" cy="17" r="0.8" fill="#1B2B65" />
          <circle cx="16" cy="17" r="0.8" fill="#1B2B65" />
        </svg>
      )
    },
    {
      id: 'computer-science',
      lines: ['Computer', 'Science'],
      route: '/semester/2',
      icon: (
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B2B65" strokeWidth="1.85" strokeLinecap="round" strokeLinejoin="round">
          <polyline points="7 8 3 12 7 16" />
          <polyline points="17 8 21 12 17 16" />
          <line x1="14" y1="4" x2="10" y2="20" />
        </svg>
      )
    },
    {
      id: 'business-economics',
      lines: ['Business &', 'Economics'],
      route: '/semester/8',
      icon: (
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B2B65" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4 20v-5h3v5" />
          <path d="M10.5 20v-8h3v8" />
          <path d="M17 20v-11h3v11" />
          <line x1="2" y1="20" x2="22" y2="20" />
          <path d="M4 11l6-5 4 3 6-6" />
          <polyline points="16 3 20 3 20 7" />
        </svg>
      )
    },
    {
      id: 'health-sciences',
      lines: ['Health', 'Sciences'],
      route: '/bpharm',
      icon: (
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B2B65" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
          <path d="M4.8 2.3A.3.3 0 1 0 5 2H4a2 2 0 0 0-2 2v5a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6V4a2 2 0 0 0-2-2h-1a.2.2 0 1 0 .3.3" />
          <path d="M8 15v1a6 6 0 0 0 6 6v0a6 6 0 0 0 6-6v-4" />
          <circle cx="20" cy="10" r="2" />
        </svg>
      )
    },
    {
      id: 'engineering',
      lines: ['Engineering'],
      route: '/semester/3',
      icon: (
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B2B65" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="12" cy="12" r="3.2" />
          <path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1 0 2.83 2 2 0 0 1-2.83 0l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-2 2 2 2 0 0 1-2-2v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83 0 2 2 0 0 1 0-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1-2-2 2 2 0 0 1 2-2h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 0-2.83 2 2 0 0 1 2.83 0l.06.06a1.65 1.65 0 0 0 1.82.33H9a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 2-2 2 2 0 0 1 2 2v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 0 2 2 0 0 1 0 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82V9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 2 2 2 2 0 0 1-2 2h-.09a1.65 1.65 0 0 0-1.51 1z" />
        </svg>
      )
    },
    {
      id: 'languages',
      lines: ['Languages'],
      route: '/subject/bp105t',
      icon: (
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B2B65" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
          <path d="M2 4h6a4 4 0 0 1 4 4v12a3 3 0 0 0-3-3H2z" />
          <path d="M22 4h-6a4 4 0 0 0-4 4v12a3 3 0 0 1 3-3h7z" />
          <path d="M6 20c2 0 4 .5 6 2 2-1.5 4-2 6-2" />
        </svg>
      )
    },
    {
      id: 'social-sciences',
      lines: ['Social', 'Sciences'],
      route: '/semester/8',
      icon: (
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B2B65" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round">
          <circle cx="9" cy="7" r="3" />
          <circle cx="16" cy="7" r="3" />
          <path d="M3 19v-1.5A4.5 4.5 0 0 1 7.5 13h3A4.5 4.5 0 0 1 15 17.5V19" />
          <path d="M15 13.2a4.5 4.5 0 0 1 6 4.3V19" />
        </svg>
      )
    },
    {
      id: 'more-subjects',
      lines: ['More', 'Subjects'],
      route: '/bpharm',
      icon: (
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="#1B2B65" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round">
          <rect x="3.5" y="3.5" width="7" height="7" rx="1.5" />
          <rect x="13.5" y="3.5" width="7" height="7" rx="1.5" />
          <rect x="3.5" y="13.5" width="7" height="7" rx="1.5" />
          <rect x="13.5" y="13.5" width="7" height="7" rx="1.5" />
        </svg>
      )
    }
  ];

  // Recommended Cards matching the exact reference screenshot
  const recommendedCards = [
    {
      id: 'rec-python',
      sourceType: 'youtube',
      sourceLabel: 'From YouTube',
      title: 'Complete Python for Beginners',
      category: 'Programming',
      metaRight: '8h 24m',
      rating: '4.8',
      reviews: '(12.6K)',
      duration: '8h 24m',
      tags: [
        { type: 'video', label: 'Video' },
        { type: 'notes', label: 'Notes' }
      ],
      price: 'Free',
      image: 'https://images.unsplash.com/photo-1517694712202-14dd9538aa97?auto=format&fit=crop&w=600&q=80',
      fallbackImage: 'https://images.unsplash.com/photo-1498050108023-c5249f4df085?auto=format&fit=crop&w=600&q=80',
      subjectId: 'bp105t',
      unitNumber: 1,
      description: 'Full beginner-to-advanced Python programming lecture series with downloadable handwritten study notes, syntax cheatsheets, and practice exercises.'
    },
    {
      id: 'rec-calculus',
      sourceType: 'wikipedia',
      sourceLabel: 'From Wikipedia',
      title: 'Calculus I - Full Notes',
      category: 'Mathematics',
      metaRight: 'PDF',
      rating: '4.7',
      reviews: '(8.4K)',
      duration: '2h 15m',
      tags: [
        { type: 'pdf', label: 'PDF' },
        { type: 'notes', label: 'Notes' }
      ],
      price: 'Free',
      image: 'https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&w=600&q=80',
      fallbackImage: 'https://images.unsplash.com/photo-1509228468518-180dd4864904?auto=format&fit=crop&w=600&q=80',
      subjectId: 'bp106rmt',
      unitNumber: 1,
      isDirectPdf: true,
      description: 'Comprehensive handwritten differential and integral calculus notes, limits, derivatives, and analytical geometry formulas.'
    },
    {
      id: 'rec-python-pro',
      sourceType: 'youtube',
      sourceLabel: 'From YouTube',
      title: 'Python Projects & Algorithms',
      category: 'Programming',
      metaRight: '6h 15m',
      rating: '4.6',
      reviews: '(6.2K)',
      duration: '6h 15m',
      tags: [
        { type: 'video', label: 'Video' },
        { type: 'notes', label: 'Notes' }
      ],
      price: 'Free',
      image: 'https://images.unsplash.com/photo-1526379095098-d400fd0bf935?auto=format&fit=crop&w=600&q=80',
      fallbackImage: 'https://images.unsplash.com/photo-1555066931-4365d14bab8c?auto=format&fit=crop&w=600&q=80',
      subjectId: 'bp102t',
      unitNumber: 1,
      description: 'Hands-on data structures, algorithmic problem solving, and practical automation scripts with annotated code notes.'
    },
    {
      id: 'rec-hap',
      sourceType: 'wikipedia',
      sourceLabel: 'From Wikipedia',
      title: 'Human Anatomy & Physiology I',
      category: 'Health Sciences',
      metaRight: 'PDF',
      rating: '4.9',
      reviews: '(15.2K)',
      duration: '3h 40m',
      tags: [
        { type: 'pdf', label: 'PDF' },
        { type: 'notes', label: 'Notes' }
      ],
      price: 'Free',
      image: 'https://images.unsplash.com/photo-1532187863486-abf9dbad1b69?auto=format&fit=crop&w=600&q=80',
      fallbackImage: 'https://images.unsplash.com/photo-1576091160550-2173dba999ef?auto=format&fit=crop&w=600&q=80',
      subjectId: 'bp101t',
      unitNumber: 1,
      isDirectPdf: true,
      description: 'High-yield PCI B.Pharm Semester 1 handwritten notes covering homeostasis, cellular transport, tissue organization, and skeletal system.'
    }
  ];

  // Open PDF Download modal for a subject/unit
  const openPdfForSubject = (subjectId, unitNum = 1) => {
    const sub = SUBJECTS_DATA.find((s) => s.id === subjectId) || SUBJECTS_DATA[0];
    const sem = SEMESTERS_DATA.find((s) => s.id === sub.semId);
    const unit = sub.units?.find((u) => u.unitNumber === unitNum) || sub.units?.[0];
    setPdfModalConfig({
      isOpen: true,
      subject: sub,
      unit,
      semester: sem
    });
  };

  const handleCardAction = (card) => {
    if (card.isDirectPdf) {
      openPdfForSubject(card.subjectId, card.unitNumber);
    } else {
      setSelectedResource(card);
    }
  };

  // Search filtering across subjects & recommended items
  const searchQuery = searchTerm.trim().toLowerCase();
  const matchingSubjects = searchQuery === ''
    ? []
    : SUBJECTS_DATA.filter((sub) =>
        sub.name.toLowerCase().includes(searchQuery) ||
        sub.code.toLowerCase().includes(searchQuery) ||
        sub.units?.some((u) =>
          u.title.toLowerCase().includes(searchQuery) ||
          u.topics?.some((t) => t.toLowerCase().includes(searchQuery))
        )
      );

  const matchingRecommended = searchQuery === ''
    ? []
    : recommendedCards.filter((c) =>
        c.title.toLowerCase().includes(searchQuery) ||
        c.category.toLowerCase().includes(searchQuery) ||
        c.sourceLabel.toLowerCase().includes(searchQuery)
      );

  return (
    <div className="min-h-screen bg-white text-[#0F172A] pb-12 pt-3 font-sans antialiased selection:bg-[#1B2B65] selection:text-white">
      <div className="max-w-[440px] mx-auto px-4">
        
        {/* ═══════════════════════════════════════════════════════════
            1. TOP SEARCH BAR
           ═══════════════════════════════════════════════════════════ */}
        <div className="relative mb-4">
          <div className="bg-[#F0F3F8] rounded-full px-4 py-3 flex items-center gap-3 border border-transparent focus-within:border-[#CBD5E1] focus-within:bg-white focus-within:shadow-sm transition-all">
            <Search className="w-[19px] h-[19px] text-[#1B2B65] stroke-[2] flex-shrink-0" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder="Search for study materials, topics or sources"
              className="w-full bg-transparent text-[13.5px] text-[#0F172A] placeholder:text-[#7A869A] font-normal focus:outline-none"
            />
            {searchTerm ? (
              <button
                onClick={() => setSearchTerm('')}
                className="text-[#64748B] hover:text-[#0F172A] p-0.5 flex-shrink-0"
                aria-label="Clear search"
              >
                <X className="w-4 h-4" />
              </button>
            ) : (
              <button
                onClick={() => navigate('/bpharm')}
                className="text-[#1B2B65] hover:opacity-80 transition-opacity flex-shrink-0"
                aria-label="Filter study materials"
                title="Browse All Semesters & Filters"
              >
                {/* Exact Filter Sliders SVG matching screenshot */}
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#1B2B65" strokeWidth="1.9" strokeLinecap="round" strokeLinejoin="round">
                  <line x1="4" y1="6" x2="14" y2="6" />
                  <line x1="18" y1="6" x2="20" y2="6" />
                  <circle cx="16" cy="6" r="2" fill="#F0F3F8" />
                  <line x1="4" y1="12" x2="6" y2="12" />
                  <line x1="10" y1="12" x2="20" y2="12" />
                  <circle cx="8" cy="12" r="2" fill="#F0F3F8" />
                  <line x1="4" y1="18" x2="14" y2="18" />
                  <line x1="18" y1="18" x2="20" y2="18" />
                  <circle cx="16" cy="18" r="2" fill="#F0F3F8" />
                </svg>
              </button>
            )}
          </div>

          {/* Live Search Results Dropdown */}
          {searchQuery !== '' && (
            <div className="absolute left-0 right-0 top-full mt-2 bg-white rounded-2xl p-2.5 border border-[#E2E8F0] shadow-xl z-40 max-h-72 overflow-y-auto space-y-1.5">
              {matchingRecommended.length === 0 && matchingSubjects.length === 0 ? (
                <div className="py-5 text-center text-xs text-[#64748B]">
                  No study materials found for "{searchTerm}"
                </div>
              ) : (
                <>
                  {matchingRecommended.map((item) => (
                    <div
                      key={item.id}
                      onClick={() => {
                        setSearchTerm('');
                        handleCardAction(item);
                      }}
                      className="p-2.5 rounded-xl hover:bg-[#F8FAFC] flex items-center justify-between cursor-pointer transition-colors"
                    >
                      <div className="min-w-0 pr-2">
                        <p className="text-xs font-bold text-[#0F172A] truncate">{item.title}</p>
                        <p className="text-[10.5px] text-[#64748B]">{item.category} • {item.sourceLabel}</p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-[#94A3B8] flex-shrink-0" />
                    </div>
                  ))}
                  {matchingSubjects.map((sub) => (
                    <div
                      key={sub.id}
                      onClick={() => {
                        setSearchTerm('');
                        navigate(`/subject/${sub.id}`);
                      }}
                      className="p-2.5 rounded-xl hover:bg-[#F8FAFC] flex items-center justify-between cursor-pointer transition-colors"
                    >
                      <div className="min-w-0 pr-2">
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-bold bg-[#1B2B65] text-white px-1.5 py-0.5 rounded">
                            {sub.code}
                          </span>
                          <p className="text-xs font-bold text-[#0F172A] truncate">{sub.name}</p>
                        </div>
                        <p className="text-[10.5px] text-[#64748B] mt-0.5">
                          Semester {sub.semId} • {sub.chaptersCount} Units • {sub.topicsCount} Topics
                        </p>
                      </div>
                      <ChevronRight className="w-4 h-4 text-[#94A3B8] flex-shrink-0" />
                    </div>
                  ))}
                </>
              )}
            </div>
          )}
        </div>

        {/* ═══════════════════════════════════════════════════════════
            2. HERO BANNER CARD
           ═══════════════════════════════════════════════════════════ */}
        <div 
          className="rounded-[22px] p-5 text-white relative overflow-hidden shadow-[0_12px_32px_rgba(19,33,87,0.22)]"
          style={{
            background: 'linear-gradient(135deg, #223784 0%, #15245E 48%, #0C153B 100%)'
          }}
        >
          {/* Ambient light streaks / diagonal sheen matching reference */}
          <div 
            className="absolute inset-0 pointer-events-none"
            style={{
              background: 'radial-gradient(circle at 18% 20%, rgba(68, 108, 228, 0.35) 0%, transparent 55%), radial-gradient(circle at 80% 75%, rgba(45, 78, 185, 0.28) 0%, transparent 50%)'
            }}
          />
          <svg className="absolute bottom-0 left-0 w-full h-24 pointer-events-none opacity-20" viewBox="0 0 400 100" preserveAspectRatio="none">
            <path d="M0 70 Q 120 30, 260 65 T 400 40 L 400 100 L 0 100 Z" fill="url(#waveGrad)" />
            <defs>
              <linearGradient id="waveGrad" x1="0" y1="0" x2="1" y2="0">
                <stop offset="0%" stopColor="#60A5FA" stopOpacity="0.5" />
                <stop offset="100%" stopColor="#1E3A8A" stopOpacity="0" />
              </linearGradient>
            </defs>
          </svg>

          {/* Right-Side 3D Illustration: Globe, Graduation Cap, Books Stack, Open Laptop & Background Doodles */}
          <div className="absolute right-1.5 top-2 w-[172px] h-[156px] pointer-events-none select-none z-0">
            <svg viewBox="0 0 220 200" className="w-full h-full overflow-visible">
              <defs>
                {/* Globe 3D Radial Gradient */}
                <radialGradient id="globeGrad" cx="38%" cy="32%" r="65%">
                  <stop offset="0%" stopColor="#60A5FA" />
                  <stop offset="45%" stopColor="#2563EB" />
                  <stop offset="85%" stopColor="#1E3A8A" />
                  <stop offset="100%" stopColor="#0F1E54" />
                </radialGradient>
                {/* Continent Gradient */}
                <linearGradient id="continentGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#93C5FD" stopOpacity="0.65" />
                  <stop offset="100%" stopColor="#3B82F6" stopOpacity="0.4" />
                </linearGradient>
                {/* Cap Top Gradient */}
                <linearGradient id="capTopGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#334155" />
                  <stop offset="50%" stopColor="#1E293B" />
                  <stop offset="100%" stopColor="#0F172A" />
                </linearGradient>
                {/* Cap Base Gradient */}
                <linearGradient id="capBaseGrad" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#1E293B" />
                  <stop offset="50%" stopColor="#334155" />
                  <stop offset="100%" stopColor="#0F172A" />
                </linearGradient>
                {/* Laptop Screen Gradient */}
                <linearGradient id="screenGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#1E3A8A" />
                  <stop offset="50%" stopColor="#172554" />
                  <stop offset="100%" stopColor="#0B132B" />
                </linearGradient>
                {/* Laptop Silver Body */}
                <linearGradient id="silverGrad" x1="0" y1="0" x2="1" y2="1">
                  <stop offset="0%" stopColor="#F8FAFC" />
                  <stop offset="50%" stopColor="#CBD5E1" />
                  <stop offset="100%" stopColor="#94A3B8" />
                </linearGradient>
                {/* Orange Book Cover */}
                <linearGradient id="orangeBook" x1="0" y1="0" x2="1" y2="0">
                  <stop offset="0%" stopColor="#F59E0B" />
                  <stop offset="100%" stopColor="#B45309" />
                </linearGradient>
              </defs>

              {/* Faint Background Doodles (Lightbulb, Open Book, Stars, Orbital Ring) */}
              <g stroke="#93C5FD" strokeOpacity="0.28" strokeWidth="1.2" fill="none">
                {/* Orbital Ring behind globe */}
                <ellipse cx="115" cy="95" rx="85" ry="26" transform="rotate(-18 115 95)" strokeDasharray="3 2" />
                {/* Top-left small book doodle */}
                <path d="M52 28 L64 24 L64 38 L52 42 Z" />
                <path d="M64 24 L76 28 L76 42 L64 38 Z" />
                {/* Top-right lightbulb doodle */}
                <path d="M188 32 a9 9 0 1 1 10 0 c-1.5 2 -2 4 -2 6 h-6 c0 -2 -0.5 -4 -2 -6 z" />
                <line x1="191" y1="40" x2="195" y2="40" />
                <line x1="193" y1="20" x2="193" y2="17" />
                <line x1="203" y1="25" x2="206" y2="23" />
                {/* Sparkle stars */}
                <path d="M88 14 L90 19 L95 21 L90 23 L88 28 L86 23 L81 21 L86 19 Z" strokeOpacity="0.35" />
                <circle cx="38" cy="68" r="2" />
                {/* Bottom-right open book doodle */}
                <path d="M182 175 Q192 170 202 175 L202 186 Q192 181 182 186 Z" strokeOpacity="0.22" />
              </g>

              {/* Soft Floor Shadow */}
              <ellipse cx="115" cy="162" rx="78" ry="12" fill="#060B26" fillOpacity="0.55" />

              {/* ── CENTER: 3D TERRESTRIAL GLOBE ── */}
              <g>
                {/* Golden-amber globe meridian frame on left */}
                <path d="M72 58 A 50 50 0 0 0 75 142" fill="none" stroke="#D97706" strokeWidth="3.5" strokeLinecap="round" />
                <path d="M70 56 A 52 52 0 0 0 73 144" fill="none" stroke="#FBBF24" strokeWidth="1.2" strokeLinecap="round" />
                
                {/* Globe Sphere */}
                <circle cx="112" cy="100" r="44" fill="url(#globeGrad)" />
                
                {/* Globe Continents (Stylized landmasses) */}
                <path d="M92 68 Q105 64 114 72 Q122 79 115 90 Q106 94 102 104 Q95 112 88 105 Q82 95 85 82 Z" fill="url(#continentGrad)" />
                <path d="M124 75 Q138 72 146 84 Q150 96 140 112 Q132 122 125 115 Q120 102 126 90 Z" fill="url(#continentGrad)" />
                <path d="M95 118 Q106 116 112 126 Q110 136 100 138 Q92 132 95 118 Z" fill="url(#continentGrad)" />

                {/* Globe Latitude/Longitude Grid Lines */}
                <ellipse cx="112" cy="100" rx="44" ry="18" fill="none" stroke="#93C5FD" strokeOpacity="0.22" strokeWidth="0.9" />
                <ellipse cx="112" cy="100" rx="22" ry="44" fill="none" stroke="#93C5FD" strokeOpacity="0.22" strokeWidth="0.9" />
                
                {/* Specular highlight on Globe */}
                <ellipse cx="96" cy="80" rx="16" ry="9" transform="rotate(-30 96 80)" fill="#FFFFFF" fillOpacity="0.18" />
              </g>

              {/* ── TOP: 3D GRADUATION MORTARBOARD CAP ── */}
              <g transform="translate(88, 12)">
                {/* Skullcap underneath */}
                <path d="M22 30 L22 44 C22 50, 62 50, 62 44 L62 30 Z" fill="url(#capBaseGrad)" stroke="#475569" strokeWidth="0.6" />
                {/* Diamond Mortarboard Top */}
                <polygon points="42,8 86,24 42,40 -2,24" fill="url(#capTopGrad)" stroke="#64748B" strokeWidth="0.8" />
                {/* Inner top highlight */}
                <polygon points="42,10 81,24 42,38 3,24" fill="none" stroke="#94A3B8" strokeOpacity="0.3" strokeWidth="0.6" />
                {/* Center Gold Button */}
                <ellipse cx="42" cy="24" rx="3.5" ry="2" fill="#F59E0B" />
                {/* Golden Tassel Cord & Fringe hanging right */}
                <path d="M42 24 Q60 28 70 33 L70 52" fill="none" stroke="#FBBF24" strokeWidth="2" strokeLinecap="round" />
                <polygon points="67,52 73,52 75,62 65,62" fill="#F59E0B" />
              </g>

              {/* ── BOTTOM-LEFT: STACK OF 3 HARDCOVER BOOKS ── */}
              <g transform="translate(30, 102)">
                {/* Bottom Book (Dark Navy) */}
                <path d="M4 44 L44 54 L68 42 L28 32 Z" fill="#1E3A8A" />
                <path d="M4 44 L44 54 L44 63 L4 53 Z" fill="#F1F5F9" />
                <path d="M44 54 L68 42 L68 51 L44 63 Z" fill="#172554" />
                <path d="M3 43 L44 53.5 M3 53 L44 63.5" stroke="#1E40AF" strokeWidth="1.8" strokeLinecap="round" />

                {/* Middle Book (Royal Blue) */}
                <path d="M6 31 L46 41 L68 30 L28 20 Z" fill="#2563EB" />
                <path d="M6 31 L46 41 L46 49 L6 39 Z" fill="#F8FAFC" />
                <path d="M46 41 L68 30 L68 38 L46 49 Z" fill="#1D4ED8" />
                <path d="M5 30.5 L46 40.5 M5 39.5 L46 49.5" stroke="#3B82F6" strokeWidth="1.6" strokeLinecap="round" />

                {/* Top Book (Golden Orange/Amber) */}
                <path d="M10 18 L46 27 L64 17 L28 8 Z" fill="url(#orangeBook)" />
                <path d="M10 18 L46 27 L46 35 L10 26 Z" fill="#FEF3C7" />
                <path d="M46 27 L64 17 L64 25 L46 35 Z" fill="#B45309" />
                {/* Page lines */}
                <line x1="12" y1="22" x2="44" y2="30" stroke="#D97706" strokeWidth="0.6" strokeOpacity="0.5" />
                <path d="M9 17.5 L46 26.5 M9 26 L46 35" stroke="#F59E0B" strokeWidth="1.6" strokeLinecap="round" />
              </g>

              {/* ── BOTTOM-RIGHT: 3D OPEN LAPTOP & MOUSE ── */}
              <g transform="translate(115, 88)">
                {/* Laptop Screen Lid (Tilted) */}
                <path d="M22 6 L82 18 L76 60 L16 48 Z" fill="#E2E8F0" stroke="#94A3B8" strokeWidth="1" rx="3" />
                {/* Dark Bezel & Glowing Blue Screen */}
                <path d="M24 9 L79 20 L74 56 L19 45 Z" fill="url(#screenGrad)" stroke="#334155" strokeWidth="1" />
                {/* Screen Glare Diagonal */}
                <polygon points="26,11 48,15 32,46 20,44" fill="#60A5FA" fillOpacity="0.14" />

                {/* Laptop Base / Keyboard Deck */}
                <path d="M16 48 L76 60 L54 76 L-6 62 Z" fill="url(#silverGrad)" stroke="#CBD5E1" strokeWidth="0.8" />
                {/* Laptop Front Thickness Edge */}
                <path d="M-6 62 L54 76 L54 79.5 L-6 65.5 Z" fill="#64748B" />
                <path d="M54 76 L76 60 L76 63.5 L54 79.5 Z" fill="#475569" />

                {/* Keyboard Grid (Dark Slate) */}
                <polygon points="16,52 68,62 54,71 4,60" fill="#1E293B" />
                {/* Key Matrix Lines */}
                <line x1="12" y1="55" x2="62" y2="65" stroke="#64748B" strokeWidth="0.6" />
                <line x1="8" y1="58" x2="58" y2="68" stroke="#64748B" strokeWidth="0.6" />
                {/* Trackpad */}
                <polygon points="22,65 34,68 30,72 18,69" fill="#94A3B8" />

                {/* Small Wireless Mouse on Left of Laptop */}
                <ellipse cx="-8" cy="69" rx="7.5" ry="4.5" fill="#F8FAFC" stroke="#94A3B8" strokeWidth="0.8" />
                <path d="M-15.5 69 C-15.5 72, -0.5 72, -0.5 69" fill="#CBD5E1" />
              </g>
            </svg>
          </div>

          {/* Left Column Text Content */}
          <div className="relative z-10 max-w-[62%]">
            <p className="text-[12.5px] font-normal text-white/95 tracking-wide">
              Your Goals. Our Resources.
            </p>
            <h1 className="text-[26px] sm:text-[28px] font-extrabold leading-[1.15] tracking-tight mt-1.5 text-white">
              Study smarter,
              <span className="block">
                not <span className="text-[#EAB308]">harder.</span>
              </span>
            </h1>
            <p className="text-[11.5px] leading-[1.45] text-white/85 font-normal mt-2.5">
              Access free learning materials from
              <span className="block">13+ trusted sources — all in one place.</span>
            </p>
          </div>

          {/* Trusted Sources Row */}
          <div className="relative z-10 mt-4 pt-0.5 flex items-center gap-3.5 text-[11px] font-medium text-white/95 flex-wrap">
            {/* YouTube */}
            <div className="flex items-center gap-1.5">
              <span className="w-4 h-3 rounded-[3px] bg-white flex items-center justify-center">
                <svg width="7" height="7" viewBox="0 0 10 10" fill="#15245E">
                  <polygon points="2,1 9,5 2,9" />
                </svg>
              </span>
              <span>YouTube</span>
            </div>

            {/* Wikipedia */}
            <div className="flex items-center gap-1">
              <span className="font-serif font-bold text-[13px] tracking-tighter text-white leading-none">
                W
              </span>
              <span>Wikipedia</span>
            </div>

            {/* Internet Archive */}
            <div className="flex items-center gap-1.5">
              <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <polygon points="12 2 2 7 22 7 12 2" fill="currentColor" />
                <line x1="6" y1="10" x2="6" y2="18" />
                <line x1="12" y1="10" x2="12" y2="18" />
                <line x1="18" y1="10" x2="18" y2="18" />
                <line x1="3" y1="21" x2="21" y2="21" />
              </svg>
              <span>Internet Archive</span>
            </div>

            {/* +10 more */}
            <span className="text-white/85 font-normal">+10 more</span>
          </div>

          {/* Two Action Pill Buttons */}
          <div className="relative z-10 mt-4 grid grid-cols-2 gap-3">
            <button
              onClick={() => navigate('/bpharm')}
              className="bg-[#FDFBF0] hover:bg-[#FAF5DE] text-[#142258] rounded-full py-2.5 px-3 flex items-center justify-center gap-2 font-bold text-[12.5px] shadow-sm transition-all active:scale-[0.98]"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#142258" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round">
                <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z" />
                <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z" />
              </svg>
              <span>Browse Materials</span>
            </button>

            <button
              onClick={() => setSelectedResource(recommendedCards[0])}
              className="bg-[#13225A]/50 hover:bg-[#1B2F78]/70 text-white border border-white/45 rounded-full py-2.5 px-3 flex items-center justify-center gap-2 font-semibold text-[12.5px] transition-all active:scale-[0.98]"
            >
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                <circle cx="12" cy="12" r="10" />
                <polygon points="10 8 16 12 10 16 10 8" fill="currentColor" stroke="none" />
              </svg>
              <span>Watch Tutorials</span>
            </button>
          </div>
        </div>

        {/* ═══════════════════════════════════════════════════════════
            3. CAROUSEL INDICATOR DOTS
           ═══════════════════════════════════════════════════════════ */}
        <div className="mt-3 mb-5 flex items-center justify-center gap-2">
          {[0, 1, 2].map((dotIdx) => (
            <button
              key={dotIdx}
              onClick={() => setActiveSlide(dotIdx)}
              aria-label={`Slide ${dotIdx + 1}`}
              className={`transition-all rounded-full ${
                activeSlide === dotIdx
                  ? 'w-3.5 h-2 bg-[#1B2B65]'
                  : 'w-2 h-2 bg-[#D5DCE6] hover:bg-[#94A3B8]'
              }`}
            />
          ))}
        </div>

        {/* ═══════════════════════════════════════════════════════════
            4. POPULAR SUBJECTS (2x4 GRID)
           ═══════════════════════════════════════════════════════════ */}
        <section className="mb-6">
          <div className="flex items-center justify-between mb-3.5">
            <h2 className="text-[18.5px] font-bold text-[#0F172A] tracking-tight">
              Popular Subjects
            </h2>
            <button
              onClick={() => navigate('/bpharm')}
              className="text-[12.5px] font-medium text-[#475569] hover:text-[#0F172A] flex items-center gap-1 transition-colors"
            >
              <span>See all</span>
              <ArrowRight className="w-3.5 h-3.5 stroke-[2]" />
            </button>
          </div>

          <div className="grid grid-cols-4 gap-2.5">
            {popularSubjects.map((subj) => (
              <button
                key={subj.id}
                onClick={() => navigate(subj.route)}
                className="bg-[#F2F4F8] hover:bg-[#E7ECF4] rounded-[16px] py-3.5 px-1.5 flex flex-col items-center justify-start text-center transition-all active:scale-95 min-h-[96px]"
              >
                <div className="mb-2 flex items-center justify-center h-8">
                  {subj.icon}
                </div>
                <div className="text-[11px] font-medium text-[#1E293B] leading-[1.25]">
                  {subj.lines.map((line, i) => (
                    <span key={i} className="block">{line}</span>
                  ))}
                </div>
              </button>
            ))}
          </div>
        </section>

        {/* ═══════════════════════════════════════════════════════════
            5. RECOMMENDED FOR YOU (HORIZONTAL CARDS)
           ═══════════════════════════════════════════════════════════ */}
        <section>
          <div className="flex items-center justify-between mb-3.5">
            <h2 className="text-[18.5px] font-bold text-[#0F172A] tracking-tight">
              Recommended for you
            </h2>
            <button
              onClick={() => navigate('/bpharm')}
              className="text-[12.5px] font-medium text-[#475569] hover:text-[#0F172A] flex items-center gap-1 transition-colors"
            >
              <span>View all</span>
              <ArrowRight className="w-3.5 h-3.5 stroke-[2]" />
            </button>
          </div>

          <div className="flex gap-3.5 overflow-x-auto pb-4 -mx-4 px-4 no-scrollbar">
            {recommendedCards.map((card) => {
              const isSaved = !!bookmarkedIds[card.id];
              return (
                <div
                  key={card.id}
                  onClick={() => handleCardAction(card)}
                  className="w-[215px] flex-shrink-0 bg-white rounded-[18px] border border-[#E2E8F0]/90 shadow-[0_2px_12px_rgba(15,23,42,0.05)] hover:shadow-md transition-all cursor-pointer overflow-hidden flex flex-col justify-between"
                >
                  {/* Top Image & Overlay Badges */}
                  <div className="relative h-[108px] w-full bg-slate-200 overflow-hidden">
                    <img
                      src={card.image}
                      alt={card.title}
                      onError={(e) => {
                        e.target.onerror = null;
                        e.target.src = card.fallbackImage;
                      }}
                      className="w-full h-full object-cover"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/20 via-transparent to-black/15 pointer-events-none" />

                    {/* Top-Left Source Pill */}
                    <div className="absolute top-2.5 left-2.5 bg-white rounded-full px-2.5 py-1 flex items-center gap-1.5 shadow-sm">
                      {card.sourceType === 'youtube' ? (
                        <span className="w-3.5 h-2.5 rounded-[3px] bg-[#EF4444] flex items-center justify-center">
                          <svg width="6" height="6" viewBox="0 0 10 10" fill="#FFFFFF">
                            <polygon points="2.5,1.5 8.5,5 2.5,8.5" />
                          </svg>
                        </span>
                      ) : (
                        <span className="font-serif font-bold text-[11px] text-[#0F172A] leading-none">
                          W
                        </span>
                      )}
                      <span className="text-[10px] font-semibold text-[#0F172A] leading-none">
                        {card.sourceLabel}
                      </span>
                    </div>

                    {/* Top-Right Bookmark Button */}
                    <button
                      onClick={(e) => toggleBookmark(e, card.id)}
                      aria-label="Bookmark material"
                      className="absolute top-2.5 right-2.5 text-white hover:scale-110 transition-transform drop-shadow"
                    >
                      <Bookmark
                        className="w-4 h-4 stroke-[2]"
                        fill={isSaved ? '#FFFFFF' : 'none'}
                      />
                    </button>
                  </div>

                  {/* Card Body */}
                  <div className="p-3 flex-1 flex flex-col justify-between">
                    <div>
                      <h3 className="text-[13.5px] font-bold text-[#0F172A] leading-[1.28] line-clamp-2 min-h-[34px]">
                        {card.title}
                      </h3>

                      <p className="text-[11px] text-[#64748B] mt-1 font-normal">
                        {card.category} &nbsp;•&nbsp; {card.metaRight}
                      </p>

                      {/* Rating & Duration */}
                      <div className="flex items-center gap-3 mt-1.5 text-[11px] text-[#475569]">
                        <div className="flex items-center gap-1">
                          <svg width="12" height="12" viewBox="0 0 24 24" fill="#F59E0B" stroke="#F59E0B" strokeWidth="1.5">
                            <polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2" />
                          </svg>
                          <span className="font-semibold text-[#1E293B]">{card.rating}</span>
                          <span className="text-[#64748B]">{card.reviews}</span>
                        </div>

                        <div className="flex items-center gap-1 text-[#64748B]">
                          <Clock className="w-3 h-3 stroke-[2]" />
                          <span>{card.duration}</span>
                        </div>
                      </div>

                      {/* Format Tag Pills */}
                      <div className="flex items-center gap-1.5 mt-2.5">
                        {card.tags.map((tag, tIdx) => (
                          <span
                            key={tIdx}
                            className="bg-[#F0F3F8] text-[#1E293B] text-[10.5px] font-medium px-2.5 py-1 rounded-full flex items-center gap-1"
                          >
                            {tag.type === 'video' && (
                              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#1B2B65" strokeWidth="2">
                                <circle cx="12" cy="12" r="10" />
                                <polygon points="10 8 16 12 10 16 10 8" fill="#1B2B65" stroke="none" />
                              </svg>
                            )}
                            {tag.type === 'pdf' && (
                              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#1B2B65" strokeWidth="2">
                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                                <polyline points="14 2 14 8 20 8" />
                              </svg>
                            )}
                            {tag.type === 'notes' && (
                              <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="#1B2B65" strokeWidth="2">
                                <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z" />
                                <line x1="8" y1="13" x2="16" y2="13" />
                                <line x1="8" y1="17" x2="13" y2="17" />
                              </svg>
                            )}
                            <span>{tag.label}</span>
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Footer: Free + View Button */}
                    <div className="flex items-center justify-between mt-3 pt-1">
                      <span className="text-[14px] font-bold text-[#0F172A]">
                        {card.price}
                      </span>
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCardAction(card);
                        }}
                        className="bg-[#1B2B65] hover:bg-[#111C45] text-white text-[12px] font-semibold px-5 py-1.5 rounded-full transition-all active:scale-95"
                      >
                        View
                      </button>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>

      </div>

      {/* Resource Preview Modal (for Video / Course cards) */}
      {selectedResource && (
        <div
          className="fixed inset-0 z-50 flex items-end sm:items-center justify-center bg-black/60 backdrop-blur-xs p-0 sm:p-4"
          onClick={(e) => {
            if (e.target === e.currentTarget) setSelectedResource(null);
          }}
        >
          <div className="w-full max-w-[440px] bg-white rounded-t-3xl sm:rounded-3xl overflow-hidden shadow-2xl border border-slate-200">
            <div className="relative h-44 w-full bg-slate-900">
              <img
                src={selectedResource.image}
                alt={selectedResource.title}
                onError={(e) => {
                  e.target.onerror = null;
                  e.target.src = selectedResource.fallbackImage;
                }}
                className="w-full h-full object-cover opacity-85"
              />
              <button
                onClick={() => setSelectedResource(null)}
                className="absolute top-3.5 right-3.5 w-8 h-8 rounded-full bg-black/50 text-white flex items-center justify-center hover:bg-black/70"
                aria-label="Close modal"
              >
                <X className="w-4 h-4" />
              </button>
              <div className="absolute bottom-3 left-4 bg-white rounded-full px-3 py-1 flex items-center gap-1.5 shadow-sm">
                <span className="text-xs font-bold text-[#0F172A]">{selectedResource.sourceLabel}</span>
              </div>
            </div>

            <div className="p-5">
              <h3 className="text-lg font-bold text-[#0F172A]">{selectedResource.title}</h3>
              <p className="text-xs text-[#64748B] mt-1">
                {selectedResource.category} • ★ {selectedResource.rating} {selectedResource.reviews} • {selectedResource.duration}
              </p>
              <p className="text-xs text-[#334155] leading-relaxed mt-3">
                {selectedResource.description}
              </p>

              <div className="mt-5 grid grid-cols-2 gap-3">
                <button
                  onClick={() => {
                    const subjId = selectedResource.subjectId;
                    const unitNum = selectedResource.unitNumber;
                    setSelectedResource(null);
                    openPdfForSubject(subjId, unitNum);
                  }}
                  className="py-3 px-4 rounded-full bg-[#1B2B65] hover:bg-[#111C45] text-white text-xs font-bold flex items-center justify-center gap-2 shadow-sm transition-all active:scale-95"
                >
                  <Download className="w-4 h-4" />
                  <span>Download Notes PDF</span>
                </button>
                <button
                  onClick={() => {
                    setSelectedResource(null);
                    navigate('/bpharm');
                  }}
                  className="py-3 px-4 rounded-full bg-[#F0F3F8] hover:bg-[#E2E8F0] text-[#1B2B65] text-xs font-bold flex items-center justify-center gap-2 transition-all active:scale-95"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>All Semesters</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Handwritten PDF Notes Download Modal */}
      <PdfViewerModal
        isOpen={pdfModalConfig.isOpen}
        onClose={() => setPdfModalConfig((prev) => ({ ...prev, isOpen: false }))}
        subject={pdfModalConfig.subject}
        unit={pdfModalConfig.unit}
        semester={pdfModalConfig.semester}
      />
    </div>
  );
}
