import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  ArrowUpRight, 
  ArrowLeft, 
  BookOpen, 
  Heart, 
  FlaskConical, 
  Pill, 
  Leaf, 
  Microscope, 
  ShieldCheck, 
  FileText,
  CheckCircle
} from 'lucide-react';
import HeaderBanner from '../components/HeaderBanner';
import { SUBJECTS_DATA, SEMESTERS_DATA } from '../data/bpharmCurriculum';

export default function UnitsPage() {
  const { subjectId } = useParams();
  const navigate = useNavigate();

  const subject = SUBJECTS_DATA.find((s) => s.id === subjectId) || SUBJECTS_DATA[0];
  const semester = SEMESTERS_DATA.find((s) => s.id === subject.semId);

  return (
    <div className="min-h-screen bg-[#F4F4F6] text-[#18181B] pb-24 font-sans select-none selection:bg-[#D4F943]">
      {/* PharmaX Signature Dark Banner */}
      <HeaderBanner
        category={`${subject.code} • ${semester ? semester.name : 'PCI Standard'}`}
        title={subject.name}
        subtitlePills={[
          { text: `${subject.units?.length || subject.chaptersCount} Units`, variant: 'lime' },
          { text: `${subject.topicsCount} Topics Total`, variant: 'default' }
        ]}
        backTo={`/semester/${subject.semId}`}
      />

      {/* Main Content Area */}
      <div className="max-w-[440px] mx-auto px-4 sm:px-5 pt-5">
        <div className="flex items-center justify-between mb-4 px-1">
          <p className="text-xs sm:text-sm text-zinc-500 font-bold">
            Tap a unit to explore topics & download notes
          </p>
          <span className="text-[11px] font-black text-black bg-[#D4F943] px-2 py-0.5 rounded-full">
            {subject.code}
          </span>
        </div>

        {/* Units / Chapters List in PharmaX Style */}
        <div className="space-y-3.5">
          {subject.units?.map((unit) => (
            <div
              key={unit.unitNumber}
              onClick={() => navigate(`/subject/${subject.id}/unit/${unit.unitNumber}`)}
              className="group bg-white rounded-[2rem] p-5 shadow-sm border border-zinc-100/90 hover:shadow-md hover:border-zinc-300 active:scale-[0.99] transition-all cursor-pointer flex items-center justify-between gap-3"
            >
              <div className="flex items-start gap-3.5 flex-1 min-w-0">
                {/* Number Badge in Lime Accent */}
                <div className="w-12 h-12 rounded-2xl bg-[#D4F943] flex items-center justify-center flex-shrink-0 group-hover:scale-105 transition-transform shadow-xs">
                  <span className="text-base font-black text-black">
                    {unit.unitNumber}
                  </span>
                </div>

                {/* Unit Details */}
                <div className="flex-1 min-w-0">
                  <h3 className="text-sm sm:text-base font-black text-zinc-950 tracking-tight leading-snug group-hover:text-black transition-colors">
                    {unit.title}
                  </h3>

                  <div className="mt-2 flex items-center gap-2">
                    <span className="inline-flex items-center text-[10px] font-extrabold px-2.5 py-0.5 rounded-full bg-[#18181B] text-white">
                      {unit.topicsCount || unit.topics?.length} Topics
                    </span>
                    <span className="text-[11px] font-medium text-zinc-400">
                      Notes Ready
                    </span>
                  </div>
                </div>
              </div>

              {/* PharmaX Action Arrow */}
              <div className="w-9 h-9 rounded-full bg-zinc-100 group-hover:bg-[#18181B] text-zinc-700 group-hover:text-white flex items-center justify-center flex-shrink-0 transition-all shadow-xs">
                <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
              </div>
            </div>
          ))}
        </div>

        {/* Back Link */}
        <div className="mt-8 text-center">
          <button
            onClick={() => navigate(`/semester/${subject.semId}`)}
            className="text-xs font-bold text-zinc-400 hover:text-zinc-700 transition-colors inline-flex items-center gap-1.5"
          >
            ← Back to {semester ? semester.name : 'Subjects'}
          </button>
        </div>
      </div>
    </div>
  );
}
