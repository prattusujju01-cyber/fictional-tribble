import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Search, 
  ArrowUpRight, 
  ArrowLeft,
  Check, 
  MoreHorizontal, 
  FileText, 
  Lock, 
  BookOpen, 
  Sparkles, 
  Mic, 
  Plus, 
  X, 
  ChevronRight,
  GraduationCap,
  FlaskConical,
  Pill,
  Dna
} from 'lucide-react';
import { YEARS_DATA, SUBJECTS_DATA } from '../data/bpharmCurriculum';
import QuickNoteModal from '../components/QuickNoteModal';

export default function BPharmYearsPage() {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [selectedYearTab, setSelectedYearTab] = useState('All Years');
  const [isQuickNoteOpen, setIsQuickNoteOpen] = useState(false);
  const [isQuizOpen, setIsQuizOpen] = useState(false);
  const [quizIdx, setQuizIdx] = useState(0);
  const [quizRevealed, setQuizRevealed] = useState(false);

  const [todayTasks, setTodayTasks] = useState([
    { id: 1, text: 'HAP I: Cellular Level & Tissue Organization', sem: 'Sem 1', subjectId: 'bp101t', done: true },
    { id: 2, text: 'Pharmaceutics I: Dosage Forms & Prescriptions', sem: 'Sem 1', subjectId: 'bp103t', done: false },
    { id: 3, text: 'Medicinal Chem: Autonomic & Histaminergic', sem: 'Sem 4', subjectId: 'bp401t', done: false },
  ]);

  const toggleTask = (id) => {
    setTodayTasks((prev) =>
      prev.map((t) => (t.id === id ? { ...t, done: !t.done } : t))
    );
  };

  const flashcards = [
    { q: "What is the primary antidote for acute organophosphate poisoning?", a: "Atropine (muscarinic blockade) + Pralidoxime (reactivates AChE)." },
    { q: "Which equation describes the relationship between pH, pKa, and ionization of drugs?", a: "Henderson-Hasselbalch equation: pH = pKa + log([Base]/[Acid])." },
    { q: "What does the mnemonic SLUDGE stand for in cholinergic excess?", a: "Salivation, Lacrimation, Urination, Defecation, GI upset, Emesis." },
    { q: "What is the official limit test standard for heavy metals in Indian Pharmacopoeia?", a: "Comparison of brownish color with standard lead solution using Nessler cylinders." }
  ];

  const searchResults = searchTerm.trim() === '' 
    ? [] 
    : SUBJECTS_DATA.filter((sub) => {
        const query = searchTerm.toLowerCase();
        const matchesName = sub.name.toLowerCase().includes(query);
        const matchesCode = sub.code.toLowerCase().includes(query);
        const matchesUnit = sub.units?.some((u) => 
          u.title.toLowerCase().includes(query) || 
          u.topics?.some((t) => t.toLowerCase().includes(query))
        );
        return matchesName || matchesCode || matchesUnit;
      });

  const getYearIcon = (code) => {
    switch (code) {
      case 'Y1':
        return <Dna className="w-5 h-5 text-black" />;
      case 'Y2':
        return <FlaskConical className="w-5 h-5 text-black" />;
      case 'Y3':
        return <Pill className="w-5 h-5 text-black" />;
      case 'Y4':
        return <GraduationCap className="w-5 h-5 text-black" />;
      default:
        return <BookOpen className="w-5 h-5 text-black" />;
    }
  };

  const displayedYears = selectedYearTab === 'All Years'
    ? YEARS_DATA
    : YEARS_DATA.filter((y) => y.name === selectedYearTab);

  return (
    <div className="min-h-screen bg-[#F4F4F6] text-[#18181B] pb-28 pt-3 font-sans selection:bg-[#D4F943]">
      <div className="max-w-[440px] mx-auto px-4 sm:px-5">
        
        {/* Top Header */}
        <header className="flex items-center justify-between py-2 mb-3">
          <div className="flex items-center gap-2.5">
            <button
              onClick={() => navigate('/')}
              className="w-9 h-9 rounded-full bg-white border border-zinc-200/80 shadow-xs flex items-center justify-center text-zinc-700 hover:text-black transition-all active:scale-95"
              aria-label="Back to Home"
            >
              <ArrowLeft className="w-4 h-4" />
            </button>
            <h1 className="text-2xl font-extrabold tracking-tight text-zinc-950 font-sans">
              Pharma<span className="text-black bg-[#D4F943] px-2 py-0.5 rounded-xl ml-0.5 font-black">X</span>
            </h1>
          </div>
          <button
            onClick={() => setIsSearchOpen(!isSearchOpen)}
            className="w-10 h-10 rounded-full bg-white border border-zinc-200/80 shadow-sm flex items-center justify-center text-zinc-700 hover:text-black hover:border-zinc-300 transition-all active:scale-95"
            aria-label="Search syllabus"
          >
            {isSearchOpen ? <X className="w-5 h-5" /> : <Search className="w-5 h-5" />}
          </button>
        </header>

        {isSearchOpen && (
          <div className="mb-4 animate-scale-up">
            <div className="relative">
              <input
                type="text"
                autoFocus
                placeholder="Search subjects, codes (BP101T), topics..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="w-full bg-white border border-zinc-200 rounded-2xl pl-11 pr-4 py-3 text-sm font-medium text-zinc-900 placeholder:text-zinc-400 shadow-sm focus:outline-none focus:ring-2 focus:ring-[#D4F943]"
              />
              <Search className="w-5 h-5 text-zinc-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              {searchTerm && (
                <button
                  onClick={() => setSearchTerm('')}
                  className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-400 hover:text-zinc-600"
                >
                  <X className="w-4 h-4" />
                </button>
              )}
            </div>

            {searchTerm && (
              <div className="mt-2.5 bg-white rounded-2xl p-2 border border-zinc-200/80 shadow-md max-h-60 overflow-y-auto space-y-1.5">
                {searchResults.length === 0 ? (
                  <div className="py-4 text-center text-xs text-zinc-400 font-medium">
                    No subjects or topics match "{searchTerm}"
                  </div>
                ) : (
                  searchResults.map((sub) => (
                    <div
                      key={sub.id}
                      onClick={() => navigate(`/subject/${sub.id}`)}
                      className="p-2.5 rounded-xl hover:bg-zinc-50 border border-transparent hover:border-zinc-100 flex items-center justify-between cursor-pointer transition-all"
                    >
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-black bg-[#D4F943] text-black px-1.5 py-0.5 rounded">
                            {sub.code}
                          </span>
                          <span className="text-xs font-bold text-zinc-900">
                            {sub.name}
                          </span>
                        </div>
                        <span className="text-[10px] text-zinc-500 mt-0.5 block">
                          Sem {sub.semId} • {sub.chaptersCount} Units • {sub.topicsCount} Topics
                        </span>
                      </div>
                      <ChevronRight className="w-4 h-4 text-zinc-400" />
                    </div>
                  ))
                )}
              </div>
            )}
          </div>
        )}

        {/* Category Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto no-scrollbar pb-3 mb-4">
          {['All Years', '1st Year', '2nd Year', '3rd Year', '4th Year'].map((tab) => {
            const isActive = selectedYearTab === tab;
            return (
              <button
                key={tab}
                onClick={() => setSelectedYearTab(tab)}
                className={`flex-shrink-0 px-4 py-2 rounded-full text-sm font-semibold transition-all flex items-center gap-2 active:scale-95 ${
                  isActive
                    ? 'bg-[#18181B] text-white shadow-sm'
                    : 'bg-white text-zinc-600 border border-zinc-200/70 hover:border-zinc-300'
                }`}
              >
                <span>{tab}</span>
                <span className={`text-xs px-2 py-0.5 rounded-full font-bold ${isActive ? 'bg-[#D4F943] text-black' : 'bg-zinc-100 text-zinc-500'}`}>
                  {tab === 'All Years' ? '8 Sem' : '2 Sem'}
                </span>
              </button>
            );
          })}
        </div>

        {/* HERO CARD */}
        <div className="bg-[#D4F943] rounded-[2rem] p-5 shadow-sm text-zinc-950 mb-5 relative overflow-hidden">
          <div className="flex items-start justify-between mb-2">
            <div>
              <span className="text-[11px] font-extrabold uppercase tracking-wider text-black/75 block">
                PCI B.PHARM CURRICULUM • ALL 8 SEMESTERS
              </span>
              <h2 className="text-3xl font-extrabold tracking-tight text-black mt-0.5">
                Syllabus
              </h2>
            </div>
            <button
              onClick={() => navigate('/year/1')}
              className="w-10 h-10 rounded-full bg-white flex items-center justify-center text-black shadow-sm hover:scale-105 active:scale-95 transition-transform"
              aria-label="Open 1st year"
            >
              <ArrowUpRight className="w-5 h-5 stroke-[2.5]" />
            </button>
          </div>

          <div className="space-y-2 mt-4">
            {todayTasks.map((task) => (
              <div
                key={task.id}
                onClick={() => toggleTask(task.id)}
                className="bg-white/95 rounded-2xl px-4 py-3 flex items-center justify-between gap-3 shadow-xs cursor-pointer hover:bg-white active:scale-[0.99] transition-all select-none"
              >
                <div className="flex items-center gap-3 min-w-0">
                  <div
                    className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 transition-colors ${
                      task.done ? 'bg-[#18181B] text-white' : 'border-2 border-zinc-400'
                    }`}
                  >
                    {task.done && <Check className="w-3 h-3 stroke-[3]" />}
                  </div>
                  <span
                    className={`text-xs sm:text-sm font-bold truncate ${
                      task.done ? 'text-zinc-500 line-through' : 'text-zinc-900'
                    }`}
                  >
                    {task.text}
                  </span>
                </div>

                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-zinc-100 text-zinc-700 flex-shrink-0">
                  {task.sem}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Academic Years */}
        <div className="flex items-center justify-between mb-3 px-1">
          <h3 className="text-lg font-extrabold text-zinc-900 tracking-tight">
            Academic Years ({displayedYears.length})
          </h3>
          <span className="text-xs font-bold text-zinc-400">
            Choose Year
          </span>
        </div>

        <div className="space-y-3.5 mb-6">
          {displayedYears.map((year) => (
            <div
              key={year.id}
              onClick={() => navigate(`/year/${year.id}`)}
              className="group bg-white rounded-[2rem] p-5 shadow-sm border border-zinc-100/90 hover:shadow-md hover:border-zinc-300 transition-all active:scale-[0.99] cursor-pointer block"
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-start gap-3.5 flex-1 min-w-0">
                  <div className="w-13 h-13 rounded-2xl bg-[#D4F943] flex flex-col items-center justify-center flex-shrink-0 shadow-xs group-hover:scale-105 transition-transform">
                    {getYearIcon(year.code)}
                    <span className="text-[10px] font-black uppercase tracking-wider text-black mt-0.5">
                      {year.code}
                    </span>
                  </div>

                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <h4 className="text-lg font-black text-zinc-950 tracking-tight group-hover:text-black transition-colors">
                        {year.name}
                      </h4>
                      <span className="text-[10px] font-black bg-zinc-100 text-zinc-800 px-2 py-0.5 rounded-full">
                        {year.semestersLabel}
                      </span>
                    </div>

                    <p className="text-xs text-zinc-500 font-medium line-clamp-1 mt-1 leading-snug">
                      {year.subjectsSummary}
                    </p>

                    <div className="mt-3 flex items-center gap-2">
                      <span className="text-[11px] font-extrabold px-2.5 py-0.5 rounded-full bg-[#18181B] text-white">
                        {year.subjectsCount} Subjects
                      </span>
                      <span className="text-[11px] font-bold px-2.5 py-0.5 rounded-full bg-zinc-100 text-zinc-600">
                        2 Semesters
                      </span>
                    </div>
                  </div>
                </div>

                <div className="w-9 h-9 rounded-full bg-zinc-100 group-hover:bg-[#18181B] text-zinc-700 group-hover:text-white flex items-center justify-center flex-shrink-0 transition-all shadow-xs">
                  <ArrowUpRight className="w-4 h-4 stroke-[2.5]" />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Quick Note Modal */}
      <QuickNoteModal
        isOpen={isQuickNoteOpen}
        onClose={() => setIsQuickNoteOpen(false)}
        onSaveNote={() => {
          alert('Note saved locally in PharmaX!');
          setIsQuickNoteOpen(false);
        }}
      />
    </div>
  );
}
