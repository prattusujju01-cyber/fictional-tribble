// Official Pharmacy Council of India (PCI) B.Pharm Comprehensive Curriculum Data
// All 8 Semesters, All Subjects, Units, Topics, and High-Yield Download Notes

export const YEARS_DATA = [
  {
    id: 1,
    name: '1st Year',
    semesters: [1, 2],
    semestersLabel: 'Sem 1 & Sem 2',
    subjectsSummary: 'Pharmaceutics, Analysis, Pharmacognosy, Biochemistry & Anatomy',
    subjectsCount: 12,
    badgeText: 'Sem 1–2',
    iconType: 'dna',
    code: 'Y1',
    themeColor: '#0284C7',
    bgColor: '#E0F2FE'
  },
  {
    id: 2,
    name: '2nd Year',
    semesters: [3, 4],
    semestersLabel: 'Sem 3 & Sem 4',
    subjectsSummary: 'Pharmaceutics II, Pathophysiology, Microbiology & Anatomy II',
    subjectsCount: 9,
    badgeText: 'Sem 3–4',
    iconType: 'flask',
    code: 'Y2',
    themeColor: '#0D9488',
    bgColor: '#CCFBF1'
  },
  {
    id: 3,
    name: '3rd Year',
    semesters: [5, 6],
    semestersLabel: 'Sem 5 & Sem 6',
    subjectsSummary: 'Pharmacology, Engineering, Medicinal Chemistry & Pharmacognosy',
    subjectsCount: 11,
    badgeText: 'Sem 5–6',
    iconType: 'pill',
    code: 'Y3',
    themeColor: '#EA580C',
    bgColor: '#FFEDD5'
  },
  {
    id: 4,
    name: '4th Year',
    semesters: [7, 8],
    semestersLabel: 'Sem 7 & Sem 8',
    subjectsSummary: 'Instrumental Methods, NDDS, Biostatistics & Pharmacy Practice',
    subjectsCount: 8,
    badgeText: 'Sem 7–8',
    iconType: 'book',
    code: 'Y4',
    themeColor: '#7C3AED',
    bgColor: '#EDE9FE'
  }
];

export const SEMESTERS_DATA = [
  {
    id: 1,
    yearId: 1,
    name: 'Semester 1',
    subtitle: 'First Half of 1st Year',
    summary: 'Pharmaceutics I, Analysis I, Pharmacognosy I, Anatomy I, Inorganic Chem',
    subjectsCount: 6,
    iconColor: '#3B82F6',
    label: 'Sem 1'
  },
  {
    id: 2,
    yearId: 1,
    name: 'Semester 2',
    subtitle: 'Second Half of 1st Year',
    summary: 'Biochemistry, Anatomy II, Organic Chemistry I, Pathophysiology',
    subjectsCount: 6,
    iconColor: '#10B981',
    label: 'Sem 2'
  },
  {
    id: 3,
    yearId: 2,
    name: 'Semester 3',
    subtitle: 'First Half of 2nd Year',
    summary: 'Organic Chem II, Physical Pharmaceutics I, Microbiology, Engineering',
    subjectsCount: 4,
    iconColor: '#F59E0B',
    label: 'Sem 3'
  },
  {
    id: 4,
    yearId: 2,
    name: 'Semester 4',
    subtitle: 'Second Half of 2nd Year',
    summary: 'Medicinal Chem I, Physical Pharmaceutics II, Pharmacology I, Pharmacognosy I',
    subjectsCount: 5,
    iconColor: '#EC4899',
    label: 'Sem 4'
  },
  {
    id: 5,
    yearId: 3,
    name: 'Semester 5',
    subtitle: 'First Half of 3rd Year',
    summary: 'Medicinal Chem II, Industrial Pharmacy I, Pharmacology II, Jurisprudence',
    subjectsCount: 5,
    iconColor: '#6366F1',
    label: 'Sem 5'
  },
  {
    id: 6,
    yearId: 3,
    name: 'Semester 6',
    subtitle: 'Second Half of 3rd Year',
    summary: 'Medicinal Chem III, Pharmacology III, Herbal Technology, Biopharmaceutics',
    subjectsCount: 6,
    iconColor: '#14B8A6',
    label: 'Sem 6'
  },
  {
    id: 7,
    yearId: 4,
    name: 'Semester 7',
    subtitle: 'First Half of 4th Year',
    summary: 'Instrumental Methods of Analysis, Industrial Pharmacy II, Pharmacy Practice, NDDS',
    subjectsCount: 4,
    iconColor: '#8B5CF6',
    label: 'Sem 7'
  },
  {
    id: 8,
    yearId: 4,
    name: 'Semester 8',
    subtitle: 'Second Half of 4th Year',
    summary: 'Biostatistics, Social & Preventive Pharmacy, Marketing, Pharmacovigilance',
    subjectsCount: 4,
    iconColor: '#E11D48',
    label: 'Sem 8'
  }
];

export const SUBJECTS_DATA = [
  // ================= SEMESTER 1 =================
  {
    id: 'bp101t',
    semId: 1,
    code: 'BP101T',
    name: 'Human Anatomy and Physiology – I',
    chaptersCount: 5,
    topicsCount: 46,
    credits: 4,
    iconType: 'heart',
    number: 1,
    units: [
      {
        unitNumber: 1,
        title: 'Introduction, Cellular & Tissue Level of Organization',
        topicsCount: 11,
        topics: [
          'Introduction to human body: Definition and scope of anatomy and physiology',
          'Levels of structural organization and body systems',
          'Basic life processes, homeostasis and homeostatic feedback mechanisms',
          'Anatomical terms, directional terms, planes and sections, body cavities',
          'Cellular level of organization: Structure and functions of cell and cell organelles',
          'Cell division (Mitosis, Meiosis) and cell junctions',
          'Cell communication and intracellular signaling (contact-dependent, paracrine, synaptic, endocrine)',
          'Classification, structure and functions of epithelial tissue',
          'Classification, structure and functions of muscular tissue',
          'Classification, structure and functions of nervous tissue',
          'Classification, structure and functions of connective tissue'
        ],
        notesSummary: 'Covers fundamental human biology, cellular organelle physiology, membrane transport, and complete classification of 4 basic tissue types with clinical implications.'
      },
      {
        unitNumber: 2,
        title: 'Integumentary, Skeletal System & Joints',
        topicsCount: 9,
        topics: [
          'Structure and functions of skin (Epidermis, Dermis, Hypodermis)',
          'Epidermal layers, melanocytes, keratinization, and skin appendages',
          'Skeletal system: Functions of skeleton, axial and appendicular division',
          'Structure and types of bones, histology of compact and spongy bone',
          'Ossification, bone growth, remodeling, and calcium homeostasis',
          'Classification of joints: Fibrous, cartilaginous, and synovial joints',
          'Structure of synovial joints and types of joint movements',
          'Disorders of joints (Osteoarthritis, Rheumatoid arthritis, Gout)',
          'Skeletal muscle structure, sarcomere, and sliding filament theory'
        ],
        notesSummary: 'High-yield guide on skin histology, dermatological barriers, axial vs appendicular bones, and synovial joint mechanics with arthritis management.'
      },
      {
        unitNumber: 3,
        title: 'Body Fluids, Blood & Lymphatic System',
        topicsCount: 10,
        topics: [
          'Body fluid compartments: Intracellular and extracellular fluid volume and composition',
          'Composition and functions of blood, plasma proteins and their clinical significance',
          'Erythrocytes (RBCs): Morphology, erythropoiesis, lifecycle and hemoglobin destruction',
          'Leukocytes (WBCs): Classification, differential count, and phagocytic functions',
          'Platelets (Thrombocytes): Structure, functions, and role in primary hemostasis',
          'Blood coagulation: Intrinsic, extrinsic and common pathways (Clotting factors I-XIII)',
          'Blood groups: ABO and Rh system, transfusion reactions and hemolytic disease of newborn',
          'Anemias and leukemias: Types, diagnostic parameters, and clinical significance',
          'Lymphatic system: Lymph fluid composition, lymphatic vessels and circulation',
          'Lymphoid organs: Spleen, lymph nodes, thymus, and mucosa-associated lymphoid tissue (MALT)'
        ],
        notesSummary: 'Comprehensive blood physiology, coagulation cascade diagram, ABO/Rh typing rules, and reticuloendothelial lymphatic immune defense.'
      },
      {
        unitNumber: 4,
        title: 'Peripheral Nervous System & Special Senses',
        topicsCount: 8,
        topics: [
          'Classification of peripheral nervous system: Somatic and Autonomic divisions',
          'Structure of spinal nerves, nerve plexuses (cervical, brachial, lumbar, sacral)',
          'Origin, course, distribution and functions of 12 pairs of Cranial Nerves',
          'Autonomic Nervous System: Sympathetic vs Parasympathetic functional comparison',
          'Anatomy and physiology of Eye: Structure of eyeball, retina, and phototransduction',
          'Physiology of vision, visual pathway, and common refractive errors',
          'Anatomy and physiology of Ear: External, middle, and inner ear (Cochlea, Organ of Corti)',
          'Physiology of hearing, equilibrium (semicircular canals), and taste/olfaction'
        ],
        notesSummary: 'Covers 12 cranial nerve clinical testing, ANS sympathetics vs parasympathetics, vision phototransduction, and auditory/vestibular physiology.'
      },
      {
        unitNumber: 5,
        title: 'Cardiovascular System',
        topicsCount: 8,
        topics: [
          'Heart anatomy: Chambers, cardiac wall layers (pericardium, myocardium, endocardium), and heart valves',
          'Coronary blood circulation, systemic and pulmonary circulation circuits',
          'Conducting system of the heart: SA node, AV node, Bundle of His, and Purkinje fibers',
          'Cardiac cycle events: Phases, pressure-volume changes, and heart sounds (S1, S2)',
          'Electrocardiogram (ECG): Normal waves (P, QRS, T), intervals, and diagnostic interpretation',
          'Cardiac output: Definition, stroke volume regulation, Starling’s law, and factors affecting CO',
          'Blood pressure: Systolic, diastolic, pulse pressure, mean arterial pressure and baroreceptor reflex',
          'Cardiovascular disorders: Hypertension, angina pectoris, myocardial infarction, and heart failure'
        ],
        notesSummary: 'High-yield cardiac hemodynamics, conduction action potentials, ECG wave interpretation guide, and renin-angiotensin-aldosterone BP regulation.'
      }
    ]
  },
  {
    id: 'bp102t',
    semId: 1,
    code: 'BP102T',
    name: 'Pharmaceutical Analysis – I',
    chaptersCount: 8,
    topicsCount: 36,
    credits: 4,
    iconType: 'microscope',
    number: 2,
    units: [
      {
        unitNumber: 1,
        title: 'Introduction, Errors & Pharmacopoeia',
        topicsCount: 7,
        topics: [
          'Definition and scope of pharmaceutical analysis',
          'Different techniques of quantitative and qualitative analysis',
          'Methods of expressing concentration: Molarity, Normality, Molality, % w/v, ppm',
          'Primary and secondary standards: Ideal requirements and examples',
          'Errors in analysis: Sources, systematic and random errors, methods of minimization',
          'Accuracy, precision, significant figures, standard deviation',
          'Pharmacopoeia: Introduction to IP, BP, USP and monograph structure'
        ],
        notesSummary: 'Master analytical fundamentals, error calculation equations, primary standard criteria, and official pharmacopoeial monograph specifications.'
      },
      {
        unitNumber: 2,
        title: 'Acid-Base & Non-Aqueous Titrations',
        topicsCount: 8,
        topics: [
          'Theories of acid-base indicators: Ostwald and Quinonoid theories',
          'Classification of acid-base titrations and neutralization curves',
          'Titration of strong acid vs strong base, weak acid vs strong base',
          'Preparation and standardization of 0.1 N HCl, 0.1 N NaOH, and 0.1 N H2SO4',
          'Estimation of Ammonium chloride and Boric acid',
          'Non-aqueous titrations: Principle, advantages and limitations',
          'Types of solvents used in non-aqueous titrations: Aprotic, protogenic, protophilic, amphiprotic',
          'Acidimetry and alkalimetry in non-aqueous solvents, estimation of Sodium benzoate'
        ],
        notesSummary: 'Neutralization titration curves, indicator selection criteria, and non-aqueous leveling/differentiating effects for weak organic drugs.'
      },
      {
        unitNumber: 3,
        title: 'Precipitation, Complexometric Titrations & Gravimetry',
        topicsCount: 8,
        topics: [
          'Precipitation titrations: Principle, solubility product and end-point detection',
          'Mohr’s method: Principle, indicator, conditions and estimation of NaCl',
          'Volhard’s and Modified Volhard’s method: Direct and back titration mechanisms',
          'Fajans method: Principle of adsorption indicators and applications',
          'Complexometric titrations: Classification, EDTA as a chelating agent',
          'Metal ion indicators, masking and demasking reagents in complexometry',
          'Gravimetric analysis: Principles, steps involved (precipitation, digestion, filtration, washing, drying, ignition)',
          'Purity of precipitate: Co-precipitation, post-precipitation and estimation of Barium sulphate'
        ],
        notesSummary: 'Mohr vs Volhard vs Fajans argentometric comparison, EDTA hexadentate chelation chemistry, and gravimetric Von Weimarn ratio calculations.'
      },
      {
        unitNumber: 4,
        title: 'Redox Titrations',
        topicsCount: 7,
        topics: [
          'Concepts of oxidation and reduction, redox potentials and Nernst equation',
          'Redox indicators: Self-indicators, internal redox indicators, starch indicator',
          'Permanganometry: Principle, preparation and standardization of 0.1 N KMnO4',
          'Cerimetry: Principle, applications, estimation of Ferrous sulphate',
          'Iodimetry vs Iodometry: Direct vs indirect titrations, standardization of 0.1 N Sodium thiosulphate',
          'Bromometry: Potassium bromate titrations and applications',
          'Dichrometry: Potassium dichromate titrations and pharmaceutical assays'
        ],
        notesSummary: 'Redox potential calculations, starch-triiodide complex chemistry, and step-by-step standardization of potassium permanganate and hypo.'
      },
      {
        unitNumber: 5,
        title: 'Electrochemical Methods of Analysis',
        topicsCount: 6,
        topics: [
          'Conductometry: Introduction, conductivity cell, specific and equivalent conductivity',
          'Conductometric titration curves: Acid-base titrations, advantages and limitations',
          'Potentiometry: Electrochemical cells, reference electrodes (Standard Hydrogen Electrode, Calomel, Ag/AgCl)',
          'Indicator electrodes: Glass electrode, metal electrodes, and measurement of pH',
          'Methods of detecting end point in potentiometric titrations',
          'Polarography: Principle, Ilkovic equation, Dropping Mercury Electrode (DME), and applications'
        ],
        notesSummary: 'Conductance curves for strong/weak acid-base pairs, glass electrode potential mechanism, and polarographic diffusion current principles.'
      }
    ]
  },
  {
    id: 'bp103t',
    semId: 1,
    code: 'BP103T',
    name: 'Pharmaceutics – I',
    chaptersCount: 7,
    topicsCount: 38,
    credits: 4,
    iconType: 'capsule',
    number: 3,
    units: [
      {
        unitNumber: 1,
        title: 'History, Pharmacopoeia, Prescription & Posology',
        topicsCount: 8,
        topics: [
          'Historical background and development of pharmacy profession in India',
          'Introduction to pharmacopoeias: IP, BP, USP, and Extra Pharmacopoeia',
          'Dosage forms: Definition, classification (solid, liquid, semisolid, novel)',
          'Prescription: Definition, parts of prescription, handling and legal aspects',
          'Errors in prescriptions and common Latin terms used in compounding',
          'Posology: Definition, factors affecting dose selection',
          'Pediatric dose calculation formulas (Young’s rule, Dilling’s rule, Fried’s rule, Clark’s rule)',
          'Calculation of doses based on body weight and body surface area'
        ],
        notesSummary: 'Prescription parts checklist, pharmaceutical Latin abbreviations table, and pediatric posology calculation cheat sheet.'
      },
      {
        unitNumber: 2,
        title: 'Pharmaceutical Calculations & Powders',
        topicsCount: 8,
        topics: [
          'Metric system and imperial system of weights and measures',
          'Calculations involving percentage solutions, alligation alternate and medial',
          'Proof spirit calculations and dilution of alcohol formulations',
          'Isotonic solutions and methods of tonicity adjustment (Freezing point depression, Molecular weight)',
          'Powders: Definition, advantages, disadvantages, and classification',
          'Bulk powders for external use: Dusting powders, effervescent powders',
          'Divided powders: Sachets, tablets triturates, cachets',
          'Geometric dilution, handling of eutectic mixtures, hygroscopic and deliquescent powders'
        ],
        notesSummary: 'Alligation grid solver, proof spirit conversion rules, and eutectic/hygroscopic powder compounding techniques.'
      },
      {
        unitNumber: 3,
        title: 'Liquid Dosage Forms: Monophasic & Biphasic',
        topicsCount: 8,
        topics: [
          'Liquid dosage forms: Classification, formulation additives (solvents, solubilizers, preservatives, colors)',
          'Monophasic liquids: Syrups (Simple Syrup IP), Elixirs (Medicated & non-medicated)',
          'Oral solutions, linctuses, gargles, mouthwashes, and throat paints',
          'Ear drops, nasal drops, douches, and enemas',
          'Suspensions: Definition, advantages, disadvantages, flocculated vs deflocculated suspensions',
          'Formulation of suspensions: Wetting agents, suspending agents, rheological modifiers',
          'Emulsions: Definition, types (O/W, W/O), theories of emulsification',
          'Emulsifying agents classification, HLB system, instability of emulsions (creaming, cracking, phase inversion)'
        ],
        notesSummary: 'Syrup 66.7% w/w preservation mechanism, flocculated vs deflocculated comparison table, and Bancroft’s rule of emulsion stability.'
      },
      {
        unitNumber: 4,
        title: 'Suppositories & Pharmaceutical Incompatibilities',
        topicsCount: 7,
        topics: [
          'Suppositories: Definition, types (rectal, vaginal/pessaries, urethral/bougies)',
          'Advantages, disadvantages, and rectal drug absorption mechanisms',
          'Suppository bases: Fatty bases (Theobroma oil/cocoa butter), Water-soluble bases (PEG, Glycerogelatin)',
          'Manufacturing methods: Hand rolling, compression, and fusion/pour molding',
          'Displacement value calculations and quality control testing of suppositories',
          'Pharmaceutical incompatibilities: Definition, physical incompatibilities and correction methods',
          'Chemical and therapeutic incompatibilities: Precipitation, gas formation, synergistic and antagonistic errors'
        ],
        notesSummary: 'Displacement value calculation formulas, cocoa butter polymorphic melting forms, and physical/chemical incompatibility troubleshooting.'
      },
      {
        unitNumber: 5,
        title: 'Semisolid Dosage Forms',
        topicsCount: 7,
        topics: [
          'Semisolids: Definition, classification and mechanism of percutaneous absorption',
          'Ointments: Definition, ointment bases (Hydrocarbon, Absorption, Water-removable, Water-soluble)',
          'Preparation of ointments: Trituration method and fusion method',
          'Pastes: Definition, differences from ointments, zinc oxide paste preparation',
          'Creams: Definition, cold cream vs vanishing cream formulation and comparison',
          'Gels: Definition, classification, gelling agents (Carbopol, Na-CMC), and mechanism of gelation',
          'Evaluation and packaging of semisolid dosage forms: Rheology, spreadability, extrudability'
        ],
        notesSummary: 'Ointment base selection chart, cold cream (W/O) vs vanishing cream (O/W) formulation recipes, and gel network crosslinking mechanisms.'
      }
    ]
  },
  {
    id: 'bp104t',
    semId: 1,
    code: 'BP104T',
    name: 'Pharmaceutical Inorganic Chemistry',
    chaptersCount: 5,
    topicsCount: 21,
    credits: 4,
    iconType: 'flask',
    number: 4,
    units: [
      {
        unitNumber: 1,
        title: 'Impurities in Pharmaceutical Substances & Limit Tests',
        topicsCount: 5,
        topics: [
          'History of Pharmacopoeia, sources and types of impurities in pharmaceuticals',
          'Principles and procedures of Limit test for Chlorides (comparison with standard opalescence)',
          'Principles and procedures of Limit test for Sulphates (barium sulphate turbidity)',
          'Principles and procedures of Limit test for Iron (thioglycolic acid / pale pink colour)',
          'Principles and procedures of Limit test for Arsenic (Gutzeit apparatus, mercuric chloride paper), Lead, and Heavy metals'
        ],
        notesSummary: 'All 6 official PCI limit test chemical reactions, reagents, standard apparatus diagrams, and troubleshooting guidelines.'
      },
      {
        unitNumber: 2,
        title: 'Acids, Bases, Buffers & Dental Products',
        topicsCount: 4,
        topics: [
          'Buffer equations, buffer capacity, buffers in pharmaceutical systems and buffer stability',
          'Buffered isotonic solutions and measurement/adjustment of tonicity',
          'Major extracellular and intracellular electrolytes: Sodium, potassium, chloride, calcium gluconate, and Oral Rehydration Salt (ORS)',
          'Dental products: Role of fluoride in dental caries, dentifrices, desensitizing agents, Calcium carbonate, Sodium fluoride, Zinc eugenol cement'
        ],
        notesSummary: 'Henderson-Hasselbalch buffer calculations, WHO standard ORS formulation table, and fluoride enamel remineralization mechanisms.'
      },
      {
        unitNumber: 3,
        title: 'Gastrointestinal Agents & Antimicrobials',
        topicsCount: 4,
        topics: [
          'Acidifiers: Ammonium chloride and Dilute Hydrochloric acid',
          'Antacids: Ideal properties of antacids, combinations, Sodium bicarbonate, Aluminum hydroxide gel, Magnesium hydroxide mixture',
          'Cathartics: Mechanism of saline cathartics, Magnesium sulphate, Sodium orthophosphate, Kaolin, Bentonite',
          'Antimicrobials: Mechanism of action, Potassium permanganate, Boric acid, Hydrogen peroxide, Chlorinated lime, Iodine solutions (Lugol’s solution, Povidone-iodine)'
        ],
        notesSummary: 'Nonsystemic vs systemic antacid acid rebound mechanisms, saline cathartic hyperosmotic action, and oxidative inorganic antiseptic reactions.'
      },
      {
        unitNumber: 4,
        title: 'Miscellaneous Pharmaceutical Compounds',
        topicsCount: 4,
        topics: [
          'Expectorants: Potassium iodide and Ammonium chloride',
          'Emetics: Copper sulphate and Sodium potassium tartrate (Tartar emetic)',
          'Haematinics: Ferrous sulphate, Ferrous gluconate, Ferrous fumarate',
          'Poison and Antidotes: Sodium thiosulphate, Activated charcoal, Sodium nitrite; Astringents: Zinc sulphate and Alum'
        ],
        notesSummary: 'Cyanide poisoning two-step antidote protocol (Nitrite + Thiosulphate), iron salt bioavailability, and astringent protein precipitation.'
      },
      {
        unitNumber: 5,
        title: 'Radiopharmaceuticals',
        topicsCount: 4,
        topics: [
          'Radioactivity: Alpha, beta and gamma radiations, half-life, units of radioactivity (Curie, Becquerel)',
          'Measurement of radioactivity: Geiger-Muller counter, Scintillation counter',
          'Pharmaceutical applications of radioisotopes: Diagnostic and therapeutic uses (Iodine-131, Technetium-99m, Cobalt-60, Chromium-51)',
          'Handling and storage of radioactive materials, radiation safety precautions and waste disposal'
        ],
        notesSummary: 'Radioactive decay equations, GM counter ionization mechanisms, clinical gamma camera imaging, and lead-shielded storage regulations.'
      }
    ]
  },
  {
    id: 'bp105t',
    semId: 1,
    code: 'BP105T',
    name: 'Communication Skills',
    chaptersCount: 5,
    topicsCount: 18,
    credits: 2,
    iconType: 'chat',
    number: 5,
    units: [
      {
        unitNumber: 1,
        title: 'Fundamentals of Communication & Barriers',
        topicsCount: 4,
        topics: [
          'Introduction, definition, objectives and importance of communication in pharmacy',
          'The communication cycle: Sender, message, channel, receiver, decoding, feedback',
          'Barriers to communication: Physical, physiological, language, psychological, and environmental',
          'Perspectives in communication: Perception, past experience, prejudices and emotional context'
        ],
        notesSummary: 'Communication loop model, noise reduction techniques, and patient counseling communication barrier removal strategies.'
      },
      {
        unitNumber: 2,
        title: 'Elements & Styles of Communication',
        topicsCount: 3,
        topics: [
          'Verbal vs Non-verbal communication: Kinesics, proxemics, paralanguage, and chronemics',
          'Active listening skills: Hearing vs listening, stages of listening, becoming an empathetic listener',
          'Communication Styles Matrix: Direct, Spirited, Systematic, and Considerate styles'
        ],
        notesSummary: 'Body language non-verbal cues in healthcare, active listening 5-stage model, and communication matrix leadership adaptation.'
      },
      {
        unitNumber: 3,
        title: 'Basic Listening & Effective Writing Skills',
        topicsCount: 4,
        topics: [
          'Listening in difficult situations, responding to emotional or angry patients',
          'Principles of effective written communication: Clarity, conciseness, coherence, correctness',
          'Writing professional emails, formal letters, and pharmacy documentation',
          'Structuring medical and scientific reports, subject lines, and audience analysis'
        ],
        notesSummary: 'Healthcare documentation standards, patient interaction conflict de-escalation, and formal pharmacy communication templates.'
      },
      {
        unitNumber: 4,
        title: 'Interview & Presentation Skills',
        topicsCount: 4,
        topics: [
          'Interview skills: Types of interviews, resume building, common clinical interview questions',
          'Pre-interview preparation, body language, answering techniques (STAR technique)',
          'Presentation skills: Planning, organizing content, visual aids, delivery techniques',
          'Overcoming stage fear, managing Q&A sessions, time management during presentations'
        ],
        notesSummary: 'STAR interview answer formulation, slide design best practices, and stage anxiety cognitive control.'
      },
      {
        unitNumber: 5,
        title: 'Group Discussion & Leadership',
        topicsCount: 3,
        topics: [
          'Group discussion: Dynamics of GD, evaluation parameters, initiation and concluding techniques',
          'Do’s and Don’ts in group discussions, consensus building, handling conflicts',
          'Leadership qualities, interpersonal skills, and professional etiquette in pharmacy practice'
        ],
        notesSummary: 'GD participation scoring metrics, topic initiation phrases, conflict moderation tactics, and clinical teamwork leadership.'
      }
    ]
  },
  {
    id: 'bp106t',
    semId: 1,
    code: 'BP106RBT/RMT',
    name: 'Remedial Biology / Remedial Mathematics',
    chaptersCount: 5,
    topicsCount: 20,
    credits: 2,
    iconType: 'leaf',
    number: 6,
    units: [
      {
        unitNumber: 1,
        title: 'Living World & Cellular Basis of Life',
        topicsCount: 4,
        topics: [
          'Living world: Diversity in living organisms, taxonomic classification and binomial nomenclature',
          'Cell: Structure of plant cell vs animal cell, cell organelles and plasma membrane',
          'Cell division: Mitosis, meiosis, cell cycle regulation and significance',
          'Biomolecules: Basic chemistry and biological functions of carbohydrates, proteins, nucleic acids'
        ],
        notesSummary: 'Plant vs animal cell ultrastructure, chromosome mitosis stages diagram, and biological macromolecules summary.'
      },
      {
        unitNumber: 2,
        title: 'Morphology & Anatomy of Flowering Plants',
        topicsCount: 4,
        topics: [
          'Morphology of root, stem, leaf and their modifications',
          'Inflorescence, flower structure, fruit types and seed anatomy',
          'Plant anatomy: Tissues (Meristematic and permanent), vascular bundles (Xylem, Phloem)',
          'Secondary growth in dicot stem and root, stomata structure and transpiration'
        ],
        notesSummary: 'Crude drug botanical identification, floral formula guide, and dicot vs monocot vascular bundle microscopy.'
      },
      {
        unitNumber: 3,
        title: 'Human Physiology: Digestion & Circulation',
        topicsCount: 4,
        topics: [
          'Digestive system: Alimentary canal anatomy, digestive glands, enzymes and food absorption',
          'Body fluids and circulation: Blood cells, cardiac cycle, and human double circulation',
          'Disorders of circulatory system: Hypertension, CAD, angina',
          'Nutritional deficiencies and gastrointestinal disorders'
        ],
        notesSummary: 'Digestive enzyme action site breakdown, cardiac circulation circuit diagram, and nutritional pathology.'
      },
      {
        unitNumber: 4,
        title: 'Breathing, Respiration & Excretion',
        topicsCount: 4,
        topics: [
          'Respiratory organs in humans: Mechanism of breathing, exchange and transport of respiratory gases',
          'Regulation of respiration, respiratory volumes and capacities (Spirometry)',
          'Excretory system: Human kidney anatomy, structure of nephron and urine formation mechanisms',
          'Countercurrent multiplier mechanism, micturition, and disorders of excretory system'
        ],
        notesSummary: 'Oxygen-hemoglobin dissociation curve, nephron glomerular filtration pressure calculations, and countercurrent system.'
      },
      {
        unitNumber: 5,
        title: 'Nervous Control & Plant Physiology',
        topicsCount: 4,
        topics: [
          'Neural control and coordination: Human nervous system, neuron structure, nerve impulse transmission',
          'Endocrine glands and human hormones: Master gland pituitary, thyroid, insulin regulation',
          'Photosynthesis: Light and dark reactions (Calvin cycle), factors affecting photosynthesis',
          'Plant growth regulators: Auxins, gibberellins, cytokinins, ethylene, abscisic acid'
        ],
        notesSummary: 'Action potential generation graphs, endocrine hormone axis overview, and photosynthetic photophosphorylation pathways.'
      }
    ]
  },

  // ================= SEMESTER 2 =================
  {
    id: 'bp201t',
    semId: 2,
    code: 'BP201T',
    name: 'Human Anatomy and Physiology – II',
    chaptersCount: 5,
    topicsCount: 40,
    credits: 4,
    iconType: 'heart',
    number: 1,
    units: [
      {
        unitNumber: 1,
        title: 'Nervous System & Central Nervous System',
        topicsCount: 8,
        topics: [
          'Organization of nervous system, neuron classification and neuroglia',
          'Central nervous system: Brain meninges, ventricles and cerebrospinal fluid (CSF) circulation',
          'Structure and functions of Cerebrum, Cerebral cortex, and functional areas',
          'Brain stem (Midbrain, Pons, Medulla oblongata) and vital reflex centers',
          'Cerebellum: Structure, functions in coordination, balance and posture',
          'Spinal cord: Gross anatomy, cross-sectional anatomy, ascending and descending tracts',
          'Reflex arc and reflex action mechanisms',
          'Neurotransmitters in CNS: Acetylcholine, Dopamine, Serotonin, GABA, Glutamate'
        ],
        notesSummary: 'Brain lobe functional localization map, CSF formation & blood-brain barrier physiology, and motor vs sensory spinal cord tracts.'
      },
      {
        unitNumber: 2,
        title: 'Digestive System & Energetics',
        topicsCount: 8,
        topics: [
          'Anatomy of gastrointestinal tract: Stomach, small intestine, large intestine',
          'Histology of GI tract wall layers and enteric nervous system',
          'Secretions of salivary glands, gastric glands, pancreas and liver',
          'Bile composition, functions and enterohepatic circulation of bile salts',
          'Digestion and absorption of carbohydrates, proteins, and lipids',
          'Movements of GI tract: Peristalsis, segmentation, and defecation reflex',
          'Energetics: Basal metabolic rate (BMR), factors affecting BMR',
          'ATP production pathways and energy balance in human body'
        ],
        notesSummary: 'Gastric acid secretion cellular mechanism (proton pump), intestinal brush border enzymes, and BMR clinical determination.'
      },
      {
        unitNumber: 3,
        title: 'Respiratory & Urinary System',
        topicsCount: 8,
        topics: [
          'Anatomy of respiratory system: Trachea, bronchial tree, and alveoli',
          'Mechanics of breathing: Pressure changes, inspiratory and expiratory muscles',
          'Transport of gases in blood: Oxygen transport (Oxyhemoglobin) and Carbon dioxide transport (Bicarbonate buffer)',
          'Regulation of respiration: Medullary rhythmicity center and chemoreceptors',
          'Anatomy of kidney: Renal cortex, medulla, nephron structure and juxtaglomerular apparatus',
          'Physiology of urine formation: Glomerular filtration, tubular reabsorption, and tubular secretion',
          'Renin-Angiotensin-Aldosterone System (RAAS) and renal blood pressure control',
          'Micturition reflex, renal function tests and clearance mechanisms'
        ],
        notesSummary: 'Bohr effect vs Haldane effect gas transport graphs, GFR Starling forces equations, and RAAS physiological diagram.'
      },
      {
        unitNumber: 4,
        title: 'Endocrine System',
        topicsCount: 8,
        topics: [
          'Classification of hormones and mechanisms of hormone action (membrane vs intracellular receptors)',
          'Pituitary gland (Hypophysis): Anterior and posterior pituitary hormones and hypothalamic regulation',
          'Thyroid gland: T3 and T4 synthesis, physiological actions, and thyroid disorders (Goitre, Graves disease, Cretinism)',
          'Parathyroid gland: Parathormone, calcitonin and calcium-phosphate balance',
          'Adrenal glands: Adrenal cortex (Mineralocorticoids, Glucocorticoids, Androgens) and Adrenal medulla (Epinephrine, Norepinephrine)',
          'Endocrine pancreas: Insulin, Glucagon, Somatostatin and blood glucose homeostasis',
          'Pineal gland and Melatonin; Thymus gland and Thymosin',
          'Disorders of endocrine system: Diabetes mellitus (Type 1 & 2), Cushing syndrome, Addison disease, Acromegaly'
        ],
        notesSummary: 'Second messenger cAMP/IP3-DAG cascade diagrams, thyroid hormone iodination steps, and insulin receptor signal transduction.'
      },
      {
        unitNumber: 5,
        title: 'Reproductive System & Genetics',
        topicsCount: 8,
        topics: [
          'Anatomy of male reproductive system: Testes, epididymis, vas deferens, prostate and semen composition',
          'Spermatogenesis, structure of sperm and hormonal regulation of male reproduction (Testosterone, LH, FSH)',
          'Anatomy of female reproductive system: Ovaries, fallopian tubes, uterus and vagina',
          'Oogenesis, ovarian cycle, follicular development and ovulation',
          'Menstrual cycle: Hormonal interplay (Estrogen, Progesterone, LH surge) and endometrial phases',
          'Fertilization, implantation, pregnancy, placenta functions and parturition',
          'Lactation physiology (Prolactin, Oxytocin) and methods of contraception',
          'Introduction to genetics: Chromosomes, genes, protein synthesis, and sex determination'
        ],
        notesSummary: 'Menstrual cycle hormone level synchronization curves, gametogenesis comparison, and placental endocrine barrier physiology.'
      }
    ]
  },
  {
    id: 'bp202t',
    semId: 2,
    code: 'BP202T',
    name: 'Pharmaceutical Organic Chemistry – I',
    chaptersCount: 5,
    topicsCount: 35,
    credits: 4,
    iconType: 'flask',
    number: 2,
    units: [
      {
        unitNumber: 1,
        title: 'Classification, Nomenclature & Isomerism',
        topicsCount: 7,
        topics: [
          'Classification of Organic Compounds: Acyclic, carbocyclic, heterocyclic, aromatic',
          'IUPAC nomenclature of organic compounds up to bifurcated functional chains',
          'Structural isomerism: Chain, positional, functional, metamerism, tautomerism',
          'Stereoisomerism: Geometrical and optical isomerism introduction',
          'Hybridization in carbon compounds: sp3, sp2, sp geometries and bond angles',
          'Inductive effect, electromeric effect, resonance / mesomeric effect, and hyperconjugation',
          'Reaction intermediates: Carbocations, carbanions, free radicals, carbenes stability order'
        ],
        notesSummary: 'IUPAC naming priority chart, electronic displacement effects comparison, and carbocation stability rearrangement patterns.'
      },
      {
        unitNumber: 2,
        title: 'Alkanes, Alkenes & Conjugated Dienes',
        topicsCount: 7,
        topics: [
          'Alkanes: General methods of preparation, free radical halogenation mechanism',
          'Combustion and pyrolysis of alkanes, conformational isomerism of ethane and butane',
          'Alkenes: Methods of preparation, Saytzeff rule vs Hofmann rule in elimination',
          'Electrophilic addition reactions: Markovnikov rule and Anti-Markovnikov (peroxide effect)',
          'Mechanisms of hydration, halogenation, hydrohalogenation, and ozonolysis of alkenes',
          'Conjugated dienes: Structure, resonance stability of 1,3-butadiene',
          'Diels-Alder reaction and 1,2- vs 1,4-addition to conjugated dienes'
        ],
        notesSummary: 'Markovnikov addition reaction energy diagrams, Saytzeff E2 elimination stereochemistry, and 1,4-addition thermodynamic control.'
      },
      {
        unitNumber: 3,
        title: 'Alkyl Halides & Alcohols',
        topicsCount: 7,
        topics: [
          'Alkyl halides: Nomenclature, classification, methods of preparation',
          'Nucleophilic substitution reactions: SN1 vs SN2 mechanisms, kinetics and stereochemistry',
          'Factors affecting SN1 and SN2 reactions: Substrate structure, nucleophile, solvent, leaving group',
          'Elimination reactions: E1 vs E2 mechanisms and competition with substitution',
          'Alcohols: Classification, general methods of preparation, industrial synthesis of ethanol',
          'Qualitative tests for alcohols: Lucas test, Victor Meyer test, Dichromate oxidation',
          'Reactions of alcohols: Esterification, dehydration, reaction with PX3, PX5, SOCl2'
        ],
        notesSummary: 'SN1 vs SN2 comparison matrix, inversion of configuration (Walden inversion), and Lucas test turbidity timeline.'
      },
      {
        unitNumber: 4,
        title: 'Carbonyl Compounds (Aldehydes & Ketones)',
        topicsCount: 7,
        topics: [
          'Structure of carbonyl group, polarity, and relative reactivity of aldehydes vs ketones',
          'Nucleophilic addition reactions: Addition of HCN, NaHSO3, Grignard reagents, alcohols',
          'Addition-elimination reactions: Reaction with ammonia derivatives (hydroxylamine, hydrazine, semicarbazide)',
          'Acidity of alpha-hydrogens and keto-enol tautomerism',
          'Aldol condensation and cross-aldol condensation mechanisms',
          'Cannizzaro reaction and cross-Cannizzaro reaction mechanisms',
          'Benzoin condensation, Perkin reaction, and qualitative tests (Tollens test, Fehling test, 2,4-DNP)'
        ],
        notesSummary: 'Carbonyl nucleophilic attack mechanisms, Aldol enolate intermediate steps, and Tollens silver mirror diagnostic reactions.'
      },
      {
        unitNumber: 5,
        title: 'Carboxylic Acids & Aliphatic Amines',
        topicsCount: 7,
        topics: [
          'Carboxylic acids: Structure, acidity, resonance of carboxylate anion and substituent effects',
          'General methods of preparation and chemical reactions of carboxylic acids',
          'Acid derivatives: Esters, acid chlorides, acid anhydrides, amides (nucleophilic acyl substitution)',
          'Aliphatic amines: Classification, nomenclature, and basicity in gas vs aqueous phase',
          'Methods of preparation: Gabriel phthalimide synthesis, Hofmann bromamide degradation',
          'Reactions of amines: Carbylamine test, reaction with nitrous acid (diazotization / gas evolution)',
          'Hinsberg method for separation of primary, secondary, and tertiary amines'
        ],
        notesSummary: 'Carboxylic acid inductive substituent pKa values, Hinsberg reagent amine separation chart, and Hofmann degradation mechanism.'
      }
    ]
  },
  {
    id: 'bp203t',
    semId: 2,
    code: 'BP203T',
    name: 'Biochemistry',
    chaptersCount: 5,
    topicsCount: 34,
    credits: 4,
    iconType: 'dna',
    number: 3,
    units: [
      {
        unitNumber: 1,
        title: 'Biomolecules & Bioenergetics',
        topicsCount: 6,
        topics: [
          'Introduction to biochemistry and chemical composition of living cells',
          'Carbohydrates, lipids, proteins and nucleic acids: Structural hierarchy and functions',
          'Bioenergetics: Concept of free energy (Delta G), enthalpy, entropy, exergonic and endergonic reactions',
          'High energy compounds: Classification, ATP as universal energy currency, phosphoenolpyruvate',
          'Biological oxidation: Redox potentials, electron transport chain (ETC) complexes I to IV',
          'Oxidative phosphorylation: Chemiosmotic hypothesis, ATP synthase mechanism, uncouplers and inhibitors'
        ],
        notesSummary: 'High-energy phosphate bond thermodynamics, ETC mitochondrial complex flow diagram, and 2,4-DNP uncoupling mechanism.'
      },
      {
        unitNumber: 2,
        title: 'Carbohydrate Metabolism',
        topicsCount: 7,
        topics: [
          'Glycolysis (Embden-Meyerhof pathway): Steps, energetics (net ATP), irreversible regulation',
          'Fate of pyruvate under aerobic and anaerobic conditions, lactic acidosis',
          'Citric Acid Cycle (TCA / Krebs cycle): Reactions, enzymes, energetic yield, amphibolic nature',
          'Gluconeogenesis: Pathway, reciprocal regulation with glycolysis, Cori cycle',
          'Glycogenesis and Glycogenolysis: Pathways, hormonal control by Insulin and Glucagon',
          'Hexose Monophosphate (HMP) Shunt: NADPH generation, ribose-5-phosphate, G6PD deficiency',
          'Glycogen storage diseases (von Gierke, Pompe, McArdle disease) and Galactosemia'
        ],
        notesSummary: 'Glycolysis vs Gluconeogenesis comparison chart, complete Krebs cycle ATP balance sheet, and G6PD favism clinical correlation.'
      },
      {
        unitNumber: 3,
        title: 'Lipid & Amino Acid Metabolism',
        topicsCount: 7,
        topics: [
          'Beta-oxidation of saturated fatty acids: Activation, carnitine shuttle, reactions and ATP calculation (Palmitic acid)',
          'Ketogenesis: Ketone bodies synthesis, utilization, ketosis, and diabetic ketoacidosis',
          'De novo synthesis of fatty acids: Fatty acid synthase multienzyme complex',
          'Cholesterol biosynthesis: HMG-CoA reductase regulation and conversion to bile acids/steroids',
          'General reactions of amino acids: Transamination, deamination, and decarboxylation',
          'Urea cycle (Krebs-Henseleit cycle): Steps, regulation, metabolic disorders of urea cycle',
          'Metabolism of aromatic amino acids (Phenylalanine, Tyrosine) and inborn errors (PKU, Alkaptonuria, Albinism)'
        ],
        notesSummary: 'Palmitic acid beta-oxidation 106 ATP yield calculation, urea cycle enzymatic steps, and Phenylketonuria biochemical pathway.'
      },
      {
        unitNumber: 4,
        title: 'Nucleic Acid Metabolism & Genetic Information',
        topicsCount: 7,
        topics: [
          'Structure of purines and pyrimidines, nucleosides, nucleotides',
          'De novo and salvage pathways of purine and pyrimidine biosynthesis',
          'Catabolism of purine nucleotides, formation of uric acid, hyperuricemia and Gout',
          'DNA structure: Watson-Crick double helix model, base pairing, forms of DNA (B, A, Z)',
          'DNA replication in prokaryotes: Semiconservative replication, replication fork, DNA polymerases',
          'Transcription: RNA polymerase, promoter, mRNA processing (capping, poly-A tail, splicing)',
          'Translation and Genetic Code: Codons, wobble hypothesis, tRNA, initiation, elongation, termination'
        ],
        notesSummary: 'Purine degradation to uric acid diagram, Watson-Crick hydrogen bonding geometry, and Central Dogma molecular biology timeline.'
      },
      {
        unitNumber: 5,
        title: 'Enzymes & Clinical Biochemistry',
        topicsCount: 7,
        topics: [
          'Introduction, IUBMB classification and nomenclature of enzymes',
          'Mechanism of enzyme action: Activation energy reduction, lock & key vs induced fit model',
          'Enzyme kinetics: Michaelis-Menten equation, Km and Vmax significance, Lineweaver-Burk plot',
          'Factors affecting enzyme activity: Temperature, pH, substrate concentration, enzyme concentration',
          'Enzyme inhibition: Reversible (competitive, non-competitive, uncompetitive) and irreversible inhibition',
          'Allosteric enzymes, feedback inhibition, and covalent modification of enzymes',
          'Clinical enzymology: Diagnostic significance of serum enzymes (SGOT/AST, SGPT/ALT, Alkaline phosphatase, CK-MB, LDH)'
        ],
        notesSummary: 'Michaelis-Menten & Lineweaver-Burk double reciprocal plots, competitive vs non-competitive inhibition kinetics, and cardiac biomarker enzymes.'
      }
    ]
  },
  {
    id: 'bp204t',
    semId: 2,
    code: 'BP204T',
    name: 'Pathophysiology',
    chaptersCount: 5,
    topicsCount: 30,
    credits: 4,
    iconType: 'pulse',
    number: 4,
    units: [
      {
        unitNumber: 1,
        title: 'Cell Injury & Inflammation',
        topicsCount: 6,
        topics: [
          'Basic principles of cell injury and cellular adaptation (Hypertrophy, Hyperplasia, Atrophy, Metaplasia)',
          'Etiology and pathogenesis of reversible cell injury (cellular swelling, fatty change)',
          'Irreversible cell injury: Mechanisms of necrosis (coagulative, liquefactive, caseous, fat) and Apoptosis',
          'Free radicals, reactive oxygen species (ROS), oxidative stress and lipid peroxidation',
          'Acute inflammation: Vascular events, cellular events (chemotaxis, phagocytosis), chemical mediators',
          'Chronic inflammation: Granulomatous inflammation, tissue healing and repair by fibrosis'
        ],
        notesSummary: 'Cellular adaptation types with clinical examples, Apoptosis vs Necrosis comparison table, and cardinal signs of acute inflammation.'
      },
      {
        unitNumber: 2,
        title: 'Cardiovascular, Respiratory & Renal Disorders',
        topicsCount: 6,
        topics: [
          'Hypertension: Pathogenesis of essential and secondary hypertension, target organ damage',
          'Congestive Heart Failure: Etiology, compensatory mechanisms, systolic vs diastolic failure',
          'Ischemic Heart Disease: Atherosclerosis pathogenesis, plaque rupture, Angina, Myocardial Infarction',
          'Respiratory disorders: Pathophysiology of Asthma (allergic vs non-allergic) and COPD (Chronic bronchitis, Emphysema)',
          'Acute Renal Failure: Prerenal, intrinsic and postrenal causes, stages and management',
          'Chronic Kidney Disease (CKD): Pathogenesis of glomerulosclerosis, uremic syndrome, ESRD'
        ],
        notesSummary: 'Atherosclerotic plaque lipid core rupture cascade, asthma airway bronchospasm remodeling, and CKD uremic toxicity.'
      },
      {
        unitNumber: 3,
        title: 'Hematological, Endocrine & Nervous Disorders',
        topicsCount: 6,
        topics: [
          'Anemias: Iron deficiency anemia, Megaloblastic anemia (B12 & Folate deficiency), Sickle cell anemia',
          'Hemophilia and Thrombocytopenia: Defective clotting factors and platelet disorders',
          'Diabetes Mellitus: Pathogenesis of Type 1 vs Type 2 DM, metabolic derangements, microvascular/macrovascular complications',
          'Thyroid disorders: Pathophysiology of Hyperthyroidism (Graves disease) and Hypothyroidism (Hashimoto thyroiditis)',
          'Parkinson’s disease: Loss of dopaminergic neurons in substantia nigra, Lewy bodies, motor symptoms',
          'Epilepsy and Alzheimer’s disease: Pathophysiology of seizures, amyloid beta plaques, neurofibrillary tangles'
        ],
        notesSummary: 'Type 1 vs Type 2 Diabetes pathogenesis comparison, Sickle cell HbS polymerization, and Parkinsonian dopamine depletion diagram.'
      },
      {
        unitNumber: 4,
        title: 'Gastrointestinal, Bone & Joint Disorders',
        topicsCount: 6,
        topics: [
          'Peptic Ulcer Disease: Aggressive vs defensive factors, H. pylori role, NSAID ulcerogenesis',
          'Inflammatory Bowel Disease: Crohn’s disease vs Ulcerative colitis pathophysiology',
          'Jaundice: Pre-hepatic, intra-hepatic, and post-hepatic (obstructive) jaundice pathophysiology',
          'Hepatitis and Cirrhosis of liver: Viral etiology, portal hypertension, ascites, hepatic encephalopathy',
          'Rheumatoid arthritis: Autoimmune synovial inflammation, pannus formation, joint destruction',
          'Gout: Hyperuricemia, monosodium urate crystal deposition in joints, acute tophi arthritis'
        ],
        notesSummary: 'H. pylori urease enzyme mucosal breakdown, Crohn vs Ulcerative colitis differential table, and uric acid crystal joint inflammatory response.'
      },
      {
        unitNumber: 5,
        title: 'Cancer & Infectious Diseases',
        topicsCount: 6,
        topics: [
          'Neoplasia: Characteristics of benign vs malignant neoplasms, grading and staging of cancer',
          'Etiology of cancer: Chemical carcinogens, physical carcinogens, viral oncogenesis',
          'Molecular basis of cancer: Proto-oncogenes to oncogenes, tumor suppressor genes (p53, Rb)',
          'Pathogenesis of HIV / AIDS: Viral structure, life cycle, CD4+ T-cell destruction, opportunistic infections',
          'Pathophysiology of Tuberculosis: Primary vs secondary TB, granuloma / Ghon complex, caseous necrosis',
          'Pathophysiology of sexually transmitted infections: Syphilis (Treponema pallidum) and Gonorrhea'
        ],
        notesSummary: 'Knudson two-hit hypothesis for tumor suppressors, HIV viral replication cycle targets, and TB Langhans giant cell granuloma histology.'
      }
    ]
  },
  {
    id: 'bp205t',
    semId: 2,
    code: 'BP205T',
    name: 'Computer Applications in Pharmacy',
    chaptersCount: 5,
    topicsCount: 20,
    credits: 3,
    iconType: 'screen',
    number: 5,
    units: [
      {
        unitNumber: 1,
        title: 'Number Systems & Web Technologies',
        topicsCount: 4,
        topics: [
          'Binary, octal, decimal and hexadecimal number systems and conversions',
          'Introduction to HTML: Basic tags, formatting, tables, forms, linking',
          'XML and CSS fundamentals, web hosting, domain registration in pharmacy',
          'Database management systems: Relational databases, SQL queries in pharmacy inventory'
        ],
        notesSummary: 'Binary-hexadecimal conversion tables, pharmacy website HTML5 structure, and relational inventory SQL schemas.'
      },
      {
        unitNumber: 2,
        title: 'Information Systems & Software in Pharmacy',
        topicsCount: 4,
        topics: [
          'Hospital Pharmacy Information System (HPIS): Modules, patient profiles, drug interactions',
          'Laboratory Information Management System (LIMS) in pharmaceutical QC',
          'Clinical trial management software and automated dispensing systems',
          'E-prescribing systems and Barcode Medication Administration (BCMA)'
        ],
        notesSummary: 'HPIS medication dispensing architecture, LIMS sample tracking workflows, and BCMA medication safety verification.'
      },
      {
        unitNumber: 3,
        title: 'Medical Transcription & Electronic Health Records',
        topicsCount: 4,
        topics: [
          'Medical transcription: Process, terminology, audio processing, standards',
          'Electronic Health Records (EHR) and Electronic Medical Records (EMR): Architecture, benefits',
          'Security and privacy of healthcare data: HIPAA compliance and data encryption',
          'Pharmacy billing software and insurance claims processing'
        ],
        notesSummary: 'EHR interoperability standards, HIPAA security compliance safeguards, and electronic prescription transmission protocols.'
      },
      {
        unitNumber: 4,
        title: 'Bioinformatics & Drug Discovery Databases',
        topicsCount: 4,
        topics: [
          'Introduction to Bioinformatics: Objectives, biological databases (NCBI, GenBank, UniProt)',
          'Protein Data Bank (PDB): Structure search, molecular coordinates, visualization tools',
          'Drug databases: DrugBank, PubChem, ChemSpider for molecular properties',
          'Sequence alignment: BLAST and FASTA algorithms for genomics'
        ],
        notesSummary: 'PDB file format interpretation, DrugBank pharmacological search parameters, and BLAST sequence homology scores.'
      },
      {
        unitNumber: 5,
        title: 'Computers in Pharmaceutical R&D',
        topicsCount: 4,
        topics: [
          'Computers in formulation design: Statistical experimental design software (Design-Expert)',
          'Molecular modeling software, quantitative structure-activity relationships (QSAR)',
          'Artificial Intelligence (AI) and Machine Learning applications in drug discovery',
          'Robotics and process automation in pharmaceutical manufacturing'
        ],
        notesSummary: 'DoE response surface optimization methodology, 2D/3D QSAR molecular descriptor analysis, and pharmaceutical AI automation.'
      }
    ]
  },
  {
    id: 'bp206t',
    semId: 2,
    code: 'BP206T',
    name: 'Environmental Sciences',
    chaptersCount: 5,
    topicsCount: 18,
    credits: 3,
    iconType: 'leaf',
    number: 6,
    units: [
      {
        unitNumber: 1,
        title: 'Ecosystems & Natural Resources',
        topicsCount: 4,
        topics: [
          'Concept of an ecosystem: Structure, food chains, food webs, ecological pyramids',
          'Forest, grassland, desert and aquatic ecosystems',
          'Renewable and non-renewable energy resources: Solar, wind, biomass, fossil fuels',
          'Water resources, deforestation, mineral resources, and sustainable development'
        ],
        notesSummary: 'Energy flow in 10% ecological trophic levels, watershed management, and renewable green energy technologies.'
      },
      {
        unitNumber: 2,
        title: 'Biodiversity & Conservation',
        topicsCount: 3,
        topics: [
          'Definition, genetic, species and ecosystem diversity',
          'Biogeographical zones of India, biodiversity hotspots (Western Ghats, Himalayas)',
          'Threats to biodiversity, endangered and endemic species, In-situ and Ex-situ conservation'
        ],
        notesSummary: 'Red Data Book endangered categories, wildlife sanctuaries vs national parks, and medicinal plant germplasm conservation.'
      },
      {
        unitNumber: 3,
        title: 'Environmental Pollution & Control',
        topicsCount: 4,
        topics: [
          'Air pollution: Sources, greenhouse effect, ozone layer depletion, acid rain, control technologies',
          'Water pollution: Industrial effluents, pharmaceutical active residues, sewage treatment, eutrophication',
          'Soil pollution, noise pollution, thermal pollution and nuclear hazards',
          'Biomedical waste management: Biomedical Waste Rules, color coding, disposal methods'
        ],
        notesSummary: 'Effluent treatment plant (ETP) 3-stage process, biomedical waste color-coded bags (Yellow, Red, White, Blue), and AQI index.'
      },
      {
        unitNumber: 4,
        title: 'Social Issues & Environmental Legislation',
        topicsCount: 4,
        topics: [
          'From unsustainable to sustainable development, urban environmental problems',
          'Water conservation, rain water harvesting, watershed management',
          'Environmental ethics: Issues and possible solutions, climate change, global warming',
          'Environment Protection Act 1986, Air Act 1981, Water Act 1974'
        ],
        notesSummary: 'Rooftop rainwater harvesting calculations, carbon credit trading mechanisms, and key Indian environmental regulatory acts.'
      },
      {
        unitNumber: 5,
        title: 'Human Population & Environment',
        topicsCount: 3,
        topics: [
          'Population growth, variation among nations, population explosion and family welfare program',
          'Environment and human health, human rights, value education, HIV / AIDS awareness',
          'Role of Information Technology in environment and human health'
        ],
        notesSummary: 'Demographic transition model, environmental epidemiology, and GIS mapping in disease vector outbreak monitoring.'
      }
    ]
  },

  // ================= SEMESTER 3 =================
  {
    id: 'bp301t',
    semId: 3,
    code: 'BP301T',
    name: 'Pharmaceutical Organic Chemistry – II',
    chaptersCount: 5,
    topicsCount: 32,
    credits: 4,
    iconType: 'flask',
    number: 1,
    units: [
      {
        unitNumber: 1,
        title: 'Benzene and Its Derivatives',
        topicsCount: 7,
        topics: [
          'Analytical, synthetic and other evidence in the derivation of structure of benzene',
          'Orbital picture, resonance in benzene, Huckel’s rule of aromaticity (4n+2 pi electrons)',
          'Aromatic electrophilic substitution reactions: Nitration, Sulphonation, Halogenation',
          'Friedel-Crafts alkylation and Friedel-Crafts acylation: Mechanisms and limitations',
          'Orientation and reactivity in monosubstituted benzenes: Activating vs deactivating groups',
          'Ortho, para, and meta directing groups (resonance and inductive considerations)',
          'Structure and medicinal uses of DDT, Saccharin, BHC, and Chloramine-T'
        ],
        notesSummary: 'Arenium ion (sigma complex) intermediate mechanism, electrophilic substitution orientation guide, and synthetic benzene derivatives.'
      },
      {
        unitNumber: 2,
        title: 'Phenols, Aromatic Amines & Aromatic Acids',
        topicsCount: 7,
        topics: [
          'Phenols: Acidity, effect of substituents on acidity, qualitative tests',
          'Reactions of phenols: Kolbe-Schmitt reaction, Reimer-Tiemann reaction, Fries rearrangement',
          'Structure and medicinal uses of Phenol, Cresol, Resorcinol, Naphthols',
          'Aromatic amines: Basicity of aromatic amines, resonance stabilization of anilinium ion',
          'Diazotization reaction: Mechanism, preparation and synthetic applications of diazonium salts',
          'Aromatic acids: Acidity of benzoic acid, effect of ortho-, meta-, and para-substituents',
          'Reactions of benzoic acid and structure/uses of Salicylic acid, Acetylsalicylic acid (Aspirin)'
        ],
        notesSummary: 'Phenoxide resonance hybrid structures, Reimer-Tiemann dichlorocarbene mechanism, and sandmeyer diazonium replacement chemistry.'
      },
      {
        unitNumber: 3,
        title: 'Fats and Oils',
        topicsCount: 6,
        topics: [
          'Introduction, definition, occurrence and biological significance of fats and oils',
          'Fatty acids: Saturated and unsaturated fatty acids, triglycerides structure',
          'Chemical reactions: Hydrolysis, hydrogenation, saponification, rancidity of oils',
          'Analytical constants: Acid value (definition, principle, official determination procedure)',
          'Saponification value and Ester value: Definition, significance and calculation',
          'Iodine value and Reichert-Meissl (RM) value: Principles and significance in adulteration detection'
        ],
        notesSummary: 'Rancidity mechanisms (hydrolytic vs oxidative), iodine number calculation equations, and lipid analytical constants table.'
      },
      {
        unitNumber: 4,
        title: 'Polynuclear Hydrocarbons',
        topicsCount: 6,
        topics: [
          'Structure, nomenclature and resonance of polynuclear hydrocarbons',
          'Naphthalene: Haworth synthesis, electrophilic substitution (nitration, sulphonation)',
          'Anthracene: Synthesis, electrophilic substitution, oxidation and reduction reactions',
          'Phenanthrene: Synthesis, chemical reactions, structure and biological significance',
          'Diphenylmethane and Triphenylmethane: Preparation and chemical reactions',
          'Medicinal uses and carcinogenic properties of polynuclear aromatic hydrocarbons'
        ],
        notesSummary: 'Haworth naphthalene ring synthesis steps, anthracene 9,10-position reactivity, and benzopyrene carcinogenesis mechanism.'
      },
      {
        unitNumber: 5,
        title: 'Cycloalkanes',
        topicsCount: 6,
        topics: [
          'Classification, nomenclature, and general methods of preparation of cycloalkanes',
          'Chemical reactions of cyclopropane, cyclobutane, cyclopentane and cyclohexane',
          'Baeyer’s strain theory: Angle strain, ring stability, and limitations',
          'Coulson and Moffitt’s modification: Banana bonds / bent bonds in cyclopropane',
          'Sachse-Mohr’s theory of strainless rings: Chair and boat conformations of cyclohexane',
          'Conformational analysis of cyclohexane: Axial and equatorial bonds, 1,3-diaxial interactions'
        ],
        notesSummary: 'Baeyer angle strain formula (1/2 [109.5 - alpha]), chair-boat cyclohexane potential energy curve, and equatorial substituent preference.'
      }
    ]
  },
  {
    id: 'bp302t',
    semId: 3,
    code: 'BP302T',
    name: 'Physical Pharmaceutics – I',
    chaptersCount: 5,
    topicsCount: 35,
    credits: 4,
    iconType: 'beaker',
    number: 2,
    units: [
      {
        unitNumber: 1,
        title: 'Solubility of Drugs',
        topicsCount: 7,
        topics: [
          'Solubility expressions: Terms, solubility parameters, ideal and real solutions',
          'Solvation and association, Raoult’s law and deviations, Henry’s law',
          'Solubility of gas in liquids: Effect of temperature, pressure, chemical reactions',
          'Solubility of liquids in liquids: Ideal solution, binary solutions, partially miscible liquids',
          'Critical Solution Temperature (CST): Phenol-water, triethylamine-water, nicotine-water systems',
          'Distribution law (Nernst partition coefficient): Statement, limitations, and applications',
          'Solubility of solids in liquids: Factors affecting solubility, dissolution rate (Noyes-Whitney equation)'
        ],
        notesSummary: 'Noyes-Whitney dissolution equation breakdown, CST phase diagrams, and Nernst distribution law solvent extraction calculation.'
      },
      {
        unitNumber: 2,
        title: 'States of Matter & Physicochemical Properties',
        topicsCount: 7,
        topics: [
          'States of matter: Changes in state, latent heats, vapor pressure, sublimation critical point',
          'Eutectic mixtures: Principle, phase diagram of camphor-menthol, applications',
          'Gases, aerosols, liquids, liquid crystals (smectic, nematic, cholesteric)',
          'Glasses, solids: Amorphous vs crystalline solids, crystal habits and crystal forms',
          'Polymorphism: Enantiotropy, monotropy, analytical methods for polymorphism',
          'Physicochemical properties of drug molecules: Refractive index, molar refraction',
          'Dielectric constant, dipole moment, optical rotation, and polarimetry'
        ],
        notesSummary: 'Polymorphic drug bioavailability differences (Chloramphenicol palmitate), liquid crystal classification, and Abbe refractometer optical physics.'
      },
      {
        unitNumber: 3,
        title: 'Surface and Interfacial Phenomenon',
        topicsCount: 7,
        topics: [
          'Liquid interfaces: Surface and interfacial tensions, surface free energy',
          'Measurement of surface and interfacial tension: Capillary rise method, Drop count method, Du Nouy ring tensiometer',
          'Spreading coefficient: Definition, equations, condition for spreading',
          'Adsorption at liquid interfaces: Surface active agents (surfactants), classification',
          'Hydrophilic-Lipophilic Balance (HLB) scale, Griffin’s method of HLB determination',
          'Critical Micelle Concentration (CMC): Micelle formation, structure, factors affecting CMC',
          'Adsorption at solid interfaces: Freundlich and Langmuir adsorption isotherms'
        ],
        notesSummary: 'Du Nouy tensiometer capillary math, HLB surfactant classification wheel, and Langmuir monolayer adsorption derivation.'
      },
      {
        unitNumber: 4,
        title: 'Complexation and Protein Binding',
        topicsCount: 7,
        topics: [
          'Classification of complexes: Metal complexes, organic molecular complexes, inclusion complexes',
          'Inclusion compounds: Channel lattice type, cage / clathrate type, cyclodextrins in drug solubilization',
          'Methods of analysis of complexes: Continuous variation method (Job’s method), pH titration, distribution method',
          'Protein binding of drugs: Mechanism of binding, binding to human serum albumin (HSA) and alpha-1 acid glycoprotein',
          'Factors affecting protein-drug binding: Physicochemical properties, drug concentration, protein concentration',
          'Significance of protein binding on pharmacokinetics: Volume of distribution, elimination, drug-drug displacement interactions',
          'Kinetics of protein binding: Scatchard plot and Klotz plot'
        ],
        notesSummary: 'Cyclodextrin hydrophobic cavity host-guest chemistry, Scatchard plot binding constants math, and warfarin-NSAID displacement toxicity.'
      },
      {
        unitNumber: 5,
        title: 'pH, Buffers and Isotonic Solutions',
        topicsCount: 7,
        topics: [
          'Sorensen’s pH scale, pH determination methods: Electrometric and colorimetric',
          'Buffer action, Henderson-Hasselbalch equation for weak acid and weak base buffers',
          'Buffer capacity: Definition, Van Slyke equation, maximum buffer capacity',
          'Buffers in pharmaceutical and biological systems: Phosphate buffer, borate buffer, blood buffer systems',
          'Buffered isotonic solutions: Osmotic pressure, tonicity and physiological effects',
          'Methods of adjusting tonicity: Class I methods (Cryoscopic / Freezing point depression, Sodium chloride equivalent method)',
          'Class II methods: White-Vincent method and Sprowls method for isotonicity adjustment'
        ],
        notesSummary: 'Van Slyke buffer capacity calculations, freezing point depression 0.52 degree C formula, and White-Vincent isotonic volume steps.'
      }
    ]
  },
  {
    id: 'bp303t',
    semId: 3,
    code: 'BP303T',
    name: 'Pharmaceutical Microbiology',
    chaptersCount: 5,
    topicsCount: 36,
    credits: 4,
    iconType: 'bug',
    number: 3,
    units: [
      {
        unitNumber: 1,
        title: 'Introduction, Microscopy & Cultivation of Bacteria',
        topicsCount: 8,
        topics: [
          'History and scope of microbiology, contributions of Antonie van Leeuwenhoek, Louis Pasteur, Robert Koch',
          'Diversity of microorganisms: Bacteria, viruses, fungi, protozoa, actinomycetes',
          'Bacterial cell anatomy: Cell wall (Gram-positive vs Gram-negative), capsule, flagella, pili, endospores',
          'Microscopy: Principles of Phase Contrast, Darkfield, Fluorescence, and Electron Microscopy (TEM, SEM)',
          'Nutritional requirements of bacteria, culture media classification (synthetic, enriched, selective, differential)',
          'Cultivation of aerobic and anaerobic bacteria (Brewer jar, anaerobic chamber)',
          'Bacterial growth curve: Lag, Log/Exponential, Stationary, and Death phases',
          'Physical and chemical factors affecting microbial growth: Temperature, pH, osmotic pressure, oxygen'
        ],
        notesSummary: 'Gram-positive vs Gram-negative cell wall peptidoglycan peptidomics, bacterial growth curve mathematical kinetics, and electron microscopy physics.'
      },
      {
        unitNumber: 2,
        title: 'Identification, Disinfection & Sterilization',
        topicsCount: 8,
        topics: [
          'Identification of bacteria: Staining techniques (Simple, Gram staining, Acid-fast / Ziehl-Neelsen, Endospore staining)',
          'Biochemical tests for bacterial identification: IMViC tests, Catalase, Oxidase, Urease tests',
          'Disinfectants, antiseptics and sanitizers: Definitions and classification',
          'Mechanisms of action of disinfectants: Protein denaturation, membrane disruption, alkylation',
          'Evaluation of disinfectants: Phenol coefficient method (Rideal-Walker, Chick-Martin test)',
          'Sterilization: Principles and methods - Moist heat sterilization (Autoclave, parameters: 121 C, 15 psi, 15 min)',
          'Dry heat sterilization (Hot Air Oven, 160 C, 2 hr), mechanism, sterilization indicators',
          'Radiation sterilization (Gamma rays, UV), Gaseous sterilization (Ethylene oxide), and Filtration (HEPA, Membrane filters)'
        ],
        notesSummary: 'Gram stain 4-step chemical mechanism, Rideal-Walker phenol coefficient calculation, and thermal death time (D-value, Z-value, F-value).'
      },
      {
        unitNumber: 3,
        title: 'Fungi, Viruses & Sterility Testing',
        topicsCount: 7,
        topics: [
          'Morphology, classification and reproduction of fungi (Yeasts, Molds, Dermatophytes)',
          'Cultivation of fungi, Sabouraud Dextrose Agar (SDA), pharmaceutical significance of fungi',
          'Viruses: Structure, viral symmetry (icosahedral, helical, complex), bacteriophages (lytic and lysogenic cycle)',
          'Cultivation of human viruses: Animal inoculation, embryonated eggs, cell culture techniques',
          'Sterility testing: Principles, official IP/BP procedures for sterile pharmaceutical products',
          'Methodology: Membrane filtration method and Direct inoculation method',
          'Culture media for sterility testing: Fluid Thioglycollate Medium (FTM) and Soybean Casein Digest Medium (SCDM)'
        ],
        notesSummary: 'Bacteriophage lytic vs lysogenic genetic integration, official IP sterility test protocols, and FTM/SCDM incubation conditions.'
      },
      {
        unitNumber: 4,
        title: 'Aseptic Area & Microbial Limit Tests',
        topicsCount: 6,
        topics: [
          'Design and layout of aseptic area, Cleanroom classification (Grade A, B, C, D / ISO classes)',
          'Sources of microbial contamination in aseptic area and prevention methods',
          'Laminar Airflow Units (LAF): Horizontal vs vertical flow, HEPA filter efficiency (99.97% of 0.3 micron)',
          'Environmental monitoring: Settle plate method, air sampling, surface swabbing, glove print test',
          'Microbial Limit Tests (MLT): Total Aerobic Microbial Count (TAMC), Total Yeast and Mold Count (TYMC)',
          'Testing for specified objectionable microorganisms: E. coli, Salmonella, Pseudomonas aeruginosa, S. aureus'
        ],
        notesSummary: 'HEPA filter dioctyl phthalate (DOP) smoke challenge testing, cleanroom pressure differential cascades, and MLT test pathways.'
      },
      {
        unitNumber: 5,
        title: 'Microbial Assays & Preservative Efficacy',
        topicsCount: 7,
        topics: [
          'Principles of microbiological assays of antibiotics, vitamins and amino acids',
          'Cylinder-plate method (Cup-plate method) and Turbidimetric method',
          'Assay of official antibiotics: Penicillin, Streptomycin, Tetracycline (standard curves)',
          'Assessment of microbiological stability of formulations',
          'Preservative efficacy testing: Challenge test methodology, log reduction requirements',
          'Microbial spoilage of pharmaceuticals: Types of spoilage, sources, and consequences',
          'Animal cell culture: Media, primary culture, secondary culture, cell lines and pharmaceutical applications'
        ],
        notesSummary: 'Antibiotic zone of inhibition 2-point vs 3-point assay math, antimicrobial preservative challenge criteria, and cell culture cryopreservation.'
      }
    ]
  },
  {
    id: 'bp304t',
    semId: 3,
    code: 'BP304T',
    name: 'Pharmaceutical Engineering',
    chaptersCount: 5,
    topicsCount: 30,
    credits: 4,
    iconType: 'cog',
    number: 4,
    units: [
      {
        unitNumber: 1,
        title: 'Flow of Fluids, Size Reduction & Size Separation',
        topicsCount: 6,
        topics: [
          'Flow of fluids: Types of manometers, Reynolds number and its significance',
          'Bernoulli’s theorem and its applications, energy losses in fluid flow',
          'Measurement of fluid flow: Orifice meter, Venturi meter, Pitot tube, Rotameter',
          'Size reduction: Mechanisms, laws governing energy requirements (Rittinger’s, Kick’s, Bond’s law)',
          'Factors affecting size reduction, working and construction of Hammer mill, Ball mill, Fluid energy mill',
          'Size separation: Official standards of powders, sieves, sieve shaker, Cyclone separator, Air separator'
        ],
        notesSummary: 'Bernoulli energy balance equations, Hammer vs Ball vs Fluid energy mill mechanism comparisons, and Tyler sieve mesh standards.'
      },
      {
        unitNumber: 2,
        title: 'Heat Transfer & Evaporation',
        topicsCount: 6,
        topics: [
          'Heat transfer: Conduction (Fourier’s law), Convection (film coefficient), Radiation (Stefan-Boltzmann law)',
          'Heat exchangers: Shell and tube heat exchanger, double pipe heat exchanger',
          'Evaporation: Basic concepts, factors affecting rate of evaporation',
          'Steam jackets, working and construction of Evaporating pan, Horizontal tube evaporator',
          'Climbing film evaporator, Forced circulation evaporator, Multiple effect evaporator',
          'Economy of multiple effect evaporators, vapor recompression systems'
        ],
        notesSummary: 'Fourier heat conduction mathematical formula, overall heat transfer coefficient, and multiple effect evaporator steam economy.'
      },
      {
        unitNumber: 3,
        title: 'Distillation & Drying',
        topicsCount: 6,
        topics: [
          'Distillation: Raoult’s law, volatility, relative volatility, phase equilibria',
          'Simple distillation, Fractional distillation (fractionating columns), Steam distillation',
          'Vacuum distillation, Molecular distillation: Principle, wiped film evaporator',
          'Drying: Theory of drying, Loss on Drying (LOD), Equilibrium moisture content, drying rate curve',
          'Working, construction and applications of Tray dryer, Fluidized Bed Dryer (FBD)',
          'Spray dryer, Freeze dryer (Lyophilizer): Sublimation principle, triple point of water'
        ],
        notesSummary: 'McCabe-Thiele distillation column plate calculation, freeze dryer shelf temperature/pressure cycle, and FBD drying rate stages.'
      },
      {
        unitNumber: 4,
        title: 'Filtration & Centrifugation',
        topicsCount: 6,
        topics: [
          'Filtration: Mechanism of filtration, theory of filtration, Darcy’s equation, Poiseuille’s equation',
          'Filter media and Filter aids (Diatomite, Perlite, Cellulose): Properties and applications',
          'Working and construction of Plate and Frame filter press, Rotary drum vacuum filter',
          'Cartridge filter, Membrane filter, Metafilter, Seiditz filter',
          'Centrifugation: Principles, centrifugal effect, sedimentation vs filtration centrifuges',
          'Perforated basket centrifuge, Non-perforated centrifuge, Semi-continuous centrifuge, Supercentrifuge'
        ],
        notesSummary: 'Darcy filter cake resistance derivation, Plate & Frame vs Rotary vacuum filter comparison, and centrifugal separation G-force equations.'
      },
      {
        unitNumber: 5,
        title: 'Materials of Construction & Corrosion',
        topicsCount: 6,
        topics: [
          'Materials of construction: Factors affecting selection of plant construction materials',
          'Ferrous metals: Cast iron, wrought iron, carbon steel, Stainless steel grades (SS 304, SS 316, SS 316L)',
          'Non-ferrous metals: Copper, aluminum, lead, nickel and alloys',
          'Non-metals: Glass (borosilicate glass, neutral glass), plastics, rubber',
          'Corrosion: Types of corrosion (electrochemical, galvanic, pitting, intergranular, stress corrosion)',
          'Theories of corrosion, prevention and control: Cathodic protection, coatings, corrosion inhibitors'
        ],
        notesSummary: 'SS 316L molybdenum pharmaceutical grade metallurgy, galvanic cell corrosion potential series, and sacrificial anode cathodic protection.'
      }
    ]
  },

  // ================= SEMESTER 4 =================
  {
    id: 'bp401t',
    semId: 4,
    code: 'BP401T',
    name: 'Pharmaceutical Organic Chemistry – III',
    chaptersCount: 5,
    topicsCount: 28,
    credits: 4,
    iconType: 'flask',
    number: 1,
    units: [
      {
        unitNumber: 1,
        title: 'Optical Isomerism',
        topicsCount: 6,
        topics: [
          'Optical activity, enantiomerism, diastereomers, meso compounds, racemic modifications',
          'Elements of symmetry: Plane of symmetry, center of symmetry, alternating axis of symmetry',
          'Chirality, chiral center, asymmetric carbon atom, prochirality',
          'Nomenclature of stereoisomers: D/L configuration and Cahn-Ingold-Prelog (CIP) R/S priority rules',
          'Optical isomerism in compounds without chiral carbon: Biphenyls (atropisomerism), allenes, spiranes',
          'Methods of resolution of racemic mixtures: Mechanical, biochemical, chemical resolution'
        ],
        notesSummary: 'CIP R/S assigning steps, Fischer vs Newman projections, and diastereomeric salt resolution chemistry.'
      },
      {
        unitNumber: 2,
        title: 'Geometrical & Conformational Isomerism',
        topicsCount: 5,
        topics: [
          'Geometrical isomerism: Origin, cis-trans isomerism, syn-anti isomerism in oximes',
          'E/Z system of nomenclature for alkenes based on CIP priority rules',
          'Methods of determination of configuration of geometrical isomers',
          'Conformational isomerism: Difference between configuration and conformation',
          'Conformational analysis of ethane, propane, n-butane, and monosubstituted cyclohexanes'
        ],
        notesSummary: 'E/Z geometric designation rules, n-butane dihedral potential energy diagram, and cyclohexane equatorial stability.'
      },
      {
        unitNumber: 3,
        title: 'Heterocyclic Chemistry: 5-Membered Rings',
        topicsCount: 5,
        topics: [
          'Nomenclature and classification of heterocyclic compounds (Hantzsch-Widman system)',
          'Pyrrole: Synthesis (Paal-Knorr synthesis), aromatic character, electrophilic substitution reactions',
          'Furan: Synthesis, resonance, chemical reactions, conversion to furfural',
          'Thiophene: Synthesis, aromaticity, comparison of reactivity (Pyrrole > Furan > Thiophene > Benzene)',
          'Medicinal compounds containing 5-membered heterocyclic rings'
        ],
        notesSummary: 'Paal-Knorr 1,4-dicarbonyl cyclization mechanisms, pyrrole alpha-position electrophilic preference, and aromaticity order.'
      },
      {
        unitNumber: 4,
        title: 'Heterocyclic Chemistry: 6-Membered Rings & Condensed Rings',
        topicsCount: 6,
        topics: [
          'Pyridine: Structure, resonance, aromaticity, basicity compared to aliphatic amines and pyrrole',
          'Reactions of pyridine: Electrophilic substitution at 3-position, Nucleophilic substitution (Chichibabin reaction)',
          'Quinoline and Isoquinoline: Skraup synthesis, Bischler-Napieralski synthesis, chemical reactions',
          'Indole: Fischer indole synthesis and chemical reactivity',
          'Imidazole and Pyrazole: Synthesis, aromatic character, and biological significance',
          'Purine and Pyrimidine: Structure, synthesis, and medicinal importance in nucleic acid antimetabolites'
        ],
        notesSummary: 'Pyridine Chichibabin amination mechanism, Skraup quinoline synthesis steps, and purine/pyrimidine nitrogen basicities.'
      },
      {
        unitNumber: 5,
        title: 'Reactions of Synthetic Importance',
        topicsCount: 6,
        topics: [
          'Beckmann rearrangement: Mechanism, migration aptitude, and industrial synthesis of caprolactam',
          'Schmidt reaction: Carboxylic acid conversion to amines via acyl azide intermediate',
          'Clemmensen reduction (Zn-Hg / HCl) vs Wolff-Kishner reduction (Hydrazine / Base)',
          'Birch reduction: Dissolving metal reduction of aromatic rings to 1,4-cyclohexadienes',
          'Michael addition reaction and Claisen-Schmidt condensation',
          'Oppenauer oxidation of secondary alcohols to ketones and Dakin reaction'
        ],
        notesSummary: 'Beckmann anti-periplanar migration stereochemistry, Birch reduction electron transfer mechanism, and Clemmensen vs Wolff-Kishner conditions.'
      }
    ]
  },
  {
    id: 'bp402t',
    semId: 4,
    code: 'BP402T',
    name: 'Medicinal Chemistry – I',
    chaptersCount: 5,
    topicsCount: 38,
    credits: 4,
    iconType: 'capsule',
    number: 2,
    units: [
      {
        unitNumber: 1,
        title: 'Introduction & Physicochemical Properties',
        topicsCount: 7,
        topics: [
          'History and development of medicinal chemistry',
          'Physicochemical properties in relation to biological action: Ionization, pKa, pH partition hypothesis',
          'Partition coefficient (log P), Ferguson’s principle, and solubility',
          'Hydrogen bonding, protein binding, chelation, and redox potential in drug action',
          'Bioisosterism: Classical and non-classical bioisosteres with medicinal examples',
          'Drug metabolism (Biotransformation): Phase I reactions (Oxidation, Reduction, Hydrolysis, Cytochrome P450)',
          'Phase II reactions: Glucuronidation, Sulfation, Glycine conjugation, Glutathione conjugation, Acetylation, Methylation'
        ],
        notesSummary: 'Hansch lipophilicity equations, Phase I vs Phase II metabolic enzymes, and bioisosteric replacement design rules.'
      },
      {
        unitNumber: 2,
        title: 'Drugs Acting on Autonomic Nervous System: Adrenergic',
        topicsCount: 8,
        topics: [
          'Biosynthesis, storage, release and catabolism of Catecholamines (Epinephrine, Norepinephrine, Dopamine)',
          'Adrenergic receptors: Alpha-1, Alpha-2, Beta-1, Beta-2, Beta-3 distribution and second messengers',
          'Structure-Activity Relationships (SAR) of beta-phenylethylamines / Sympathomimetics',
          'Direct acting sympathomimetics: Epinephrine, Norepinephrine, Phenylephrine, Salbutamol, Terbutaline, Clonidine',
          'Indirect and mixed acting sympathomimetics: Ephedrine, Pseudoephedrine, Amphetamine',
          'Adrenergic antagonists (Alpha blockers): Tolazoline, Phentolamine, Phenoxybenzamine, Prazosin',
          'Adrenergic antagonists (Beta blockers): Propranolol, Atenolol, Metoprolol, Timolol, Labetalol',
          'Chemical synthesis of: Phenylephrine, Salbutamol, Tolazoline, Propranolol'
        ],
        notesSummary: 'Adrenergic phenylethylamine SAR rules, alpha-1 vs beta-2 selectivity structural modifications, and Propranolol synthesis scheme.'
      },
      {
        unitNumber: 3,
        title: 'Drugs Acting on Autonomic Nervous System: Cholinergic',
        topicsCount: 8,
        topics: [
          'Biosynthesis, storage, release and enzymatic hydrolysis of Acetylcholine (AChE)',
          'Cholinergic receptors: Muscarinic (M1, M2, M3, M4, M5) and Nicotinic (Nm, Nn)',
          'Structure-Activity Relationships (SAR) of Parasympathomimetic agents',
          'Direct acting cholinergic agonists: Acetylcholine, Methacholine, Carbachol, Bethanechol, Pilocarpine',
          'Indirect acting cholinergic agonists (Reversible AChE inhibitors): Physostigmine, Neostigmine, Pyridostigmine, Donepezil',
          'Irreversible AChE inhibitors: Organophosphates (Isoflurophate, Echothiophate, Malathion), Cholinesterase reactivators (Pralidoxime)',
          'Cholinergic antagonists (Antimuscarinics): Atropine, Scopolamine, Homatropine, Ipratropium, Dicyclomine, Tropicamide',
          'Chemical synthesis of: Neostigmine, Dicyclomine, Ipratropium bromide'
        ],
        notesSummary: 'Ing’s 5-atom rule for muscarinic agonists, organophosphate aging mechanism, and atropine competitive receptor blockade SAR.'
      },
      {
        unitNumber: 4,
        title: 'Drugs Acting on Central Nervous System: Sedatives & Antipsychotics',
        topicsCount: 8,
        topics: [
          'Sedatives and Hypnotics: Classification, Benzodiazepines vs Barbiturates',
          'GABA-A receptor chloride channel complex and allosteric modulation mechanism',
          'SAR of Barbiturates (5,5-disubstituted barbituric acid derivatives)',
          'SAR of Benzodiazepines (1,4-benzodiazepine-2-ones): Diazepam, Oxazepam, Lorazepam, Alprazolam',
          'Antipsychotics / Neuroleptics: Dopamine D2 receptor blockade hypothesis',
          'SAR of Phenothiazines: Chlorpromazine, Promazine, Triflupromazine, Fluphenazine',
          'Ring analogues of phenothiazines: Thioxanthenes, Butyrophenones (Haloperidol), Atypical antipsychotics (Clozapine, Risperidone)',
          'Chemical synthesis of: Diazepam, Chlordiazepoxide, Chlorpromazine, Haloperidol'
        ],
        notesSummary: '1,4-Benzodiazepine ring numbering and substituent SAR, phenothiazine aliphatic vs piperazine side chains, and Diazepam synthesis.'
      },
      {
        unitNumber: 5,
        title: 'Anticonvulsants, Anesthetics & Opioid Analgesics',
        topicsCount: 7,
        topics: [
          'Anticonvulsants: Mechanism of action, sodium channel blockers, GABA enhancers, T-type calcium channel blockers',
          'SAR of Hydantoins (Phenytoin), Oxazolidinediones, Succinimides (Ethosuximide), Barbiturates (Phenobarbital)',
          'General Anesthetics: Inhalation anesthetics (Halothane, Isoflurane), Intravenous anesthetics (Ketamine, Propofol)',
          'Local Anesthetics: Classification (Benzoic acid esters, Anilides), SAR of Local Anesthetics (Procaine, Lidocaine)',
          'Opioid Analgesics: Morphine structure, peripheral vs central effects, mu, delta, kappa opioid receptors',
          'SAR of Morphine analogues: Codeine, Heroin, Meperidine, Methadone, Fentanyl, Opioid antagonists (Naloxone, Naltrexone)',
          'Chemical synthesis of: Phenytoin, Ethosuximide, Procaine, Lidocaine'
        ],
        notesSummary: 'Morphine structure reduction to Meperidine/Methadone SAR, Lidocaine anilide amide stability, and Phenytoin hydantoin synthesis.'
      }
    ]
  },
  {
    id: 'bp403t',
    semId: 4,
    code: 'BP403T',
    name: 'Physical Pharmaceutics – II',
    chaptersCount: 5,
    topicsCount: 32,
    credits: 4,
    iconType: 'pulse',
    number: 3,
    units: [
      {
        unitNumber: 1,
        title: 'Colloidal Dispersions',
        topicsCount: 7,
        topics: [
          'Colloids: Definition, classification (Lyophilic, Lyophobic, Association colloids)',
          'Comparison of properties between true solutions, colloidal dispersions and coarse suspensions',
          'Optical properties of colloids: Tyndall effect, light scattering, ultramicroscopy',
          'Kinetic properties: Brownian movement, diffusion, sedimentation, osmotic pressure',
          'Electrical properties: Electrical double layer (Stern layer, Gouy-Chapman layer), Zeta potential and Nernst potential',
          'Stability of colloidal systems: DLVO theory (attractive van der Waals vs electrostatic repulsion)',
          'Sensitization, protective colloids, Gold number and pharmaceutical applications of colloids'
        ],
        notesSummary: 'Stern potential vs Zeta potential diagram, DLVO potential energy barrier curve, and Gold number protective efficiency values.'
      },
      {
        unitNumber: 2,
        title: 'Rheology & Deformation of Solids',
        topicsCount: 6,
        topics: [
          'Rheology: Introduction, Newtonian systems, Newton’s law of flow, dynamic and kinematic viscosity',
          'Non-Newtonian systems: Plastic flow (Bingham bodies, yield value), Pseudoplastic flow (shear thinning), Dilatant flow (shear thickening)',
          'Thixotropy: Definition, measurement, hysteresis loop, negative thixotropy / antithixotropy',
          'Determination of viscosity: Capillary viscometer (Ostwald), Falling sphere viscometer, Rotational viscometers (Cup & Bob, Cone & Plate)',
          'Deformation of solids: Hooke’s law of elasticity, Young’s modulus, plasticity, viscoelasticity',
          'Heckel plots and applications of rheology in pharmacy (packaging, syringeability, skin spreadability)'
        ],
        notesSummary: 'Rheograms (shear stress vs shear rate) for plastic, pseudoplastic, dilatant fluids, thixotropic loops, and Brookfield viscometer operation.'
      },
      {
        unitNumber: 3,
        title: 'Coarse Dispersions (Suspensions & Emulsions)',
        topicsCount: 6,
        topics: [
          'Suspensions: Interfacial properties of suspended particles, thermodynamic instability',
          'Flocculated vs deflocculated suspensions: Sedimentation behavior, caking, redispersibility comparison table',
          'Formulation of suspensions: Wetting agents, controlled flocculation, rheological modifiers',
          'Evaluation of suspensions: Sedimentation volume (F), degree of flocculation (Beta), electrokinetic methods',
          'Emulsions: Theories of emulsification, surface tension theory, oriented wedge theory, interfacial film theory',
          'Stability of emulsions: Creaming, sedimentation, coalescence, breaking/cracking, phase inversion'
        ],
        notesSummary: 'Sedimentation volume F = Vu / Vo formula, controlled flocculation with electrolytes, and Stokes law droplet velocity calculations.'
      },
      {
        unitNumber: 4,
        title: 'Micromeritics',
        topicsCount: 6,
        topics: [
          'Micromeritics: Definition, importance in pharmacy (dissolution, flowability, dose uniformity)',
          'Particle size and distribution: Feret diameter, Martin diameter, projected area diameter, average particle size formulas',
          'Methods for determining particle size: Optical microscopy, sieving, sedimentation (Andreason pipette), laser diffraction',
          'Particle surface area: Specific surface area, adsorption method (BET equation), air permeability method (Fisher subsieve sizer)',
          'Derived properties of powders: True density, granule density, bulk density, porosity, packing arrangements',
          'Flow properties of powders: Angle of repose, Carr’s compressibility index, Hausner’s ratio'
        ],
        notesSummary: 'Andreasen pipette sedimentation sampling math, Carr’s index flowability rating scale, and BET nitrogen adsorption surface area.'
      },
      {
        unitNumber: 5,
        title: 'Drug Stability & Chemical Kinetics',
        topicsCount: 7,
        topics: [
          'Chemical kinetics: Reaction rate, order of reaction (Zero order, First order, Pseudo-first order, Second order)',
          'Rate equations, integrated rate laws, units of rate constants, and half-life (t1/2) calculations',
          'Determination of order of reaction: Substitution method, graphical method, half-life method',
          'Physical and chemical degradation pathways of drugs: Hydrolysis, oxidation, photolysis, racemization',
          'Preventive measures against degradation: Antioxidants, chelating agents, light protection, desiccant packaging',
          'Accelerated stability testing: Arrhenius equation, activation energy (Ea), prediction of shelf life (t90)',
          'ICH guidelines for stability testing of drug substances and drug products (Q1A to Q1E climatic zones)'
        ],
        notesSummary: 'Zero vs 1st order rate equations derivation, Arrhenius plot extrapolation of shelf life t90, and ICH stability zones table.'
      }
    ]
  },
  {
    id: 'bp404t',
    semId: 4,
    code: 'BP404T',
    name: 'Pharmacology – I',
    chaptersCount: 5,
    topicsCount: 42,
    credits: 4,
    iconType: 'shield',
    number: 4,
    units: [
      {
        unitNumber: 1,
        title: 'General Pharmacology: Pharmacokinetics',
        topicsCount: 9,
        topics: [
          'Introduction to pharmacology: Scope, history, sources of drugs, routes of drug administration (advantages & disadvantages)',
          'Pharmacokinetics: Biological membranes and mechanisms of drug transfer (passive diffusion, carrier mediated, pinocytosis)',
          'Drug absorption: Factors affecting absorption, bioavailability and bioequivalence, first-pass metabolism',
          'Drug distribution: Apparent volume of distribution (Vd), plasma protein binding, blood-brain barrier, placental barrier',
          'Drug biotransformation / metabolism: Phase I and Phase II reactions, microsomal enzyme induction and inhibition',
          'Drug excretion: Renal excretion (glomerular filtration, tubular secretion/reabsorption), biliary excretion, enterohepatic recycling',
          'Pharmacokinetic parameters: Half-life (t1/2), clearance (CL), steady-state concentration (Css), loading dose, maintenance dose',
          'Therapeutic drug monitoring (TDM): Indications and clinical significance',
          'Drug dosage regimens and pediatric/geriatric dosage adjustments'
        ],
        notesSummary: 'First pass hepatic extraction math, Vd and clearance formulas, enzyme inducers (Rifampicin, Phenytoin) vs inhibitors (Cimetidine, Ketoconazole).'
      },
      {
        unitNumber: 2,
        title: 'General Pharmacology: Pharmacodynamics',
        topicsCount: 8,
        topics: [
          'Principles of drug action: Non-receptor mediated mechanisms (physical, chemical, enzyme inhibition, ion channels)',
          'Receptor-mediated mechanisms: Concept of receptors, drug-receptor interactions, affinity, efficacy, potency',
          'Major receptor families: G-protein coupled receptors (GPCR), ion-channel linked, kinase-linked, nuclear receptors',
          'Second messengers: Adenylyl cyclase - cAMP pathway, Phospholipase C - IP3/DAG pathway, cGMP, Calcium',
          'Dose-Response Relationships: Graded and quantal dose-response curves, ED50, LD50, Therapeutic Index, Margin of safety',
          'Receptor antagonism: Competitive vs non-competitive antagonism (surmountable vs insurmountable)',
          'Adverse drug effects: Side effects, toxic effects, allergic reactions, idiosyncrasy, teratogenicity, carcinogenicity',
          'Drug tolerance, dependence (physical & psychological), tachyphylaxis, and drug interactions'
        ],
        notesSummary: 'GPCR Gs/Gi/Gq protein signaling cascades, parallel shift in competitive antagonism DRC, and therapeutic index calculation.'
      },
      {
        unitNumber: 3,
        title: 'Pharmacology of Peripheral Nervous System',
        topicsCount: 8,
        topics: [
          'Neurohumoral transmission in peripheral nervous system: Synthesis, storage, release, and termination of ACh and NE',
          'Parasympathomimetics / Cholinergic drugs: Direct acting (Pilocarpine, Bethanechol) and indirect acting (Neostigmine, Donepezil)',
          'Organophosphate poisoning: SLUDGE symptoms, diagnosis, and management with Atropine and Pralidoxime',
          'Parasympatholytics / Anticholinergics: Atropine, Glycopyrrolate, Ipratropium, Dicyclomine (indications & toxicity)',
          'Sympathomimetics / Adrenergic agonists: Epinephrine, Norepinephrine, Dopamine, Dobutamine, Salbutamol, Clonidine',
          'Sympatholytics: Alpha blockers (Prazosin, Phenoxybenzamine) and Beta blockers (Propranolol, Metoprolol, Atenolol)',
          'Neuromuscular blocking agents: Depolarizing (Succinylcholine) and Non-depolarizing (d-Tubocurarine, Atracurium)',
          'Local anesthetics: Mechanism of action (voltage-gated Na+ channels), pharmacokinetics, and clinical toxicity'
        ],
        notesSummary: 'SLUDGE organophosphate toxicity mnemonic, Atropine pharmacological profile, and Succinylcholine phase I/II block.'
      },
      {
        unitNumber: 4,
        title: 'Pharmacology of Central Nervous System: Sedatives & Antidepressants',
        topicsCount: 9,
        topics: [
          'Neurohumoral transmission in CNS: Excitatory (Glutamate, Aspartate) and Inhibitory (GABA, Glycine) transmitters',
          'General anesthetics: Inhalation agents (Halothane, Sevoflurane, Nitrous oxide), IV agents (Propofol, Ketamine, Thiopental)',
          'Stages of anesthesia (Guedel’s classification) and pre-anesthetic medication',
          'Sedatives and Hypnotics: Benzodiazepines, Barbiturates, Z-drugs (Zolpidem), melatonin receptor agonists',
          'Antiepileptics / Anticonvulsants: Phenytoin, Carbamazepine, Valproic acid, Ethosuximide, Levetiracetam',
          'Antipsychotics / Neuroleptics: Typical (Chlorpromazine, Haloperidol) vs Atypical (Risperidone, Olanzapine, Clozapine)',
          'Extrapyramidal side effects of antipsychotics and neuroleptic malignant syndrome',
          'Antidepressants: SSRIs (Fluoxetine, Sertraline), SNRIs, TCAs (Amitriptyline), MAO inhibitors, atypical antidepressants',
          'Pharmacotherapy of Bipolar disorder: Lithium mechanism, toxicity, and therapeutic monitoring'
        ],
        notesSummary: 'Guedel surgical anesthesia stages, GABA-A receptor channel gating kinetics, and SSRI serotonin syndrome symptoms.'
      },
      {
        unitNumber: 5,
        title: 'Analgesics, Anti-Parkinsonian & CNS Stimulants',
        topicsCount: 8,
        topics: [
          'Opioid Analgesics: Morphine pharmacology, analgesia, respiratory depression, constipation, miosis, tolerance, addiction',
          'Other opioids: Codeine, Fentanyl, Pethidine, Methadone, Tramadol, Opioid antagonists (Naloxone)',
          'Acute opioid toxicity (Pinpoint pupils, coma, respiratory depression) and withdrawal syndrome',
          'Pharmacotherapy of Parkinson’s disease: Levodopa + Carbidopa (mechanism of peripheral decarboxylase inhibition)',
          'Dopamine agonists (Bromocriptine, Pramipexole), MAO-B inhibitors (Selegiline), COMT inhibitors (Entacapone)',
          'Pharmacotherapy of Alzheimer’s disease: Cholinesterase inhibitors (Donepezil, Rivastigmine), NMDA blocker (Memantine)',
          'CNS stimulants: Caffeine, Theophylline, Methylphenidate, Amphetamines and Nootropics (Piracetam)',
          'Drug abuse, addiction, dependence and rehabilitation pharmacotherapy'
        ],
        notesSummary: 'Morphine triad toxicity treatment with IV Naloxone, Levodopa on-off phenomenon, and Carbidopa metabolic sparing mechanism.'
      }
    ]
  },
  {
    id: 'bp405t',
    semId: 4,
    code: 'BP405T',
    name: 'Pharmacognosy and Phytochemistry – I',
    chaptersCount: 5,
    topicsCount: 30,
    credits: 4,
    iconType: 'leaf',
    number: 5,
    units: [
      {
        unitNumber: 1,
        title: 'Introduction & Classification of Crude Drugs',
        topicsCount: 6,
        topics: [
          'Definition, history, scope and development of pharmacognosy',
          'Sources of crude drugs: Plants, animals, marine, minerals and microorganisms',
          'Organized vs unorganized crude drugs with official examples',
          'Classification of crude drugs: Alphabetical, morphological, taxonomical, chemical, pharmacological, and chemotaxonomical',
          'Advantages and limitations of each crude drug classification system',
          'Quality control of crude drugs: Adulteration (intentional, unintentional) and drug evaluation parameters'
        ],
        notesSummary: 'Organized vs unorganized crude drug characteristics, official botanical taxonomy, and crude drug adulteration types.'
      },
      {
        unitNumber: 2,
        title: 'Cultivation, Collection & Processing of Crude Drugs',
        topicsCount: 6,
        topics: [
          'Cultivation of medicinal plants: Advantages over wild collection, factors affecting cultivation',
          'Exogenous factors: Altitude, temperature, rainfall, soil fertility, fertilizers, pest control',
          'Endogenous factors: Genetic variation, hybridization, mutation, polyploidy',
          'Collection, harvesting and post-harvest processing of crude drugs: Drying (sun, shade, tray, vacuum drying)',
          'Garbling, packaging and storage conditions of crude drugs to prevent deterioration',
          'Quality evaluation of crude drugs: Organoleptic, microscopic, physical, chemical, and biological evaluation'
        ],
        notesSummary: 'Lycopodium spore method quantitative microscopy math, stomatal index calculation, and ash value analytical procedures.'
      },
      {
        unitNumber: 3,
        title: 'Plant Tissue Culture',
        topicsCount: 6,
        topics: [
          'Historical development and principles of plant tissue culture (Totipotency, Cellular differentiation)',
          'Nutritional requirements of plant tissue culture: Murashige & Skoog (MS) medium components',
          'Plant growth hormones in PTC: Auxins (NAA, 2,4-D), Cytokinins (BAP, Kinetin) ratio for organogenesis',
          'Types of plant tissue cultures: Callus culture, cell suspension culture, organ culture, protoplast culture',
          'Applications of plant tissue culture: Micropropagation, somaclonal variation, transgenic plant generation',
          'Production of secondary metabolites in plant cell cultures: Elicitation, biotransformation, and bioreactors'
        ],
        notesSummary: 'Totipotency biological theory, MS basal media formulation, and auxin-to-cytokinin organogenesis ratio rules.'
      },
      {
        unitNumber: 4,
        title: 'Traditional Systems of Medicine & Primary Metabolites',
        topicsCount: 6,
        topics: [
          'Introduction to alternative and complementary systems of medicine: Ayurveda, Siddha, Unani, Homeopathy (AYUSH)',
          'Basic principles and diagnostic methods of Ayurvedic medicine: Tridosha theory (Vata, Pitta, Kapha), Panchamahabhuta',
          'Homeopathic principles: Law of Similars, potentization / dilution scales',
          'Primary metabolites in pharmacy: Carbohydrates and derived products: Acacia, Tragacanth, Agar, Honey',
          'Lipids: Castor oil, Chaulmoogra oil, Wool fat, Beeswax - Source, chemistry, uses',
          'Marine pharmacognosy: Novel bioactive molecules from marine flora and fauna (Sponges, coral, marine toxins)'
        ],
        notesSummary: 'Tridosha Ayurvedic constitution theory, Agar microbial nutrient solidifying chemistry, and marine anticancer molecules.'
      },
      {
        unitNumber: 5,
        title: 'Plant Secondary Metabolites',
        topicsCount: 6,
        topics: [
          'Definition, occurrence, general properties, and classification of plant secondary metabolites',
          'Alkaloids: Definition, chemical classification (True, Proto, Pseudo-alkaloids), chemical tests (Mayer, Wagner, Dragendorff, Hager)',
          'Glycosides: Definition, classification (Cardiac, Anthraquinone, Saponin, Cyanogenetic, Flavonoid), chemical tests (Borntrager, Keller-Kiliani)',
          'Tannins: Hydrolyzable vs condensed tannins, Goldbeater’s skin test, gelatin test',
          'Resins and resin combinations: Oleoresins, gum resins, oleo-gum resins, balsams with examples',
          'Volatile oils: Chemistry (Terpenes), methods of extraction (steam distillation, enfleurage, expression)'
        ],
        notesSummary: 'Alkaloid general color precipitating reagents, Keller-Kiliani cardiac digitoxose test, and volatile oil enfleurage technique.'
      }
    ]
  },

  // ================= SEMESTER 5 =================
  {
    id: 'bp501t',
    semId: 5,
    code: 'BP501T',
    name: 'Medicinal Chemistry – II',
    chaptersCount: 5,
    topicsCount: 35,
    credits: 4,
    iconType: 'capsule',
    number: 1,
    units: [
      {
        unitNumber: 1,
        title: 'Antihistamines & Antineoplastic Agents',
        topicsCount: 7,
        topics: [
          'Histamine receptors (H1, H2, H3, H4) and distribution in tissues',
          'H1-receptor antagonists: First generation (Diphenhydramine, Chlorpheniramine, Promethazine, Cyproheptadine) vs Second generation (Cetirizine, Loratadine, Fexofenadine)',
          'SAR of H1 antihistamines (Ethylenediamine, Aminoalkyl ether, Alkylamine derivatives)',
          'H2-receptor antagonists: Cimetidine, Ranitidine, Famotidine and SAR',
          'Antineoplastic agents: Alkylating agents (Mechlorethamine, Cyclophosphamide, Melphalan, Busulfan, Cisplatin)',
          'Antimetabolites: Methotrexate (Folate antagonist), 5-Fluorouracil, Mercaptopurine; Plant products: Vincristine, Vinblastine, Paclitaxel',
          'Chemical synthesis of: Diphenhydramine, Promethazine, Cimetidine, Chlorambucil, Methotrexate'
        ],
        notesSummary: 'H1 vs H2 pharmacophore diagrams, Cyclophosphamide acrolein bladder toxicity activation pathway, and Methotrexate DHFR inhibition.'
      },
      {
        unitNumber: 2,
        title: 'Anti-Anginal, Vasodilators & Diuretics',
        topicsCount: 7,
        topics: [
          'Anti-anginal agents: Organic nitrates (Nitroglycerin, Isosorbide dinitrate, Isosorbide mononitrate) and nitric oxide release',
          'Calcium channel blockers: 1,4-Dihydropyridines (Nifedipine, Amlodipine, Felodipine), Verapamil, Diltiazem and SAR',
          'Diuretics: Carbonic anhydrase inhibitors (Acetazolamide) and mechanism of action',
          'Thiazide diuretics: Chlorothiazide, Hydrochlorothiazide and SAR',
          'Loop / High-ceiling diuretics: Furosemide, Bumetanide, Torsemide and Na-K-2Cl symport inhibition',
          'Potassium-sparing diuretics: Spironolactone (Aldosterone antagonist), Triamterene, Amiloride',
          'Chemical synthesis of: Isosorbide dinitrate, Chlorthalidone, Furosemide, Acetazolamide'
        ],
        notesSummary: '1,4-Dihydropyridine ester substituent SAR, organic nitrate mitochondrial aldehyde dehydrogenase conversion, and Furosemide synthesis.'
      },
      {
        unitNumber: 3,
        title: 'Antihypertensives, Antiarrhythmics & Antihyperlipidemics',
        topicsCount: 7,
        topics: [
          'Antihypertensive agents: Centrally acting agents (Clonidine, Methyldopa), Ganglionic blockers',
          'Adrenergic neuron blockers (Reserpine, Guanethidine), Vasodilators (Hydralazine, Minoxidil, Sodium nitroprusside)',
          'Renin-Angiotensin System inhibitors: ACE inhibitors (Captopril, Enalapril, Lisinopril) and ARBs (Losartan, Telmisartan) and SAR',
          'Antiarrhythmic agents: Vaughan-Williams classification (Class I Na+ blockers, Class II beta-blockers, Class III K+ blockers, Class IV Ca2+ blockers)',
          'Drugs: Quinidine, Procainamide, Disopyramide, Lidocaine, Amiodarone, Sotalol',
          'Antihyperlipidemic agents: HMG-CoA reductase inhibitors (Statins - Atorvastatin, Simvastatin, Rosuvastatin) and SAR',
          'Fibrates (Gemfibrozil, Fenofibrate), Bile acid sequestrants (Cholestyramine), and Niacin',
          'Chemical synthesis of: Captopril, Hydralazine, Procainamide, Disopyramide'
        ],
        notesSummary: 'ACE inhibitor zinc-binding thiol/carboxylate pharmacophore SAR, Vaughan-Williams Class I-IV electrophysiology, and Statin HMG-CoA mimicry.'
      },
      {
        unitNumber: 4,
        title: 'Endocrine Drugs: Steroids & Contraceptives',
        topicsCount: 7,
        topics: [
          'Steroid chemistry: Nomenclature, stereochemistry of cyclopentanoperhydrophenanthrene ring (cis/trans fusion)',
          'Sex hormones: Androgens and Anabolic steroids (Testosterone, Methyltestosterone, Nandrolone)',
          'Estrogens: Natural (Estradiol, Estrone) and Synthetic (Ethinylestradiol, Diethylstilbestrol) and SAR',
          'Progestins: Progesterone, Norethindrone, Levonorgestrel and role in oral contraceptives',
          'Corticosteroids: Glucocorticoids (Hydrocortisone, Prednisolone, Dexamethasone, Betamethasone) and Mineralocorticoids (Aldosterone, Fludrocortisone)',
          'SAR of Corticosteroids: 9-alpha fluoro, 16-alpha methyl, and 1,2-double bond modifications for anti-inflammatory potency',
          'Chemical synthesis of: Diethylstilbestrol, Betamethasone, Ethinylestradiol'
        ],
        notesSummary: 'Steroid ABCD ring conformation rules, Dexamethasone glucocorticoid vs mineralocorticoid selectivity SAR, and Oral contraceptive mechanisms.'
      },
      {
        unitNumber: 5,
        title: 'Antidiabetic Agents & Thyroid Drugs',
        topicsCount: 7,
        topics: [
          'Insulin and its preparations: Regular, NPH, Lente, Glargine, Lispro',
          'Oral hypoglycemic agents: Sulfonylureas - First generation (Tolbutamide) vs Second generation (Glibenclamide, Glipizide, Glimepiride) and SAR',
          'Biguanides: Metformin mechanism (AMPK activation, reduction of hepatic gluconeogenesis)',
          'Thiazolidinediones (Pioglitazone - PPAR-gamma agonists), Meglitinides (Repaglinide), DPP-4 inhibitors (Sitagliptin), SGLT2 inhibitors (Dapagliflozin)',
          'Thyroid hormones: Levothyroxine, Liothyronine; Anti-thyroid agents: Propylthiouracil, Methimazole, Carbimazole',
          'Local anesthetics: Detailed SAR of benzoic acid and anilide type local anesthetics',
          'Chemical synthesis of: Tolbutamide, Metformin, Procaine, Benzocaine'
        ],
        notesSummary: 'Sulfonylurea SUR1 receptor binding SAR, Metformin biguanide synthesis, and Propylthiouracil thyroid peroxidase inhibition.'
      }
    ]
  },
  {
    id: 'bp502t',
    semId: 5,
    code: 'BP502T',
    name: 'Industrial Pharmacy – I',
    chaptersCount: 5,
    topicsCount: 36,
    credits: 4,
    iconType: 'factory',
    number: 2,
    units: [
      {
        unitNumber: 1,
        title: 'Preformulation Studies',
        topicsCount: 7,
        topics: [
          'Introduction, goals and objectives of preformulation studies in product development',
          'Physical properties: Particle size, shape, surface area, polymorphism, solvates, hygroscopicity',
          'Solubility profile: pH solubility profile, pKa, partition coefficient, dissolution rate',
          'Chemical properties: Hydrolysis, oxidation, reduction, racemization, photolysis',
          'Solid-state stability and drug-excipient compatibility studies (DSC, FTIR, isothermal stress testing)',
          'BCS (Biopharmaceutics Classification System) classes I-IV and formulation challenges',
          'Preformulation screening of crystal forms and amorphous solid dispersions'
        ],
        notesSummary: 'DSC thermogram endotherm/exotherm interpretation, BCS classes I-IV solubility-permeability matrix, and drug-excipient compatibility protocols.'
      },
      {
        unitNumber: 2,
        title: 'Tablets & Tablet Coating',
        topicsCount: 8,
        topics: [
          'Tablets: Formulation additives (diluents, binders, disintegrants, lubricants, glidants, antiadherents)',
          'Granulation techniques: Wet granulation, dry granulation (roller compaction, slugging), direct compression',
          'Tablet compression machines: Single punch and multi-station rotary tablet machines, tooling (B tooling, D tooling)',
          'Tablet compression physics: Consolidation, compaction, Heckel equation',
          'Tablet processing defects: Capping, lamination, chipping, cracking, picking, sticking, mottling, weight variation',
          'Tablet coating: Sugar coating (steps: sealing, subcoating, smoothing, coloring, polishing)',
          'Film coating: Polymers, plasticizers, colorants, defects (blistering, orange peel effect, bridging)',
          'Evaluation of tablets: Weight variation, thickness, hardness, friability (Roche friabilator), disintegration, dissolution'
        ],
        notesSummary: 'Rotary press compression cycle stages, tablet defect troubleshooting guide, and USP/IP dissolution apparatus 1 & 2.'
      },
      {
        unitNumber: 3,
        title: 'Hard & Soft Gelatin Capsules',
        topicsCount: 7,
        topics: [
          'Hard gelatin capsules: Raw materials, gelatin manufacture (Type A vs Type B, Bloom strength 150-250 g)',
          'Capsule shell manufacturing steps: Dipping, spinning, drying, stripping, trimming, joining',
          'Capsule sizes (000 to 5) and volumetric filling capacities',
          'Filling of hard gelatin capsules: Hand filling, semi-automatic, and automatic machines (tamping pin vs dosator)',
          'Soft gelatin capsules: Nature of shell and capsule content, plasticizers (Glycerin, Sorbitol ratio: 0.3-1.0)',
          'Manufacturing process: Rotary die process for softgels, drying and quality control',
          'Quality control of capsules: Weight variation, content uniformity, disintegration, dissolution, moisture content'
        ],
        notesSummary: 'Bloom strength determination, capsule sizes chart (000 largest to 5 smallest), and rotary die softgel encapsulation mechanics.'
      },
      {
        unitNumber: 4,
        title: 'Parenteral Products & Ophthalmic Preparations',
        topicsCount: 7,
        topics: [
          'Parenterals: Definition, routes of administration, formulation vehicles (Water for Injection, non-aqueous)',
          'Additives in parenterals: Antimicrobials, antioxidants, buffers, tonicity adjusters, solubilizers',
          'Containers and closures: Glass containers (Type I, II, III), rubber closures, testing of glass and rubber',
          'Facilities and environmental control: Cleanroom design, HEPA filtration, laminar airflow benches',
          'Manufacturing process: Compounding, filtration, filling, sealing of ampoules and vials, terminal sterilization',
          'Evaluation of parenterals: Sterility testing, particulate matter inspection, Pyrogen testing (Rabbit test) and LAL test',
          'Ophthalmic preparations: Eye drops, eye lotions, eye ointments, formulation requirements (sterility, tonicity, viscosity, pH)'
        ],
        notesSummary: 'LAL bacterial endotoxin test gel-clot method, Glass type I-III alkalinity testing, and ophthalmic preservative requirements.'
      },
      {
        unitNumber: 5,
        title: 'Cosmetics & Pharmaceutical Aerosols',
        topicsCount: 7,
        topics: [
          'Cosmetics: Definition, formulation and preparation of Lipsticks, Shampoos, Cold creams, Vanishing creams',
          'Toothpastes and dentifrices: Abrasives, humectants, foaming agents, binding agents, fluorides',
          'Hair dyes and sunscreens: Mechanism of action, evaluation parameters',
          'Pharmaceutical Aerosols: Definition, components (propellants, container, valve, actuator)',
          'Propellants: Compressed gases and Liquefied gases (CFCs, HFA-134a, hydrocarbons) and vapor pressure',
          'Types of aerosol systems: Two-phase systems, three-phase systems, Metered Dose Inhalers (MDIs)',
          'Evaluation of aerosols: Discharge rate, spray pattern, particle size determination (Cascade impactor)'
        ],
        notesSummary: 'MDI metering valve metering chamber volume control, cascade impactor aerodynamic particle cutoff, and cold cream formulation.'
      }
    ]
  },
  {
    id: 'bp503t',
    semId: 5,
    code: 'BP503T',
    name: 'Pharmacology – II',
    chaptersCount: 5,
    topicsCount: 38,
    credits: 4,
    iconType: 'shield',
    number: 3,
    units: [
      {
        unitNumber: 1,
        title: 'Cardiovascular System Pharmacology',
        topicsCount: 8,
        topics: [
          'Hemodynamics and electrophysiology of the heart',
          'Drugs used in Congestive Heart Failure: Cardiac glycosides (Digoxin mechanism - Na+/K+ ATPase inhibition, toxicity, management)',
          'Inotropic agents: Dobutamine, Milrinone; Vasodilators in CHF',
          'Antihypertensive drugs: ACE inhibitors, ARBs, CCBs, Diuretics, Beta-blockers, Vasodilators (stepped-care approach)',
          'Antianginal drugs: Nitrates, beta-blockers, calcium channel blockers, potassium channel openers (Nicorandil), Ranolazine',
          'Antiarrhythmic drugs: Detailed pharmacology of Class I, II, III, IV antiarrhythmic agents',
          'Drugs used in Atherosclerosis and Hyperlipidemia: Statins, Fibrates, Ezetimibe, PCSK9 inhibitors',
          'Shock and its pharmacological management'
        ],
        notesSummary: 'Digoxin therapeutic window (0.5-2 ng/mL) and potassium interaction, antianginal triple combination therapy, and antiarrhythmic ion channel targets.'
      },
      {
        unitNumber: 2,
        title: 'Drugs Acting on Hemopoietic & Urinary System',
        topicsCount: 7,
        topics: [
          'Hematinics: Iron pharmacology, oral vs parenteral iron therapy, iron toxicity and treatment with Deferoxamine',
          'Vitamin B12 and Folic acid in megaloblastic anemia, Erythropoietin and colony stimulating factors',
          'Anticoagulants: Heparin (unfractionated and LMWH), Warfarin (vitamin K epoxide reductase inhibition), DOACs (Dabigatran, Rivaroxaban)',
          'Thrombolytic agents: Streptokinase, Urokinase, Alteplase (tPA) in acute myocardial infarction and stroke',
          'Antiplatelet drugs: Aspirin, Clopidogrel, Ticagrelor, Glycoprotein IIb/IIIa inhibitors',
          'Diuretics: Carbonic anhydrase inhibitors, Loop diuretics, Thiazides, Potassium-sparing diuretics (site and mechanism of action)',
          'Antidiuretics: Vasopressin and desmopressin in diabetes insipidus'
        ],
        notesSummary: 'Nephron segmental tubular transporter map, Heparin vs Warfarin monitoring (aPTT vs PT/INR), and protamine sulfate reversal.'
      },
      {
        unitNumber: 3,
        title: 'Autacoids & Anti-inflammatory Agents',
        topicsCount: 8,
        topics: [
          'Autacoids: Definition, biological roles of Histamine, 5-Hydroxytryptamine (Serotonin), and their antagonists',
          'Pharmacotherapy of Migraine: Triptans (Sumatriptan - 5-HT1B/1D agonists), Ergot alkaloids, prophylaxis (Propranolol, Topiramate)',
          'Prostaglandins, Thromboxanes and Leukotrienes: Biosynthesis from arachidonic acid, physiological functions, clinical uses',
          'Non-steroidal anti-inflammatory drugs (NSAIDs): Mechanism of action (COX-1 vs COX-2 inhibition)',
          'Classification of NSAIDs: Salicylates, Propionic acid derivatives (Ibuprofen), Acetic acid derivatives (Diclofenac), Oxicams, Coxibs (Celecoxib)',
          'Adverse effects of NSAIDs: Gastric ulceration, renal toxicity, cardiovascular risks',
          'Pharmacotherapy of Gout: Acute gout (Colchicine, NSAIDs) and Chronic gout (Allopurinol, Febuxostat, Probenecid)',
          'Antirheumatoid drugs / DMARDs: Methotrexate, Sulfasalazine, Hydroxychloroquine, Biological DMARDs (Infliximab)'
        ],
        notesSummary: 'Arachidonic acid cascade COX vs LOX enzyme pathways, COX-2 selective inhibitor cardiac risk, and Allopurinol xanthine oxidase inhibition.'
      },
      {
        unitNumber: 4,
        title: 'Endocrine System Pharmacology',
        topicsCount: 8,
        topics: [
          'Anterior pituitary hormones: Growth hormone, Prolactin, ACTH, TSH, Gonadotropins and their clinical uses',
          'Thyroid and Antithyroid drugs: Levothyroxine, Carbimazole, Propylthiouracil, radioiodine therapy',
          'Insulin: Types of insulin, molecular structure, mechanism of action, insulin resistance, adverse effects',
          'Oral hypoglycemic drugs: Sulfonylureas, Biguanides, DPP-4 inhibitors, SGLT2 inhibitors, GLP-1 receptor agonists',
          'Adrenal corticosteroids: Glucocorticoids (Prednisolone, Dexamethasone), therapeutic uses, adverse effects, withdrawal syndrome',
          'Androgens and Anabolic steroids: Testosterone pharmacology, clinical uses, misuse in athletics',
          'Estrogens, Progestins, Oral Contraceptives (combined pills, mini pills, emergency contraception), SERMs (Tamoxifen)',
          'Drugs affecting calcium regulation: Parathyroid hormone, Calcitonin, Vitamin D, Bisphosphonates in Osteoporosis'
        ],
        notesSummary: 'Insulin injection pharmacokinetic onset/peak curves, steroid hypothalamic-pituitary-adrenal axis suppression, and Bisphosphonate osteoclast apoptosis.'
      },
      {
        unitNumber: 5,
        title: 'Bioassays & Principles of Toxicology',
        topicsCount: 7,
        topics: [
          'Bioassays: Definition, principles, advantages and limitations, applications in drug standardization',
          'Types of bioassays: Graded bioassay (Interpolation, Matching / Bracketing, Three-point, Four-point assay) and Quantal bioassay (End-point)',
          'Official bioassay procedures: Bioassay of Insulin, Oxytocin, d-Tubocurarine, Digitalis, Histamine',
          'General principles of toxicology: Acute, subacute and chronic toxicity studies',
          'Determination of LD50 and ED50, OECD guidelines for acute oral toxicity testing (OECD 420, 423, 425)',
          'Treatment of general poisoning: Gastric lavage, emetics, activated charcoal, forced diuresis, hemodialysis',
          'Specific antidotes for common poisons: Paracetamol (N-Acetylcysteine), Organophosphates (Atropine), Heavy metals (BAL, EDTA, Penicillamine)'
        ],
        notesSummary: 'Three-point and four-point bioassay parallel line equations, OECD 423 acute oral toxicity flowchart, and specific poison antidote matching table.'
      }
    ]
  },
  {
    id: 'bp504t',
    semId: 5,
    code: 'BP504T',
    name: 'Pharmacognosy and Phytochemistry – II',
    chaptersCount: 5,
    topicsCount: 32,
    credits: 4,
    iconType: 'leaf',
    number: 4,
    units: [
      {
        unitNumber: 1,
        title: 'Metabolic Pathways in Higher Plants',
        topicsCount: 6,
        topics: [
          'Brief introduction to primary vs secondary metabolism in medicinal plants',
          'Shikimic acid pathway: Biosynthesis of aromatic amino acids (Phenylalanine, Tyrosine, Tryptophan) and phenylpropanoids',
          'Acetate-Mevalonate pathway: Biosynthesis of monoterpenes, sesquiterpenes, squalene, and steroids',
          'Acetate-Malonate pathway: Biosynthesis of fatty acids and polyketides (Anthraquinones)',
          'Methods used to determine biosynthetic pathways: Tracer techniques (Radioactive and stable isotopes)',
          'Autoradiography, grafting method, isolated organs and mutational genetics in pathway elucidation'
        ],
        notesSummary: 'Shikimic acid to chorismate biochemical steps, mevalonic acid pyrophosphate condensation, and carbon-14 tracer methodologies.'
      },
      {
        unitNumber: 2,
        title: 'General Pharmacognosy of Secondary Metabolites',
        topicsCount: 7,
        topics: [
          'Composition, chemistry, chemical tests, therapeutic and commercial uses of drugs containing:',
          'Alkaloids: Vinca, Rauwolfia, Belladonna, Opium, Tea',
          'Phenylpropanoids and Flavonoids: Lignans, Tea, Rue, Ginger, Capsicum',
          'Volatile oils: Mentha, Clove, Cinnamon, Fennel, Coriander',
          'Tannins: Catechu, Pterocarpus; Resins: Benzoin, Guggul, Ginger, Asafoetida, Myrrh, Colophony',
          'Glycosides: Senna, Aloe, Digitalis, Dioscorea, Liquorice',
          'Iridoids, other terpenoids and carotenoids: Gentian, Artemisia, Taxus'
        ],
        notesSummary: 'Alkaloid, glycoside and tannin diagnostic chemical test reactions, botanical sources, family names, and active chemical constituents.'
      },
      {
        unitNumber: 3,
        title: 'Isolation, Identification & Analysis of Phytoconstituents',
        topicsCount: 7,
        topics: [
          'Isolation, identification and analysis of: Terpenoids - Menthol, Citral, Artemisinin',
          'Alkaloids - Atropine, Quinine, Reserpine, Caffeine',
          'Glycosides - Sennosides, Diosgenin, Digoxin',
          'Resins - Podophyllotoxin, Curcumin',
          'TLC, paper chromatography, and spectral characterization of isolated markers',
          'Quality control markers and chromatographic fingerprinting of herbal raw materials',
          'Standards for active marker content determination in crude extracts'
        ],
        notesSummary: 'Curcumin soxhlet isolation protocol, Menthol fractional crystallization, and TLC Rf value identification criteria.'
      },
      {
        unitNumber: 4,
        title: 'Industrial Production & Utilization of Phytoconstituents',
        topicsCount: 6,
        topics: [
          'Industrial production, estimation and utilization of the following phytoconstituents:',
          'Forskolin (Coleus forskohlii), Sennosides (Cassia angustifolia), Artemisinin (Artemisia annua)',
          'Diosgenin (Dioscorea deltoidea) as a precursor for steroid hormone semi-synthesis',
          'Digoxin (Digitalis lanata), Atropine (Atropa belladonna), Podophyllotoxin (Podophyllum hexandrum)',
          'Vincristine and Vinblastine (Catharanthus roseus)',
          'Commercial significance of plant-derived medicines in global pharmaceutical trade'
        ],
        notesSummary: 'Diosgenin marker extraction yields, Marker-based industrial HPLC assay protocols, and steroid hormone semi-synthesis route.'
      },
      {
        unitNumber: 5,
        title: 'Modern Extraction Methods & Phytochemical Spectroscopy',
        topicsCount: 6,
        topics: [
          'Basics of phytochemistry: Modern methods of extraction of medicinal plants',
          'Supercritical Fluid Extraction (SFE): Principle of carbon dioxide critical state, advantages, and applications',
          'Microwave-Assisted Extraction (MAE) and Ultrasound-Assisted Extraction (UAE) / Sonication',
          'Hydrodistillation, Steam distillation, and Solvent extraction techniques',
          'Application of spectroscopy in phytochemical analysis: UV-Visible and Infrared spectroscopy',
          'Mass spectrometry and NMR spectroscopy in structural elucidation of novel natural products'
        ],
        notesSummary: 'Supercritical CO2 density-pressure solubility tuning, microwave dielectric heating mechanics, and phytomolecule mass fragmentation.'
      }
    ]
  },
  {
    id: 'bp505t',
    semId: 5,
    code: 'BP505T',
    name: 'Pharmaceutical Jurisprudence',
    chaptersCount: 5,
    topicsCount: 25,
    credits: 4,
    iconType: 'gavel',
    number: 5,
    units: [
      {
        unitNumber: 1,
        title: 'Drugs and Cosmetics Act, 1940 and Rules 1945',
        topicsCount: 6,
        topics: [
          'Objectives, definitions (Misbranded, Adulterated, Spurious drugs, Cosmetic)',
          'Advisory boards: Drugs Technical Advisory Board (DTAB), Drugs Consultative Committee (DCC), Central Drug Laboratory (CDL)',
          'Import of drugs and cosmetics: Classes of drugs prohibited from import, import licenses',
          'Manufacture of drugs: Conditions for grant of license, loan license, repacking license',
          'Schedules to the Act and Rules: Schedule M (GMP), Schedule Y (Clinical trials), Schedule G, H, H1, X (Prescription drugs)',
          'Sale of drugs: Wholesale, retail, restricted license, conditions and records to be maintained'
        ],
        notesSummary: 'DTAB ex-officio and nominated members list, Schedule M GMP factory premises requirements, and Schedule H vs H1 prescription rules.'
      },
      {
        unitNumber: 2,
        title: 'Pharmacy Act, 1948 & Medicinal Preparations Act',
        topicsCount: 5,
        topics: [
          'Pharmacy Act 1948: Objectives, constitution and functions of Pharmacy Council of India (PCI)',
          'Education Regulations (ER): Approval of institutions, withdrawal of approval',
          'State Pharmacy Councils and Joint State Pharmacy Councils: Constitution, functions',
          'Registration of Pharmacists: First register, subsequent registers, qualifications, removal from register',
          'Medicinal and Toilet Preparations (Excise Duties) Act 1955: Manufacture in bond and non-bonded laboratories'
        ],
        notesSummary: 'PCI constitution table, pharmacist registration qualifications, and bonded laboratory customs excise supervision.'
      },
      {
        unitNumber: 3,
        title: 'NDPS Act & Drugs Magic Remedies Act',
        topicsCount: 5,
        topics: [
          'Narcotic Drugs and Psychotropic Substances (NDPS) Act 1985 and Rules: Objectives, definitions',
          'Authorities and officers, prohibition, control and regulation of cultivation, production, sale of narcotics',
          'Offences and penalties under NDPS Act, powers of search, seizure, arrest',
          'Drugs and Magic Remedies (Objectionable Advertisements) Act 1954: Prohibited advertisements, classes of exempted advertisements',
          'Diseases and conditions that cannot be advertised under Schedule of the Act, penalties'
        ],
        notesSummary: 'NDPS illicit trafficking mandatory minimum punishment, opium poppy license terms, and prohibited magic remedy disease list.'
      },
      {
        unitNumber: 4,
        title: 'Prevention of Cruelty to Animals & DPCO',
        topicsCount: 5,
        topics: [
          'Prevention of Cruelty to Animals Act 1960: Objectives, Institutional Animal Ethics Committee (IAEC)',
          'CPCSEA (CCSEA) guidelines for breeding and housing of experimental animals',
          'National Pharmaceutical Pricing Authority (NPPA): Role, powers',
          'Drugs (Price Control) Order (DPCO) 2013: Objectives, definitions, calculation of ceiling price of scheduled formulations',
          'National List of Essential Medicines (NLEM) and retail price calculation formulas'
        ],
        notesSummary: 'CPCSEA 3Rs principle (Replacement, Reduction, Refinement), IAEC approval protocol, and DPCO ceiling price calculation formula.'
      },
      {
        unitNumber: 5,
        title: 'Code of Pharmaceutical Ethics & Intellectual Property',
        topicsCount: 4,
        topics: [
          'Code of Pharmaceutical Ethics: Pharmacist’s code of ethics in relation to his job, trade, medical profession, and profession',
          'Pharmacist’s oath, responsibilities toward society',
          'Intellectual Property Rights (IPR): Patents, Copyrights, Trademarks, Trade Secrets, Patent Act 1970 (amendments)',
          'Patent filing procedure in India: Provisional and complete specification, patent opposition, patent infringement, compulsory licensing'
        ],
        notesSummary: 'Pharmacist Code of Conduct clauses, Patent Cooperation Treaty (PCT) filing steps, and compulsory licensing grounds in public health.'
      }
    ]
  },

  // ================= SEMESTER 6 =================
  {
    id: 'bp601t',
    semId: 6,
    code: 'BP601T',
    name: 'Medicinal Chemistry – III',
    chaptersCount: 5,
    topicsCount: 36,
    credits: 4,
    iconType: 'capsule',
    number: 1,
    units: [
      {
        unitNumber: 1,
        title: 'Antibiotics: Beta-Lactams & Aminoglycosides',
        topicsCount: 8,
        topics: [
          'Historical background, nomenclature, stereochemistry of Beta-Lactam antibiotics',
          'Penicillins: Penicillin G, Ampicillin, Amoxicillin, Methicillin, Carbenicillin and SAR',
          'Beta-lactamase inhibitors: Clavulanic acid, Sulbactam, Tazobactam',
          'Cephalosporins: First, second, third, fourth and fifth generation cephalosporins and SAR',
          'Other beta-lactams: Carbapenems (Imipenem, Meropenem) and Monobactams (Aztreonam)',
          'Aminoglycoside antibiotics: Streptomycin, Gentamicin, Tobramycin, Amikacin, Neomycin',
          'SAR and mechanism of action of aminoglycosides (30S ribosomal subunit inhibition)',
          'Chemical synthesis of: Ampicillin, Amoxicillin, Cephalexin'
        ],
        notesSummary: 'Penicillin thiazolidine-beta lactam strained bicyclic SAR, Cephalosporin C-3/C-7 substituent rules, and clavulanate suicidal inactivation.'
      },
      {
        unitNumber: 2,
        title: 'Tetracyclines, Macrolides & Antimalarials',
        topicsCount: 7,
        topics: [
          'Tetracyclines: Chlortetracycline, Oxytetracycline, Doxycycline, Minocycline and detailed SAR',
          'Mechanism of action, bacterial resistance, epimerization and degradation products of tetracyclines',
          'Macrolide antibiotics: Erythromycin, Clarithromycin, Azithromycin, Roxithromycin (50S subunit inhibition)',
          'Miscellaneous antibiotics: Chloramphenicol (synthesis and SAR), Lincomycin, Clindamycin',
          'Antimalarial agents: Life cycle of Plasmodium, targets of antimalarial drugs',
          'Classification of antimalarials: 4-Aminoquinolines (Chloroquine), 8-Aminoquinolines (Primaquine), 9-Aminoacridines, Biguanides (Proguanil)',
          'Chemical synthesis of: Chloramphenicol, Chloroquine, Primaquine'
        ],
        notesSummary: 'Tetracycline calcium chelation and epimerization chemistry, Macrolide acid instability solutions, and Chloroquine synthesis.'
      },
      {
        unitNumber: 3,
        title: 'Antitubercular, Antileprotic & Antifungal Agents',
        topicsCount: 7,
        topics: [
          'Antitubercular agents: First-line drugs (Isoniazid, Rifampicin, Ethambutol, Pyrazinamide, Streptomycin)',
          'Second-line antitubercular drugs: PAS, Ethionamide, Cycloserine, Bedaquiline, and DOTS strategy',
          'SAR and mechanism of action of Isoniazid (Mycolic acid synthesis inhibition)',
          'Antileprotic agents: Sulfones (Dapsone mechanism and SAR), Clofazimine, Rifampicin',
          'Antifungal agents: Polyene macrolides (Amphotericin B, Nystatin - Ergosterol binding)',
          'Azole antifungals: Imidazoles (Ketoconazole, Miconazole) and Triazoles (Fluconazole, Itraconazole) and SAR',
          'Chemical synthesis of: Isoniazid, Ethambutol, Dapsone, Ketoconazole'
        ],
        notesSummary: 'Isoniazid KatG prodrug activation, Dapsone dihydropteroate synthase inhibition, and Azole 14-alpha demethylase binding model.'
      },
      {
        unitNumber: 4,
        title: 'Antiviral, Antiprotozoal & Anthelmintic Agents',
        topicsCount: 7,
        topics: [
          'Antiviral agents: Viral replication cycle and targets for drug discovery',
          'Anti-herpes agents: Acyclovir, Valacyclovir, Ganciclovir (Thymidine kinase activation and SAR)',
          'Anti-influenza agents: Amantadine, Rimantadine, Oseltamivir, Zanamivir (Neuraminidase inhibitors)',
          'Antiretroviral agents (Anti-HIV): NRTIs (Zidovudine/AZT, Lamivudine), NNRTIs (Efavirenz, Nevirapine)',
          'HIV Protease inhibitors (Ritonavir, Saquinavir), Integrase inhibitors (Raltegravir)',
          'Antiprotozoal agents: Metronidazole, Tinidazole, Diloxanide furoate, Iodoquinol',
          'Anthelmintics: Mebendazole, Albendazole, Pyrantel pamoate, Diethylcarbamazine (DEC)',
          'Chemical synthesis of: Acyclovir, Zidovudine, Metronidazole, Mebendazole'
        ],
        notesSummary: 'Acyclovir viral thymidine kinase triphosphorylation mechanism, HIV reverse transcriptase inhibitor binding pocket, and Metronidazole synthesis.'
      },
      {
        unitNumber: 5,
        title: 'Sulfonamides, Quinolones & CADD',
        topicsCount: 7,
        topics: [
          'Sulfonamides: History, classification, antibacterial spectrum, and Woods-Fildes PABA antimetabolite theory',
          'SAR of Sulfonamides (N1 and N4 substitution rules), Cotrimoxazole (Sulfamethoxazole + Trimethoprim synergy)',
          'Fluoroquinolones: Nalidixic acid, Ciprofloxacin, Norfloxacin, Ofloxacin, Levofloxacin and detailed SAR',
          'Mechanism of action of fluoroquinolones: Bacterial DNA gyrase (topoisomerase II) and Topoisomerase IV inhibition',
          'Combinatorial chemistry: Solid phase synthesis, parallel synthesis, split and pool method',
          'Computer Aided Drug Design (CADD): Structure-Based Drug Design (SBDD - Molecular docking)',
          'Ligand-Based Drug Design (LBDD - Pharmacophore modeling, 2D/3D QSAR, Lipinski Rule of 5)',
          'Chemical synthesis of: Sulfamethoxazole, Trimethoprim, Ciprofloxacin'
        ],
        notesSummary: 'Sulfonamide N1-heteroaryl ionization SAR, Fluoroquinolone C-6 fluorine & C-7 piperazine SAR, and Lipinski Rule of 5 parameters.'
      }
    ]
  },
  {
    id: 'bp602t',
    semId: 6,
    code: 'BP602T',
    name: 'Pharmacology – III',
    chaptersCount: 5,
    topicsCount: 38,
    credits: 4,
    iconType: 'shield',
    number: 2,
    units: [
      {
        unitNumber: 1,
        title: 'Respiratory & Gastrointestinal Pharmacology',
        topicsCount: 8,
        topics: [
          'Pharmacotherapy of Asthma: Bronchodilators (Beta-2 agonists - Salbutamol, Salmeterol; Methylxanthines - Theophylline; Anticholinergics - Ipratropium)',
          'Anti-inflammatory agents in asthma: Inhaled corticosteroids (Budesonide, Fluticasone), Leukotriene receptor antagonists (Montelukast)',
          'Mast cell stabilizers (Sodium cromoglycate) and Anti-IgE antibody (Omalizumab)',
          'Pharmacotherapy of COPD and management of acute asthma attack / status asthmaticus',
          'Expectorants and Antitussives: Codeine, Dextromethorphan, Ambroxol, Bromhexine',
          'Drugs for Peptic Ulcer Disease: Proton Pump Inhibitors (Omeprazole, Pantoprazole), H2 blockers, Antacids, Sucralfate',
          'H. pylori eradication regimens: Triple therapy and quadruple therapy protocols',
          'Antiemetics (Ondansetron, Metoclopramide, Domperidone), Laxatives, and Antidiarrheals'
        ],
        notesSummary: 'Omeprazole sulfenamide proton pump covalent bond chemistry, Montelukast CysLT1 antagonism, and H. pylori triple therapy eradication kit.'
      },
      {
        unitNumber: 2,
        title: 'Chemotherapy: Antibacterials & Antibiotics',
        topicsCount: 8,
        topics: [
          'General principles of chemotherapy: Selective toxicity, spectrum of activity, bactericidal vs bacteriostatic',
          'Bacterial resistance mechanisms: Mutation, plasmid-mediated, enzymatic degradation, efflux pumps, altered target',
          'Penicillins: Natural, penicillinase-resistant, aminopenicillins, antipseudomonal penicillins, adverse reactions',
          'Cephalosporins: First to fifth generations, spectrum of activity, and clinical indications',
          'Beta-lactamase inhibitors: Amoxicillin-clavulanic acid combination rationale',
          'Aminoglycosides: Gentamicin, Amikacin - Pharmacokinetics, nephrotoxicity and ototoxicity monitoring',
          'Macrolides: Azithromycin, Clarithromycin - Clinical uses, drug interactions (CYP3A4 inhibition)',
          'Fluoroquinolones: Ciprofloxacin, Levofloxacin - Mechanism, cartilage toxicity, QT prolongation'
        ],
        notesSummary: 'Bactericidal vs bacteriostatic synergy/antagonism rules, aminoglycoside ototoxicity prevention, and antibiotic stewardship principles.'
      },
      {
        unitNumber: 3,
        title: 'Chemotherapy of TB, Leprosy & Systemic Infections',
        topicsCount: 8,
        topics: [
          'Chemotherapy of Tuberculosis: First-line regimen (HRZE), mechanism, adverse effects (Hepatotoxicity, peripheral neuropathy, optic neuritis)',
          'Multi-Drug Resistant TB (MDR-TB) and Extensively Drug Resistant TB (XDR-TB) regimens',
          'Chemotherapy of Leprosy: WHO Multi-Drug Therapy (MDT) for paucibacillary and multibacillary leprosy (Dapsone, Rifampicin, Clofazimine)',
          'Antifungal agents: Amphotericin B infusion reactions and nephrotoxicity, Liposomal amphotericin B',
          'Systemic and topical azoles: Fluconazole, Itraconazole, Voriconazole, Terbinafine',
          'Antiviral drugs: Anti-herpes agents, Anti-hepatitis agents (Sofosbuvir, Ledipasvir for HCV)',
          'Antiretroviral therapy (ART / HAART): First-line regimens for HIV, monitoring CD4 counts and viral load',
          'Chemotherapy of Malaria: Chloroquine, Artemisinin-based Combination Therapy (ACT), Primaquine for radical cure'
        ],
        notesSummary: 'WHO Leprosy MDT blister pack schedule, Isoniazid pyridoxine co-administration rationale, and ACT artemisinin partner drug protocols.'
      },
      {
        unitNumber: 4,
        title: 'Chemotherapy of Cancer & Immunopharmacology',
        topicsCount: 7,
        topics: [
          'General principles of cancer chemotherapy: Cell-cycle specific vs non-specific agents, log-kill hypothesis',
          'Alkylating agents: Cyclophosphamide, Ifosfamide, Cisplatin, Carboplatin (toxicities: nephrotoxicity, emesis, hemorrhagic cystitis)',
          'Antimetabolites: Methotrexate (rescue therapy with Leucovorin / Folinic acid), 5-Fluorouracil, Cytarabine',
          'Antitumor antibiotics: Doxorubicin (cardiotoxicity), Bleomycin (pulmonary fibrosis)',
          'Targeted therapies: Tyrosine kinase inhibitors (Imatinib in CML), Monoclonal antibodies (Trastuzumab, Rituximab)',
          'Immunosuppressive agents: Calcineurin inhibitors (Cyclosporine, Tacrolimus), Antiproliferative agents (Azathioprine, Mycophenolate)',
          'Immunostimulants: Interferons, Interleukins, Vaccines in immunotherapy'
        ],
        notesSummary: 'Log-kill cancer kinetic curve, Leucovorin rescue of high-dose Methotrexate, and Cyclosporine calcineurin-NFAT inhibition pathway.'
      },
      {
        unitNumber: 5,
        title: 'Toxicology & Poisoning Management',
        topicsCount: 7,
        topics: [
          'General principles of clinical toxicology: ABC of resuscitation, prevention of further absorption',
          'Elimination enhancement techniques: Alkaline diuresis for phenobarbital/salicylates, hemodialysis',
          'Barbiturate and Opioid poisoning: Symptoms, diagnosis, management with supportive care and Naloxone',
          'Organophosphorus and carbamate insecticide poisoning: Pralidoxime timing and Atropine dosage titration',
          'Heavy metal poisoning and chelation therapy: Lead, Mercury, Arsenic, Iron poisoning',
          'Chelating agents: Dimercaprol (BAL), Calcium disodium edetate, D-Penicillamine, Deferoxamine',
          'Teratogenicity: Critical gestational periods, FDA pregnancy categories (A, B, C, D, X)'
        ],
        notesSummary: 'Lead plumbism basophilic stippling signs, urinary alkalinization pKa shifting math, and FDA pregnancy safety risk categories.'
      }
    ]
  },
  {
    id: 'bp603t',
    semId: 6,
    code: 'BP603T',
    name: 'Herbal Drug Technology',
    chaptersCount: 5,
    topicsCount: 28,
    credits: 4,
    iconType: 'leaf',
    number: 3,
    units: [
      {
        unitNumber: 1,
        title: 'Herbs as Raw Materials & Biodynamic Agriculture',
        topicsCount: 6,
        topics: [
          'Definition of herb, herbal medicine, herbal medicinal product, and herbal drug preparation',
          'Sources of herbs, selection, identification and authentication of herbal materials',
          'Processing of herbal raw materials: Harvesting, cleaning, drying, packaging, storage',
          'Good Agricultural and Collection Practices (GACP) for medicinal plants as per WHO guidelines',
          'Biodynamic agriculture: Principles, preparation of biodynamic compost and preparations (BD 500, BD 501)',
          'Organic farming: Principles, biofertilizers, biopesticides, and certification standards'
        ],
        notesSummary: 'WHO GACP quality compliance checklist, biodynamic preparation formulations, and organic crop certification parameters.'
      },
      {
        unitNumber: 2,
        title: 'Ayurvedic Formulations & Herbal Excipients',
        topicsCount: 6,
        topics: [
          'Principles of Ayurvedic, Siddha and Unani systems of medicine',
          'Method of preparation and standardization of Ayurvedic formulations: Aristas and Asavas (self-generated alcohol)',
          'Preparation and quality control of Gutika, Churna, Bhasma (calcined mineral formulations), Taila, and Lehya',
          'Herbal excipients: Definition, importance, and applications of natural polymers',
          'Herbal colorants, natural sweeteners (Stevia), flavoring agents, and binding agents',
          'Herbal disintegrants, diluents, and natural viscosity builders (Guar gum, Xanthan gum)'
        ],
        notesSummary: 'Arishta fermentation chemical reaction, Bhasma shodhna and marana nanomedicine heating cycles, and natural Stevia rebaudiana sweetener properties.'
      },
      {
        unitNumber: 3,
        title: 'Herbal Cosmetics & Formulations for Systemic Disorders',
        topicsCount: 6,
        topics: [
          'Herbal cosmetics: Raw materials of herbal origin used in skin care (Aloe vera, Turmeric, Sandalwood)',
          'Herbal hair care products: Amla, Shikakai, Henna, Bhringraj for hair growth and conditioning',
          'Oral hygiene herbal products: Neem, Clove, Babool in herbal toothpastes and mouthwashes',
          'Herbal formulations for systemic disorders: Hepatoprotective herbal drugs (Silymarin / Milk Thistle, Picrorhiza)',
          'Antidiabetic herbal drugs (Gymnema sylvestre, Bitter gourd, Fenugreek), Antihypertensive drugs (Rauwolfia)',
          'Herbal anti-inflammatory drugs (Curcumin, Boswellia serrata) and memory enhancers (Bacopa monnieri)'
        ],
        notesSummary: 'Silymarin liver cell membrane stabilizing action, Gymnema gurmarin sugar taste blocking peptide, and Boswellia 5-LOX inhibition.'
      },
      {
        unitNumber: 4,
        title: 'Evaluation of Drugs & Regulatory Requirements',
        topicsCount: 5,
        topics: [
          'WHO guidelines for safety and quality evaluation of herbal medicines',
          'Quality control parameters: Foreign organic matter, ash values, extractive values, moisture content',
          'Testing for microbial contamination, pesticide residues, heavy metals, and aflatoxins in herbs',
          'Stability testing of herbal products: Protocols, climatic zones, degradation parameters',
          'Regulatory status of herbal medicines in India: Ayurvedic Pharmacopoeia of India (API) standards'
        ],
        notesSummary: 'Aflatoxin B1/B2/G1/G2 HPLC-fluorescence limits, heavy metal atomic absorption thresholds, and API monograph structure.'
      },
      {
        unitNumber: 5,
        title: 'Schedule T (GMP) & Patenting of Herbal Products',
        topicsCount: 5,
        topics: [
          'Schedule T of Drugs and Cosmetics Rules: Good Manufacturing Practices (GMP) for ASU drugs',
          'Factory premises: Building, infrastructure, water supply, machinery, sanitation, waste disposal requirements',
          'Quality control laboratory, batch manufacturing records (BMR) for herbal manufacturing',
          'Patenting of herbal medicines: Indian Patent Act 1970 provisions, patentable vs non-patentable natural products',
          'Traditional Knowledge Digital Library (TKDL) and prevention of bio-piracy (Turmeric, Basmati, Neem patent battles)'
        ],
        notesSummary: 'Schedule T machinery and area square footage requirements, TKDL bio-piracy defense database, and Section 3(p) Patent Act exclusions.'
      }
    ]
  },
  {
    id: 'bp604t',
    semId: 6,
    code: 'BP604T',
    name: 'Biopharmaceutics and Pharmacokinetics',
    chaptersCount: 5,
    topicsCount: 32,
    credits: 4,
    iconType: 'pulse',
    number: 4,
    units: [
      {
        unitNumber: 1,
        title: 'Introduction to Biopharmaceutics & Absorption',
        topicsCount: 7,
        topics: [
          'Definition of biopharmaceutics and pharmacokinetics and role in formulation development',
          'Biological membranes: Structure, fluid mosaic model, membrane transport mechanisms',
          'Physicochemical factors affecting drug absorption: Solubility, dissolution, particle size, polymorphism, pKa, lipophilicity',
          'Formulation factors affecting drug absorption: Dosage form type, disintegration, dissolution, excipient interactions',
          'Physiological factors affecting GI absorption: Gastric emptying rate, intestinal transit, surface area, blood flow',
          'Biopharmaceutics Classification System (BCS): Classes I, II, III, IV and waiver of in vivo bioequivalence',
          'Mechanisms of drug transport: Passive diffusion, Carrier-mediated (Active, Facilitated), Pore transport, Vesicular'
        ],
        notesSummary: 'Fick’s first law of diffusion derivation, gastric emptying half-life factors, and BCS Class I-IV solubility-permeability chart.'
      },
      {
        unitNumber: 2,
        title: 'Drug Distribution & Elimination',
        topicsCount: 6,
        topics: [
          'Tissue distribution of drugs: Apparent volume of distribution (Vd) and physiological significance',
          'Factors affecting drug distribution: Tissue permeability, tissue perfusion rate, blood-brain barrier',
          'Plasma protein binding of drugs: Albumin, alpha-1 acid glycoprotein, lipoproteins, binding kinetics',
          'Clinical significance of protein binding: Displacement interactions and volume of distribution changes',
          'Drug elimination: Renal clearance, concept of total body clearance (CL = GFR + Secretion - Reabsorption)',
          'Non-renal clearance: Hepatic clearance, extraction ratio, biliary excretion, enterohepatic recirculation'
        ],
        notesSummary: 'Vd = Dose / C0 mathematical formula, hepatic extraction ratio EH equation, and protein binding Scatchard plot.'
      },
      {
        unitNumber: 3,
        title: 'One-Compartment Pharmacokinetic Models',
        topicsCount: 7,
        topics: [
          'Compartment modeling: Concept of central and peripheral compartments, assumptions',
          'One-compartment open model - Intravenous Bolus administration: Plasma concentration-time curve',
          'Elimination rate constant (Kel), half-life (t1/2), apparent volume of distribution (Vd), and clearance (CL)',
          'One-compartment open model - Intravenous Infusion: Steady-state plasma concentration (Css), loading dose',
          'One-compartment open model - Extra-vascular (Oral) administration: Absorption rate constant (Ka)',
          'Method of Residuals (Feathering technique) for calculating Ka and Kel from oral plasma data',
          'Flip-flop phenomenon in sustained release drug formulations'
        ],
        notesSummary: 'IV bolus mono-exponential equation C = C0 * e^(-Kel*t), method of residuals graphing steps, and flip-flop model kinetics.'
      },
      {
        unitNumber: 4,
        title: 'Multicompartment & Non-Linear Pharmacokinetics',
        topicsCount: 6,
        topics: [
          'Two-compartment open model: Distribution phase (alpha phase) and elimination phase (beta phase)',
          'Intravenous bolus administration in two-compartment model: Biexponential equation C = A*e^(-alpha*t) + B*e^(-beta*t)',
          'Rate constants between central and peripheral compartments (k12, k21, k10)',
          'Non-linear pharmacokinetics: Definition, causes of non-linearity (capacity-limited processes)',
          'Enzyme saturation, Michaelis-Menten pharmacokinetics (Phenytoin, Alcohol)',
          'Estimation of Vmax and Km in steady-state conditions, clinical implications of non-linear kinetics'
        ],
        notesSummary: 'Biexponential two-compartment curve stripping, Michaelis-Menten elimination equation, and Phenytoin dose titration hazards.'
      },
      {
        unitNumber: 5,
        title: 'Bioavailability and Bioequivalence',
        topicsCount: 6,
        topics: [
          'Definition of bioavailability, absolute bioavailability (F) vs relative bioavailability',
          'Objectives of bioavailability studies and regulatory bioequivalence requirements',
          'Methods for assessing bioavailability: Pharmacokinetic methods (Plasma drug concentration: Cmax, tmax, AUC)',
          'Urinary drug excretion data: Cumulative drug excreted (Xu_inf), maximum excretion rate ((dXu/dt)max)',
          'Bioequivalence studies: Study design (single-dose crossover 2x2 design, parallel design), washout period',
          'In vitro - In vivo correlation (IVIVC): Levels of correlation (Level A, Level B, Level C) and dissolution criteria'
        ],
        notesSummary: 'Trapezoidal rule AUC calculation formula, 2x2 Latin square crossover design, and FDA 80-125% 90% confidence interval criteria.'
      }
    ]
  },
  {
    id: 'bp605t',
    semId: 6,
    code: 'BP605T',
    name: 'Pharmaceutical Biotechnology',
    chaptersCount: 5,
    topicsCount: 26,
    credits: 4,
    iconType: 'dna',
    number: 5,
    units: [
      {
        unitNumber: 1,
        title: 'Recombinant DNA Technology',
        topicsCount: 6,
        topics: [
          'Brief introduction to biotechnology and historical milestones in genetic engineering',
          'Enzymes used in r-DNA technology: Restriction endonucleases (Type II), DNA ligases, DNA polymerases',
          'Cloning vectors: Plasmids (pBR322), Bacteriophages (Lambda phage), Cosmids, YAC, BAC',
          'Gene transfer methods: Transformation, electroporation, microinjection, lipofection',
          'Screening and selection of recombinant clones: Blue-white screening, antibiotic resistance markers',
          'Polymerase Chain Reaction (PCR): Principle, steps (Denaturation, Annealing, Extension), and diagnostic applications'
        ],
        notesSummary: 'Type II restriction enzyme palindromic cleavage, pBR322 plasmid genetic map, and PCR thermal cycler temperature program.'
      },
      {
        unitNumber: 2,
        title: 'Therapeutic Proteins & Hybridoma Technology',
        topicsCount: 5,
        topics: [
          'Production of recombinant therapeutic proteins: Recombinant Human Insulin (Humulin) manufacturing process',
          'Production of Hepatitis B vaccine by recombinant yeast, Human Growth Hormone (hGH), Interferons',
          'Hybridoma technology: Principle of monoclonal antibody (mAb) production',
          'Cell fusion: B-lymphocytes and myeloma cells using Polyethylene Glycol (PEG), HAT medium selection',
          'Applications of monoclonal antibodies in diagnostics, cancer targeted therapy (Rituximab), and ELISA'
        ],
        notesSummary: 'Humulin A and B chain recombinant synthesis, HAT medium salvage pathway selection mechanism, and sandwich ELISA steps.'
      },
      {
        unitNumber: 3,
        title: 'Fermentation Technology',
        topicsCount: 5,
        topics: [
          'Introduction to industrial fermentation: Media formulation, carbon and nitrogen sources, antifoam agents',
          'Design of industrial fermenter (Bioreactor): Impeller, sparger, baffles, temperature and pH sensors',
          'Types of fermentation: Batch, fed-batch, continuous fermentation, solid-state fermentation',
          'Industrial production of Penicillin: Microorganism (Penicillium chrysogenum), fermentation conditions, downstream recovery',
          'Production of Citric acid, Vitamin B12, Glutamic acid, and Industrial enzymes (Amylase, Protease)'
        ],
        notesSummary: 'Continuous stirred tank bioreactor (CSTR) engineering diagram, Penicillin downstream crystallization, and aeration kla math.'
      },
      {
        unitNumber: 4,
        title: 'Microbial Genetics & Biotransformation',
        topicsCount: 5,
        topics: [
          'Microbial genetics: Bacterial conjugation, transformation, transduction (generalized vs specialized)',
          'Mutations: Spontaneous, induced mutations, physical and chemical mutagens, Ames test for mutagenicity',
          'Biotransformation: Definition, advantages of microbial biotransformation over chemical synthesis',
          'Steroid biotransformation: 11-alpha hydroxylation of progesterone using Rhizopus nigricans',
          'Enzyme immobilization: Methods (adsorption, covalent bonding, entrapment, cross-linking) and industrial applications'
        ],
        notesSummary: 'Ames Salmonella typhimurium histidine reversion test, microbial steroid hydroxylation stereospecificity, and alginate entrapment.'
      },
      {
        unitNumber: 5,
        title: 'Blood Products & Biosensors',
        topicsCount: 5,
        topics: [
          'Collection, processing and storage of whole human blood and plasma fractionation',
          'Blood products: Dextran 40 and Dextran 70 as plasma volume expanders, Human serum albumin',
          'Coagulation factor concentrates (Factor VIII, Factor IX), Dried human plasma, Immunoglobulins',
          'Biosensors: Principle, biological sensing elements (enzymes, antibodies, DNA), transducer types',
          'Applications of biosensors in blood glucose monitoring (Glucometer) and diagnostic clinical analysis'
        ],
        notesSummary: 'Cohn ethanol cold plasma fractionation steps, glucose oxidase amperometric biosensor circuit, and plasma expanders.'
      }
    ]
  },
  {
    id: 'bp606t',
    semId: 6,
    code: 'BP606T',
    name: 'Pharmaceutical Quality Assurance',
    chaptersCount: 5,
    topicsCount: 25,
    credits: 4,
    iconType: 'checkCircle',
    number: 6,
    units: [
      {
        unitNumber: 1,
        title: 'Quality Management Concepts & ISO',
        topicsCount: 5,
        topics: [
          'Introduction to Quality Control (QC), Quality Assurance (QA), and Total Quality Management (TQM)',
          'Differences and relationships between QC, QA, and cGMP in pharmaceutical industry',
          'Philosophy of Quality by Design (QbD): Target product profile (QTPP), critical quality attributes (CQAs)',
          'ISO 9000 and ISO 14000 series: Elements, requirements, and implementation in pharma manufacturing',
          'National Accreditation Board for Testing and Calibration Laboratories (NABL) accreditation'
        ],
        notesSummary: 'QA vs QC vs cGMP hierarchy pyramid, Ishikawa fishbone root cause analysis, and ISO 9001 quality management principles.'
      },
      {
        unitNumber: 2,
        title: 'Personnel, Premises & Equipment Qualification',
        topicsCount: 5,
        topics: [
          'Organization and personnel: Responsibilities of key personnel, training, hygiene and clothing',
          'Premises design: Location, layout, construction, lighting, ventilation, and cross-contamination prevention',
          'HVAC systems: Design, pressure differential, air changes per hour (ACPH), and particulate monitoring',
          'Equipment qualification: Design Qualification (DQ), Installation Qualification (IQ)',
          'Operational Qualification (OQ), and Performance Qualification (PQ) with official documentation protocols'
        ],
        notesSummary: 'HVAC air handling unit (AHU) schematic with HEPA filters, air change calculations, and DQ-IQ-OQ-PQ qualification V-model.'
      },
      {
        unitNumber: 3,
        title: 'GLP, SOPs & Manufacturing Documentation',
        topicsCount: 5,
        topics: [
          'Good Laboratory Practices (GLP): Organization, personnel, testing facilities, and standard laboratory protocols',
          'Standard Operating Procedures (SOPs): Purpose, format, drafting, distribution, and revision controls',
          'Master Formula Record (MFR) and Batch Manufacturing Record (BMR): Components and importance',
          'Batch Packaging Record (BPR) and distribution records for finished pharmaceutical batches',
          'Data integrity principles: ALCOA and ALCOA+ standards for electronic and manual records'
        ],
        notesSummary: 'ALCOA+ data integrity rules (Attributable, Legible, Contemporaneous, Original, Accurate), BMR line clearance checklist.'
      },
      {
        unitNumber: 4,
        title: 'Quality Control of Packaging & IPQC',
        topicsCount: 5,
        topics: [
          'Quality control testing of packaging materials: Glass containers (hydrolytic resistance, light transmission)',
          'Testing of plastic containers, rubber closures, aluminum foils, and paper board cartons',
          'In-Process Quality Control (IPQC) tests during solid dosage form manufacturing (Tablets, Capsules)',
          'IPQC tests during liquid and parenteral manufacturing (pH, clarity, fill volume, leak testing)',
          'Quality review of complaints, recall procedures, and product recall classification (Class I, II, III)'
        ],
        notesSummary: 'Glass water attack hydrolytic test, rubber closure fragmentation testing, and Class I-III product recall urgency criteria.'
      },
      {
        unitNumber: 5,
        title: 'Validation & Regulatory Audits',
        topicsCount: 5,
        topics: [
          'Validation: Definition, types of process validation (Prospective, Concurrent, Retrospective validation)',
          'Revalidation, validation master plan (VMP), and calibration of laboratory analytical equipment',
          'Cleaning validation: Residue limits, sampling techniques (swab sampling vs rinse sampling)',
          'Analytical method validation: Parameters as per ICH Q2(R1) (Specificity, Linearity, Range, Accuracy, Precision, LOD, LOQ)',
          'Quality audits: Internal self-inspections, supplier audits, and regulatory inspections (US-FDA 483 notices, WHO)'
        ],
        notesSummary: 'ICH Q2(R1) method validation parameters equations, swab sampling surface recovery math, and FDA Form 483 audit responses.'
      }
    ]
  },

  // ================= SEMESTER 7 =================
  {
    id: 'bp701t',
    semId: 7,
    code: 'BP701T',
    name: 'Instrumental Methods of Analysis',
    chaptersCount: 5,
    topicsCount: 35,
    credits: 4,
    iconType: 'microscope',
    number: 1,
    units: [
      {
        unitNumber: 1,
        title: 'UV-Visible Spectroscopy & Fluorimetry',
        topicsCount: 7,
        topics: [
          'Electromagnetic radiation: Properties, wave parameters, electromagnetic spectrum',
          'UV-Visible spectroscopy: Electronic transitions, chromophores, auxochromes, bathochromic and hypsochromic shifts',
          'Beer-Lambert’s law: Derivation, limitations, and deviations (chemical and instrumental)',
          'Instrumentation of UV-Visible spectrophotometer: Radiation sources, monochromators, sample cells, detectors',
          'Woodward-Fieser rules for calculating absorption maxima (lambda max) of conjugated dienes and enones',
          'Fluorimetry: Theory of fluorescence and phosphorescence, Jablonski diagram, factors affecting fluorescence (quenching)',
          'Instrumentation of spectrofluorometer and quantitative pharmaceutical applications (Quinine, Thiamine)'
        ],
        notesSummary: 'Beer’s law derivation A = epsilon * b * c, Woodward-Fieser base values table, Jablonski state transitions, and fluorimetric quenching.'
      },
      {
        unitNumber: 2,
        title: 'Infrared Spectroscopy & Flame Photometry',
        topicsCount: 7,
        topics: [
          'Infrared (IR) spectroscopy: Principle, molecular vibrations (Stretching and Bending vibrations), Hooke’s law',
          'Factors affecting vibrational frequencies: Inductive effect, resonance, hydrogen bonding, conjugation',
          'Instrumentation of dispersive IR vs Fourier Transform Infrared (FTIR) spectrophotometer',
          'Sample handling techniques in IR: Solid (KBr pellet, Nujol mull), liquid and gas sampling',
          'Interpretation of characteristic IR absorption bands of functional groups',
          'Flame Photometry: Principle, excitation mechanism, instrumentation, and estimation of Sodium and Potassium',
          'Atomic Absorption Spectroscopy (AAS): Principle, Hollow Cathode Lamp, graphite furnace, heavy metal estimation'
        ],
        notesSummary: 'Hooke’s law wave number equation, characteristic IR functional group frequencies (OH, C=O, NH), and AAS hollow cathode lamp physics.'
      },
      {
        unitNumber: 3,
        title: 'Chromatography: TLC, Paper & Column',
        topicsCount: 7,
        topics: [
          'Chromatography: Introduction, classification based on mobile/stationary phase and mechanism (Adsorption vs Partition)',
          'Plate theory vs Rate theory of chromatography, Van Deemter equation and factors affecting column efficiency',
          'Thin Layer Chromatography (TLC): Adsorbents, preparation of plates, activation, development techniques, visualization',
          'Rf value (Retardation factor) and factors affecting Rf values, High-Performance TLC (HPTLC) overview',
          'Paper chromatography: Principle, types (ascending, descending, radial, two-dimensional), applications',
          'Column chromatography: Adsorbents, column packing techniques (wet packing vs dry packing)',
          'Factors affecting column resolution and applications in isolation of phytoconstituents'
        ],
        notesSummary: 'Van Deemter equation (A + B/u + C*u) column efficiency graph, Rf value calculation formula, and HPTLC densitometric scanning.'
      },
      {
        unitNumber: 4,
        title: 'HPLC & Gas Chromatography',
        topicsCount: 7,
        topics: [
          'High Performance Liquid Chromatography (HPLC): Principle, instrumentation, and advantages over column chromatography',
          'Pumps (Reciprocating, syringe), sample injection valves (Rheodyne injector)',
          'Columns: Normal phase vs Reversed-Phase HPLC (C18 / ODS columns, C8 columns)',
          'Mobile phase: Isocratic elution vs Gradient elution, degassing techniques',
          'Detectors: UV-Vis detector, Photodiode Array (PDA), Fluorescence, Refractive Index detector (RID)',
          'Gas Chromatography (GC): Principle, carrier gas requirements, sample injection (Split / Splitless)',
          'GC Columns (Packed vs Capillary) and Detectors: Flame Ionization Detector (FID), Thermal Conductivity Detector (TCD), Electron Capture Detector (ECD)'
        ],
        notesSummary: 'RP-HPLC C18 hydrophobic retention mechanism, PDA 3D spectral scanning, and GC FID ionization chemical mechanism.'
      },
      {
        unitNumber: 5,
        title: 'Ion Exchange, Affinity Chromatography & Electrophoresis',
        topicsCount: 7,
        topics: [
          'Ion Exchange Chromatography: Principle, cation and anion exchange resins, mechanism of exchange',
          'Gel Chromatography (Size Exclusion / Gel Filtration): Principle, molecular sieving, dextran gels (Sephadex), applications',
          'Affinity chromatography: Principle, ligands, matrix activation, elution methods, purification of enzymes/antibodies',
          'Electrophoresis: Principle, factors affecting electrophoretic mobility, moving boundary vs zone electrophoresis',
          'Paper electrophoresis, Agarose gel electrophoresis, and SDS-PAGE (Sodium Dodecyl Sulfate Polyacrylamide Gel Electrophoresis)',
          'Isoelectric focusing and Western blotting applications in biopharmaceuticals',
          'X-Ray Crystallography: Bragg’s law, crystal diffraction patterns, and 3D macromolecular structure determination'
        ],
        notesSummary: 'SDS-PAGE protein molecular weight separation mechanism, Bragg’s law n*lambda = 2d*sin(theta), and Sephadex exclusion limits.'
      }
    ]
  },
  {
    id: 'bp702t',
    semId: 7,
    code: 'BP702T',
    name: 'Industrial Pharmacy – II',
    chaptersCount: 5,
    topicsCount: 26,
    credits: 4,
    iconType: 'factory',
    number: 2,
    units: [
      {
        unitNumber: 1,
        title: 'Pilot Plant Scale-Up Techniques',
        topicsCount: 5,
        topics: [
          'General considerations, steps, goals and objectives of pilot plant scale-up techniques',
          'Scale-up considerations for solid dosage forms: Tablets, capsules (mixing, granulating, compression)',
          'Scale-up considerations for liquid dosage forms: Solutions, suspensions, emulsions',
          'Scale-up considerations for semisolids: Ointments, creams (mixing, deaeration, cooling rates)',
          'SUPAC (Scale-Up and Post-Approval Changes) guidelines: Level 1, 2, and 3 changes'
        ],
        notesSummary: 'Pilot plant scale-up ratio rules, SUPAC regulatory change reporting requirements, and industrial shear rate scaling.'
      },
      {
        unitNumber: 2,
        title: 'Technology Transfer',
        topicsCount: 5,
        topics: [
          'Technology transfer: Concept, importance, WHO guidelines on transfer of technology in pharmaceutical manufacturing',
          'Technology transfer protocol: Roles and responsibilities of sending unit (SU) and receiving unit (RU)',
          'Technology transfer from R&D to production: Formulation and analytical method transfer',
          'Packaging technology transfer and cleaning procedure technology transfer',
          'Granularity of documentation, troubleshooting, and Technology Transfer Documentation (TTD)'
        ],
        notesSummary: 'WHO technology transfer checklist, sending vs receiving unit acceptance criteria, and analytical transfer co-validation.'
      },
      {
        unitNumber: 3,
        title: 'Regulatory Affairs & Drug Approval Process',
        topicsCount: 6,
        topics: [
          'Role and responsibilities of Regulatory Affairs department in pharmaceutical industry',
          'Drug Master File (DMF): Types of DMF (Type I, II, III, IV, V as per US-FDA)',
          'Investigational New Drug (IND) application: Objectives, contents, review process',
          'New Drug Application (NDA): Pre-clinical, clinical trial data submission, FDA review timeline',
          'Abbreviated New Drug Application (ANDA): Hatch-Waxman Act, Paragraph I to IV patent certifications',
          'Common Technical Document (CTD) and electronic CTD (eCTD): 5 Modules structure'
        ],
        notesSummary: 'eCTD 5-module hierarchy triangle, Paragraph IV patent challenge 180-day exclusivity, and IND clinical phases.'
      },
      {
        unitNumber: 4,
        title: 'Quality Management Systems & ISO Standards',
        topicsCount: 5,
        topics: [
          'Quality Risk Management (QRM): Principles, risk assessment, risk control, and risk review (ICH Q9)',
          'QRM Tools: Failure Mode and Effects Analysis (FMEA), Fault Tree Analysis (FTA), Hazard Analysis and Critical Control Points (HACCP)',
          'ISO 9001:2015 Quality Management Systems: Principles and documentation requirements',
          'ISO 13485: Medical devices quality management system standards',
          'National Accreditation Board for Hospitals (NABH) overview for healthcare institutions'
        ],
        notesSummary: 'ICH Q9 Quality Risk Management flowchart, FMEA Risk Priority Number (RPN) scoring formula, and ISO 13485 device lifecycle.'
      },
      {
        unitNumber: 5,
        title: 'Indian Regulatory Requirements & CDSCO',
        topicsCount: 5,
        topics: [
          'Central Drugs Standard Control Organization (CDSCO): Constitution, organization structure, role of DCGI',
          'SUGAM online portal: Functionality, online submission of applications for import, clinical trial, and manufacturing',
          'Regulatory requirements for clinical trials in India: New Drugs and Clinical Trials Rules 2019',
          'Ethics Committees (Institutional and Independent): Registration, composition, responsibilities',
          'Bioavailability and Bioequivalence (BA/BE) center accreditation by CDSCO'
        ],
        notesSummary: 'CDSCO DCGI hierarchy structure, SUGAM portal filing modules, and New Drugs & Clinical Trials Rules 2019 ethics regulations.'
      }
    ]
  },
  {
    id: 'bp703t',
    semId: 7,
    code: 'BP703T',
    name: 'Pharmacy Practice',
    chaptersCount: 5,
    topicsCount: 30,
    credits: 4,
    iconType: 'hospital',
    number: 3,
    units: [
      {
        unitNumber: 1,
        title: 'Hospital Pharmacy & Adverse Drug Reactions',
        topicsCount: 6,
        topics: [
          'Hospital: Definition, classification, organizational structure, role of hospital pharmacist',
          'Hospital Pharmacy: Location, layout, personnel requirements, inventory control methods (ABC, VED)',
          'Adverse Drug Reactions (ADR): Definition, classification (Type A, B, C, D, E, F)',
          'Detection, monitoring and reporting of ADRs, Pharmacovigilance Program of India (PvPI)',
          'Causality assessment of ADRs: Naranjo algorithm and WHO-UMC causality scale',
          'Drug interactions: Pharmacokinetic and pharmacodynamic drug-drug, drug-food interactions'
        ],
        notesSummary: 'Naranjo causality probability questionnaire scoring, ABC-VED inventory matrix, and PvPI suspect ADR reporting form.'
      },
      {
        unitNumber: 2,
        title: 'Drug Distribution & Hospital Formulary',
        topicsCount: 6,
        topics: [
          'Drug distribution systems in hospital: Outpatient and inpatient dispensing',
          'Inpatient drug distribution methods: Individual prescription order, complete floor stock, unit dose dispensing system',
          'Central Sterile Supply Department (CSSD): Organization, layout, and sterile processing',
          'Pharmacy and Therapeutics Committee (PTC): Composition, role, and functions',
          'Hospital Formulary: Definition, contents, preparation, revision and formulary management',
          'Drug Information Center (DIC): Resources, queries handling, and computer-assisted retrieval'
        ],
        notesSummary: 'Unit dose automated cart distribution advantages, PTC formulary addition evaluation criteria, and CSSD sterilization workflow.'
      },
      {
        unitNumber: 3,
        title: 'Therapeutic Drug Monitoring & Patient Counseling',
        topicsCount: 6,
        topics: [
          'Therapeutic Drug Monitoring (TDM): Objectives, indications, drugs requiring TDM (Theophylline, Digoxin, Phenytoin, Gentamicin)',
          'Organization and operational protocols of a hospital TDM laboratory',
          'Medication adherence: Definition, consequences of non-adherence, methods of assessment, pharmacist interventions',
          'Patient counseling: Stages of counseling (introduction, consultation, conclusion), communication barriers',
          'Patient counseling in special populations (geriatrics, pediatrics, pregnancy, chronic illness)',
          'Health education programs, smoking cessation, and community health screening'
        ],
        notesSummary: 'TDM sampling timing (trough vs peak serum levels), patient counseling 3-step Indian Pharmacist protocol, and adherence scales.'
      },
      {
        unitNumber: 4,
        title: 'Budget, Clinical Pharmacy & Ward Rounds',
        topicsCount: 6,
        topics: [
          'Hospital pharmacy budget: Types of budgets, budget preparation, resource allocation and auditing',
          'Clinical Pharmacy: Definition, historical development, scope and daily functions of a clinical pharmacist',
          'Ward round participation: Pre-rounds, bedside rounds, medication order review, treatment plan monitoring',
          'Clinical review of patient charts, SOAP format (Subjective, Objective, Assessment, Plan)',
          'Prescription audit and drug utilization review (DUR / DUE)',
          'Medication reconciliation at admission, transfer, and discharge to prevent errors'
        ],
        notesSummary: 'SOAP clinical note writing examples, medication reconciliation 5-step process, and prospective vs retrospective DUR audits.'
      },
      {
        unitNumber: 5,
        title: 'Community Pharmacy & OTC Medication',
        topicsCount: 6,
        topics: [
          'Community Pharmacy: Organization, legal requirements, design and layout of modern retail pharmacy',
          'Inventory management, financial planning, customer service in community pharmacy',
          'Over The Counter (OTC) medication: Rational use, pharmacist counseling on OTC drugs',
          'Counseling for common self-limiting ailments: Pain, cough, cold, diarrhea, acidity, fever',
          'Good Pharmacy Practice (GPP) guidelines as per FIP and WHO',
          'Digital health in community pharmacy: Online pharmacies, tele-pharmacy, and legal boundaries'
        ],
        notesSummary: 'FIP/WHO Good Pharmacy Practice four core roles, OTC differential triage algorithms, and retail pharmacy layout ergonomics.'
      }
    ]
  },
  {
    id: 'bp704t',
    semId: 7,
    code: 'BP704T',
    name: 'Novel Drug Delivery System (NDDS)',
    chaptersCount: 5,
    topicsCount: 28,
    credits: 4,
    iconType: 'shield',
    number: 4,
    units: [
      {
        unitNumber: 1,
        title: 'Controlled Drug Delivery Systems & Microencapsulation',
        topicsCount: 6,
        topics: [
          'Introduction, terminology: Sustained release, controlled release, delayed release, targeted delivery',
          'Advantages, limitations, and physicochemical & biological factors in controlled drug design',
          'Polymers used in controlled drug delivery: Classification, properties, biodegradation mechanism (Eudragit, PLGA, HPMC)',
          'Classification of CDDS: Diffusion-controlled, dissolution-controlled, osmotic systems, ion-exchange systems',
          'Microencapsulation: Definition, core and coating materials, microcapsule morphology',
          'Methods of microencapsulation: Coacervation-phase separation, spray drying, solvent evaporation, fluid-bed coating'
        ],
        notesSummary: 'Zero-order constant release kinetics, PLGA hydrolytic bioerosion mechanism, and coacervation phase diagram steps.'
      },
      {
        unitNumber: 2,
        title: 'Mucosal & Transdermal Drug Delivery Systems',
        topicsCount: 6,
        topics: [
          'Mucosal drug delivery systems: Principles of bioadhesion/mucoadhesion, theories of adhesion (electronic, adsorption, wetting)',
          'Transmucosal routes: Buccal, sublingual, nasal, ocular, pulmonary drug delivery advantages',
          'Buccal patches, sublingual tablets, nasal sprays, and ocular in situ gels',
          'Transdermal Drug Delivery Systems (TDDS): Anatomy of skin, barrier properties of stratum corneum',
          'Components of TDDS: Polymer matrix, drug reservoir, rate-controlling membrane, backing film, adhesives',
          'Chemical permeation enhancers (DMSO, Azone, terpenes) and Physical methods (Iontophoresis, Sonophoresis, Microneedles)'
        ],
        notesSummary: 'Mucoadhesion polymer wetting and chain interpenetration physics, TDDS Franz diffusion cell testing, and microneedle types.'
      },
      {
        unitNumber: 3,
        title: 'Gastroretentive & Osmotic Drug Delivery',
        topicsCount: 5,
        topics: [
          'Gastroretentive Drug Delivery Systems (GRDDS): Principle, physiological considerations of stomach, gastric motility (MMC)',
          'Approaches for GRDDS: Floating drug delivery systems (effervescent vs non-effervescent), swelling systems',
          'High density systems, bioadhesive systems, magnetic systems and evaluation of floating lag time / floating duration',
          'Osmotically Controlled Drug Delivery Systems: Principle, osmotic pressure equation (Van’t Hoff)',
          'Elementary Osmotic Pump (EOP) vs Push-Pull Osmotic Pump (PPOP): Construction, laser drilling, release kinetics'
        ],
        notesSummary: 'Migrating motor complex (MMC) phase I-IV stomach motility, effervescent sodium bicarbonate buoyancy chemistry, and Push-Pull laser orifice mechanics.'
      },
      {
        unitNumber: 4,
        title: 'Targeted Drug Delivery Systems (Nanocarriers)',
        topicsCount: 6,
        topics: [
          'Targeted drug delivery: Concepts, active vs passive targeting, Enhanced Permeability and Retention (EPR) effect',
          'Liposomes: Definition, structure (phospholipid bilayer), classification (MLV, SUV, LUV), thin-film hydration method',
          'Niosomes: Non-ionic surfactant vesicles, structure, comparison with liposomes, preparation methods',
          'Nanoparticles: Polymeric nanoparticles, nanospheres vs nanocapsules, Solid Lipid Nanoparticles (SLN)',
          'Monoclonal antibodies in drug targeting: Immunotoxins, antibody-drug conjugates (ADCs)',
          'Evaluation and therapeutic applications of nanocarriers in cancer chemotherapy'
        ],
        notesSummary: 'Tumor EPR vascular fenestration passive targeting, thin-film rotary evaporator liposome extrusion, and ADC linker chemistry.'
      },
      {
        unitNumber: 5,
        title: 'Ocular, Intrauterine & Transdermal Implants',
        topicsCount: 5,
        topics: [
          'Ocular drug delivery systems: Physiological barriers, precorneal drug loss, corneal penetration pathways',
          'Ophthalmic inserts: Non-erodible inserts (Ocusert pilocarpine system) and Erodible inserts (Lacrisert)',
          'In situ gelling systems (temperature-triggered, pH-triggered, ion-triggered)',
          'Intrauterine Drug Delivery Systems (IUDs): Types (copper-releasing, hormone-releasing - Progestasert, Mirena)',
          'Subcutaneous implants: Norplant levonorgestrel system, biodegradable implant polymers, therapeutic applications'
        ],
        notesSummary: 'Ocusert ethylene-vinyl acetate rate-controlling membrane, Mirena levonorgestrel release rates, and ophthalmic in-situ sol-gel transition.'
      }
    ]
  },

  // ================= SEMESTER 8 =================
  {
    id: 'bp801t',
    semId: 8,
    code: 'BP801T',
    name: 'Biostatistics and Research Methodology',
    chaptersCount: 5,
    topicsCount: 25,
    credits: 4,
    iconType: 'chart',
    number: 1,
    units: [
      {
        unitNumber: 1,
        title: 'Introduction, Central Tendency & Dispersion',
        topicsCount: 5,
        topics: [
          'Introduction to biostatistics: Definition, role and applications in pharmacy and clinical research',
          'Data collection, classification and presentation: Frequency distribution, histogram, frequency polygon, bar charts, pie charts',
          'Measures of central tendency: Arithmetic Mean, Median, Mode - Definitions, formulas, properties, and comparison',
          'Measures of dispersion: Range, quartile deviation, Mean deviation, Standard Deviation (SD), Variance, Coefficient of variation',
          'Correlation and Regression: Karl Pearson’s correlation coefficient, Spearman’s rank correlation, simple linear regression lines'
        ],
        notesSummary: 'Mean vs Median vs Mode selection criteria, sample vs population standard deviation math, and Pearson r coefficient formulas.'
      },
      {
        unitNumber: 2,
        title: 'Probability, Sampling & Parametric Tests',
        topicsCount: 5,
        topics: [
          'Probability: Definition, addition theorem, multiplication theorem, conditional probability',
          'Probability distributions: Normal distribution (Gaussian curve, Z-score, 68-95-99.7 empirical rule), Binomial distribution, Poisson distribution',
          'Sampling techniques: Random sampling, stratified sampling, cluster sampling, systematic sampling, sampling error',
          'Hypothesis testing: Null hypothesis (H0), alternative hypothesis (H1), Type I error (alpha), Type II error (beta), p-value significance',
          'Parametric tests: Student’s t-test (One-sample t-test, Unpaired / Independent two-sample t-test, Paired t-test)'
        ],
        notesSummary: 'Normal distribution bell curve Z-table calculations, Type I vs Type II statistical errors, and Student t-test degrees of freedom formulas.'
      },
      {
        unitNumber: 3,
        title: 'ANOVA & Non-Parametric Tests',
        topicsCount: 5,
        topics: [
          'Analysis of Variance (ANOVA): One-way ANOVA and Two-way ANOVA, F-test, post-hoc tests (Tukey’s test, Dunnett’s test)',
          'Non-parametric tests: Advantages and limitations compared to parametric tests',
          'Chi-square test (X2): Test of independence, test of goodness of fit, contingency tables, Yates’ correction',
          'Mann-Whitney U test (Wilcoxon rank-sum test) for two independent groups',
          'Wilcoxon signed-rank test for paired data and Kruskal-Wallis test for multiple groups'
        ],
        notesSummary: 'ANOVA sum of squares between/within groups table, Chi-square (O-E)^2/E calculation, and non-parametric rank ordering steps.'
      },
      {
        unitNumber: 4,
        title: 'Research Methodology & Literature Review',
        topicsCount: 5,
        topics: [
          'Research Methodology: Meaning, objectives, motivation, and types of research (Descriptive, Analytical, Applied, Fundamental)',
          'Research problem formulation, research question, hypothesis generation',
          'Research design: Principles of experimental design (Randomization, Replication, Local control)',
          'Literature search: Primary, secondary, tertiary literature sources, PubMed, Scopus, Web of Science, Google Scholar',
          'Report writing: Structure of research proposal, dissertation, thesis, IMRAD format (Introduction, Methods, Results, Discussion)'
        ],
        notesSummary: 'Clinical research protocol design, citation managers, impact factor metrics, and IMRAD scientific manuscript writing.'
      },
      {
        unitNumber: 5,
        title: 'Design of Experiments (DoE) & Statistical Software',
        topicsCount: 5,
        topics: [
          'Design of Experiments (DoE): Introduction, historical development, full factorial designs (2^2, 2^3 factorial design)',
          'Fractional factorial designs, Central Composite Design (CCD), Box-Behnken Design',
          'Response surface methodology (RSM), contour plots, optimization of pharmaceutical formulations',
          'Statistical software packages in pharmacy: Introduction to SPSS, GraphPad Prism, Minitab, Design-Expert',
          'Interpretation of statistical software outputs: p-values, R-squared values, regression coefficients'
        ],
        notesSummary: 'Factorial design 2^3 interaction effect equations, Box-Behnken response surface optimization, and GraphPad Prism curve fitting.'
      }
    ]
  },
  {
    id: 'bp802t',
    semId: 8,
    code: 'BP802T',
    name: 'Social and Preventive Pharmacy',
    chaptersCount: 5,
    topicsCount: 24,
    credits: 4,
    iconType: 'hospital',
    number: 2,
    units: [
      {
        unitNumber: 1,
        title: 'Concept of Health & Disease Prevention',
        topicsCount: 5,
        topics: [
          'Concept of health: WHO definition of health, dimensions of health (physical, mental, social, spiritual)',
          'Determinants of health, health indicators (mortality indicators, morbidity indicators, disability rates)',
          'Disease causation: Epidemiological triad (Agent, Host, Environment), natural history of disease',
          'Levels of prevention: Primordial, primary (health promotion, specific protection), secondary (early diagnosis, treatment), tertiary (rehabilitation)',
          'Prevention and control of communicable diseases: Malaria, Dengue, Tuberculosis, HIV/AIDS, Hepatitis'
        ],
        notesSummary: 'Epidemiological triad interactive model, 4 levels of disease prevention with clinical examples, and vector-borne outbreak mitigation.'
      },
      {
        unitNumber: 2,
        title: 'National Health Programs in India',
        topicsCount: 5,
        topics: [
          'National Health Mission (NHM): National Rural Health Mission (NRHM) and National Urban Health Mission (NUHM)',
          'Ayushman Bharat: Pradhan Mantri Jan Arogya Yojana (PMJAY) and Health and Wellness Centers (HWCs)',
          'National Tuberculosis Elimination Program (NTEP / RNTCP): Objectives, DOTS, Nikshay portal',
          'National Vector Borne Disease Control Programme (NVBDCP) and National AIDS Control Programme (NACP)',
          'Pulse Polio Immunization Program and National Leprosy Eradication Programme (NLEP)'
        ],
        notesSummary: 'Ayushman Bharat 5-lakh health coverage structure, Nikshay TB patient direct benefit transfer, and Pulse Polio zero-case strategy.'
      },
      {
        unitNumber: 3,
        title: 'Maternal, Child Health & Immunization Schedules',
        topicsCount: 5,
        topics: [
          'Maternal and child health (MCH): Antenatal care, intranatal care, postnatal care, high-risk pregnancy screening',
          'Maternal Mortality Ratio (MMR) and Infant Mortality Rate (IMR) in India: Targets and interventions',
          'National Family Welfare Programme: Family planning methods, contraceptive prevalence',
          'Universal Immunization Programme (UIP) / Mission Indradhanush: Goals and coverage',
          'National Immunization Schedule: Vaccines administered from birth to 16 years (BCG, Hepatitis B, OPV, Pentavalent, Rotavirus, Measles-Rubella)'
        ],
        notesSummary: 'National Immunization Schedule timeline chart, Pentavalent vaccine antigens, and cold chain vaccine vial monitor (VVM) stages.'
      },
      {
        unitNumber: 4,
        title: 'Community Nutrition & Deficiency Disorders',
        topicsCount: 4,
        topics: [
          'Community nutrition: Balanced diet, macronutrients, micronutrients, Recommended Dietary Allowances (RDA)',
          'Nutritional deficiency disorders: Protein-Energy Malnutrition (PEM - Kwashiorkor vs Marasmus)',
          'Micronutrient deficiencies: Nutritional anemia (Iron deficiency), Vitamin A deficiency (xerophthalmia, night blindness), Iodine deficiency disorders (Goitre)',
          'National nutritional intervention programs: Mid-Day Meal Scheme, Integrated Child Development Services (ICDS), Vitamin A prophylaxis'
        ],
        notesSummary: 'Kwashiorkor vs Marasmus clinical differential table, ICMR RDA nutritional intake tables, and National Anemia Mukt Bharat program.'
      },
      {
        unitNumber: 5,
        title: 'Socio-Economic Factors in Health & De-Addiction',
        topicsCount: 5,
        topics: [
          'Socio-economic factors affecting health: Poverty, sanitation, drinking water supply, housing conditions',
          'Urban and rural health disparities, health care delivery infrastructure in India (Sub-centres, PHCs, CHCs, District hospitals)',
          'Substance abuse and addiction: Alcoholism, tobacco smoking, opioid addiction and health impacts',
          'National de-addiction programs, tobacco cessation counseling, pharmacological and behavioral rehabilitation',
          'Role of pharmacists in public health, community awareness campaigns, and national health policy implementation'
        ],
        notesSummary: 'Primary Health Centre (PHC) staffing and Indian public health standards (IPHS), tobacco nicotine replacement therapy, and de-addiction centers.'
      }
    ]
  },
  {
    id: 'bp803et',
    semId: 8,
    code: 'BP803ET',
    name: 'Pharma Marketing Management',
    chaptersCount: 5,
    topicsCount: 22,
    credits: 4,
    iconType: 'chart',
    number: 3,
    units: [
      {
        unitNumber: 1,
        title: 'Marketing Concepts & Environment',
        topicsCount: 4,
        topics: [
          'Definition, general marketing principles vs pharmaceutical marketing',
          'Marketing environment: Micro and macro environment in the Indian pharmaceutical industry',
          'Market segmentation, targeting, and product positioning (STP strategy)',
          'Consumer behavior in pharmaceuticals: Prescriber behavior, patient behavior, and influencer roles'
        ],
        notesSummary: 'Pharmaceutical STP marketing model, physician prescription decision drivers, and healthcare micro-environment dynamics.'
      },
      {
        unitNumber: 2,
        title: 'Product Management & Product Life Cycle',
        topicsCount: 5,
        topics: [
          'Classification of pharmaceutical products, brand management and branding strategies',
          'Product Life Cycle (PLC): Introduction, Growth, Maturity, Decline phases and marketing strategies',
          'New Product Development (NPD): Stages in pharmaceutical product development, clinical positioning',
          'Product packaging as a marketing tool: Compliance packaging, secondary packaging design',
          'Patent expiration strategies and generic entry defense'
        ],
        notesSummary: 'Product Life Cycle marketing matrix, pharmaceutical brand naming psychology, and authorized generics defense strategy.'
      },
      {
        unitNumber: 3,
        title: 'Promotion & Sales Management',
        topicsCount: 5,
        topics: [
          'Promotion mix: Detailing, physician detailing aids, leave-behind literature (LBL), samples',
          'Medical Representatives (MR): Role, recruitment, training, key performance indicators (KPIs)',
          'Sales territory design, routing, sales quotas, and incentive structures',
          'Continuous Medical Education (CME), round table meetings, conferences, and digital detailing',
          'Uniform Code for Pharmaceutical Marketing Practices (UCPMP) in India'
        ],
        notesSummary: 'Medical rep 3-minute detailing structure, UCPMP ethical marketing guidelines, and territory sales quota optimization.'
      },
      {
        unitNumber: 4,
        title: 'Pricing & Channels of Distribution',
        topicsCount: 4,
        topics: [
          'Pharmaceutical pricing: Methods (Cost-plus, Value-based, Competition-oriented, Penetration, Skimming)',
          'Drug price regulations in India: National Pharmaceutical Pricing Authority (NPPA), DPCO compliance',
          'Distribution channels: C&F agents, stockists, wholesalers, retail chemists, hospital pharmacies',
          'Supply chain management, cold chain logistics for biologicals and temperature-sensitive drugs'
        ],
        notesSummary: 'Price skimming vs penetration pricing in generics, wholesale-retail trade margin regulations, and cold chain logistics.'
      },
      {
        unitNumber: 5,
        title: 'Emerging Trends in Pharmaceutical Marketing',
        topicsCount: 4,
        topics: [
          'Digital pharmaceutical marketing: Omnichannel engagement, healthcare professional (HCP) portals, webinars',
          'Direct-to-Consumer (DTC) advertising: Global perspectives and regulations in India',
          'Social media marketing, patient advocacy groups, and health influencer engagement',
          'Market research: Quantitative and qualitative market research techniques, IMS / IQVIA data analytics'
        ],
        notesSummary: 'IQVIA pharmaceutical audit data analytics, HCP digital detailing metrics, and ethical boundaries of DTC marketing.'
      }
    ]
  },
  {
    id: 'bp804et',
    semId: 8,
    code: 'BP804ET',
    name: 'Pharmacovigilance',
    chaptersCount: 5,
    topicsCount: 25,
    credits: 4,
    iconType: 'shield',
    number: 4,
    units: [
      {
        unitNumber: 1,
        title: 'Introduction & International Pharmacovigilance',
        topicsCount: 5,
        topics: [
          'Introduction and history of Pharmacovigilance, Thalidomide tragedy and birth of modern safety monitoring',
          'Aims, scope and importance of pharmacovigilance in clinical practice and pharmaceutical industry',
          'Basic terminologies: Adverse Event (AE), Adverse Drug Reaction (ADR), Serious Adverse Event (SAE), Suspected Unexpected Serious Adverse Reaction (SUSAR)',
          'WHO International Drug Monitoring Programme: Uppsala Monitoring Centre (UMC), VigiBase database',
          'Pharmacovigilance Programme of India (PvPI): Organizational structure, ADR monitoring centers (AMCs), NCC-IPC'
        ],
        notesSummary: 'Thalidomide historical timeline, WHO-UMC VigiBase reporting network, and PvPI AMC network organization.'
      },
      {
        unitNumber: 2,
        title: 'ADR Reporting & Causality Assessment',
        topicsCount: 5,
        topics: [
          'Methods of ADR reporting: Spontaneous reporting, targeted reporting, active surveillance, cohort event monitoring',
          'Individual Case Safety Report (ICSR): Mandatory elements (patient, reporter, suspect drug, adverse event)',
          'Causality assessment methods: WHO-UMC causality categories (Certain, Probable, Possible, Unlikely, Conditional, Unassessable)',
          'Naranjo Adverse Drug Reaction Probability Scale and European DIPS scale',
          'Severity and predictability assessment of ADRs (Hartwig and Siegel scale)'
        ],
        notesSummary: 'ICSR 4 minimum validity criteria, WHO-UMC 6-tier causality algorithm, and Naranjo probability score sheet.'
      },
      {
        unitNumber: 3,
        title: 'Safety Data Management & Medical Dictionaries',
        topicsCount: 5,
        topics: [
          'Medical Dictionary for Regulatory Activities (MedDRA): Hierarchy (SOC, HLGT, HLT, PT, LLT), versioning',
          'WHO Adverse Reaction Terminology (WHO-ART) and WHO Drug Dictionary (WHODrug)',
          'Pharmacovigilance safety databases: Argus Safety, ARISg - Case intake, triage, medical review, workflow',
          'Signal detection in pharmacovigilance: Concept of signal, qualitative and quantitative signal detection',
          'Proportional Reporting Ratio (PRR), Reporting Odds Ratio (ROR), Information Component (IC)'
        ],
        notesSummary: 'MedDRA 5-level hierarchy tree (System Organ Class to Lowest Level Term), PRR calculation 2x2 contingency table, and Argus workflow.'
      },
      {
        unitNumber: 4,
        title: 'Aggregate Safety Reports & Risk Management',
        topicsCount: 5,
        topics: [
          'Periodic Safety Update Reports (PSUR): Objectives, format, submission frequencies, and ICH E2C guidelines',
          'Periodic Benefit-Risk Evaluation Report (PBRER): Structure and comparative benefit-risk evaluation',
          'Development Safety Update Report (DSUR) in clinical trials as per ICH E2F',
          'Risk Management Plan (RMP): Structure, safety specifications, pharmacovigilance plan, risk minimization measures',
          'Post-Authorization Safety Studies (PASS) and Post-Authorization Efficacy Studies (PAES)'
        ],
        notesSummary: 'ICH E2C PBRER executive structure, EU-RMP module checklist, and routine vs additional risk minimization measures.'
      },
      {
        unitNumber: 5,
        title: 'Regulatory Guidelines & Vaccine Safety',
        topicsCount: 5,
        topics: [
          'Pharmacovigilance inspection and audit by regulatory authorities (US-FDA, EMA, CDSCO)',
          'Good Pharmacovigilance Practices (GVP) modules in European Union',
          'Adverse Events Following Immunization (AEFI): Definition, classification (vaccine reaction, programmatic error, coincidental)',
          'AEFI surveillance and investigation protocol in National Immunization Programme',
          'Pharmacogenomics in pharmacovigilance: HLA alleles and severe cutaneous adverse reactions (Abacavir, Carbamazepine)'
        ],
        notesSummary: 'EMA GVP Module I-XVI overview, WHO AEFI causality classification matrix, and HLA-B*5701 genetic screening guidelines.'
      }
    ]
  }
];
