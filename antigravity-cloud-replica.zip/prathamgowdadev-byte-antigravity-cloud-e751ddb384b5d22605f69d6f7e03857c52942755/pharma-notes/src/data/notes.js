export const notes = [
  {
    id: 'cholinergic',
    unit: 'Unit 2: ANS Drugs',
    title: 'Cholinergic Drugs',
    subtitle: 'Cholinergic Agonists (Parasympathomimetics)',
    readTime: '3 min',
    content: [
      {
        type: 'heading',
        text: 'CHOLINERGIC DRUGS',
      },
      {
        type: 'italic',
        text: 'Drugs that mimic Acetylcholine (ACh) action',
      },
      {
        type: 'paragraph',
        text: 'Cholinergic drugs act either directly by stimulating muscarinic and nicotinic receptors or indirectly by inhibiting acetylcholinesterase.',
      }
    ]
  },
  {
    id: 'anticholinergic',
    unit: 'Unit 2: ANS Drugs',
    title: 'Anticholinergic Drugs',
    subtitle: 'Muscarinic Antagonists (Parasympatholytics)',
    readTime: '4 min',
    content: [
      {
        type: 'heading',
        text: 'ANTICHOLINERGIC DRUGS',
      },
      {
        type: 'paragraph',
        text: 'Drugs that block muscarinic acetylcholine receptors, such as Atropine and Scopolamine.',
      }
    ]
  }
];

export default notes;
