import bp101tNotes from './bp101t_hap.js';
import bp102tNotes from './bp102t_analysis.js';
import bp103tNotes from './bp103t_pharmaceutics.js';
import bp104tNotes from './bp104t_pic.js';
import bp105tNotes from './bp105t_communication.js';
import bp106tNotes from './bp106t_remedial.js';

export const SEMESTER_1_NOTES = {
  bp101t: bp101tNotes,
  bp102t: bp102tNotes,
  bp103t: bp103tNotes,
  bp104t: bp104tNotes,
  bp105t: bp105tNotes,
  bp106rmt: bp106tNotes,
  bp106rbt: bp106tNotes,
};

export function getSemester1Notes(subjectId, unitNumber) {
  const normId = (subjectId || '').toLowerCase().trim();
  const subjectNotes = SEMESTER_1_NOTES[normId];
  if (!subjectNotes) return null;

  if (!unitNumber) return subjectNotes;

  const targetUnitNum = parseInt(unitNumber, 10);
  const foundUnit = subjectNotes.units.find((u) => u.unitNumber === targetUnitNum);
  return foundUnit || subjectNotes.units[0];
}

export default SEMESTER_1_NOTES;
