// BP105T: Communication Skills - Comprehensive Handwritten-Style Exam Study Notes
// Formatted with Exam Weightage, Highlighted Scoring Keywords, Flowcharts, Diagrams & Practice Questions

export const bp105tNotes = {
  subjectCode: 'BP105T',
  subjectName: 'Communication Skills',
  units: [
    {
      unitNumber: 1,
      title: 'Communication Process, Barriers & Non-Verbal Communication',
      examImportance: 'Very High (15 Marks: Barriers to Communication + Non-verbal Kinesics/Proxemics)',
      concepts: [
        {
          id: 'comm_u1_c1',
          topic: 'Communication Cycle & Barriers to Effective Communication',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Guaranteed 10-Marker in 95% University Exams',
          definition: 'Communication is a dynamic two-way transactional process of exchanging information, ideas, feelings, and messages between a sender and a receiver through a mutually understood medium to reach a shared common understanding.',
          highlightKeywords: [
            'Sender (Encoder of idea)', 'Message (Formulated content)',
            'Channel / Medium (Oral, Written, Digital)', 'Receiver (Decoder of message)',
            'Feedback (Vital completing loop)', 'Noise (Interference / Distortion)',
            'Physical Barriers (Distance, Acoustic noise, Faulty equipment)',
            'Psychological Barriers (Prejudice, Anger, Stress, Selective perception)',
            'Semantic / Linguistic Barriers (Medical jargon, Ambiguous words, Misinterpretation)',
            'Physiological Barriers (Hearing impairment, Illness)', 'Socio-cultural Barriers'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  TRANSACTIONAL COMMUNICATION CYCLE & NOISE              |
+-------------------------------------------------------------------------+
              [NOISE / DISTORTION (Interferes at any stage)]
                                   |
    [SENDER] -----> [ENCODING] -----> [MESSAGE] -----> [CHANNEL / MEDIUM]
       ^                                                     |
       |                                                     v
   [FEEDBACK] <--- [SHARED UNDERSTANDING] <--- [DECODING] <-- [RECEIVER]
`,
          explanation: [
            '1. Essential Elements of the Communication Process:',
            '   a) Sender: Source who conceptualizes and initiates message transmission.',
            '   b) Encoding: Translating abstract thoughts into systematic verbal/written symbols or signals.',
            '   c) Message: The tangible payload of information being conveyed.',
            '   d) Channel: Physical transmission medium (spoken airwaves, print, telephone, email).',
            '   e) Receiver: Target person who captures the incoming signal.',
            '   f) Decoding: Interpreting incoming symbols into mental meaning.',
            '   g) Feedback: The response returned to the sender, confirming whether message was comprehended accurately. Without feedback, communication remains incomplete!',
            '   h) Noise: Any environmental, psychological, or mechanical disturbance that impairs message fidelity.',
            '2. Classification of Communication Barriers in Pharmacy Practice:',
            '   a) Physical Barriers: Glass dispensary partitions, loud pharmaceutical machinery, spatial distance between pharmacist and patient counter.',
            '   b) Semantic (Language) Barriers: Use of high-level medical terminology (e.g. telling a rural patient to take a "hypoglycemic agent for postprandial hyperglycemia" instead of "take this sugar tablet after food").',
            '   c) Psychological/Emotional Barriers: Patient anxiety about diagnosis, pharmacist occupational burnout, defensive attitudes.',
            '   d) Socio-Cultural Barriers: Cultural stigmas, language accents, differing body language interpretations.'
          ],
          diagramDescription: 'Circular communication loop diagram illustrating Sender -> Encoding -> Channel -> Decoding -> Receiver -> Feedback loop with lightning bolt symbols representing Noise interference.',
          scoringKeywordsSummary: 'Sender, Encoding, Channel, Receiver, Decoding, Feedback completing loop, Noise, Physical noise, Semantic medical jargon, Psychological stress, Glass counter barrier.',
          topperPearls: 'Always highlight that "Feedback is the lifeblood of communication"; without feedback, communication is merely information dissemination, not a complete communication process.',
          expectedQuestions: {
            tenMarker: 'Define Communication. Draw and explain the communication process model. Classify and discuss in detail the various barriers to effective communication with examples from pharmacy practice.',
            fiveMarker: 'What are Semantic barriers? Give examples of how medical jargon hinders patient counseling. Explain the role of feedback.',
            twoMarker: 'What is Noise in communication? Name four essential components of the communication cycle.'
          }
        },
        {
          id: 'comm_u1_c2',
          topic: 'Non-Verbal Communication: Kinesics, Proxemics, Paralinguistics & Chronemics',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated in 9/10 University Exams',
          definition: 'Non-verbal communication is the transfer of information, emotions, and subtle psychological cues without spoken or written words, accounting for over 65-70% of human interpersonal communication (Mehrabian Rule: 7% words, 38% tone, 55% body language).',
          highlightKeywords: [
            'Albert Mehrabian 7-38-55 Rule', 'Kinesics (Body language: Facial expressions, Eye contact, Gestures, Posture)',
            'Oculesics (Eye contact - Confidence vs Evasion)', 'Proxemics (Edward Hall Spatial Zones: Intimate, Personal, Social, Public)',
            'Paralinguistics (Vocalics: Tone, Pitch, Rate, Inflection, Pauses)',
            'Haptics (Communicative Touch)', 'Chronemics (Time perception & punctuality)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  BRANCHES OF NON-VERBAL COMMUNICATION                   |
+-------------------------------------------------------------------------+
                      NON-VERBAL COMMUNICATION
                                 |
       +---------------+---------+---------+---------------+
       |               |                   |               |
    KINESICS       PROXEMICS         PARALINGUISTICS    HAPTICS
 (Body Movements,  (Spatial Distances, (Vocal Tone,     (Touch,
  Gestures, Eye     Intimate 0-1.5ft,   Pitch, Volume,   Reassuring Handshake,
  Contact, Posture) Personal 1.5-4ft,   Speech Rate,     Consoling Touch)
                    Social 4-12ft)      Pauses)
`,
          explanation: [
            '1. Kinesics (Study of Body Language):',
            '   - Facial Expressions: Universal human emotions (happiness, sadness, disgust, surprise, anger, fear) recognized across all world cultures.',
            '   - Oculesics (Eye Contact): Sustained eye contact conveys honesty, attentiveness, and empathy; downcast eyes signal guilt or insecurity; glaring signals hostility.',
            '   - Posture: Open posture (arms uncrossed, leaning slightly forward) indicates receptivity; closed posture (folded arms, turned away) communicates defensiveness.',
            '2. Proxemics (Edward T. Hall Spatial Distance Zones):',
            '   - Intimate Zone (0 to 1.5 feet): Reserved for close family, emotional bonding, and physical medical examination.',
            '   - Personal Zone (1.5 to 4 feet): Optimal distance for private patient-pharmacist consultation counters.',
            '   - Social Zone (4 to 12 feet): Formal business meetings and general retail floor interaction.',
            '   - Public Zone (> 12 feet): Public speaking and large lecture halls.',
            '3. Paralinguistics (Vocalics): "Not what you say, but HOW you say it." Encompasses pitch variation, vocal timbre, speaking pace (120-150 words/min ideal), volume modulation, and strategic silence/pauses to emphasize crucial drug administration instructions.'
          ],
          diagramDescription: 'Concentric circles diagram of Edward Hall Proxemics showing Intimate (0-1.5ft), Personal (1.5-4ft), Social (4-12ft), and Public (>12ft) spatial radii.',
          scoringKeywordsSummary: 'Mehrabian 7-38-55, Kinesics body language, Oculesics eye contact, Proxemics personal space 1.5-4ft, Paralinguistics pitch and tone, Haptics touch, Open vs closed posture.',
          topperPearls: 'Cite Mehrabian\'s 7-38-55 Rule: 7% verbal words, 38% vocal tone, 55% facial/body language in conveying emotional attitudes.',
          expectedQuestions: {
            tenMarker: 'Explain the various forms of Non-Verbal Communication in detail. Discuss the relevance of Kinesics, Proxemics, and Paralinguistics in pharmacist-patient counseling.',
            fiveMarker: 'Describe Edward Hall\'s four spatial zones of Proxemics with diagrams. Explain the Mehrabian 7-38-55 rule.',
            twoMarker: 'What is Kinesics and Oculesics? State the distance of the Personal Zone in Proxemics.'
          }
        }
      ]
    },
    {
      unitNumber: 2,
      title: 'Perspectives, Communication Styles & 7 Cs of Effective Communication',
      examImportance: 'High (10-15 Marks: 7 Cs of Communication OR Assertive Communication Style)',
      concepts: [
        {
          id: 'comm_u2_c1',
          topic: '7 Cs of Effective Communication & Four Communication Styles',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated in 9/10 University Exams',
          definition: 'The 7 Cs of Communication are seven universal checklist principles formulated by Cutlip and Center that ensure all written and verbal professional messages are transmitted with maximum clarity, persuasion, and accuracy.',
          highlightKeywords: [
            '7 Cs: Clear, Concise, Concrete, Correct, Coherent, Complete, Courteous',
            'Clarity (Simple language, one central idea)', 'Conciseness (Eliminate redundant fluff)',
            'Concreteness (Factual, precise figures, no vagueness)', 'Correctness (Grammar, dosage accuracy)',
            'Coherence (Logical flow)', 'Completeness (Answers who, what, when, where, how)',
            'Courtesy (Polite, empathetic, respectful)', 'Assertive Style (I-statements, Win-Win)',
            'Aggressive Style (You-statements, Win-Lose)', 'Passive Style (Submissive, Lose-Win)',
            'Passive-Aggressive Style (Sarcastic, indirect hostility)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  THE 7 Cs OF EFFECTIVE PROFESSIONAL COMMUNICATION       |
+-------------------------------------------------------------------------+
  1. CLEAR       -> Unambiguous purpose; familiar vocabulary.
  2. CONCISE     -> Expresses maximum meaning in fewest words; avoids filler.
  3. CONCRETE    -> Backed by specific factual data, measurements & evidence.
  4. CORRECT     -> Free from factual errors, spelling mistakes & dosage typos.
  5. COHERENT    -> Ideas flow logically with clear transitional connectors.
  6. COMPLETE    -> Contains all essential details needed for action (5 Ws & 1 H).
  7. COURTEOUS   -> Shows genuine empathy, cultural respect & professional warmth.
`,
          explanation: [
            '1. Deep Dive into the 7 Cs with Pharmacy Examples:',
            '   - Concrete: Saying "Take 500 mg Paracetamol twice daily at 8 AM and 8 PM after meals" instead of "Take some painkiller often".',
            '   - Concise: Eliminating redundant phrases ("at this point in time" -> "now"; "due to the fact that" -> "because").',
            '   - Complete: Medication counseling must state drug name, indication, dose, timing, adverse effects, and missed-dose instructions.',
            '2. The Four Behavioral Communication Styles:',
            '   a) Assertive Style (Gold Standard): Communicates thoughts, needs, and boundaries directly, honestly, and calmly while fully respecting the rights of others (Win-Win mindset). Uses "I-statements" ("I need you to verify this dosage before dispensing").',
            '   b) Aggressive Style: Bullies, interrupts, uses threatening tone, blame, and "You-statements" ("You always mess up the prescription!"). Fosters fear, defensive errors, and hostility (Win-Lose).',
            '   c) Passive Style: Avoids conflict, remains silent, swallows concerns, and fails to express crucial professional opinions (Lose-Win). Leads to dangerous medication errors when pharmacists fail to challenge unclear physician orders.',
            '   d) Passive-Aggressive Style: Appears compliant outwardly but expresses underlying anger through sarcasm, eye-rolling, procrastination, and backstabbing.'
          ],
          diagramDescription: 'A 2x2 grid matrix mapping Communication Styles: X-axis = Respect for Others (Low to High), Y-axis = Respect for Self (Low to High), placing Passive, Aggressive, Passive-Aggressive, and Assertive in the four quadrants.',
          scoringKeywordsSummary: '7 Cs (Clear, Concise, Concrete, Correct, Coherent, Complete, Courteous), Assertive Win-Win I-statements, Aggressive Win-Lose, Passive Lose-Win, Medication error prevention.',
          topperPearls: 'Draw the 2x2 Assertiveness Grid (Respect for Self vs Respect for Others); placing Assertive in the top-right high-self/high-others quadrant earns full marks.',
          expectedQuestions: {
            tenMarker: 'Explain the 7 Cs of Effective Communication in detail with relevant examples from pharmaceutical industry and healthcare practice. Compare the four communication styles (Assertive, Aggressive, Passive, Passive-Aggressive).',
            fiveMarker: 'What is Assertive communication? Why is it considered the ideal communication style for a hospital pharmacist?',
            twoMarker: 'List the 7 Cs of communication. Differentiate between Concrete and Concise communication.'
          }
        }
      ]
    },
    {
      unitNumber: 3,
      title: 'Listening Skills & Patient Counseling',
      examImportance: 'High (10-15 Marks: Active Listening vs Hearing + SOLER Model)',
      concepts: [
        {
          id: 'comm_u3_c1',
          topic: 'Active Listening Skills, Empathy & The SOLER Model',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated in 8/10 University Exams',
          definition: 'Active listening is a structured, intentional cognitive communication technique that requires the listener to fully concentrate, understand, respond to, and remember what is being verbally and emotionally communicated by the speaker, rather than passively hearing words.',
          highlightKeywords: [
            'Hearing (Passive physiological sensory process)', 'Listening (Active intellectual cognitive process)',
            'Empathic Listening (Understanding patient emotional perspective)',
            'Paraphrasing & Restating ("What I hear you saying is...")',
            'Withholding premature judgment / interruptive advice',
            'SOLER Model (Gerard Egan): Squarely face, Open posture, Lean forward, Eye contact, Relax',
            'Open-ended questions (How, What, When) vs Closed-ended questions (Yes/No)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  THE SOLER NON-VERBAL LISTENING FRAMEWORK               |
+-------------------------------------------------------------------------+
   S - SQUARELY FACE THE PATIENT (Indicates undivided, exclusive attention)
   -----------------------------------------------------------------------
   O - ADOPT AN OPEN POSTURE (Uncrossed arms and legs; conveys receptivity)
   -----------------------------------------------------------------------
   L - LEAN SLIGHTLY FORWARD (Shows active engagement and genuine concern)
   -----------------------------------------------------------------------
   E - MAINTAIN COMFORTABLE EYE CONTACT (Builds interpersonal trust & rapport)
   -----------------------------------------------------------------------
   R - RELAXED & NATURAL DEMEANOR (Reduces patient anxiety and defensiveness)
`,
          explanation: [
            '1. Hearing vs Listening Contrast:',
            '   - Hearing is involuntary, effortless, passive auditory reception of sound wave frequencies striking the tympanic membrane.',
            '   - Listening is voluntary, purposeful, disciplined mental interpretation requiring 100% focused cognitive attention and emotional sensitivity.',
            '2. Five Stages of Active Listening (HURIER Model):',
            '   - Hearing (auditory reception) -> Understanding (comprehending vocabulary) -> Remembering (storing key points) -> Interpreting (decoding underlying feelings) -> Evaluating (objective critical assessment) -> Responding (providing validating verbal feedback).',
            '3. Core Techniques of Active Listening for Pharmacists:',
            '   - Paraphrasing: Restating the patient\'s concerns in your own words to verify accuracy ("So you experience dizzy spells whenever you take the tablet on an empty stomach?").',
            '   - Reflecting Feelings: Acknowledging emotional pain ("It sounds like managing these multiple medications has been very stressful for you").',
            '   - Using Open-Ended Questions: Invites patients to describe symptoms fully ("What did your doctor explain regarding how to take this inhaler?").'
          ],
          diagramDescription: 'Five-step circular HURIER listening sequence diagram alongside human figure sketches illustrating each letter of the SOLER posture framework.',
          scoringKeywordsSummary: 'Hearing passive vs Listening active cognitive, SOLER (Square, Open, Lean, Eye, Relax), Paraphrasing, Empathic listening, Open-ended questions, HURIER model, Withholding judgment.',
          topperPearls: 'Always delineate the SOLER acronym step by step; this behavioral counseling framework is universally tested in university evaluations.',
          expectedQuestions: {
            tenMarker: 'Differentiate between Hearing and Listening. Explain the stages of the listening process. Describe the SOLER model of non-verbal communication and its significance in patient counseling.',
            fiveMarker: 'What is Empathic Listening? How does active listening prevent medication compliance errors in community pharmacy?',
            twoMarker: 'What does the acronym SOLER stand for? Give one example of an open-ended question in patient counseling.'
          }
        }
      ]
    },
    {
      unitNumber: 4,
      title: 'Interview Skills, Presentations & Group Discussions',
      examImportance: 'High (10-15 Marks: STAR Interview Method OR GD Evaluation Criteria)',
      concepts: [
        {
          id: 'comm_u4_c1',
          topic: 'Interview Skills: The STAR Method & Group Discussion Etiquette',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated in 8/10 University Exams',
          definition: 'An employment interview is a formal goal-driven interaction where an employer evaluates an applicant\'s technical competence, interpersonal demeanor, and organizational fit. The STAR technique is a structured behavioral answering method using Situation, Task, Action, and Result.',
          highlightKeywords: [
            'Behavioral Interviewing', 'STAR Method: Situation, Task, Action, Result',
            'Pre-interview company research', 'Professional attire & Grooming',
            'Group Discussion (GD): Evaluation of Leadership, Knowledge, Communication, Body language',
            'Constructive initiation vs Aggressive interruption', 'Summarizing in GD'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  THE STAR BEHAVIORAL ANSWERING FRAMEWORK                |
+-------------------------------------------------------------------------+
   S - SITUATION (Describe the specific context or background of challenge)
           |
           v
   T - TASK      (Explain your exact responsibility or objective required)
           |
           v
   A - ACTION    (Detail the specific clinical/technical steps YOU took)
           |
           v
   R - RESULT    (Quantify the positive outcome, metrics & key lesson learned)
`,
          explanation: [
            '1. The STAR Technique Applied to Pharmacy Practice:',
            '   - Situation: "During my hospital internship, an elderly patient was prescribed a fatal ten-fold overdose of Digoxin due to an erroneous decimal point placement on an emergency chart."',
            '   - Task: "My responsibility as clinical dispensary intern was to verify the therapeutic safety of all cardiac prescriptions before dispensing."',
            '   - Action: "I held the dispensing order, reviewed the patient\'s serum creatinine, immediately called the prescribing physician respectfully, explained the lethal toxicity risk, and recommended the correct 0.125 mg dose."',
            '   - Result: "The doctor accepted the correction gratefully, updated the order, and the patient avoided fatal cardiac toxicity."',
            '2. Group Discussion (GD) Do\'s and Don\'ts in Professional Selection:',
            '   - Do\'s: Speak clearly and concisely, listen actively when others speak, back statements with factual clinical evidence, encourage quieter participants, and build upon others\' ideas constructively.',
            '   - Don\'ts: Never shout or point fingers, avoid dominating the floor without letting others contribute, never interrupt rudely, and do not become emotionally aggressive during disagreements.'
          ],
          diagramDescription: 'Four-pillar sequential diagram of STAR framework alongside a circular group discussion table diagram highlighting speaker, active listeners, and moderator.',
          scoringKeywordsSummary: 'STAR method (Situation, Task, Action, Result), Behavioral interview, Quantifiable outcome, Group Discussion leadership, Active listening in GD, Constructive disagreement.',
          topperPearls: 'Always write down a real-life pharmaceutical example demonstrating all 4 steps of the STAR method; examiners appreciate practical clinical application.',
          expectedQuestions: {
            tenMarker: 'Explain the preparation, conduct, and follow-up steps for a professional job interview. Describe the STAR method of answering behavioral questions with a pharmaceutical scenario. Discuss Do\'s and Don\'ts in Group Discussions.',
            fiveMarker: 'What is the STAR method? How should a pharmacist answer questions regarding handling workplace conflicts?',
            twoMarker: 'What does the acronym STAR stand for? Name two key skills evaluated in a Group Discussion.'
          }
        }
      ]
    },
    {
      unitNumber: 5,
      title: 'Written Communication & Email Etiquette',
      examImportance: 'High (10-15 Marks: Resume vs CV Preparation + Business Email Etiquette)',
      concepts: [
        {
          id: 'comm_u5_c1',
          topic: 'Resume vs Curriculum Vitae (CV) & Professional Email Etiquette',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated in 8/10 University Exams',
          definition: 'A resume is a concise 1-2 page summary of skills, work experience, and education tailored to a specific job opening. A Curriculum Vitae (CV) is an exhaustive, in-depth academic dossier detailing publications, research, clinical trials, and credentials.',
          highlightKeywords: [
            'Resume (French: Summary, 1-2 pages, Job-tailored)',
            'Curriculum Vitae (Latin: Course of Life, Detailed, Academic/Research)',
            'Chronological vs Functional Resume', 'Professional Email Structure',
            'Informative Subject Line', 'Formal Salutation (Dear Dr./Mr./Ms.)',
            'Professional Tone & Concise Body', 'Professional Sign-off & Email Signature',
            'Attachment protocols (PDF format, Meaningful file names)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  COMPARATIVE ARCHITECTURE: RESUME vs CV                 |
+-------------------------------------------------------------------------+
  FEATURE            RESUME                             CURRICULUM VITAE (CV)
  Origin & Meaning:  French ("Summary")                 Latin ("Course of Life")
  Length:            Concise (1 to 2 pages maximum)     Comprehensive (3 to 10+ pages)
  Purpose:           Targeted private industry,         Academic, Research, Fellowships,
                     hospital & corporate jobs.         Clinical trials & Teaching posts.
  Content Focus:     Select skills & quantifiable       Exhaustive list of all degrees,
                     achievements relevant to post.     publications, grants, conferences.
  Modifications:     Tailored dynamically for every     Static document; updated only
                     individual job application.        as new credentials accumulate.
`,
          explanation: [
            '1. Essential Components of a Modern Pharmacist Resume:',
            '   - Contact Details: Name, registered pharmacist license number, professional email, LinkedIn URL.',
            '   - Professional Summary: 3-4 sentence value proposition highlighting core pharmaceutical strengths.',
            '   - Education: Degrees, university, graduation year, GPA / percentage.',
            '   - Work Experience / Hospital Internships: Action verbs + quantifiable clinical outcomes.',
            '   - Technical Skills: HPLC, UV Spectrophotometry, Tablet Punching, Dispensing, Clinical Pharmacokinetics.',
            '2. Professional Business Email Rules in Pharmaceutical Industry:',
            '   - Subject Line: Specific and informative (e.g. "Adverse Drug Reaction Report - Ward 4 - Patient ID 942" instead of "Urgent").',
            '   - Salutation: Formal ("Dear Dr. Sharma," instead of "Hey").',
            '   - Body: State purpose in first sentence; use bullet points for lists.',
            '   - Attachments: Ensure files are in standardized PDF format with clean titles (e.g. "R_Sharma_Pharmacist_Resume.pdf").',
            '   - Sign-off: "Sincerely," or "Warm regards," followed by full name, credentials (B.Pharm, R.Ph), contact number, and organization.'
          ],
          diagramDescription: 'Side-by-side template layout comparing 1-page modern chronological resume format with structured corporate email template labeling Header, Subject, Salutation, Body, and Signature block.',
          scoringKeywordsSummary: 'Resume concise 1-2 pages tailored, CV exhaustive academic publications, Action verbs, Professional subject line, Formal salutation, PDF attachment naming, Email signature block.',
          topperPearls: 'Highlight that resumes should always use strong past-tense action verbs (e.g. "Standardized", "Formulated", "Counselled", "Audited") followed by quantifiable clinical metrics.',
          expectedQuestions: {
            tenMarker: 'Differentiate between a Resume and a Curriculum Vitae (CV) in detail. Prepare a standard professional resume of a fresh B.Pharm graduate applying for a QA/QC Pharmacist post. Discuss professional email etiquette rules.',
            fiveMarker: 'Write a short note on business email etiquette in healthcare settings. Explain the structure of an effective professional email.',
            twoMarker: 'Differentiate between Resume and CV in terms of length and purpose. What is the importance of a professional email signature?'
          }
        }
      ]
    }
  ]
};

export default bp105tNotes;
