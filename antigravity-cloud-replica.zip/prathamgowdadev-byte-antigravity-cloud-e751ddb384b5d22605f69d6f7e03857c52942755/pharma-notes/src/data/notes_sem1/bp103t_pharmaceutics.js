// BP103T: Pharmaceutics I - Comprehensive Handwritten-Style Exam Study Notes
// Formatted with Exam Weightage, Highlighted Scoring Keywords, Flowcharts, Diagrams & Practice Questions

export const bp103tNotes = {
  subjectCode: 'BP103T',
  subjectName: 'Pharmaceutics – I',
  units: [
    {
      unitNumber: 1,
      title: 'History of Pharmacy, Pharmacopoeia, Prescription & Posology',
      examImportance: 'Very High (15 Marks: Parts of Prescription + Posology Formulas + IP History)',
      concepts: [
        {
          id: 'ceutics_u1_c1',
          topic: 'Prescription: Definition, Parts, Handling & Errors',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated in 9/10 University Exams',
          definition: 'A prescription is a formal, legally binding written order from a registered medical practitioner (physician, dentist, or veterinarian) to a registered pharmacist, instructing the compounding and dispensing of a specific medication for a designated patient.',
          highlightKeywords: [
            'Superscription (Symbol Rx = Recipe / Take Thou / Eye of Horus)',
            'Inscription (Main body: Base, Adjuvant, Corrective, Vehicle)',
            'Subscription (Direction to Pharmacist: Dispense 20 capsules, Make emulsion)',
            'Signatura / Sig (Direction to Patient: Dose, frequency, route, with water)',
            'Prescriber signature & Registration number', 'Prescription Handling 4 Steps: Receiving, Reading & Checking, Collecting & Weighing, Compounding, Packaging & Labeling'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  PARTS OF A MEDICAL PRESCRIPTION                        |
+-------------------------------------------------------------------------+
   1. PRESCRIBER & PATIENT INFO: Doctor Name, Reg No, Patient Name, Age, Sex, Date
   -------------------------------------------------------------------------
   2. SUPERSCRIPTION: Symbol Rx (Latin: "Recipe" meaning "Take Thou")
   -------------------------------------------------------------------------
   3. INSCRIPTION (Core Formulation Ingredients):
      - Base: Active Therapeutic Drug (e.g. Paracetamol 500 mg)
      - Adjuvant: Enhances action/solubility (e.g. Caffeine 30 mg)
      - Corrective: Improves taste/color/flavor (e.g. Syrup simplex, Orange oil)
      - Vehicle: Liquid diluent/medium (e.g. Purified water q.s.)
   -------------------------------------------------------------------------
   4. SUBSCRIPTION: Directions to the Pharmacist (e.g. "Fiat mistura", Make 100 mL)
   -------------------------------------------------------------------------
   5. SIGNATURA (Sig): Directions to the Patient (e.g. "One teaspoonful tid pc")
   -------------------------------------------------------------------------
   6. RENEWAL INSTRUCTIONS: Number of refills permitted
   -------------------------------------------------------------------------
   7. SIGNATURE, REGISTRATION NUMBER & CLINICAL STAMP OF PRESCRIBER
`,
          explanation: [
            '1. Detailed Anatomy of Inscription: Inscription represents the principal body of the prescription, traditionally composed of four elements:',
            '   a) Base: The principal active pharmaceutical ingredient (API) intended to produce the desired pharmacological cure.',
            '   b) Adjuvant: Secondary substance added to augment action of base, enhance absorption, or stabilize formulation.',
            '   c) Corrective: Agent added to mask bitter taste, noxious odor, or unpleasant color.',
            '   d) Vehicle: Carrier solvent or base excipient to bring formulation to required volume/bulk.',
            '2. Four Vital Steps in Prescription Handling:',
            '   a) Receiving: Pharmacist must receive the prescription personally without changing facial expression to avoid alarming the patient.',
            '   b) Reading & Checking: Scrutinize handwriting, check therapeutic doses, interactions, and legality before compounding.',
            '   c) Collecting & Weighing Materials: Keep all ingredients on the left of balance; transfer each container to the right ONLY AFTER weighing to avoid omission or double addition.',
            '   d) Compounding, Packaging & Labeling: Compound in clean sanitized area, pack in amber glass bottles, apply neat bilingual label with proper auxiliary warnings (e.g. "Shake Well Before Use").'
          ],
          diagramDescription: 'Standard prescription blank sheet layout with 7 numbered boxes mapping out Patient details, Rx symbol, Inscription table, Subscription, Signatura, and Doctor seal.',
          scoringKeywordsSummary: 'Recipe / Take thou / Horus, Inscription (Base, Adjuvant, Corrective, Vehicle), Subscription (to pharmacist), Signatura (to patient), Receiving without facial reaction, Balance left-to-right rule.',
          topperPearls: 'Always mention that the symbol Rx historically represents the Egyptian Eye of Horus (symbol of healing and protection) or Latin imperative "Recipe" meaning "Take thou".',
          expectedQuestions: {
            tenMarker: 'Define prescription. Explain the various parts of a prescription with an ideal specimen model. Discuss the four steps involved in handling a prescription by a pharmacist.',
            fiveMarker: 'Write a short note on Superscription and Inscription. What precautions should a pharmacist observe during compounding and weighing?',
            twoMarker: 'What is the meaning of the symbol Rx? Differentiate between Subscription and Signatura.'
          }
        },
        {
          id: 'ceutics_u1_c2',
          topic: 'Posology: Factors Influencing Dose & Pediatric Dose Calculation Formulas',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Guaranteed Numerical + Theory Question in 95% Exams',
          definition: 'Posology is the branch of medical and pharmaceutical science that deals with the quantitative determination of the appropriate dose or dosage regimen of drugs required to produce the desired pharmacological effect without eliciting toxicity.',
          highlightKeywords: [
            'Posology (Greek: Posos = how much, Logos = study)', 'Age, Sex, Body Weight, Route of Administration',
            'Time of administration', 'Synergism & Antagonism', 'Idiosyncrasy & Hypersensitivity',
            'Tolerance (Tachyphylaxis)', 'Young Rule (Age in years / (Age + 12) x Adult Dose)',
            'Dilling Rule (Age in years / 20 x Adult Dose)', 'Fried Rule (Age in months / 150 x Adult Dose)',
            'Clark Rule (Weight in lbs / 150 x Adult Dose OR Weight in kg / 70 x Adult Dose)',
            'Body Surface Area (BSA) Most Accurate Method'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  PEDIATRIC DOSE CALCULATION FORMULA MATRIX              |
+-------------------------------------------------------------------------+
  1. BASED ON AGE (CHILDREN 1-12 YEARS):
     Young's Formula:    Child Dose = [ Age (Years) / (Age + 12) ] x Adult Dose
     Dilling's Formula:  Child Dose = [ Age (Years) / 20 ] x Adult Dose (For >4 yrs)

  2. BASED ON AGE (INFANTS < 1 YEAR):
     Fried's Formula:    Infant Dose = [ Age (Months) / 150 ] x Adult Dose

  3. BASED ON BODY WEIGHT:
     Clark's Formula:    Child Dose = [ Weight in Pounds (lbs) / 150 ] x Adult Dose
                         Child Dose = [ Weight in kg / 70 ] x Adult Dose

  4. BASED ON BODY SURFACE AREA (MOST ACCURATE):
     Surface Area Rule:  Child Dose = [ BSA of Child (m2) / 1.73 m2 ] x Adult Dose
                         (Average adult surface area = 1.73 m2)
`,
          explanation: [
            '1. Factors Influencing Drug Dosage:',
            '   a) Age: Neonates and infants have immature hepatic microsomal enzymes (glucuronyl transferase) and poor glomerular filtration rates, causing drug toxicity (e.g. Gray Baby Syndrome with Chloramphenicol). Elderly have diminished renal clearance.',
            '   b) Sex: Females generally possess smaller body stature, higher adipose percentage, and during pregnancy/lactation many drugs cross placenta or enter breast milk (teratogenicity).',
            '   c) Body Weight: Obese patients require dose adjustment based on lean body mass for polar drugs.',
            '   d) Route of Administration: IV dose < Oral dose because intravenous route delivers 100% bioavailability bypassing first-pass hepatic metabolism.',
            '   e) Tolerance: Decreased physiological response to repeated administration requiring increasing doses (e.g. Morphine, Nitrates). Tachyphylaxis is rapid acute tolerance (e.g. Ephedrine).',
            '   f) Idiosyncrasy: Genetically determined abnormal unexpected reaction (e.g. Primaquine causing hemolytic anemia in G6PD deficiency).',
            '2. Standard Numerical Model Exam Example: Adult dose of Paracetamol is 500 mg. Calculate the dose for a child of 4 years:',
            '   - Young\'s Rule: Dose = [ 4 / (4 + 12) ] x 500 = (4 / 16) x 500 = 125 mg.',
            '   - Dilling\'s Rule: Dose = [ 4 / 20 ] x 500 = 100 mg.'
          ],
          diagramDescription: 'Nomogram chart showing height and weight lines converging on Body Surface Area (m2), alongside summary formula cards with Young, Dilling, Clark, and Fried formulas.',
          scoringKeywordsSummary: 'Posos how much, Young Age/(Age+12), Dilling Age/20, Fried Months/150, Clark Wt(lbs)/150, BSA/1.73 m2, Gray baby chloramphenicol, G6PD primaquine, Tachyphylaxis.',
          topperPearls: 'Always state that Body Surface Area (BSA) based calculation is the most physiologically accurate method because physiological parameters (cardiac output, GFR) correlate with surface area rather than simple weight or age.',
          expectedQuestions: {
            tenMarker: 'Define Posology. Enumerate and explain various factors influencing drug dosage. Give mathematical formulas for calculating pediatric doses based on age, body weight, and surface area with one numerical example.',
            fiveMarker: 'Differentiate between Young\'s rule and Dilling\'s rule. Calculate the dose for an 8-year-old child if the adult dose is 600 mg. Explain drug tolerance and idiosyncrasy.',
            twoMarker: 'State Clark\'s rule and Fried\'s rule. What is Tachyphylaxis?'
          }
        }
      ]
    },
    {
      unitNumber: 2,
      title: 'Pharmaceutical Calculations & Powders',
      examImportance: 'High (10-15 Marks: Alligation Method Numericals + Eutectic Powders / Effervescent Granules)',
      concepts: [
        {
          id: 'ceutics_u2_c1',
          topic: 'Pharmaceutical Calculations: Alligation Method & Proof Spirit',
          weightage: '5 MARKS / 10 MARKS',
          frequency: 'Repeated 8/10 Exams (100% Guaranteed Numerical)',
          definition: 'The Alligation method is an arithmetical method used to calculate the proportions in which two or more substances of known different strengths must be blended together to prepare a mixture of an intermediate desired strength.',
          highlightKeywords: [
            'Alligation Alternate (Tic-tac-toe grid)', 'Alligation Medial',
            'Higher percentage (H) & Lower percentage (L)', 'Desired percentage (D)',
            'Parts of Higher = D - L', 'Parts of Lower = H - D',
            'Proof Spirit (British & Indian Pharmacopoeia standard)',
            '57.1% v/v Ethyl Alcohol = 100° Proof Spirit', 'Overproof (O.P.) & Underproof (U.P.)',
            'Proof Strength formula: (% v/v x 1.753) - 100'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  ALLIGATION ALTERNATE TIC-TAC-TOE MATRIX                |
+-------------------------------------------------------------------------+
       Higher Strength (H)               Parts of Higher = (D - L)
                             \\         /
                              Desired (D)
                             /         \\
       Lower Strength  (L)               Parts of Lower  = (H - D)
  -------------------------------------------------------------------------
  Total Parts = (D - L) + (H - D) = (H - L)
`,
          explanation: [
            '1. Alligation Alternate Example: In what proportions should 90% alcohol and 50% alcohol be mixed to prepare 70% alcohol?',
            '   - Higher (H) = 90%; Lower (L) = 50%; Desired (D) = 70%.',
            '   - Parts of 90% = D - L = 70 - 50 = 20 parts.',
            '   - Parts of 50% = H - D = 90 - 70 = 20 parts.',
            '   - Ratio = 20 : 20 = 1 : 1 (equal parts of each).',
            '2. Proof Spirit Concept (Customs & Excise Standard):',
            '   - In India and Britain, Proof Spirit is defined as an aqueous solution of ethyl alcohol which at 51°F weighs exactly 12/13th of an equal volume of distilled water.',
            '   - Proof Spirit contains 57.1% v/v (or 49.28% w/w) of absolute alcohol.',
            '   - Any alcohol containing MORE than 57.1% v/v is OVERPROOF (O.P.).',
            '   - Any alcohol containing LESS than 57.1% v/v is UNDERPROOF (U.P.).',
            '3. Proof Spirit Conversion Formula:',
            '   - Proof Strength = (% v/v of alcohol × 1.753) - 100',
            '   - If positive -> Overproof (°O.P.). If negative -> Underproof (°U.P.).',
            '   - Example: Convert 90% v/v alcohol to proof spirit:',
            '     Proof strength = (90 × 1.753) - 100 = 157.77 - 100 = +57.77° O.P. (57.77 degrees Overproof).'
          ],
          diagramDescription: 'Grid layout of Alligation showing diagonal subtraction arrows and Proof Spirit scale showing 0% (100° U.P.), 57.1% (100° Proof / 0°), and 100% absolute alcohol (75.35° O.P.).',
          scoringKeywordsSummary: 'Alligation tic-tac-toe, (D-L) and (H-D), 57.1% v/v = 100 Proof, 1.753 multiplier, (% v/v x 1.753) - 100, Overproof positive, Underproof negative.',
          topperPearls: 'Always state that diluent water has 0% strength when calculating alligation with water, and pure chemical has 100% strength.',
          expectedQuestions: {
            tenMarker: 'Explain the principle and application of Alligation Alternate with three distinct pharmaceutical numerical examples. Define Proof Spirit and derive the proof strength of 40% v/v and 95% v/v alcohol.',
            fiveMarker: 'Calculate the volume of 95% alcohol and water required to prepare 500 mL of 70% alcohol using alligation.',
            twoMarker: 'Define Proof Spirit. What is the proof strength of absolute alcohol (100% v/v)?'
          }
        },
        {
          id: 'ceutics_u2_c2',
          topic: 'Powders: Classification, Geometric Dilution, Eutectic & Effervescent Granules',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated 8/10 Exams',
          definition: 'Pharmaceutical powders are dry, intimate mixtures of finely divided drugs and/or chemicals intended for internal or external use, offering good chemical stability and rapid dissolution compared to tablets.',
          highlightKeywords: [
            'Simple vs Compound powders', 'Geometric Dilution technique (Equal weight mixing)',
            'Eutectic Mixtures (Liquefaction at room temp: Camphor, Menthol, Thymol)',
            'Inert adsorbents (Light magnesium oxide, Kaolin, Starch, Talc)',
            'Effervescent Granules: Sodium bicarbonate + Citric acid + Tartaric acid (1 : 2 : 5 ratio)',
            'Fusion Method (Water of crystallization of citric acid)', 'Wet Granulation Method'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  EUTECTIC MIXTURE DISPENSING PROTOCOL                   |
+-------------------------------------------------------------------------+
      [CAMPHOR] + [MENTHOL] + [THYMOL] (When rubbed together in mortar)
                        |
                        v
     [INTERMOLECULAR HYDROGEN BONDING LOWERS MELTING POINT BELOW ROOM TEMP (25°C)]
                        |
                        v
               [PASTY LIQUID FORMED]
                        |
        +---------------+---------------+
        |                               |
  METHOD 1 (SEPARATION):         METHOD 2 (ADSORPTION - PREFERRED):
  Dispense ingredients in        Mix with equal weight of inert absorbent
  separate packets with label.   (Light MgO, Talc, Kaolin) BEFORE blending.
                                 -> Dry, free-flowing powder maintained!
`,
          explanation: [
            '1. Geometric Dilution Method: Technique employed to uniformly blend a potent, small-quantity drug (e.g. 10 mg) with a large bulk diluent (e.g. 990 mg):',
            '   - Step 1: Place potent drug (10 mg) in clean mortar.',
            '   - Step 2: Add equal weight of diluent (10 mg) and triturate thoroughly.',
            '   - Step 3: Add volume of diluent equal to current total mixture (20 mg) and blend.',
            '   - Step 4: Continue doubling diluent additions geometrically until all excipient is incorporated.',
            '2. Eutectic Mixtures: When two or more organic crystalline substances with low melting points (e.g. Camphor mp 176°C, Menthol mp 42°C, Thymol mp 51°C) are ground together, their mutual contact reduces the melting point of the mixture below room temperature (liquid paste forms).',
            '   - Pharmaceutical Remediation: Triturate each eutectic ingredient separately with an inert protective adsorbent (Light Magnesium Oxide, Magnesium Carbonate, Kaolin, or Starch) before gently mixing them together with a spatula.',
            '3. Effervescent Granules Formulation (Citric acid + Tartaric acid + Sodium Bicarbonate):',
            '   - Why a mixture of Citric and Tartaric acid? Citric acid alone makes granules sticky and difficult to dry. Tartaric acid alone yields crumbly, chalky granules that lack mechanical strength. Blending both in a 1 : 2 : 3.4 ratio yields robust, porous granules.',
            '   - Fusion Method: Citric acid monohydrate (C6H8O7.H2O) contains 1 molecule of water of crystallization. On heating in porcelain dish at 54°C, this water of crystallization is liberated, acting as a natural granulating solvent without adding external liquid!'
          ],
          diagramDescription: 'Stepwise geometric dilution pyramid diagram showing 1:1, 2:2, 4:4 progressive doubling and diagram of fusion heating of effervescent granules.',
          scoringKeywordsSummary: 'Geometric dilution doubling rule, Eutectic camphor-menthol, Inert adsorbents Light MgO, Effervescent ratio Citric : Tartaric : NaHCO3, Water of crystallization 54°C fusion.',
          topperPearls: 'Always mention why Citric acid monohydrate is critical for the Fusion Method: its 1 molecule of water of crystallization is released upon heating at 54°C, eliminating the need for an external liquid binder.',
          expectedQuestions: {
            tenMarker: 'Classify powders. Explain the technique of Geometric Dilution with an example. What are Eutectic mixtures and how are they dispensed? Detail the preparation of Effervescent granules by fusion method.',
            fiveMarker: 'What are Effervescent granules? Why is a combination of citric acid and tartaric acid used instead of single acid? Explain the fusion method.',
            twoMarker: 'What is a Eutectic mixture? Name two inert adsorbents used to dispense eutectic powders.'
          }
        }
      ]
    },
    {
      unitNumber: 3,
      title: 'Monophasic Liquid Dosage Forms',
      examImportance: 'High (10-15 Marks: Syrups Self-Preservation Mechanism + Liniments vs Lotions)',
      concepts: [
        {
          id: 'ceutics_u3_c1',
          topic: 'Syrups: Formulation, Simple Syrup IP & Self-Preservation Mechanism',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated in 9/10 University Exams',
          definition: 'A syrup is a concentrated or nearly saturated aqueous solution of sucrose or other sugars in purified water, with or without added medicinal substances and flavoring agents (Simple Syrup IP contains 66.7% w/w sucrose).',
          highlightKeywords: [
            'Simple Syrup IP (66.7% w/w sucrose, Specific gravity 1.32)',
            'Simple Syrup USP (85% w/v = 64.7% w/w sucrose)',
            'Self-Preserving Osmotic Mechanism (High osmotic pressure, Low water activity aw)',
            'Microbial plasmolysis (Dehydration of bacteria/fungi)',
            'Inversion of Sucrose (Dextrose + Levulose / Invert sugar)',
            'Cap-locking phenomenon & Crystallization', 'Polyols (Glycerin, Sorbitol) as anti-crystallizers'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  SELF-PRESERVATION MECHANISM OF SYRUP IP                |
+-------------------------------------------------------------------------+
   [SUCROSE CONCENTRATION: 66.7% w/w (NEAR SATURATION AT ROOM TEMP)]
                               |
                               v
   [EXCEEDINGLY HIGH OSMOTIC PRESSURE OF CONCENTRATED SUGAR SOLUTION]
                               |
                               v
   [WATER ACTIVITY (aw) DROPS DRAMATICALLY BELOW 0.70]
                               |
                               v
   [WHEN BACTERIA / MOLD SPORES ENTER SYRUP CONTAINER]:
                               |
                               v
   [EXOSMOSIS OCCURS: Water drawn rapidly out of microbial cytoplasm]
                               |
                               v
   [MICROBIAL CELL SHRIVELS & UNDERGOES PLASMOLYSIS]
                               |
                               v
   [MICROORGANISMS CANNOT GROW OR REPRODUCE -> PERMANENT SELF-PRESERVING!]
`,
          explanation: [
            '1. Why Simple Syrup IP is Exactly 66.7% w/w:',
            '   - At 20°C, 1 gram of sucrose dissolves in 0.5 mL of water (saturated solution is ~67% w/w).',
            '   - If concentration is LESS than 66.7% w/w: Water activity is high enough to allow mold, yeast, and bacterial proliferation. Additional preservatives (methylparaben) would be required.',
            '   - If concentration is GREATER than 66.7% w/w: The syrup becomes supersaturated at lower room temperatures, causing sucrose crystals to precipitate out (cap-locking of bottles), leaving the supernatant liquid dilute and susceptible to microbial spoilage.',
            '2. Inversion of Sucrose: During prolonged boiling or acidic storage, sucrose (dextrorotatory, +66.5°) hydrolyzes into equal parts D-glucose (+52.5°) and D-fructose (-92.4°), yielding a net levorotatory mixture called Invert Sugar. Invert sugar is sweeter than sucrose, darkens in color (caramelization), and increases susceptibility to fermentation.',
            '3. Cap-Locking Prevention: Addition of polyhydric alcohols like Sorbitol (70%) or Glycerin (10-15%) retards crystallization around bottle caps and preserves clarity.'
          ],
          diagramDescription: 'Bacterial cell before and after entering 66.7% syrup showing water molecules exiting across cell membrane (exosmosis) causing cytoplasmic shrinkage (plasmolysis).',
          scoringKeywordsSummary: '66.7% w/w IP vs 85% w/v USP, Specific gravity 1.32, High osmotic pressure, Water activity aw < 0.70, Exosmosis, Microbial plasmolysis, Cap-locking, Invert sugar, Sorbitol anti-crystallizer.',
          topperPearls: 'Highlight the difference between Indian Pharmacopoeia (66.7% w/w) and United States Pharmacopeia (85% w/v = 64.74% w/w) simple syrup to demonstrate superior mastery.',
          expectedQuestions: {
            tenMarker: 'Define Syrup. Give the formula, preparation, and storage of Simple Syrup IP. Explain in detail the self-preserving mechanism of syrups with a diagram. What is inversion of sucrose and cap-locking?',
            fiveMarker: 'Why is Simple Syrup IP self-preserving without added chemical preservatives? What happens if sucrose concentration is higher or lower than 66.7% w/w?',
            twoMarker: 'State the concentration of Simple Syrup IP and USP. What is invert sugar?'
          }
        },
        {
          id: 'ceutics_u3_c2',
          topic: 'Comparative Study: Liniments vs Lotions, Elixirs vs Syrups',
          weightage: '5 MARKS / 10 MARKS',
          frequency: 'Repeated 8/10 Exams',
          definition: 'Liniments are monophasic liquid or semi-liquid preparations intended for external application to the skin with rubbing or friction (rubefacient/counter-irritant). Lotions are liquid preparations intended for external application to skin without friction.',
          highlightKeywords: [
            'Liniments: Applied WITH friction / rubbing', 'Counter-irritant, Rubefacient, Anodyne',
            'NEVER applied to broken skin, cuts, or abrasions', 'Vehicle: Alcoholic or oily',
            'Lotions: Applied WITHOUT friction (dabbed on cotton)', 'Cooling, Soothing, Protective (Calamine)',
            'Can be applied to broken/irritated skin', 'Vehicle: Aqueous or dilute alcoholic',
            'Elixirs: Clear, pleasantly flavored, hydroalcoholic (10-40% alcohol) solutions',
            'Self-preserving if alcohol > 15%'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  COMPARATIVE ARCHITECTURE: LINIMENTS vs LOTIONS         |
+-------------------------------------------------------------------------+
  PARAMETER           LINIMENTS                          LOTIONS
  Application:        Applied WITH friction/massage      Applied WITHOUT friction
                      into skin.                         (dabbed with cotton/gauze).
  Broken Skin:        STRICTLY CONTRAINDICATED on        SAFE to apply on broken,
                      broken/inflamed skin (excessive    bruised, or inflamed skin.
                      irritation/absorption).
  Vehicle:            Alcoholic (enhances penetration)   Aqueous, dilute alcoholic,
                      or Oily (eases massage).           or suspensions.
  Action:             Rubefacient, Counter-irritant,     Soothing, Cooling,
                      Analgesic (Camphor, Turpentine).   Protective (Calamine lotion).
  Auxiliary Label:    "FOR EXTERNAL USE ONLY"            "FOR EXTERNAL USE ONLY"
                      "DO NOT APPLY TO BROKEN SKIN"      "SHAKE WELL BEFORE USE"
`,
          explanation: [
            '1. Essential Precaution for Liniments: Liniments contain irritant active ingredients (e.g. Methyl Salicylate, Camphor, Turpentine Oil) dissolved in alcohol or oil. If applied to broken skin or mucous membranes, intense burning, ulceration, and systemic toxicity will occur.',
            '2. Elixirs vs Syrups Comparison:',
            '   - Elixirs are clear, sweetened, hydroalcoholic solutions containing 10% to 40% alcohol. Because of the alcoholic content, elixirs can solubilize both water-soluble and alcohol-soluble ingredients (e.g. Phenobarbital Elixir).',
            '   - Elixirs are less sweet and less viscous than syrups, but are significantly more stable against temperature fluctuations.',
            '   - Syrups are concentrated aqueous sucrose solutions (66.7% w/w) with minimal or no alcohol, primarily used as taste-masking vehicles for pediatric patients.'
          ],
          diagramDescription: 'Side-by-side comparison table cards with warning label badges ("Do not apply to broken skin" vs "Shake well before use").',
          scoringKeywordsSummary: 'Liniment WITH friction, Lotion WITHOUT friction, Contraindicated broken skin, Rubefacient counter-irritant, Calamine soothing, Elixirs hydroalcoholic 10-40%, Water-and-alcohol soluble.',
          topperPearls: 'Always write the exact auxiliary label warning in double quotes and capital letters: "FOR EXTERNAL USE ONLY - NOT TO BE APPLIED TO WOUNDS OR BROKEN SKIN".',
          expectedQuestions: {
            tenMarker: 'Differentiate between Liniments and Lotions in detail. Write a note on Elixirs, discussing formulation, alcohol content, and advantages over syrups.',
            fiveMarker: 'Why must Liniments never be applied to broken skin? Compare Syrups and Elixirs.',
            twoMarker: 'What is a counter-irritant? Give one example of a Liniment and one example of a Lotion.'
          }
        }
      ]
    },
    {
      unitNumber: 4,
      title: 'Biphasic Liquid Dosage Forms (Suspensions & Emulsions)',
      examImportance: 'Maximum High (15-20 Marks: Flocculated vs Deflocculated OR Emulsion Instability is 100% asked)',
      concepts: [
        {
          id: 'ceutics_u4_c1',
          topic: 'Suspensions: Flocculated vs Deflocculated & Formulation Stability',
          weightage: '10 MARKS ESSAY',
          frequency: 'Guaranteed 10-Marker in 98% University Exams',
          definition: 'A pharmaceutical suspension is a coarse, heterogeneous, biphasic liquid dosage form in which finely divided insoluble solid drug particles (internal/dispersed phase, 0.5-5.0 µm) are homogeneously distributed throughout a continuous liquid vehicle with the aid of suspending agents.',
          highlightKeywords: [
            'Flocculated Suspensions (Loose flocs, High sedimentation rate, No caking)',
            'Deflocculated Suspensions (Discrete particles, Slow sedimentation, Hard irreversible cake / Claying)',
            'Sedimentation Volume (F = Vu / Vo)', 'Degree of Flocculation (Beta)',
            'DLVO Theory (Van der Waals attractive forces vs Electrostatic double-layer repulsion)',
            'Secondary minimum attraction (Loose flocculation)', 'Zeta Potential (-20 to -50 mV)',
            'Suspending agents / Hydrocolloids (Sodium CMC, Methylcellulose, Tragacanth)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|             COMPARATIVE ARCHITECTURE: FLOCCULATED vs DEFLOCCULATED      |
+-------------------------------------------------------------------------+
  PROPERTY               FLOCCULATED SUSPENSION         DEFLOCCULATED SUSPENSION
  Particle State:        Particles form loose clusters  Particles exist as separate,
                         or flocs (network).            discrete individual entities.
  Sedimentation Rate:    HIGH (Rapid settling because   LOW (Settles very slowly in
                         flocs act as large globules).  accordance with Stokes law).
  Sediment Nature:       Loose, porous, honeycomb-like  Dense, compact, closely packed
                         sediment structure.            solid mass.
  Redispersion:          EASILY REDISPERSED upon        VERY DIFFICULT / IMPOSSIBLE TO
                         gentle shaking.                REDISPERSE (Hard Cake / Clay).
  Supernatant Liquid:    CLEAR (All flocs settle down   TURBID / CLOUDY (Fine particles
                         together cleanly).             remain suspended).
  Zeta Potential:        Low (-10 to -20 mV).           High (> -30 mV, strong repulsion).
  Ideal Formulation:     YES (Pharmaceutical ideal).    NO (Rejected due to caking).
`,
          explanation: [
            '1. Why Deflocculated Suspensions Form Hard Cakes (Claying):',
            '   - In deflocculated systems, high repulsive zeta potential keeps particles separate. They settle slowly according to Stokes Law: v = 2r^2(d1-d2)g / 9η.',
            '   - Particles settle individually, with smaller particles filling the voids between larger particles.',
            '   - Weight of upper layers presses the lower particles past the primary energy barrier into the deep primary thermodynamic minimum.',
            '   - Strong short-range attractive Van der Waals forces fuse the particles into an irreversible, cement-like "hard cake" that CANNOT be resuspended by shaking.',
            '2. Why Flocculated Suspensions are Pharmaceutically Preferred:',
            '   - Controlled flocculation is achieved by adding electrolytes (monovalent/divalent ions e.g. KH2PO4, AlCl3) to reduce zeta potential to the secondary minimum (~10-20 nm separation distance).',
            '   - Particles form light, fluffy, porous flocs. Although they settle rapidly, the sediment structure entraps vehicle liquid, preventing close contact and enabling instant uniform redispersion upon mild agitation.',
            '3. Sedimentation Volume (F): F = Vu / Vo, where Vu = ultimate settled volume of sediment, Vo = original initial suspension volume. Ideal suspension F approaches 1.0 (no clear supernatant).'
          ],
          diagramDescription: 'DLVO potential energy curve showing Primary Minimum (caking), Primary Maximum (energy barrier), and Secondary Minimum (flocculation), paired with settling cylinder diagrams showing flocculated porous sediment with clear liquid vs deflocculated hard cake with cloudy supernatant.',
          scoringKeywordsSummary: 'Flocculated loose flocs, Deflocculated discrete particles, Hard cake claying, DLVO secondary minimum, Stokes law, Sedimentation volume F = Vu/Vo, Zeta potential, Easy redispersion.',
          topperPearls: 'Draw the DLVO Energy vs Distance curve showing the Secondary Minimum where flocculation occurs; this elevates your paper to highest university honors.',
          expectedQuestions: {
            tenMarker: 'Define Suspension. Differentiate between Flocculated and Deflocculated suspensions in detail with diagrams. Explain the formulation of stable suspensions and describe DLVO theory.',
            fiveMarker: 'What is Sedimentation Volume (F) and Degree of Flocculation (Beta)? Explain why caking occurs in deflocculated suspensions.',
            twoMarker: 'State Stokes Law of sedimentation and define Zeta potential.'
          }
        },
        {
          id: 'ceutics_u4_c2',
          topic: 'Emulsions: Types, Identification Tests & Physical Instability (Creaming vs Cracking)',
          weightage: '10 MARKS ESSAY',
          frequency: 'Guaranteed 10-Marker in 95% Exams',
          definition: 'An emulsion is a thermodynamically unstable biphasic liquid system consisting of at least two immiscible liquid phases (usually oil and water), one of which is uniformly dispersed as microscopic droplets (globules, 0.1-100 µm) throughout the other, stabilized by an emulsifying agent.',
          highlightKeywords: [
            'Oil-in-Water (O/W - Oral, Non-greasy)', 'Water-in-Oil (W/O - External cold cream, Greasy)',
            'Identification Tests: Dilution test, Dye solubility test (Amaranth, Scarlet Red)',
            'Conductivity test (O/W conducts electricity)', 'Cobalt chloride paper test (Blue to Pink)',
            'Fluorescence test (UV light)', 'Bancroft Rule (Phase in which emulsifier is soluble is continuous phase)',
            'HLB System (Griffin, 0-20 scale: W/O emulsifiers HLB 3-6, O/W emulsifiers HLB 8-16)',
            'Instability: Creaming (Reversible, Upward/Downward)', 'Sedimentation',
            'Cracking / Breaking (Irreversible coalescence of interfacial film)', 'Phase Inversion'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  PHYSICAL INSTABILITIES OF EMULSIONS                    |
+-------------------------------------------------------------------------+
                            EMULSION INSTABILITY
                                     |
         +---------------------------+---------------------------+
         |                                                       |
     REVERSIBLE                                             IRREVERSIBLE
  (Redistributed by Shaking)                             (Permanently Destroyed)
         |                                                       |
   +-----+-----+                                           +-----+-----+
   |           |                                           |           |
Creaming   Sedimentation                                Cracking   Phase Inversion
(Upward    (Downward settling                           (Breaking, (O/W transforms
 flotation  of dense globules)                           interfacial into W/O)
 of oil)                                                 film ruined)
`,
          explanation: [
            '1. Five Official Identification Tests for Emulsion Type:',
            '   a) Dilution Test: Emulsion is diluted with water. If it dilutes smoothly without separation, it is O/W. If oil droplets separate out, it is W/O.',
            '   b) Dye Solubility Test: Water-soluble dye (Amaranth / Methylene Blue) stains continuous phase of O/W (colored background, clear globules). Oil-soluble dye (Scarlet Red / Sudan III) stains continuous phase of W/O.',
            '   c) Conductivity Test: A bulb connected to electrodes dipped into O/W glows because water contains ions and conducts current; bulb fails to glow in W/O (oil is a dielectric non-conductor).',
            '   d) Cobalt Chloride Paper Test: Filter paper impregnated with CoCl2 turns from blue to pink when dipped into O/W emulsion.',
            '   e) Fluorescence Test: Mineral oils fluoresce under UV light. W/O shows continuous uniform fluorescence; O/W shows spotty fluorescent globules.',
            '2. Detailed Comparison: Creaming vs Cracking:',
            '   - Creaming (Reversible): Upward or downward movement of dispersed droplets due to density differences (Stokes Law). Globules retain their protective emulsifier film. REVERSIBLE upon simple shaking.',
            '   - Cracking/Breaking (Irreversible): Complete destruction and coalescence of dispersed droplets into a continuous free oil layer. The protective monomolecular or multimolecular emulsifying film is completely ruptured. IRREVERSIBLE; cannot be reconstituted by shaking.',
            '   - Causes of Cracking: Addition of opposite emulsifier, temperature extremes (freezing/boiling), microbial degradation of gum emulsifier, addition of electrolytes.',
            '3. Phase Inversion: Dynamic reversal of an emulsion from O/W to W/O (or vice versa), triggered by changing phase volume ratio (oil > 74%), altering temperature, or switching monovalent soap (Na+ -> O/W) with divalent soap (Ca2+ -> W/O).'
          ],
          diagramDescription: 'Sketches showing 5 identification test setups (Conductivity bulb, Dye under microscope) and 4 emulsion instability stages: Good uniform emulsion -> Creamed emulsion -> Cracked emulsion (separate oil slick on top).',
          scoringKeywordsSummary: 'O/W vs W/O, Dilution test, Amaranth / Scarlet Red dye, Conductivity bulb, Cobalt chloride blue to pink, Bancroft rule, HLB 3-6 vs 8-16, Creaming reversible, Cracking irreversible, Phase inversion 74% limit.',
          topperPearls: 'Always state Bancroft\'s Rule: "The phase in which an emulsifier is more soluble constitutes the continuous (external) phase." Hydrophilic emulsifiers yield O/W; lipophilic emulsifiers yield W/O.',
          expectedQuestions: {
            tenMarker: 'Define Emulsion. Classify emulsions with examples. Discuss the five identification tests to determine emulsion type. Explain physical instability mechanisms (Creaming, Cracking, Phase Inversion) and their prevention.',
            fiveMarker: 'Differentiate between Creaming and Cracking in emulsions. What is Bancroft\'s rule and HLB system?',
            twoMarker: 'Name two water-soluble and two oil-soluble dyes used in emulsion testing. What is phase inversion?'
          }
        }
      ]
    },
    {
      unitNumber: 5,
      title: 'Suppositories & Pharmaceutical Incompatibilities',
      examImportance: 'Very High (15 Marks: Displacement Value Numerical + Physical/Chemical Incompatibilities)',
      concepts: [
        {
          id: 'ceutics_u5_c1',
          topic: 'Suppositories: Types, Bases, Cocoa Butter Polymorphism & Displacement Value',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated in 9/10 University Exams (100% Guaranteed Numerical)',
          definition: 'Suppositories are solid unit dosage forms of various shapes, weights, and sizes intended for insertion into body cavities (rectum, vagina, or urethra) where they melt at body temperature (37°C) or dissolve in cavity fluids to exert local or systemic pharmacological actions.',
          highlightKeywords: [
            'Rectal suppositories (1-2 g torpedo/bullet shape)', 'Vaginal suppositories / Pessaries (3-5 g globular/oviform)',
            'Urethral bougies (Pencil shape, 2-4 g)', 'Theobroma Oil / Cocoa Butter (Oleaginous base, mp 30-35°C)',
            'Cocoa Butter Polymorphism (Gamma 18°C, Alpha 24°C, Beta-prime 28°C, Stable Beta 34.5°C)',
            'Hydrophilic bases (Glycerogelatin base, Polyethylene Glycols / PEGs / Macrogols)',
            'Displacement Value (DV = Weight of drug / Weight of base displaced)',
            'Lubricants for suppository molds (Liquid paraffin for aqueous bases, Alcohol/soap for oily bases)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  DISPLACEMENT VALUE CALCULATION PROTOCOL                |
+-------------------------------------------------------------------------+
  FORMULA FOR DISPLACEMENT VALUE (D):
  
         D = [ Weight of Medicament (w) ] / [ (G - (M - w)) ]
  
  Where:
  - G = Weight of pure base required to fill N mold cavities
  - M = Weight of medicated suppositories filling N mold cavities
  - w = Total weight of drug present in N medicated suppositories
  - (M - w) = Weight of base present in N medicated suppositories
  - Base Displaced = G - (M - w)
`,
          explanation: [
            '1. Theobroma Oil (Cocoa Butter) Polymorphism Hazard:',
            '   - Cocoa butter is a natural triglyceride of stearic, palmitic, and oleic acids.',
            '   - If overheated above 36°C during melting, it converts to unstable polymorphic forms (Gamma mp 18°C, Alpha mp 24°C, Beta-prime mp 28°C).',
            '   - These unstable forms remain liquid at room temperature and fail to solidify in the suppository mold for days!',
            '   - To avoid this, melt cocoa butter gently on a water bath until only 2/3rd is melted, then remove from heat so latent heat melts the remainder into the stable Beta form (mp 34.5°C).',
            '2. Standard Displacement Value Numerical Model:',
            '   - Problem: Calculate the displacement value of Zinc Oxide if 12 suppositories containing 0.2 g Zinc Oxide each weigh 13.2 g, and 12 unmedicated cocoa butter suppositories weigh 12.0 g.',
            '   - Total pure base weight (G) = 12.0 g.',
            '   - Total medicated suppository weight (M) = 13.2 g.',
            '   - Total weight of drug (w) = 12 × 0.2 = 2.4 g.',
            '   - Weight of base in medicated suppositories = M - w = 13.2 - 2.4 = 10.8 g.',
            '   - Weight of base displaced by 2.4 g drug = G - (M - w) = 12.0 - 10.8 = 1.2 g.',
            '   - Displacement Value (DV) = w / Base displaced = 2.4 / 1.2 = 2.0.',
            '   - Interpretation: 2 grams of Zinc Oxide displace 1 gram of cocoa butter base!'
          ],
          diagramDescription: 'Suppository mold diagram showing 6 cavities and lubrication, paired with melting point graph of 4 polymorphic crystal states of cocoa butter.',
          scoringKeywordsSummary: 'Rectal 1-2g torpedo, Pessaries 3-5g, Cocoa butter mp 30-35°C, Unstable alpha/gamma vs stable beta 34.5°C, Glycerogelatin base, Displacement value D = w / [G-(M-w)], Liquid paraffin mold lubricant.',
          topperPearls: 'Always state the mold lubricant selection rule: Oily bases (cocoa butter) require aqueous lubricant (Liquid paraffin or soft soap solution); Aqueous bases (glycerogelatin) require oily lubricant (Liquid paraffin).',
          expectedQuestions: {
            tenMarker: 'Define Suppository. Classify suppository bases with examples. Explain the polymorphism of Cocoa Butter. Define Displacement Value and solve a complete numerical problem.',
            fiveMarker: 'Explain the preparation of Glycerogelatin suppository base. Why must Cocoa Butter not be overheated during melting?',
            twoMarker: 'Define Displacement Value. What lubricant is used for Cocoa Butter suppository molds?'
          }
        },
        {
          id: 'ceutics_u5_c2',
          topic: 'Pharmaceutical Incompatibilities: Physical, Chemical & Therapeutic',
          weightage: '10 MARKS ESSAY',
          frequency: 'Guaranteed 10-Marker in 90% Exams',
          definition: 'A pharmaceutical incompatibility is an unintended, undesirable reaction or clash that occurs when two or more substances are prescribed or mixed together, resulting in an unsafe, unsightly, inactive, or hazardous pharmaceutical preparation.',
          highlightKeywords: [
            'Physical Incompatibility (Immiscibility, Insolubility, Precipitation, Liquefaction)',
            'Chemical Incompatibility: Tolerated vs Adjusted',
            'Precipitation by double decomposition', 'Effervescence',
            'Alkaloidal chemical incompatibility (Alkaloidal salts precipitated by tannins/alkalies)',
            'Therapeutic Incompatibility (Synergism, Antagonism, Contraindicated drugs, Overdose)',
            'Remediation: Order of mixing, Thickening agents, Changing solvent vehicle'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  CLASSIFICATION OF PHARMACEUTICAL INCOMPATIBILITIES     |
+-------------------------------------------------------------------------+
                       PHARMACEUTICAL INCOMPATIBILITIES
                                      |
         +----------------------------+----------------------------+
         |                                                         |
     PHYSICAL                              CHEMICAL            THERAPEUTIC
  (Visible change,                      (Reaction forms        (Clashing in vivo
   no chemical change)                   new compound)          drug action)
         |                                     |                   |
   +-----+-----+-----+                   +-----+-----+       +-----+-----+
   |           |     |                   |           |       |           |
Immiscibility Liquefaction Tolerated  Adjusted   Antagonism  Contraindicated
 (Oil/Water)   (Eutectic) (Order of   (Substitute (Penicillin (Aspirin in peptic
                           mixing)    reagent)     + Tetra)    ulcer)
`,
          explanation: [
            '1. Physical Incompatibilities & Solutions:',
            '   a) Immiscibility: Oil and water do not mix -> Add emulsifying agent and homogenize into an emulsion.',
            '   b) Insolubility: Insoluble solids (Chalk, Calamine) settle rapidly -> Add suspending agent (Tragacanth) to increase viscosity.',
            '   c) Liquefaction of Solids: Eutectic mixtures (Camphor + Menthol) -> Mix with inert adsorbent (Light Kaolin, Starch) before blending.',
            '2. Chemical Incompatibilities (Tolerated vs Adjusted):',
            '   a) Tolerated: Incompatibility can be minimized by altering the order of mixing or diluting solutions before mixing, WITHOUT altering the prescription formula (e.g. Strychnine HCl + Aromatic spirit of ammonia -> dilute both in separate halves of water before combining).',
            '   b) Adjusted: Incompatibility CANNOT be prevented by order of mixing; requires substituting or adding an official equivalent excipient with prescriber permission (e.g. adding compound powder of tragacanth to suspend indiffusible precipitates).',
            '3. Therapeutic Incompatibilities:',
            '   a) Synergism/Additive: Two sedatives given together produce fatal respiratory depression.',
            '   b) Antagonism: Bactericidal antibiotic (Penicillin, requires active cell wall synthesis) given with Bacteriostatic antibiotic (Tetracycline, halts cell division) -> Tetracycline inhibits the bactericidal action of Penicillin!',
            '   c) Contraindication: Prescribing Aspirin to a patient with active peptic ulcer (causes severe gastric hemorrhage).'
          ],
          diagramDescription: 'Flowchart classifying Physical, Chemical, and Therapeutic categories with two clinical prescription specimens and their specific pharmaceutical remediation steps.',
          scoringKeywordsSummary: 'Physical immiscibility/liquefaction, Chemical tolerated (order of mixing) vs adjusted (substitute excipient), Alkaloidal precipitation, Therapeutic antagonism (Penicillin + Tetracycline), Contraindicated aspirin peptic ulcer.',
          topperPearls: 'Always give the classic example of Therapeutic Antagonism: "Penicillin (Bactericidal) + Tetracycline (Bacteriostatic)" to demonstrate exact clinical pharmacology mastery.',
          expectedQuestions: {
            tenMarker: 'What is a Pharmaceutical Incompatibility? Classify incompatibilities with detailed examples. Explain the differences between Tolerated and Adjusted chemical incompatibilities with remediation methods.',
            fiveMarker: 'Explain Therapeutic Incompatibility with examples of drug antagonism, synergism, and contraindications.',
            twoMarker: 'Differentiate between Tolerated and Adjusted chemical incompatibilities. Give one example of a physical incompatibility.'
          }
        }
      ]
    }
  ]
};

export default bp103tNotes;
