// BP106RMT/RBT: Remedial Mathematics & Remedial Biology - Comprehensive Handwritten-Style Exam Study Notes
// Formatted with Exam Weightage, Highlighted Scoring Keywords, Flowcharts, Diagrams & Practice Questions

export const bp106tNotes = {
  subjectCode: 'BP106RMT',
  subjectName: 'Remedial Mathematics / Remedial Biology',
  units: [
    {
      unitNumber: 1,
      title: 'Partial Fractions, Matrices & Determinants (Math) / Living World & Plant Morphology (Bio)',
      examImportance: 'Very High (15-20 Marks: Cramer\'s Rule OR Stomata Types & Plant Anatomy is guaranteed)',
      concepts: [
        {
          id: 'remedial_u1_c1',
          topic: 'Cramer\'s Rule & Matrix Inversion in Pharmaceutical Calculations',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Guaranteed 10-Marker in 95% Mathematics Exams',
          definition: 'Cramer\'s Rule is an explicit algebraic algorithm that uses determinants to solve a system of linear equations with as many equations as unknowns, widely applied in multi-component spectrophotometric assays and chemical mixture equilibria.',
          highlightKeywords: [
            'System of linear equations', 'Coefficient matrix determinant (Delta / D)',
            'Numerator determinants (Dx, Dy, Dz)', 'Cramer\'s formula: x = Dx/D, y = Dy/D, z = Dz/D',
            'Non-singular matrix condition (Det != 0)', 'Singular matrix (Det = 0, No unique solution)',
            'Minor (Mij) & Cofactor (Cij = (-1)^(i+j) Mij)', 'Adjoint of Matrix (Transpose of Cofactor Matrix)',
            'Inverse Matrix formula: A^-1 = (1 / Det A) * Adj A'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  CRAMER'S RULE COMPUTATION ALGORITHM                    |
+-------------------------------------------------------------------------+
  GIVEN SYSTEM:   a1*x + b1*y + c1*z = d1
                  a2*x + b2*y + c2*z = d2
                  a3*x + b3*y + c3*z = d3
                            |
                            v
       [CALCULATE COEFFICIENT DETERMINANT (D)]
       | a1  b1  c1 |
   D = | a2  b2  c2 |  ---> IF D = 0: STOP (No unique solution!)
       | a3  b3  c3 |  ---> IF D != 0: PROCEED TO COMPUTE Dx, Dy, Dz:
                            |
         +------------------+------------------+
         |                                     |
   Replace Col 1 with Constants:         Replace Col 2 with Constants:
       | d1  b1  c1 |                        | a1  d1  c1 |
  Dx = | d2  b2  c2 |                   Dy = | a2  d2  c2 |
       | d3  b3  c3 |                        | a3  d3  c3 |
                            |
                            v
            [FINAL VALUES: x = Dx / D,  y = Dy / D,  z = Dz / D]
`,
          explanation: [
            '1. Step-by-Step Cramer\'s Rule Implementation:',
            '   - Step 1: Formulate the coefficient determinant D from the coefficients of variables x, y, and z.',
            '   - Step 2: Compute D. If D = 0, the equations are either inconsistent (no solution) or linearly dependent (infinite solutions).',
            '   - Step 3: Compute Dx by replacing the first column of D with the constant column vector [d1, d2, d3]T.',
            '   - Step 4: Compute Dy by replacing the second column of D with the constant vector.',
            '   - Step 5: Compute Dz by replacing the third column of D with the constant vector.',
            '   - Step 6: Find variables: x = Dx / D, y = Dy / D, z = Dz / D.',
            '2. Matrix Inversion Method (A * X = B -> X = A^-1 * B):',
            '   - Step 1: Find determinant of matrix A: Det(A). Must be non-zero (non-singular).',
            '   - Step 2: Compute matrix of minors Mij.',
            '   - Step 3: Compute cofactor matrix Cij = (-1)^(i+j) * Mij.',
            '   - Step 4: Transpose cofactor matrix to obtain Adjoint matrix: Adj(A) = (Cij)T.',
            '   - Step 5: Calculate inverse: A^-1 = (1 / Det A) × Adj(A).',
            '   - Step 6: Multiply A^-1 by column vector B to obtain solution vector X.'
          ],
          diagramDescription: 'Matrix bracket equations showing 3x3 determinant expansion along first row with alternating (+ - +) signs and substitution of constant column vectors.',
          scoringKeywordsSummary: 'Cramer\'s rule x = Dx/D, D != 0 non-singular condition, Minor and Cofactor (-1)^(i+j), Adjoint transpose of cofactor, Inverse A^-1 = (1/Det A)*Adj(A), Spectrophotometric multi-component assay.',
          topperPearls: 'Always state the prerequisite condition: "Cramer\'s rule is applicable only when the determinant of the coefficient matrix D is non-zero (D ≠ 0)."',
          expectedQuestions: {
            tenMarker: 'State and prove Cramer\'s rule. Solve the following system of linear equations using Cramer\'s rule: 2x - y + 3z = 9, x + y + z = 6, x - y + z = 2. Find the inverse of a 3x3 matrix.',
            fiveMarker: 'Solve the system: 3x + y = 7, 2x - 3y = 1 using Cramer\'s rule. Explain the properties of determinants.',
            twoMarker: 'What is a Singular matrix? State the formula for the inverse of a matrix.'
          }
        },
        {
          id: 'remedial_u1_c2',
          topic: 'Stomata Classification & Plant Anatomy (Remedial Biology)',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Guaranteed 10-Marker in 95% Biology Exams',
          definition: 'Stomata are microscopic specialized epidermal pores flanked by two kidney-shaped guard cells that regulate gas exchange (CO2/O2) and transpiration, whose arrangement relative to surrounding subsidiary cells forms a primary taxonomic and pharmacognostical identification standard.',
          highlightKeywords: [
            'Guard cells (Kidney-shaped in dicots, Dumbbell-shaped in monocots/grasses)',
            'Subsidiary cells / Accessory cells', 'Paracytic (Rubiaceous - Parallel subsidiary cells, Senna)',
            'Diacytic (Caryophyllaceous - Perpendicular cross subsidiary cells, Peppermint/Vasaka)',
            'Anisocytic (Cruciferous - Unequal 3 subsidiary cells, Datura/Belladonna)',
            'Anomocytic (Ranunculaceous - Irregular subsidiary cells, Digitalis/Clove)',
            'Actinocytic (Radiating subsidiary cells)', 'Stomatal Number & Stomatal Index formula'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  PHARMACOGNOSTIC CLASSIFICATION OF STOMATA              |
+-------------------------------------------------------------------------+
                              STOMATA TYPES
                                    |
         +-----------------+--------+--------+-----------------+
         |                 |                 |                 |
     PARACYTIC         DIACYTIC          ANISOCYTIC        ANOMOCYTIC
   (Rubiaceous)      (Caryophyllaceous)(Cruciferous)     (Ranunculaceous)
         |                 |                 |                 |
   Subsidiary cells  Two subsidiary    THREE subsidiary  Subsidiary cells
   parallel to       cells at RIGHT    cells; ONE is     indistinguishable
   stoma pore.       ANGLES to stoma.  MUCH SMALLER.     from epidermal.
         |                 |                 |                 |
   Senna, Coca       Peppermint,       Datura,           Digitalis,
                     Vasaka            Belladonna        Clove
`,
          explanation: [
            '1. Four Principal Pharmacognostical Stomatal Classes:',
            '   a) Paracytic (Rubiaceous / Parallel-celled): The stoma is accompanied by two subsidiary cells whose long axes lie completely parallel to the stoma pore. Classic drug example: Senna leaves (Cassia angustifolia), Coca.',
            '   b) Diacytic (Caryophyllaceous / Cross-celled): The stoma is enclosed by two subsidiary cells whose shared cell boundary wall lies at exact right angles (90°, perpendicular) to the long axis of the pore. Classic drug example: Vasaka (Adhatoda vasica), Peppermint.',
            '   c) Anisocytic (Cruciferous / Unequal-celled): The stoma is surrounded by exactly three subsidiary cells, of which one is distinctly and significantly SMALLER than the other two. Classic drug example: Datura stramonium, Belladonna, Henbane.',
            '   d) Anomocytic (Ranunculaceous / Irregular-celled): The stoma is surrounded by an indefinite number of subsidiary cells that do not differ in size or shape from ordinary epidermal cells. Classic drug example: Digitalis purpurea, Clove, Buchu.',
            '2. Stomatal Index (I) Formula: Standardized quantitative microscopic parameter that remains constant for a plant species regardless of environmental or leaf age variations:',
            '   - Stomatal Index: I = [ S / (E + S) ] × 100',
            '     * S = Number of stomata per unit area of leaf.',
            '     * E = Number of epidermal cells in the exact same unit area.'
          ],
          diagramDescription: 'High-yield microscopic drawings of the 4 stomata types: Paracytic (parallel sandwich), Diacytic (perpendicular cross), Anisocytic (two large, one small triangle), and Anomocytic (irregular puzzle border).',
          scoringKeywordsSummary: 'Guard cells, Subsidiary cells, Paracytic parallel Senna, Diacytic right-angle Vasaka, Anisocytic 3 cells one smaller Datura, Anomocytic irregular Digitalis, Stomatal Index I = S/(E+S)*100.',
          topperPearls: 'Always draw all 4 stomatal diagrams with their accompanying medicinal plant examples and state the Stomatal Index equation: I = [S / (E + S)] × 100.',
          expectedQuestions: {
            tenMarker: 'Classify stomata with neat labeled diagrams and official pharmacognostical crude drug examples. Define Stomatal Number and Stomatal Index with their calculation formula and significance in detecting adulteration.',
            fiveMarker: 'Differentiate between Paracytic, Diacytic, and Anisocytic stomata with diagrams. Calculate the Stomatal Index if S = 20 and E = 80.',
            twoMarker: 'What type of stomata is found in Datura and Senna? State the Stomatal Index formula.'
          }
        }
      ]
    },
    {
      unitNumber: 2,
      title: 'Analytical Geometry & Calculus (Math) / Digestive & Circulatory Physiology (Bio)',
      examImportance: 'High (10-15 Marks: Differentiation / Integration in Pharmacokinetics OR Digestive Enzymes)',
      concepts: [
        {
          id: 'remedial_u2_c1',
          topic: 'Calculus: Differentiation, Integration & Area Under Curve (AUC)',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated in 9/10 Mathematics Exams',
          definition: 'Calculus is the mathematical study of continuous change. Differential calculus determines the instantaneous rate of change (slope/derivatives), while Integral calculus computes accumulated totals (areas under curves, AUC) in pharmacokinetics and drug bioavailability.',
          highlightKeywords: [
            'Derivative definition: dy/dx = lim h->0 [f(x+h) - f(x)] / h',
            'Standard Derivatives: d/dx(x^n) = n*x^(n-1), d/dx(e^x) = e^x, d/dx(ln x) = 1/x',
            'Product Rule: d/dx(u*v) = u*(dv/dx) + v*(du/dx)',
            'Quotient Rule: d/dx(u/v) = [v*(du/dx) - u*(dv/dx)] / v^2',
            'Chain Rule: dy/dx = (dy/du) * (du/dx)',
            'Maxima & Minima (dy/dx = 0 and d2y/dx2 < 0 for Maximum peak concentration Cmax)',
            'Area Under Curve (AUC) by Trapezoidal Rule: AUC = sum [ (C_i + C_i+1)/2 * (t_i+1 - t_i) ]'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  CALCULUS IN PHARMACOKINETICS (Cmax & AUC)              |
+-------------------------------------------------------------------------+
       Plasma Drug Conc (C) vs Time (t) Curve: C(t) = A*e^(-ka*t) - B*e^(-ke*t)
                                   |
         +-------------------------+-------------------------+
         |                                                   |
   DIFFERENTIATION (FINDING PEAK Cmax):             INTEGRATION (FINDING TOTAL EXPOSURE AUC):
   Set first derivative to zero:                    Definite integral from 0 to infinity:
   dC/dt = 0  ---> Solves for Peak Time (tmax)      AUC = Integral [ C(t) dt ] from 0 to Inf
   Verify d2C/dt2 < 0 (confirms Maximum)            Computed by Trapezoidal Rule:
   Substitute tmax into C(t) to get Cmax!           Basis of Bioavailability & Bioequivalence!
`,
          explanation: [
            '1. Essential Differentiation Formulas for Pharmacy Students:',
            '   - Power Rule: d/dx (x^n) = n × x^(n-1)',
            '   - Exponential Rule: d/dx (e^(k*x)) = k × e^(k*x)',
            '   - Logarithmic Rule: d/dx (ln x) = 1/x',
            '   - Product Rule: d/dx (u × v) = u (dv/dx) + v (du/dx)',
            '   - Quotient Rule: d/dx (u / v) = [ v (du/dx) - u (dv/dx) ] / v^2',
            '2. Maxima and Minima in Pharmacokinetics:',
            '   - To locate peak plasma drug concentration (Cmax) and time of peak absorption (tmax):',
            '   - Step 1: Calculate the first derivative dC/dt and set it equal to 0 (slope at peak is horizontal).',
            '   - Step 2: Solve for t -> this gives tmax.',
            '   - Step 3: Compute second derivative d2C/dt2. If negative (< 0), it confirms a local Maximum!',
            '3. Trapezoidal Rule for Area Under Curve (AUC):',
            '   - Represents the total systemic drug exposure over time in blood circulation.',
            '   - The plasma concentration-time curve is divided into vertical trapezoids between consecutive sampling time points t1, t2, ..., tn.',
            '   - Area of each trapezoid = [ (C1 + C2) / 2 ] × (t2 - t1).',
            '   - Total AUC(0->t) = Sum of all trapezoidal segments.',
            '   - Absolute Bioavailability (F) = [ AUC_oral / Dose_oral ] / [ AUC_iv / Dose_iv ].'
          ],
          diagramDescription: 'Pharmacokinetic plasma concentration vs time curve illustrating slope = 0 at peak (tmax, Cmax) and vertical trapezoidal slices under the curve labeled AUC.',
          scoringKeywordsSummary: 'Power rule n*x^(n-1), Product rule, Quotient rule, Maxima dC/dt = 0 and d2C/dt2 < 0, tmax and Cmax, Trapezoidal rule (C1+C2)/2 * (t2-t1), AUC bioavailability F.',
          topperPearls: 'Always connect Calculus directly to its clinical use: Differentiation finds peak time tmax (dC/dt = 0), and Integration finds systemic drug exposure Area Under Curve (AUC).',
          expectedQuestions: {
            tenMarker: 'Explain the rules of differentiation (Product, Quotient, Chain rule) with examples. How is differentiation used to determine maximum drug concentration (Cmax)? Explain the Trapezoidal Rule for calculating Area Under the Curve (AUC) in bioavailability studies.',
            fiveMarker: 'Find the derivative of y = (x^2 + 1) / (x - 1). Explain the Trapezoidal rule formula with a diagram.',
            twoMarker: 'State the condition for a function to have a maximum value. What is the pharmacological significance of AUC?'
          }
        },
        {
          id: 'remedial_u2_c2',
          topic: 'Human Digestive Physiology & Enzyme Cascade (Remedial Biology)',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated in 9/10 Biology Exams',
          definition: 'Digestion is the biochemical and mechanical breakdown of complex, insoluble macromolecules (carbohydrates, proteins, lipids) into simple, soluble, absorbable monomers (glucose, amino acids, fatty acids) across the gastrointestinal tract mucosa.',
          highlightKeywords: [
            'Salivary Amylase / Ptyalin (Starch to Maltose at pH 6.8)',
            'Gastric Chief cells (Pepsinogen activated by HCl to Pepsin)',
            'Parietal / Oxyntic cells (HCl pH 1.5-2.0 & Intrinsic Factor for B12)',
            'Pancreatic Proteases: Trypsinogen activated by Enterokinase to Trypsin',
            'Chymotrypsin, Carboxypeptidase', 'Pancreatic Amylase & Lipase',
            'Bile salts (Sodium glycocholate & taurocholate - Lipid emulsification & Micelles)',
            'Brush border disaccharidases (Maltase, Sucrase, Lactase)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  BIOCHEMICAL MACROMOLECULE DIGESTIVE CASCADE           |
+-------------------------------------------------------------------------+
  1. CARBOHYDRATES:
     Starch + Salivary/Pancreatic Amylase -> Maltose + Maltase -> GLUCOSE

  2. PROTEINS:
     Proteins + Pepsin (Stomach, pH 2) -> Peptides
     Peptides + Trypsin/Chymotrypsin (Pancreas, pH 8) -> Dipeptides
     Dipeptides + Aminopeptidases (Intestine) -> AMINO ACIDS

  3. FATS / LIPIDS:
     Triglycerides + Bile Salts (Emulsification into fine droplets)
     Emulsified Lipids + Pancreatic Lipase -> FATTY ACIDS + MONOGLYCERIDES
     (Absorbed into lymphatic lacteals as Chylomicrons)
`,
          explanation: [
            '1. Gastric Secretion & Digestion:',
            '   - Parietal (Oxyntic) cells secrete Hydrochloric Acid (HCl, lowering stomach pH to 1.5-2.0, killing ingested pathogens) and Castle\'s Intrinsic Factor (essential for ileal absorption of Vitamin B12; deficiency leads to Pernicious Anemia).',
            '   - Chief (Peptic) cells secrete inactive proenzyme Pepsinogen. Acidic pH cleaves pepsinogen into active Pepsin, an endopeptidase that digests proteins into proteoses and peptones.',
            '2. Pancreatic Activation Enzyme Cascade:',
            '   - Pancreatic juice contains inactive zymogens to prevent self-digestion of pancreas.',
            '   - Enterokinase (Enteropeptidase) embedded in duodenal brush border cleaves inactive Trypsinogen into active Trypsin.',
            '   - Active Trypsin autocatalytically activates more trypsinogen and activates Chymotrypsinogen to Chymotrypsin and Procarboxypeptidase to Carboxypeptidase.',
            '3. Role of Bile Salts in Lipid Digestion:',
            '   - Liver synthesizes bile salts (Sodium glycocholate and Sodium taurocholate).',
            '   - Bile contains NO digestive enzymes, but its amphipathic bile salts lower surface tension, breaking down large lipid fat globules into microscopic droplets (Emulsification).',
            '   - This increases surface area thousand-fold for Pancreatic Lipase to hydrolyze triglycerides into fatty acids and 2-monoglycerides, encapsulated into water-soluble Micelles for intestinal uptake.'
          ],
          diagramDescription: 'Anatomical flowchart tracing food transit through Stomach (Chief/Parietal cells), Duodenum (Bile duct and Pancreatic duct entry), and Enterocyte brush border with enzyme labels at each station.',
          scoringKeywordsSummary: 'Ptyalin pH 6.8, Parietal HCl and Intrinsic Factor, Chief pepsinogen, Duodenal enterokinase activates trypsin, Bile salts emulsification micelles, Pancreatic lipase, Chylomicrons.',
          topperPearls: 'Always state that bile contains NO digestive enzymes; its role is purely mechanical emulsification via bile salts to increase surface area for pancreatic lipase.',
          expectedQuestions: {
            tenMarker: 'Describe the digestion and absorption of carbohydrates, proteins, and lipids in the human gastrointestinal tract with enzymes, pH, and products. Explain the activation of pancreatic zymogens and the role of bile salts.',
            fiveMarker: 'Explain the physiological role of Hydrochloric Acid and Intrinsic Factor in gastric digestion. How are lipids absorbed into lacteals?',
            twoMarker: 'What is Enterokinase? Why does bile digest fats even though it contains no enzymes?'
          }
        }
      ]
    }
  ]
};

export default bp106tNotes;
