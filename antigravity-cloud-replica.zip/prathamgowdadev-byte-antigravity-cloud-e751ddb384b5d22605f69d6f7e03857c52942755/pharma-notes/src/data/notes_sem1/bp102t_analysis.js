// BP102T: Pharmaceutical Analysis I - Comprehensive Handwritten-Style Exam Study Notes
// Formatted with Exam Weightage, Highlighted Scoring Keywords, Flowcharts, Diagrams & Practice Questions

export const bp102tNotes = {
  subjectCode: 'BP102T',
  subjectName: 'Pharmaceutical Analysis – I',
  units: [
    {
      unitNumber: 1,
      title: 'Errors, Primary Standards & Acid-Base Titrations',
      examImportance: 'Very High (15-20 Marks: Errors Classification + Indicator Theories / Titration Curves)',
      concepts: [
        {
          id: 'analysis_u1_c1',
          topic: 'Classification & Minimization of Errors in Quantitative Analysis',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated in 9/10 University Exams',
          definition: 'An analytical error is defined as the deviation or difference between the experimentally observed numerical value (measured value) and the true or accepted reference value of a given quantity.',
          highlightKeywords: [
            'Determinate (Systematic) Errors', 'Indeterminate (Random) Errors',
            'Instrumental errors', 'Reagent impurities', 'Operative / Personal errors',
            'Methodic errors (Co-precipitation, incomplete reaction)', 'Accuracy vs Precision',
            'Calibration of instruments', 'Blank determination', 'Control determination',
            'Independent method analysis', 'Running parallel duplicates'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  CLASSIFICATION OF ANALYTICAL ERRORS                    |
+-------------------------------------------------------------------------+
                           ANALYTICAL ERRORS
                                  |
            +---------------------+---------------------+
            |                                           |
    DETERMINATE (SYSTEMATIC)                   INDETERMINATE (RANDOM)
   (Known cause, Unidirectional,             (Accidental, Fluctuating,
    Can be measured & eliminated)             Cannot be eliminated, Gaussian)
            |
    +-------+-------+-------+
    |       |       |       |
Instrumental Operative Reagents Methodic
 (Faulty    (Color-  (Trace   (Incomplete
  balance,   blind,   metals,  reaction,
  pipette)   parallax) CO2)   decomposition)
`,
          explanation: [
            '1. Determinate (Systematic) Errors: Have definite identifiable causes and exert a bias in one consistent direction (constant error or proportional error).',
            '   a) Instrumental Errors: Faulty weights, uncalibrated burettes, electronic drift.',
            '   b) Operative/Personal Errors: Parallax error while reading meniscus, improper transfer of precipitates, color blindness for indicator end points.',
            '   c) Reagent Errors: Impurities present in analytical grade chemicals, leaching of alkali from glass reagent bottles.',
            '   d) Methodic Errors: Inherent flaws in the chemical reaction, e.g. co-precipitation, post-precipitation, side reactions, incomplete precipitation.',
            '2. Indeterminate (Random) Errors: Arise from uncontrollable variations in environment (slight temperature or voltage fluctuations, drafts on balance pans). Follow a normal Gaussian distribution bell curve.',
            '3. Methods for Minimizing Determinate Errors:',
            '   - Calibration of apparatus and volumetric glassware against standard weights and pure water.',
            '   - Blank Determination: Performing assay omitting sample to subtract reagent impurity consumption.',
            '   - Control Determination: Running standard known substance under identical conditions.',
            '   - Independent Method of Analysis: Verifying results with an orthogonal method (e.g. titrimetry verified by spectrophotometry).',
            '   - Parallel Replicates: Performing triplicates and taking mean/median.'
          ],
          diagramDescription: 'Target board diagrams comparing Accuracy vs Precision (High Accuracy + High Precision clustered at bullseye; High Precision + Low Accuracy tightly clustered off-center; Low Accuracy + Low Precision scattered widely) and Normal Gaussian Error Distribution curve.',
          scoringKeywordsSummary: 'Determinate vs Indeterminate, Instrumental, Operative, Reagent, Methodic, Blank determination, Calibration, Gaussian curve, Accuracy (trueness) vs Precision (reproducibility).',
          topperPearls: 'Always draw the 4 target dartboards to illustrate Accuracy vs Precision; examiners give immediate 5/5 for this visual representation.',
          expectedQuestions: {
            tenMarker: 'Define error. Classify errors with examples and explain in detail the various methods employed to minimize determinate errors in pharmaceutical analysis.',
            fiveMarker: 'Differentiate between Accuracy and Precision with suitable target diagrams. Write a note on Blank and Control determinations.',
            twoMarker: 'What is a methodic error? Define significant figures with one example.'
          }
        },
        {
          id: 'analysis_u1_c2',
          topic: 'Theories of Acid-Base Indicators & Neutralization Curves',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated 8/10 Exams',
          definition: 'An acid-base indicator is an organic weak acid (HIn) or weak base (InOH) that exhibits different colors in its unionized and ionized molecular forms, having a visible color transition range of approximately pH = pKa ± 1.',
          highlightKeywords: [
            'Ostwald Theory (Ionization theory)', 'Quinonoid Theory (Resonance tautomerism)',
            'Benzenoid (Colorless/Light) vs Quinonoid form (Intense color)', 'Phenolphthalein pH range 8.2-10.0',
            'Methyl Orange pH range 3.1-4.4', 'Indicator transition interval (pH = pKa ± 1)',
            'Neutralization Curves (Titration Curves)', 'Strong Acid vs Strong Base (pH inflection 3.5 - 10.5)',
            'Weak Acid vs Strong Base (pH inflection 7.5 - 10.5)', 'Weak Base vs Strong Acid (pH inflection 3.5 - 7.0)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  NEUTRALIZATION TITRATION CURVES (INFLECTION)           |
+-------------------------------------------------------------------------+
   pH 14 |
         |                   +------- Strong Base (NaOH)
   pH 10 |                 /
         |       INFLECTION VERTICAL BREAK (pH 3.5 to 10.5)
         |       [Both Phenolphthalein & Methyl Orange work]
   pH  7 |-------------|-- Equivalence Point (pH 7.0 for SA-SB)
         |             |
   pH  4 |             |
         |           /
   pH  0 +----------+-------------------- Volume of Titrant (mL)
         Strong Acid (HCl)
`,
          explanation: [
            '1. Ostwald Theory: Color change is due to ionization. The unionized indicator molecule (HIn) has one color, while its dissociated ion (In-) has a different color. In acidic solution, excess H+ suppresses indicator ionization by common ion effect, showing unionized color.',
            '2. Quinonoid (Resonance) Theory: Color change occurs due to structural tautomeric shift between two forms: Benzenoid form (light colored or colorless, contains benzene ring) and Quinonoid form (intensely colored, contains conjugated para-quinonoid chromophore system).',
            '   - Phenolphthalein: Acidic pH (<8.2) exists in colorless Benzenoid lactone ring structure. In alkaline medium (pH >8.2), lactone ring opens to form a pink diphenolic quinonoid resonant structure.',
            '3. Titration Curves and Indicator Selection:',
            '   a) Strong Acid vs Strong Base (0.1M HCl vs 0.1M NaOH): Sharp vertical inflection from pH 3.5 to 10.5. Both Methyl Orange (3.1-4.4) and Phenolphthalein (8.2-10.0) produce accurate end points.',
            '   b) Weak Acid vs Strong Base (CH3COOH vs NaOH): Equivalence point is alkaline (pH ~8.8) due to sodium acetate hydrolysis. Sharp inflection is from pH 7.5 to 10.5. Phenolphthalein is suitable; Methyl Orange CANNOT be used.',
            '   c) Weak Base vs Strong Acid (NH4OH vs HCl): Equivalence point is acidic (pH ~5.2) due to NH4Cl hydrolysis. Inflection is from pH 3.5 to 7.0. Methyl Orange is suitable; Phenolphthalein CANNOT be used.',
            '   d) Weak Acid vs Weak Base: Inflection is too gradual and indistinct; no indicator gives a sharp color transition.'
          ],
          diagramDescription: 'Chemical resonance structures of phenolphthalein in acid (lactone benzenoid) vs alkali (dianion quinonoid pink) alongside 4 titration curve plots on pH vs Volume axes.',
          scoringKeywordsSummary: 'Ostwald ionization, Quinonoid chromophore, Benzenoid colorless, Phenolphthalein 8.2-10.0, Methyl Orange 3.1-4.4, pH = pKa ± 1, Inflection pH range, Hydrolysis at equivalence.',
          topperPearls: 'Always state why Weak Acid vs Weak Base titrations cannot be performed with visual indicators (absence of steep vertical inflection break).',
          expectedQuestions: {
            tenMarker: 'Explain the theories of acid-base indicators (Ostwald and Quinonoid theories) with chemical structures. Plot and explain the neutralization curve for Strong Acid vs Strong Base and Weak Acid vs Strong Base.',
            fiveMarker: 'Write a short note on Quinonoid theory of indicators using Phenolphthalein as an example. Explain indicator transition interval.',
            twoMarker: 'Why is Methyl Orange not suitable for titrating Acetic acid against Sodium Hydroxide?'
          }
        }
      ]
    },
    {
      unitNumber: 2,
      title: 'Non-Aqueous & Precipitation Titrations',
      examImportance: 'Very High (15 Marks: Solvents in Non-aqueous OR Mohr vs Volhard vs Fajan is 100% asked)',
      concepts: [
        {
          id: 'analysis_u2_c1',
          topic: 'Non-Aqueous Titration: Solvents, Indicators & Assay of Sodium Benzoate',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated in 8/10 Exams',
          definition: 'Non-aqueous titration is the quantitative titration of very weak acids or very weak bases (pKa > 8 or pKb > 8) in non-aqueous organic solvents where water cannot be used due to its leveling or poor solubility effects.',
          highlightKeywords: [
            'Leveling effect of water', 'Differentiating effect', 'Protogenic solvents (Glacial acetic acid)',
            'Protophilic solvents (Pyridine, Ethylenediamine)', 'Amphiprotic solvents (Methanol, Ethanol)',
            'Aprotic solvents (Benzene, Toluene, Chloroform)', 'Perchloric acid in glacial acetic acid (0.1 N HClO4)',
            'Crystal Violet (Violet to Blue-Green to Yellow)', 'Acetous perchloric acid standardization',
            'Potassium hydrogen phthalate (KHP)', 'Assay of Sodium Benzoate / Ephedrine HCl'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  CLASSIFICATION OF NON-AQUEOUS SOLVENTS                 |
+-------------------------------------------------------------------------+
                         NON-AQUEOUS SOLVENTS
                                   |
         +-----------------+-------+---------+-----------------+
         |                 |                 |                 |
     PROTOGENIC        PROTOPHILIC       AMPHIPROTIC        APROTIC
   (Acidic, Donates   (Basic, Accepts   (Both Donates    (Inert, Neither
    Protons, Enhances  Protons, Enhances & Accepts,       Donates nor Accepts,
    Weak Bases)        Weak Acids)       Neutral)         Low Dielectric)
         |                 |                 |                 |
   Glacial Acetic      Pyridine,         Methanol,        Benzene,
   Acid, Formic Acid   Ethylenediamine   Ethanol          Toluene, Chloroform
`,
          explanation: [
            '1. Why Non-Aqueous?: Weakly basic drugs (amines, nitrogenous alkaloids, e.g. Ephedrine, Diazepam) are too weakly basic to be titrated in water because water acts as a competing base (leveling effect). In glacial acetic acid (protogenic solvent), the basic drug is forced to accept protons and behaves as a strong base.',
            '2. Titrant Preparation (0.1 N Acetous Perchloric Acid): 8.5 mL of 70% perchloric acid is dissolved in glacial acetic acid. To remove water introduced with perchloric acid, acetic anhydride is added (it reacts with water to form acetic acid: (CH3CO)2O + H2O -> 2 CH3COOH). Caution: Excess acetic anhydride must not be added to prevent acetylation of primary/secondary amines.',
            '3. Primary Standard: Standardized against pure Potassium Hydrogen Phthalate (KHP) using Crystal Violet indicator.',
            '4. Indicators Used: Crystal Violet (0.5% in glacial acetic acid: violet in basic, emerald-green at equivalence point, yellowish-green in excess acid), Quinaldine Red, 1-Naphtholbenzein.',
            '5. Assay of Sodium Benzoate IP:',
            '   - Sodium benzoate is the salt of a weak acid and strong base, behaving as a weak base in glacial acetic acid.',
            '   - Reaction: C6H5COONa + HClO4 (in CH3COOH) -> C6H5COOH + NaClO4.',
            '   - 1 mL of 0.1 N HClO4 = 0.01441 g of C6H5COONa.'
          ],
          diagramDescription: 'Reaction scheme showing Perchloric acid reacting with glacial acetic acid to form onium ion (CH3COOH2+), which then protonates the weak base (B + CH3COOH2+ -> BH+ + CH3COOH), followed by titration curves.',
          scoringKeywordsSummary: 'Leveling vs Differentiating, Protogenic/Protophilic/Amphiprotic/Aprotic, Acetic anhydride water scavenger, KHP standard, Crystal violet emerald-green, Sodium benzoate 0.01441 g.',
          topperPearls: 'Always explain the role of Acetic Anhydride in removing water from perchloric acid; writing this specific chemical precaution scores extra bonus marks.',
          expectedQuestions: {
            tenMarker: 'What is Non-aqueous titration? Classify non-aqueous solvents with examples. Explain the preparation and standardization of 0.1 N Perchloric acid with the assay of Sodium Benzoate.',
            fiveMarker: 'Classify non-aqueous solvents. Why is non-aqueous titration preferred for weakly basic drugs?',
            twoMarker: 'What is the role of acetic anhydride in perchloric acid preparation? Name two indicators used in non-aqueous titrations.'
          }
        },
        {
          id: 'analysis_u2_c2',
          topic: 'Precipitation Titrations: Mohr, Volhard, Modified Volhard & Fajan Methods',
          weightage: '10 MARKS ESSAY',
          frequency: 'Guaranteed 10-Marker in 95% Exams',
          definition: 'Precipitation titration is a volumetric analytical method involving the formation of a sparingly soluble precipitate upon the stoichiometric reaction of an analyte with a standard precipitating titrant (Argentometric titration using AgNO3).',
          highlightKeywords: [
            'Argentometric titration (Standard 0.1 N AgNO3)', 'Solubility Product (Ksp)',
            'Mohr Method (Direct, Potassium Chromate K2CrO4 indicator)', 'Brick-red precipitate Ag2CrO4',
            'Neutral pH 6.5 - 9.0 requirement', 'Volhard Method (Indirect back titration, Acidic medium HNO3)',
            'Ferric ammonium sulphate indicator (Red ferric thiocyanate [Fe(SCN)]2+)',
            'Modified Volhard Method (Nitrobenzene coating of AgCl precipitate)',
            'Fajan Method (Adsorption indicator, Dichlorofluorescein / Eosin)',
            'Primary vs Secondary adsorption layer', 'Colloidal precipitate'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  COMPARATIVE ARCHITECTURE: MOHR vs VOLHARD vs FAJAN     |
+-------------------------------------------------------------------------+
  PARAMETER         MOHR METHOD           VOLHARD METHOD       FAJAN METHOD
  Type:             Direct Titration      Indirect Back-Titran Direct Titration
  Titrant:          Standard AgNO3        AgNO3 excess + NH4SCN Standard AgNO3
  Indicator:        Potassium Chromate    Ferric Ammonium      Adsorption Indicator
                    (K2CrO4)              Alum (Fe3+)          (Fluorescein, Eosin)
  pH Condition:     Neutral (pH 6.5-9.0)  Acidic (Dilute HNO3) Specific to indicator
  Precipitate:      AgCl (White) ->       AgCl (White) ->      AgCl colloid with
  End Point:        Brick-red Ag2CrO4     Blood-red [Fe(SCN)]2+ Pink surface complex
  Special Feature:  Fractional Precip     Nitrobenzene added   Adsorption at zero
                                          to prevent AgCl loss charge point
`,
          explanation: [
            '1. Principle of Mohr Method: Direct titration of halides (Cl-, Br-) with standard AgNO3. White AgCl precipitates first because Ksp of AgCl (1.8 x 10^-10) is lower than Ksp of Ag2CrO4 (1.1 x 10^-12). At equivalence point, first excess drop of Ag+ reacts with chromate indicator to precipitate brick-red silver chromate (Ag2CrO4).',
            '   - pH Limitation: pH must be 6.5 to 9.0. If pH < 6.5, chromate converts to dichromate (low CrO42-); if pH > 9.0, Ag+ precipitates as brown silver hydroxide/oxide Ag2O.',
            '2. Principle of Volhard Method (Back Titration): An excess known volume of standard AgNO3 is added to chloride in dilute HNO3 medium. Excess unreacted Ag+ is back-titrated with standard 0.1 N Ammonium Thiocyanate (NH4SCN) using Ferric Alum indicator. At end point, excess SCN- reacts with Fe3+ to form a blood-red complex [Fe(SCN)]2+.',
            '3. Why Modified Volhard?: Silver chloride is more soluble than silver thiocyanate (Ksp AgCl > Ksp AgSCN). During titration, SCN- can displace Cl- from AgCl precipitate: AgCl + SCN- -> AgSCN + Cl-, causing false end points and underestimation. Solution: Add 2-3 mL of Nitrobenzene to shake and form an oily hydrophobic protective layer over AgCl precipitate.',
            '4. Principle of Fajan Method (Adsorption Indicators): Fluorescein is a dye anion. Before equivalence point, AgCl particles have excess Cl- adsorbed on surface forming a primary negative layer that repels the yellow-green dye anion. At equivalence point, excess Ag+ creates a primary positive layer that adsorbs the dye anion into the secondary layer, causing an intense color change to pink on the precipitate surface.'
          ],
          diagramDescription: 'Colloidal AgCl particle sketches: (A) Before end point showing [AgCl]-Cl- negative sphere repelling dye; (B) At end point showing [AgCl]-Ag+ positive sphere attracting pink fluoresceinate anion.',
          scoringKeywordsSummary: 'Argentometry, Mohr K2CrO4 brick red pH 6.5-9, Volhard back titration HNO3, Nitrobenzene coating AgCl, Fajan adsorption indicator, Primary vs secondary layer, Blood red [Fe(SCN)]2+.',
          topperPearls: 'Always explain the exact chemical reason why Nitrobenzene is added in Modified Volhard method (Ksp AgCl = 1.8x10^-10 vs Ksp AgSCN = 1.0x10^-12).',
          expectedQuestions: {
            tenMarker: 'Explain the principle, reactions, and limitations of Mohr method and Volhard method. Why is Nitrobenzene used in Modified Volhard method? Detail Fajan adsorption theory.',
            fiveMarker: 'Describe Fajan method of precipitation titration with the mechanism of adsorption indicators. Compare it with Mohr method.',
            twoMarker: 'What is the pH requirement for Mohr method and why? Why is Nitrobenzene added in Volhard method?'
          }
        }
      ]
    },
    {
      unitNumber: 3,
      title: 'Complexometric Titrations & Gravimetry',
      examImportance: 'High (10-15 Marks: Masking/Demasking + Gravimetric Steps/Coprecipitation)',
      concepts: [
        {
          id: 'analysis_u3_c1',
          topic: 'Complexometric Titrations: EDTA Complexes, Masking & Demasking Agents',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated 8/10 Exams',
          definition: 'Complexometric titration is a volumetric analytical technique based on the stoichiometric formation of a stable, soluble, un-ionized chelate complex between metal ions and a multidentate complexing agent, predominantly Disodium EDTA (Ethylenediaminetetraacetic acid).',
          highlightKeywords: [
            'Disodium EDTA (Hexadentate ligand)', '1:1 Stoichiometric chelation',
            'Chelate effect (Bite denticity)', 'Metallochromic (pM) Indicators (Eriochrome Black T, Murexide)',
            'Metal-Indicator complex vs Metal-EDTA complex', 'Stability constant (Kst)',
            'Masking Agents (Potassium Cyanide, Triethanolamine, Fluoride)',
            'Demasking Agents (Formaldehyde, Chloral hydrate)', 'Assay of Calcium Gluconate / Magnesium Sulphate'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  METALLOCHROMIC INDICATOR DISPLACEMENT MECHANISM        |
+-------------------------------------------------------------------------+
      [FREE METAL ION (M2+)] + [BLUE INDICATOR (EBT)] (At pH 10 Ammonia Buffer)
                                    |
                                    v
                     [METAL-EBT COMPLEX (WINE-RED)]
                                    |
                      + Standard Disodium EDTA (Titrant)
                                    v
            [METAL-EDTA CHELATE (STABLE, COLORLESS)] + [FREE EBT (SKY BLUE)]
                       (End point: Wine-Red to Pure Sky Blue)
`,
          explanation: [
            '1. Hexadentate Nature of EDTA: EDTA has 6 donor atoms (2 basic amine nitrogen atoms + 4 acidic carboxylate oxygen atoms) that wrap around a central metal cation like a claw to form an octahedrally coordinated stable 5-membered ring chelate in a strict 1:1 molar ratio regardless of metal valency.',
            '2. Indicator Mechanism: Metallochromic indicator (e.g. Mordant Black II / EBT) binds to metal ions to form a wine-red Metal-Indicator complex. The Metal-EDTA stability constant must be significantly HIGHER than the Metal-Indicator stability constant. When EDTA is added, it strips the metal from the indicator, liberating free indicator which displays its original sky blue color at pH 10.',
            '3. Masking Agents: Reagents added to prevent interfering metal ions from reacting with EDTA without physically separating them:',
            '   - Potassium Cyanide (KCN): Masks Cu2+, Zn2+, Ni2+, Co2+ by forming extremely stable cyano complexes, leaving Mg2+ and Ca2+ free to be titrated.',
            '   - Triethanolamine (TEA): Masks Fe3+, Al3+, Mn2+ in alkaline medium.',
            '   - Ammonium Fluoride (NH4F): Masks Ca2+ and Mg2+ through insoluble fluoride complexes to titrate Zn2+.',
            '4. Demasking Agents: Reagents that selectively destroy or release a masked complex so the liberated metal can subsequently be titrated (e.g. Formaldehyde:acetic acid mixture reacts with cyanide to form cyanohydrin, unmasking Zn2+ from [Zn(CN)4]2-).',
            '5. Assay of Magnesium Sulphate IP: Titrated with 0.05 M Disodium EDTA at pH 10 (Ammonia-Ammonium Chloride buffer) using Mordant Black II (EBT) indicator. 1 mL 0.05 M EDTA = 0.00602 g MgSO4.'
          ],
          diagramDescription: 'Chemical structural formula of Disodium EDTA showing 2 nitrogen lone pairs and 4 carboxylate groups chelating central Ca2+ ion inside octahedral 5-membered rings.',
          scoringKeywordsSummary: 'Hexadentate ligand, 1:1 chelate ratio, Eriochrome Black T, Wine-red to Sky-blue, pH 10 buffer, Masking (KCN, TEA, Fluoride), Demasking (Formaldehyde), Magnesium Sulphate 0.00602g.',
          topperPearls: 'Always state the stability criteria: K(Metal-EDTA) > K(Metal-Indicator); if Metal-Indicator is too strong, indicator blocking occurs (no sharp color change).',
          expectedQuestions: {
            tenMarker: 'Explain the principle of complexometric titrations. Describe the structure of EDTA and the mechanism of metallochromic indicators. Discuss masking and demasking agents with examples.',
            fiveMarker: 'What are masking and demasking agents? Give two pharmaceutical examples of each. Explain the assay of Calcium Gluconate.',
            twoMarker: 'Why is Ammonia-Ammonium Chloride buffer (pH 10) used in EDTA titrations? What is meant by indicator blocking?'
          }
        },
        {
          id: 'analysis_u3_c2',
          topic: 'Gravimetric Analysis: Steps, Coprecipitation, Postprecipitation & Assay of BaSO4',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated 7/10 Exams',
          definition: 'Gravimetric analysis is a classical quantitative analytical technique where the constituent to be determined is selectively separated from a sample solution as a precipitate of known chemical composition, filtered, washed, ignited, and accurately weighed.',
          highlightKeywords: [
            'Precipitation (Von Weimarn ratio: RSS = (Q - S)/S)', 'Relative supersaturation (RSS)',
            'Digestion / Ostwald ripening', 'Filtration (Whatman 40, 41, 42 ashless filter paper)',
            'Washing (Peptization prevention using electrolyte)', 'Ignition (Muffle furnace / Silica crucible)',
            'Coprecipitation: Surface adsorption, Inclusion, Occlusion',
            'Postprecipitation (Time-dependent surface deposition)', 'Assay of Barium Sulphate'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  CHRONOLOGICAL STEPS IN GRAVIMETRIC ANALYSIS            |
+-------------------------------------------------------------------------+
  [PREPARATION OF SAMPLE SOLUTION]
               |
               v
  [PRECIPITATION] (Slow dropwise addition of hot dilute precipitant with stirring)
               |  (Keep RSS low -> Coarse crystalline precipitate)
               v
  [DIGESTION / OSTWALD RIPENING] (Heating on steam bath for 1-2 hours)
               |  (Small crystals dissolve & redeposit on large crystals)
               v
  [FILTRATION & WASHING] (Whatman 42 Ashless filter paper, Wash with dilute electrolyte)
               |  (Prevents Peptization / Colloidal reversal)
               v
  [DRYING / IGNITION] (Silica crucible in Muffle Furnace at 800-900°C)
               |  (Ashless paper burns with 0.0001g ash weight)
               v
  [COOLING IN DESICCATOR & ACCURATE WEIGHING]
`,
          explanation: [
            '1. Von Weimarn Equation: Particle size is inversely proportional to Relative Supersaturation: RSS = (Q - S) / S, where Q = instantaneous solute concentration, S = equilibrium solubility. To get large, easily filterable crystalline precipitates, minimize (Q - S) by: using hot solutions, dilute solutions, slow addition with constant stirring, and adjusting pH.',
            '2. Digestion (Ostwald Ripening): Keeping precipitate in mother liquor at near-boiling temperature for 1-2 hours. Small irregular crystals with higher surface energy dissolve and re-precipitate onto larger crystals, improving purity and filtration speed.',
            '3. Coprecipitation: Phenomenon where normally soluble impurities precipitate simultaneously with desired analyte. Mechanisms: Surface adsorption (impurities adsorbed on surface), Occlusion (impurities trapped inside crystal lattice voids), Inclusion (impurity ion substitutes for host ion of similar ionic radius).',
            '4. Postprecipitation: Deposition of an otherwise insoluble second substance onto primary precipitate AFTER the primary precipitate has already formed, increasing with standing time (e.g. Zinc oxalate precipitating on Calcium oxalate).',
            '5. Assay of Barium Sulphate: BaCl2 + H2SO4 (dilute, hot) -> BaSO4 (white crystalline) + 2 HCl. Precipitate is digested, filtered via ashless paper, ignited at 800°C, and weighed as pure BaSO4.'
          ],
          diagramDescription: 'Plot of Von Weimarn ratio RSS vs Particle size and schematic of crystal lattice showing Surface Adsorption, Occlusion, and Inclusion defects.',
          scoringKeywordsSummary: 'Von Weimarn RSS = (Q-S)/S, Ostwald ripening digestion, Peptization, Ashless Whatman paper, Occlusion vs Inclusion, Postprecipitation time factor, Muffle furnace 800°C.',
          topperPearls: 'Always highlight how to prevent Peptization during washing by adding a volatile electrolyte (e.g. dilute NH4NO3 or dilute HCl) instead of pure water.',
          expectedQuestions: {
            tenMarker: 'Explain the principles and detailed steps involved in Gravimetric analysis. Differentiate between Coprecipitation and Postprecipitation. Describe the assay of Barium Sulphate.',
            fiveMarker: 'What is Von Weimarn ratio? Explain how relative supersaturation influences precipitate morphology. Write a note on Digestion.',
            twoMarker: 'What is Peptization and how is it prevented during washing of precipitates? What is ashless filter paper?'
          }
        }
      ]
    },
    {
      unitNumber: 4,
      title: 'Redox Titrations',
      examImportance: 'High (10-15 Marks: Iodimetry vs Iodometry OR Permanganometry is guaranteed)',
      concepts: [
        {
          id: 'analysis_u4_c1',
          topic: 'Redox Titrations: Iodimetry vs Iodometry & Starch Indicator Mechanism',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Top Repeated Question in 90% Exams',
          definition: 'Redox titration is a volumetric analytical method based on electron transfer reactions between an oxidizing agent and a reducing agent. Iodometry is the indirect titration of liberated iodine, while Iodimetry is the direct titration with standard iodine solution.',
          highlightKeywords: [
            'Oxidation (Loss of e-) & Reduction (Gain of e-)', 'Direct Iodimetric Titration (Standard I2 in KI)',
            'Indirect Iodometric Titration (Liberated I2 titrated with Na2S2O3)', 'Sodium Thiosulphate (0.1 N Na2S2O3)',
            'Starch Indicator (Amylose-Iodine inclusion complex, Intense Blue)',
            'Addition of Starch NEAR the end point (Straw yellow stage)',
            'Irreversible coagulation / decomposition of starch', 'Assay of Copper Sulphate / Ascorbic Acid'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  COMPARATIVE ARCHITECTURE: IODIMETRY vs IODOMETRY       |
+-------------------------------------------------------------------------+
  FEATURE               IODIMETRY (DIRECT)             IODOMETRY (INDIRECT)
  Definition:           Direct titration of reducing   Indirect titration where
                        analyte with standard Iodine.  oxidant liberates I2 from KI.
  Titrant:              Standard 0.1 N Iodine (in KI)  Standard 0.1 N Sodium
                                                       Thiosulphate (Na2S2O3)
  Reagents Involved:    I2 + 2e- -> 2 I-               2 I- -> I2 (liberated), then
                                                       I2 + 2 S2O3(2-) -> S4O6(2-) + 2 I-
  Analyte Type:         Strong reducing agents         Oxidizing agents
                        (Thiosulphate, Ascorbic acid)  (CuSO4, KMnO4, K2Cr2O7)
  End Point:            Colorless to Pale Yellow       Intense Blue to Colorless
                        (or Permanent Blue with starch)(Starch added near end point)
`,
          explanation: [
            '1. Why Iodine Requires KI: Molecular Iodine (I2) is virtually insoluble in water (0.03 g/100 mL). It dissolves readily in aqueous Potassium Iodide (KI) by forming the highly soluble triiodide complex ion: I2 + I- <=> I3-.',
            '2. Iodometric Mechanism (Indirect): The oxidizing analyte (e.g. Copper Sulphate CuSO4) is treated with excess KI in acetic acid medium: 2 CuSO4 + 4 KI -> 2 CuI (cuprous iodide white ppt) + I2 (liberated) + 2 K2SO4. The liberated iodine is immediately titrated with standard 0.1 N Sodium Thiosulphate: I2 + 2 Na2S2O3 -> 2 NaI + Na2S4O6 (Sodium Tetrathionate).',
            '3. Starch Indicator Mechanism: Starch consists of Amylose (20%, helical polymer of alpha-D-glucose) and Amylopectin (80%). The linear helical core of Amylose encapsulates triiodide (I3-) ions to form an intense coordination deep blue inclusion complex.',
            '4. CRITICAL EXAM RULE - Why Starch is Added NEAR the End Point:',
            '   - In high iodine concentrations, starch forms an irreversible, insoluble blue complex that adsorbs iodine strongly and refuses to release it readily near equivalence, causing inaccurate, lagging end points.',
            '   - Starch decomposes in high acidity.',
            '   - Therefore, titration is conducted until the dark brown solution fades to a pale straw-yellow color; ONLY THEN is starch added to produce blue color, and titrated dropwise until blue disappears cleanly.'
          ],
          diagramDescription: 'Helical amylose coil entrapment of I3- linear polyiodide chain to yield deep blue charge-transfer complex, alongside reaction flasks showing color transition: Brown -> Straw Yellow (+ Starch) -> Dark Blue -> Colorless.',
          scoringKeywordsSummary: 'Iodimetry direct vs Iodometry indirect, I3- triiodide KI solubilization, Sodium thiosulphate Na2S2O3, Tetrathionate, Amylose helical inclusion, Straw-yellow stage addition, Irreversible coagulation.',
          topperPearls: 'Underline the exact reason for adding starch near the end point: "To avoid irreversible coagulation of starch-iodine complex and prevent sluggish desorption of iodine."',
          expectedQuestions: {
            tenMarker: 'Differentiate between Iodimetry and Iodometry with reactions, conditions, and indicators. Explain the preparation and standardization of 0.1 N Sodium Thiosulphate and the assay of Copper Sulphate.',
            fiveMarker: 'Why is starch indicator added near the end point in iodometric titrations? Explain the structure and mechanism of starch-iodine complex.',
            twoMarker: 'Why is KI used in the preparation of standard iodine solution? Name the product formed when iodine reacts with sodium thiosulphate.'
          }
        }
      ]
    },
    {
      unitNumber: 5,
      title: 'Electrochemical Methods of Analysis',
      examImportance: 'Very High (15 Marks: Conductometry Curves OR Potentiometric End Point / Polarography)',
      concepts: [
        {
          id: 'analysis_u5_c1',
          topic: 'Conductometry: Principle, Conductance & Titration Curves',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated 8/10 Exams',
          definition: 'Conductometry is an electrochemical analytical technique that measures the electrical conductance of an electrolyte solution between two inert platinum electrodes, utilizing the high mobility differences between various ionic species during neutralization.',
          highlightKeywords: [
            'Specific Conductance (Kappa, k)', 'Equivalent Conductance (Lambda)',
            'Molar Conductance', 'Ionic Mobility (H+ = 350, OH- = 198, Na+ = 50, Cl- = 76 ohm-1 cm2)',
            'Conductometric Titration Curves', 'Strong Acid vs Strong Base (V-shaped curve)',
            'Weak Acid vs Strong Base (Inverted V / Ascending curve)', 'Strong Acid vs Weak Base',
            'Conductivity Cell (Platinized platinum electrodes, Cell constant)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  CONDUCTOMETRIC TITRATION CURVES                        |
+-------------------------------------------------------------------------+
   (A) STRONG ACID vs STRONG BASE (HCl vs NaOH)   (B) WEAK ACID vs STRONG BASE (CH3COOH vs NaOH)
   Conductance |  \\          /                    Conductance |               /
               |   \\        /                                 |       _--/
               |    \\      /                                  |     /
               |     \\    /                                   |  \\ /
               |      \\  /                                    |   V (Equivalence)
               +--------V-----------------                    +-------------------------
                    Equivalence                                      Equivalence
`,
          explanation: [
            '1. Principle: Electrical conductance of a solution depends on the total number of ions, charge on ions, and ionic mobility. Hydrogen ions (H+, 350 S.cm2/mol) and Hydroxyl ions (OH-, 198 S.cm2/mol) possess exceptionally high mobility compared to other cations and anions due to the Grotthuss proton-hopping mechanism across water molecules.',
            '2. Strong Acid vs Strong Base Curve (HCl vs NaOH):',
            '   - Initial conductance is very high due to fast H+ ions.',
            '   - As NaOH is added, fast H+ ions are replaced by slower Na+ ions (H+ + Cl- + Na+ + OH- -> Na+ + Cl- + H2O). Conductance falls steeply in a straight line.',
            '   - At equivalence point, conductance is minimum (only Na+ and Cl- present).',
            '   - After equivalence point, addition of excess NaOH introduces highly mobile OH- ions, causing conductance to rise sharply -> Characteristic V-shaped curve.',
            '3. Weak Acid vs Strong Base Curve (CH3COOH vs NaOH):',
            '   - Initial conductance is low due to poor dissociation of acetic acid.',
            '   - Initial drop occurs as common ion effect suppresses weak acid dissociation.',
            '   - Then conductance rises steadily because unionized CH3COOH is converted to highly ionized sodium acetate (CH3COONa).',
            '   - After equivalence point, excess NaOH adds fast OH- ions, producing a much steeper ascending slope.',
            '4. Advantages of Conductometric Titrations:',
            '   - Highly accurate for colored, turbid, or fluorescent solutions where visual indicators fail.',
            '   - Useful for very dilute solutions and weak acids/bases.',
            '   - No indicator blank error.'
          ],
          diagramDescription: 'Four graphs showing Conductance vs Volume of Titrant for: (1) Strong Acid-Strong Base, (2) Weak Acid-Strong Base, (3) Strong Acid-Weak Base, (4) Mixture of Strong Acid and Weak Acid vs Strong Base.',
          scoringKeywordsSummary: 'Specific conductance Kappa, Ionic mobility H+ (350) and OH- (198), Grotthuss proton jumping, V-shaped curve, Minimum equivalence point, Turbid/colored solutions, Platinized platinum.',
          topperPearls: 'Draw the Conductometric curve for Mixture of Acids (HCl + CH3COOH vs NaOH); showing the two distinct intersection inflection points guarantees a perfect 10/10.',
          expectedQuestions: {
            tenMarker: 'Explain the principle of conductometry. Describe the conductometric titration curves obtained in the titration of: (a) Strong acid vs Strong base, (b) Weak acid vs Strong base, and (c) Mixture of strong and weak acid vs Strong base.',
            fiveMarker: 'What are the advantages of conductometric titrations over visual indicator titrations? Explain specific conductance and cell constant.',
            twoMarker: 'Why do H+ and OH- ions exhibit extraordinarily high ionic conductances compared to other ions?'
          }
        },
        {
          id: 'analysis_u5_c2',
          topic: 'Potentiometry & Polarography (Ilkovic Equation & DME)',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated 8/10 Exams',
          definition: 'Potentiometry measures the electromotive force (EMF) of a galvanic cell at zero current flow using the Nernst Equation. Polarography is a voltammetric method using a Dropping Mercury Electrode (DME) to record current-voltage curves (polarograms).',
          highlightKeywords: [
            'Nernst Equation (E = E0 - (0.0591/n) log [Red]/[Ox])', 'Reference Electrodes (SHE E=0.00V, Saturated Calomel Electrode SCE E=+0.242V)',
            'Indicator Electrodes (Glass electrode, Platinum redox)', 'Potentiometric End Point (First & Second derivative plots)',
            'Polarography (Jaroslav Heyrovsky, Nobel Prize 1959)', 'Dropping Mercury Electrode (DME)',
            'Ilkovic Equation (Id = 607 n D^1/2 m^2/3 t^1/6 C)', 'Diffusion Current (Id)',
            'Residual Current', 'Limiting Current', 'Half-Wave Potential (E1/2 - Qualitative identification)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  POLAROGRAPHIC WAVE (POLAROGRAM) ARCHITECTURE           |
+-------------------------------------------------------------------------+
   Current (µA) |                             ---------------- Limiting Current
                |                           /
                |                         /  <-- Diffusion Current (Id = Ilim - Ires)
                |                       /        (Id is proportional to Concentration C)
                |                     /
                |                   /   <-- Half-Wave Potential (E1/2)
                |   ---------------        (Characteristic property of each ion)
                |   ^ Residual Current
                +----------------------------------------- Voltage (-V vs SCE)
`,
          explanation: [
            '1. Nernst Equation in Potentiometry: E = E0 - (2.303 RT / nF) log [Activities]. At 25°C: E = E0 - (0.0591 / n) log [Red]/[Ox].',
            '2. Potentiometric Titration End Point Determination:',
            '   a) Direct plot: E vs V (Sigmoidal S-shaped curve).',
            '   b) First Derivative: dE/dV vs V (Sharp peak at equivalence volume).',
            '   c) Second Derivative: d2E/dV2 vs V (Zero crossing point corresponds exactly to equivalence point).',
            '3. Polarography & The Ilkovic Equation: Current-voltage relationship at a polarizable Dropping Mercury Electrode (DME) against non-polarizable Saturated Calomel Electrode (SCE).',
            '   - Ilkovic Equation: Id = 607 n D^(1/2) m^(2/3) t^(1/6) C',
            '     * Id = Diffusion current (µA)',
            '     * n = Number of electrons transferred',
            '     * D = Diffusion coefficient of analyte (cm2/s)',
            '     * m = Mercury flow rate from capillary (mg/s)',
            '     * t = Drop time of mercury droplet (seconds, typically 3-5 s)',
            '     * C = Analyte concentration (mmol/L) -> Basis of quantitative analysis!',
            '4. Half-Wave Potential (E1/2): Potential at which the current is equal to half of the diffusion current (Id/2). E1/2 is independent of concentration and is the qualitative fingerprint of each reducible electroactive species.',
            '5. Advantages of DME: Constantly renewed, fresh, clean, smooth mercury droplet surface prevents electrode poisoning; reproducible surface area; high overpotential for hydrogen gas evolution allows analysis of easily reduced metals.'
          ],
          diagramDescription: 'Polarographic cell setup showing DME capillary submerged in deoxygenated sample solution with N2 bubbling tube, SCE reference electrode, and typical sigmoidal polarogram wave labeling Residual, Diffusion, Limiting currents, and E1/2.',
          scoringKeywordsSummary: 'Nernst equation E0 - 0.0591/n logQ, Saturated Calomel Electrode (SCE), First derivative dE/dV, Ilkovic equation 607 n D1/2 m2/3 t1/6 C, Half-wave potential E1/2, DME renewable surface, Hydrogen overpotential.',
          topperPearls: 'Write down every term of the Ilkovic Equation with its exact units; examiners verify this specific formula letter by letter.',
          expectedQuestions: {
            tenMarker: 'Explain the principle, construction, and working of Dropping Mercury Electrode (DME). Derive and explain the Ilkovic equation. Define Half-Wave Potential and Diffusion Current with a labeled polarogram.',
            fiveMarker: 'Explain the methods used for end point detection in Potentiometric titrations (First and Second derivative curves). Describe the Saturated Calomel Electrode.',
            twoMarker: 'State the Ilkovic equation and define its parameters. Why is nitrogen gas bubbled through the solution before polarographic analysis?'
          }
        }
      ]
    }
  ]
};

export default bp102tNotes;
