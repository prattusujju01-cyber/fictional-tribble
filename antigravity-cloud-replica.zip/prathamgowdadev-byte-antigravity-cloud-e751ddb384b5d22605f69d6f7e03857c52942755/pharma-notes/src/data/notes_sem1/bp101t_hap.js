// BP101T: Human Anatomy and Physiology I - Comprehensive Handwritten-Style Exam Study Notes
// Formatted with Exam Weightage, Highlighted Scoring Keywords, Flowcharts, Diagrams & Practice Questions

export const bp101tNotes = {
  subjectCode: 'BP101T',
  subjectName: 'Human Anatomy and Physiology – I',
  units: [
    {
      unitNumber: 1,
      title: 'Introduction, Cellular & Tissue Level of Organization',
      examImportance: 'Very High (15-20 Marks in University Exam: 1 Long Question + 1 Short Question + 2 Two-Markers)',
      concepts: [
        {
          id: 'hap_u1_c1',
          topic: 'Introduction to Human Body, Homeostasis & Feedback Systems',
          weightage: '5 MARKS / 10 MARKS',
          frequency: 'Repeated 8/10 Exams (RGUHS, AKTU, PCI, WBUHS)',
          definition: 'Homeostasis is the state of dynamic equilibrium in the internal environment of the body maintained by regulatory physiological processes, despite continuous internal and external variations.',
          highlightKeywords: [
            'Dynamic equilibrium', 'Negative feedback mechanism', 'Positive feedback mechanism',
            'Sensor/Receptor', 'Control center (Hypothalamus)', 'Effector organ', 'Homeostatic imbalance'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  HOMEOSTATIC FEEDBACK LOOP ARCHITECTURE                 |
+-------------------------------------------------------------------------+
       [STIMULUS] (e.g. Body Temp rises above 37°C)
           |
           v
       [RECEPTOR/SENSOR] (Thermoreceptors in Skin & Hypothalamus)
           |  (Afferent Nerve Pathway)
           v
       [CONTROL CENTER] (Hypothalamic Preoptic Area - Evaluates Setpoint)
           |  (Efferent Autonomic Signals)
           v
       [EFFECTOR] (Eccrine Sweat Glands activate + Cutaneous Vasodilation)
           |
           v
       [RESPONSE] (Heat loss through evaporation -> Temp returns to 37°C)
           |
           +---> [NEGATIVE FEEDBACK SHUTS OFF INITIAL STIMULUS]
`,
          explanation: [
            '1. Dynamic Equilibrium: Internal variables oscillate within a narrow physiological reference range rather than being rigidly fixed.',
            '2. Negative Feedback Systems: The output of the effector decreases or reverses the original stimulus, restoring normality (e.g. Blood pressure regulation via carotid baroreceptors, Blood glucose regulation via Insulin/Glucagon).',
            '3. Positive Feedback Systems: The response reinforces and amplifies the stimulus in the same direction until a definitive physiological event occurs (e.g. Oxytocin release in uterine contractions during parturition/labor, Thrombin amplification in blood clotting).',
            '4. Homeostatic Imbalance: Failure of homeostatic mechanisms leads to pathological disorders, diseases, or death.'
          ],
          diagramDescription: 'Diagram depicts circular control loop: Stimulus -> Receptor -> Afferent Pathway -> Control Center -> Efferent Pathway -> Effector -> Response (Feedback arrow shutting stimulus).',
          scoringKeywordsSummary: 'Set-point value (37°C / 7.35-7.45 pH), Afferent vs Efferent, Hypothalamus, Baroreceptors, Oxytocin amplification, Reversal of stimulus.',
          topperPearls: 'Always cite both Negative Feedback (Thermoregulation) and Positive Feedback (Uterine contractions / Parturition) with labeled loop diagrams to score full 5/5 marks.',
          expectedQuestions: {
            tenMarker: 'Define Homeostasis. Explain the components of a homeostatic control system with detailed negative and positive feedback mechanism examples.',
            fiveMarker: 'Describe negative feedback mechanism of blood pressure regulation or thermoregulation with a schematic diagram.',
            twoMarker: 'Define homeostasis with one positive feedback physiological example.'
          }
        },
        {
          id: 'hap_u1_c2',
          topic: 'Cellular Structure, Plasma Membrane & Transport Mechanisms',
          weightage: '10 MARKS ESSAY',
          frequency: 'Guaranteed Long Question in Unit 1',
          definition: 'The cell is the basic structural and functional biological unit of all living organisms. The plasma membrane is a dynamic, selectively permeable phospholipid bilayer with embedded integral and peripheral proteins (Singer & Nicolson Fluid Mosaic Model).',
          highlightKeywords: [
            'Fluid Mosaic Model (1972)', 'Amphipathic phospholipids', 'Hydrophilic polar heads',
            'Hydrophobic fatty acid tails', 'Integral transmembrane proteins', 'Active Transport (Na+/K+ ATPase)',
            'Primary vs Secondary active transport', 'Facilitated diffusion', 'Osmosis', 'Endocytosis & Exocytosis'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  CELLULAR MEMBRANE TRANSPORT SCHEME                     |
+-------------------------------------------------------------------------+
                               MEMBRANE TRANSPORT
                                       |
                 +---------------------+---------------------+
                 |                                           |
         PASSIVE TRANSPORT                           ACTIVE TRANSPORT
        (Down Gradient, No ATP)                     (Against Gradient, ATP)
                 |                                           |
       +---------+---------+                       +---------+---------+
       |         |         |                       |                   |
    Simple  Facilitated  Osmosis                Primary Active     Secondary Active
   Diffusion  Diffusion  (Aquaporins)          (Na+/K+ ATPase)    (Symport/Antiport)
  (O2, CO2)   (GLUT-4)                          (3 Na+ out,       (Na+/Glucose
                                                 2 K+ in)          SGLT-1)
`,
          explanation: [
            '1. Singer & Nicolson Fluid Mosaic Model: The matrix consists of a sea of fluid phospholipids (amphipathic, glycerol-phosphate head + 2 non-polar hydrocarbon fatty acid chains) in which mosaic proteins float.',
            '2. Cholesterol molecules (20% of membrane lipids) stabilize membrane fluidity across variable temperatures.',
            '3. Integral (Transmembrane) Proteins act as ion channels (Voltage/Ligand-gated), carrier proteins (transporters), receptors (GPCRs), and enzymes.',
            '4. Primary Active Transport (Na+/K+ ATPase pump): Hydrolyzes 1 molecule of ATP to pump 3 Na+ ions out of the cell against concentration gradient, and 2 K+ ions into the cell. Crucial for resting membrane potential (-70 mV) and cell volume regulation.',
            '5. Secondary Active Transport (Coupled Transport): Utilizes the electrochemical sodium gradient established by the primary pump (e.g. SGLT-1 Sodium-Glucose symport in renal tubules and intestine).',
            '6. Vesicular Bulk Transport: Phagocytosis (cell eating), Pinocytosis (cell drinking), Receptor-mediated endocytosis, and Exocytosis (neurotransmitter release).'
          ],
          diagramDescription: 'Cross-section of bilayer showing polar heads facing ICF and ECF, fatty acid chains in core, glycoprotein carbohydrate chains on outer surface (glycocalyx), peripheral proteins on inner face, and cylindrical alpha-helix transmembrane channels.',
          scoringKeywordsSummary: 'Fluid Mosaic 1972, Amphipathic, 3 Na+ out / 2 K+ in, -70 mV resting potential, Cholesterol fluidity buffer, GLUT carriers, Aquaporins, SGLT symporter.',
          topperPearls: 'Draw the cross-section of the phospholipid bilayer with 3 distinct colored arrows indicating simple diffusion, facilitated diffusion, and active Na+/K+ pump transport to secure the full 10 marks.',
          expectedQuestions: {
            tenMarker: 'Explain the ultrastructure of the plasma membrane with a neat labeled diagram. Discuss passive and active transport mechanisms across the membrane.',
            fiveMarker: 'Write a short note on Primary Active Transport with special reference to Na+/K+ ATPase pump.',
            twoMarker: 'State the function of cholesterol in plasma membrane and define resting membrane potential.'
          }
        },
        {
          id: 'hap_u1_c3',
          topic: 'Classification, Structure & Functions of Epithelial Tissue',
          weightage: '5 MARKS / 10 MARKS',
          frequency: 'Repeated 9/10 Exams',
          definition: 'Epithelial tissue is a cellular avascular sheet of tightly packed cells with minimal extracellular matrix that covers body surfaces, lines hollow cavities and ducts, and forms secretory glands.',
          highlightKeywords: [
            'Avascular nature', 'Basement membrane (Basal lamina + Reticular lamina)',
            'Simple vs Stratified', 'Squamous (Endothelium/Mesothelium)', 'Cuboidal (Renal tubules)',
            'Columnar (Goblet cells/Brush border)', 'Pseudostratified ciliated (Trachea)',
            'Transitional epithelium / Urothelium (Urinary bladder)', 'Keratinized vs Non-keratinized'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  CLASSIFICATION OF EPITHELIAL TISSUES                   |
+-------------------------------------------------------------------------+
                          EPITHELIAL TISSUE
                                  |
            +---------------------+---------------------+
            |                                           |
      SIMPLE (Single Layer)                    STRATIFIED (Multiple Layers)
            |                                           |
   +--------+--------+--------+               +---------+---------+
   |        |        |        |               |                   |
Simple   Simple   Simple   Pseudostratified Stratified          Transitional
Squamous Cuboidal Columnar Ciliated         Squamous            (Urothelium)
(Alveoli)(Thyroid)(Stomach)(Trachea)          |                 (Bladder)
                                       +------+------+
                                       |             |
                                  Keratinized    Non-Keratinized
                                    (Skin)       (Esophagus, Vagina)
`,
          explanation: [
            '1. Simple Squamous Epithelium: Single layer of flat, tile-like polygonal cells with central oval nucleus. Optimized for filtration and rapid diffusion. Examples: Pulmonary alveoli, glomerular Bowman capsule, endothelium of capillaries.',
            '2. Simple Cuboidal Epithelium: Cube-shaped cells with central round nucleus. Specialized for secretion and absorption. Examples: Thyroid follicles, renal proximal/distal convoluted tubules.',
            '3. Simple Columnar Epithelium: Tall column-like cells with oval basal nuclei. Can be ciliated (fallopian tubes) or non-ciliated with microvilli & mucus-secreting goblet cells (gastric and intestinal lining).',
            '4. Pseudostratified Ciliated Columnar: Nuclei appear at variable levels giving false impression of stratification, but all cells contact the basement membrane. Lines upper respiratory tract (nasal cavity, trachea, bronchi) to sweep mucus upward.',
            '5. Stratified Squamous (Keratinized): Outer layers are dead, dehydrated scales packed with protective keratin protein (epidermis of skin, prevents desiccation and abrasion). Non-keratinized moist layer lines oral cavity, esophagus, and vagina.',
            '6. Transitional Epithelium (Urothelium): Multilayered cells where surface cells (umbrella cells) can transform from dome-shaped to flattened when stretched under hydrostatic pressure (urinary bladder, ureters).'
          ],
          diagramDescription: 'Side-by-side microscopic histology sketches showing simple flat squamous, cuboidal boxes, tall columnar with goblets, pseudostratified with cilia, and dome-shaped transitional cells resting on pink basement line.',
          scoringKeywordsSummary: 'Avascular, Basement membrane, Endothelium, Microvilli, Goblet cells, Mucociliary escalator, Keratin, Urothelium umbrella cells, Elastic distension.',
          topperPearls: 'Always draw the basement membrane for every epithelial diagram; examiners cut 1-2 marks if basement membrane line is missing.',
          expectedQuestions: {
            tenMarker: 'Classify epithelial tissues with neat diagrams, characteristics, functions, and specific anatomical locations for each type.',
            fiveMarker: 'Differentiate between Keratinized and Non-keratinized stratified squamous epithelium. Write a note on Transitional Epithelium.',
            twoMarker: 'Where is Pseudostratified Ciliated Columnar epithelium found and what is its physiological role?'
          }
        }
      ]
    },
    {
      unitNumber: 2,
      title: 'Integumentary, Skeletal System & Joints',
      examImportance: 'High (10-15 Marks: 1 Long Question on Synovial Joint / Bone Histology + Short Questions)',
      concepts: [
        {
          id: 'hap_u2_c1',
          topic: 'Structure & Functions of Skin (Integumentary System)',
          weightage: '5 MARKS / 10 MARKS',
          frequency: 'Repeated 7/10 Exams',
          definition: 'The skin is the largest organ of the human body, composed of the outer avascular stratified keratinized epidermis and the inner vascular dense connective tissue dermis, supported by subcutaneous hypodermis.',
          highlightKeywords: [
            'Stratum Basale (Mitotic stem cells)', 'Stratum Spinosum (Desmosomes)',
            'Stratum Granulosum (Keratohyalin)', 'Stratum Lucidum (Eleidin in thick skin)',
            'Stratum Corneum (Cornified dead cells)', 'Melanocytes (Melanin pigment)',
            'Langerhans cells (Immunity)', 'Merkel cells (Touch)', 'Dermal Papillae'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|              EPIDERMAL STRATA HIERARCHY (DEEP TO SUPERFICIAL)           |
+-------------------------------------------------------------------------+
       [STRATUM BASALE] (Single layer stem cells, Melanocytes, Mitosis)
             |  (Daughter cells push upwards over 28-30 days)
             v
       [STRATUM SPINOSUM] (8-10 layers, Spiny desmosomes, Langerhans cells)
             |
             v
       [STRATUM GRANULOSUM] (3-5 layers, Keratohyalin granules, Nucleus degenerates)
             |
             v
       [STRATUM LUCIDUM] (Present ONLY in thick skin of palms & soles, Eleidin)
             |
             v
       [STRATUM CORNEUM] (25-30 layers of dead, flat, anucleated keratinized squames)
             |
             v
       [DESQUAMATION] (Constant shedding of outer protective barrier)
`,
          explanation: [
            '1. Epidermal Cell Types: Keratinocytes (90%, produce fibrous keratin barrier), Melanocytes (8%, produce eumelanin/pheomelanin transferred to keratinocytes to shield DNA from UV rays), Langerhans cells (epidermal dendritic antigen-presenting cells), Merkel discs (mechanoreceptors for light touch).',
            '2. Five Strata Mnemonic: "Come, Let\'s Get Sun Burned" -> Corneum, Lucidum, Granulosum, Spinosum, Basale.',
            '3. Dermis: Divided into superficial Papillary layer (areolar connective tissue with Meissner corpuscles and capillary loops forming dermal ridges/fingerprints) and deep Reticular layer (dense irregular collagen & elastin fibers providing tensile strength, Pacinian corpuscles, sebaceous and sweat glands).',
            '4. Functions: Thermoregulation (sweating and arteriolar shunt), Protection (acid mantle pH 4.5-5.5, physical barrier), Cutaneous sensations, Vitamin D3 synthesis (7-dehydrocholesterol converted by UV-B to cholecalciferol), and Excretion.'
          ],
          diagramDescription: 'Full skin cross-section showing Epidermis (with 5 layers labeled), Dermal Papillae, Arrector pili muscle attached to hair follicle, Sebaceous gland, Eccrine sweat duct, and Pacinian lamellar corpuscle in hypodermis.',
          scoringKeywordsSummary: 'Come Lets Get Sun Burned, Melanocyte UV shield, Langerhans dendritic immunity, Keratohyalin, Meissner vs Pacinian, Acid mantle pH 5.5, 7-dehydrocholesterol Vitamin D.',
          topperPearls: 'Mention that Stratum Lucidum is present only in thick skin (palms and soles) - writing this distinction earns full marks in 5-mark skin anatomy questions.',
          expectedQuestions: {
            tenMarker: 'Describe the histological structure of the skin with a labeled diagram. Detail the five layers of the epidermis and skin functions.',
            fiveMarker: 'Discuss the cell types present in the epidermis and explain the process of keratinization.',
            twoMarker: 'Name the layers of epidermis from superficial to deep and state the function of Melanocytes.'
          }
        },
        {
          id: 'hap_u2_c2',
          topic: 'Classification of Joints & Structure of Synovial Joint',
          weightage: '10 MARKS ESSAY',
          frequency: 'Top Repeated University Question',
          definition: 'A joint (articulation) is a point of contact between two bones, between bone and cartilage, or between bone and teeth. A synovial joint is a freely movable (diarthrotic) joint characterized by a fluid-filled synovial cavity between articulating bones.',
          highlightKeywords: [
            'Synarthrosis (Immovable - Sutures)', 'Amphiarthrosis (Slightly movable - Symphysis)',
            'Diarthrosis (Freely movable - Synovial)', 'Articular cartilage (Hyaline)',
            'Synovial membrane (Synoviocytes Type A & B)', 'Synovial fluid (Hyaluronic acid & Lubricin)',
            'Fibrous capsule', 'Extracapsular & Intracapsular ligaments', 'Bursae & Tendon sheaths'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  CLASSIFICATION OF JOINTS (STRUCTURAL)                  |
+-------------------------------------------------------------------------+
                                 JOINTS
                                   |
         +-------------------------+-------------------------+
         |                         |                         |
     FIBROUS                  CARTILAGINOUS               SYNOVIAL
  (No Cavity, Sutures,     (Hyaline/Fibrocartilage,    (Synovial Cavity,
   Gomphosis, Syndesmosis)   Synchondrosis, Symphysis)  Diarthrodial, Freely Movable)
                                                             |
                 +---------------+---------------+-----------+----+
                 |               |               |                |
             Ball & Socket     Hinge           Pivot            Gliding
            (Shoulder, Hip)  (Elbow, Knee)  (Atlanto-axial)   (Carpals)
`,
          explanation: [
            '1. Structural Classification: Fibrous joints (held by collagen fibers, no joint cavity, e.g. skull sutures), Cartilaginous joints (held by cartilage, e.g. pubic symphysis, intervertebral discs), Synovial joints (possess synovial cavity).',
            '2. Anatomy of Synovial Joint:',
            '   a) Articular Cartilage: Smooth, glassy avascular hyaline cartilage (2-4 mm thick) covering bone articular ends, reducing friction and absorbing shock.',
            '   b) Articular Capsule: Double-layered envelope. Outer fibrous capsule (dense irregular connective tissue continuous with periosteum, prevents bone displacement) and Inner synovial membrane (vascular loose connective tissue).',
            '   c) Synovial Fluid: Viscous, egg-white consistency dialysate of blood plasma containing hyaluronic acid and lubricin secreted by fibroblast-like synoviocytes (Type B). Nourishes chondrocytes and lubricates joint.',
            '   d) Reinforcing Ligaments: Extracapsular (collateral ligaments) and Intracapsular (cruciate ligaments of knee).',
            '3. Types of Synovial Joints with Examples:',
            '   - Ball and Socket: Multiaxial (Shoulder, Hip joints).',
            '   - Hinge: Uniaxial flexion/extension (Elbow, Ankle, Interphalangeal).',
            '   - Pivot: Uniaxial rotation (Atlanto-axial joint "No" gesture, Radioulnar joint).',
            '   - Condyloid / Ellipsoidal: Biaxial (Wrist radiocarpal joint).',
            '   - Saddle: Biaxial with reciprocal concavo-convex surfaces (1st carpometacarpal joint of thumb).',
            '   - Gliding / Plane: Non-axial flat sliding (Intercarpal, Intertarsal).'
          ],
          diagramDescription: 'Cross-section of a synovial joint showing articulating bones, blue hyaline cartilage caps, fibrous capsule outer sleeve, pink inner synovial membrane, yellow synovial fluid cavity, and lateral collateral ligaments.',
          scoringKeywordsSummary: 'Diarthrosis, Hyaline articular cartilage, Synoviocytes Type B (Hyaluronic acid), Viscosity lubrication, Ball & Socket, Hinge, Pivot, Saddle, Rheumatoid vs Osteoarthritis.',
          topperPearls: 'Include the 6 functional subtypes of synovial joints with their degree of freedom (Uniaxial, Biaxial, Multiaxial) and one exact clinical example each.',
          expectedQuestions: {
            tenMarker: 'Classify joints with examples. Describe the typical structure of a synovial joint with a neat labeled diagram. Explain 6 types of synovial joints.',
            fiveMarker: 'Write a short note on the composition, secretion, and functions of Synovial Fluid. Mention two disorders of joints.',
            twoMarker: 'Differentiate between Synarthrosis, Amphiarthrosis, and Diarthrosis with one example each.'
          }
        }
      ]
    },
    {
      unitNumber: 3,
      title: 'Body Fluids, Blood & Lymphatic System',
      examImportance: 'Extreme High (15-20 Marks: Coagulation Cascade or Erythropoiesis is 100% asked)',
      concepts: [
        {
          id: 'hap_u3_c1',
          topic: 'Blood Coagulation Cascade (Hemostasis)',
          weightage: '10 MARKS ESSAY',
          frequency: 'Guaranteed Long Essay Question in 95% Exams',
          definition: 'Hemostasis is the physiological sequence of responses that halts bleeding from a ruptured vascular wall, consisting of vascular spasm, platelet plug formation, and blood coagulation (fibrin meshwork clot).',
          highlightKeywords: [
            'Hemostasis triad', 'Vascular spasm (Endothelin)', 'Platelet adhesion (von Willebrand factor)',
            'Platelet release reaction (ADP, Thromboxane A2)', 'Intrinsic pathway (Factor XII / Contact activation)',
            'Extrinsic pathway (Tissue Factor III / Thromboplastin)', 'Common pathway (Factor X -> Prothrombinase)',
            'Prothrombin (Factor II) to Thrombin (IIa)', 'Fibrinogen (Factor I) to Fibrin monomers',
            'Factor XIII (Fibrin stabilizing factor)', 'Calcium ions (Factor IV co-factor)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  BLOOD COAGULATION CASCADE (ENZYME CASCADE)             |
+-------------------------------------------------------------------------+
    [INTRINSIC PATHWAY]                     [EXTRINSIC PATHWAY]
   (Damaged vessel surface/collagen)       (Tissue trauma / Extravascular)
             |                                       |
    Factor XII -> XIIa                      Tissue Factor (Factor III)
             |                                       |
    Factor XI  -> XIa                                + Factor VII + Ca2+
             |                                       |
    Factor IX  + Factor VIII + Ca2+ + PF3            v
             |                                Factor VIIa - TF Complex
             +-----------------------+---------------+
                                     |
                                     v
                       [FACTOR X ACTIVATION (Xa)]
                                     |
                       + Factor V + Ca2+ + Phospholipids
                                     v
                           [PROTHROMBINASE COMPLEX]
                                     |
                Prothrombin (II) ----+----> Thrombin (IIa)
                                                 |
                       +-------------------------+
                       |
                       v
         Fibrinogen (I, Soluble) ---------> Fibrin Monomers (Loose Gel)
                                                 |
                                            Factor XIIIa + Ca2+
                                                 v
                                        [STABILIZED FIBRIN CLOT]
                                        (Insoluble cross-linked mesh)
`,
          explanation: [
            '1. Three Stages of Hemostasis: Vascular Spasm (arteriolar smooth muscle vasoconstriction via endothelin & serotonin), Platelet Plug Formation (platelets adhere via GPIb to subendothelial collagen via vWF, undergo degranulation releasing ADP and TXA2 to aggregate further platelets), and Blood Coagulation.',
            '2. Extrinsic Pathway (Rapid, Seconds): Initiated when blood contacts extravascular Tissue Factor (Thromboplastin / Factor III). TF binds with Factor VII in presence of Ca2+ to directly activate Factor X.',
            '3. Intrinsic Pathway (Slower, Minutes): Initiated by contact of Factor XII with negatively charged exposed collagen. XIIa activates XI -> XIa activates IX -> IXa teams with cofactor VIIIa, Ca2+, and platelet phospholipids to activate Factor X.',
            '4. Common Pathway: Factor Xa combines with Factor Va, Ca2+, and platelet factor 3 (PF3) to form the Prothrombinase Enzyme Complex. Prothrombinase converts Prothrombin (Factor II) into active Thrombin (Factor IIa).',
            '5. Thrombin Action: Thrombin cleaves soluble Fibrinogen (Factor I) into insoluble sticky Fibrin strands. Thrombin also activates Factor XIII (Fibrin Stabilizing Factor) which cross-links fibrin into an irreversible, robust meshwork trapping RBCs.',
            '6. Clot Retraction & Fibrinolysis: Platelets contract pulling clot margins together (serum squeezes out). Tissue Plasminogen Activator (t-PA) converts inactive Plasminogen into Plasmin, which digests fibrin threads to restore vascular patency.'
          ],
          diagramDescription: 'Flowchart showing two converging arms (Intrinsic Factor XII, XI, IX, VIII and Extrinsic Factor III, VII) meeting at Common Factor X, yielding Prothrombinase which converts Prothrombin -> Thrombin, and Fibrinogen -> Fibrin mesh with Factor XIII cross-links.',
          scoringKeywordsSummary: 'Hemostasis triad, vWF, ADP/TXA2, Factor III (TF), Factor VIII (Antihemophilic), Prothrombinase, Thrombin (IIa), Fibrinogen to Fibrin, Factor XIII cross-linking, Calcium (Factor IV), Plasmin.',
          topperPearls: 'Draw the clotting cascade with Roman numerals and name all 13 factors in a side table; this structured layout guarantees a 10/10 perfect score.',
          expectedQuestions: {
            tenMarker: 'Define Hemostasis. Describe the stages of blood coagulation detailing intrinsic, extrinsic, and common pathways with a complete schematic cascade.',
            fiveMarker: 'Write a short note on Platelet Plug Formation. Mention the role of Vitamin K and Calcium in blood coagulation.',
            twoMarker: 'Name clotting Factor VIII and Factor XIII. Why is Calcium called Factor IV?'
          }
        },
        {
          id: 'hap_u3_c2',
          topic: 'Erythropoiesis, RBC Structure & Hemoglobin Destruction',
          weightage: '5 MARKS / 10 MARKS',
          frequency: 'Repeated 8/10 Exams',
          definition: 'Erythropoiesis is the physiological process of production and maturation of erythrocytes (red blood cells) occurring predominantly in red bone marrow, stimulated by the renal glycoprotein hormone Erythropoietin (EPO).',
          highlightKeywords: [
            'Pluripotent hemopoietic stem cell (HSC)', 'Proerythroblast', 'Basophilic erythroblast',
            'Polychromatic erythroblast', 'Normoblast (Nucleus extruded)', 'Reticulocyte (1-2% in peripheral blood)',
            'Mature Erythrocyte (Biconcave, 7.2 µm, 120 days lifespan)', 'Erythropoietin (EPO - Hypoxia stimulus)',
            'Heme breakdown to Biliverdin -> Bilirubin', 'Iron recycling via Transferrin & Ferritin'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  STAGES OF ERYTHROPOIESIS (STEM CELL TO RBC)            |
+-------------------------------------------------------------------------+
  [PLURIPOTENT STEM CELL (PPSC)]
               |
               v
  [MYELOID STEM CELL -> CFU-E]
               |  (Stimulated by Erythropoietin from Hypoxic Kidneys)
               v
  [PROERYTHROBLAST] (Large, nucleated, ribosome synthesis begins)
               |
               v
  [BASOPHILIC ERYTHROBLAST] (Intense blue staining due to RNA)
               |
               v
  [POLYCHROMATIC ERYTHROBLAST] (Hemoglobin synthesis begins)
               |
               v
  [NORMOBLAST / ORTHOCHROMATIC] (Nucleus condensed & EXTRUDED from cell)
               |
               v
  [RETICULOCYTE] (Contains residual ribosomal RNA, enters bloodstream)
               |  (1-2 days in circulation)
               v
  [MATURE ERYTHROCYTE] (Biconcave disc, 7.2 µm diameter, no nucleus, 120 days)
`,
          explanation: [
            '1. Essential Maturation Factors: Vitamin B12 (Cyanocobalamin) & Folic acid (required for thymidine triphosphate DNA synthesis; deficiency causes Megaloblastic Pernicious Anemia), and Iron (essential for hemoglobin synthesis; deficiency causes Microcytic Hypochromic Anemia).',
            '2. Regulation by Renal Hypoxia: When renal arterial pO2 drops (anemia, altitude), peritubular interstitial cells in kidneys release Erythropoietin (EPO), accelerating proerythroblast proliferation.',
            '3. RBC Destruction (Reticuloendothelial System): After 120 days, fragile RBCs squeeze through spleen and liver sinusoids, engulfed by macrophages.',
            '4. Hemoglobin Catabolism: Globin hydrolyzes to amino acids. Heme ring opens: Iron (Fe2+) binds to Transferrin and returns to bone marrow or stores in liver as Ferritin/Hemosiderin; Porphyrin ring converts to Biliverdin (green) -> unconjugated Bilirubin (yellow) -> carried by albumin to liver -> conjugated with glucuronic acid -> bile -> stercobilin (feces) & urobilin (urine).'
          ],
          diagramDescription: 'Step-by-step maturation line showing size decreasing from large nucleated proerythroblast down to small biconcave erythrocyte with nucleus ejection step clearly highlighted.',
          scoringKeywordsSummary: 'Erythropoietin, 120 days, 7.2 µm biconcave, Nucleus extruded at normoblast, Reticulocyte 1-2%, B12 & Folate DNA maturation, Ferritin storage, Bilirubin jaundice.',
          topperPearls: 'Always highlight that the nucleus is extruded at the normoblast stage, and reticulocytes take 24-48 hours to mature in the bloodstream.',
          expectedQuestions: {
            tenMarker: 'Explain the stages of Erythropoiesis with a neat diagram. Discuss the factors necessary for maturation of red blood cells and describe hemoglobin degradation.',
            fiveMarker: 'Write a short note on Erythropoietin feedback loop. What are the morphological changes seen during erythropoiesis?',
            twoMarker: 'What is a Reticulocyte count and what does its elevation indicate?'
          }
        }
      ]
    },
    {
      unitNumber: 4,
      title: 'Peripheral Nervous System & Special Senses',
      examImportance: 'High (10-15 Marks: Cranial Nerves Table or Anatomy of Eye/Ear is standard question)',
      concepts: [
        {
          id: 'hap_u4_c1',
          topic: '12 Pairs of Cranial Nerves: Name, Type, Origin & Function',
          weightage: '10 MARKS ESSAY / 5 MARKS',
          frequency: 'Repeated 8/10 Exams',
          definition: 'Cranial nerves are 12 pairs of peripheral nerves that emerge directly from the brain and brainstem, passing through foramina of the cranium to innervate structures of the head, neck, thorax, and abdomen.',
          highlightKeywords: [
            '12 Cranial nerve pairs', 'Sensory, Motor, Mixed classification',
            'CN I Olfactory (Smell)', 'CN II Optic (Vision)', 'CN III Oculomotor (Eye movements, pupil)',
            'CN IV Trochlear (Superior oblique)', 'CN V Trigeminal (Ophthalmic, Maxillary, Mandibular)',
            'CN VI Abducens (Lateral rectus)', 'CN VII Facial (Taste anterior 2/3, Facial expression)',
            'CN VIII Vestibulocochlear (Hearing & Balance)', 'CN IX Glossopharyngeal (Taste posterior 1/3)',
            'CN X Vagus (Parasympathetic viscera)', 'CN XI Accessory (Sternocleidomastoid)',
            'CN XII Hypoglossal (Tongue movements)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  CRANIAL NERVES MNEMONIC ARCHITECTURE                   |
+-------------------------------------------------------------------------+
  Mnemonic for Names: "Oh Oh Oh To Touch And Feel Very Good Velvet, Ah Heaven"
  Mnemonic for Types: "Some Say Marry Money But My Brother Says Big Brains Matter More"
                      (S = Sensory, M = Motor, B = Both/Mixed)

  CN I   - Olfactory         [Sensory] -> Sense of smell
  CN II  - Optic             [Sensory] -> Vision
  CN III - Oculomotor        [Motor]   -> 4 Extrinsic eye muscles + Ciliary/Pupil
  CN IV  - Trochlear         [Motor]   -> Superior oblique muscle
  CN V   - Trigeminal        [Both]    -> Facial sensation + Muscles of mastication
  CN VI  - Abducens          [Motor]   -> Lateral rectus muscle (Abducts eye)
  CN VII - Facial            [Both]    -> Taste ant 2/3 + Facial expression + Salivation
  CN VIII- Vestibulocochlear [Sensory] -> Hearing (Cochlea) & Equilibrium (Vestibule)
  CN IX  - Glossopharyngeal  [Both]    -> Taste post 1/3 + Parotid gland secretion
  CN X   - Vagus             [Both]    -> Major parasympathetic supply to thorax/abdomen
  CN XI  - Accessory         [Motor]   -> Trapezius & Sternocleidomastoid
  CN XII - Hypoglossal       [Motor]   -> Intrinsic & extrinsic tongue muscles
`,
          explanation: [
            '1. Functional Division: Purely Sensory (CN I, II, VIII); Purely Motor (CN III, IV, VI, XI, XII); Mixed Sensory and Motor (CN V, VII, IX, X).',
            '2. Trigeminal Branches (CN V): Largest cranial nerve. Three sensory divisions: V1 Ophthalmic, V2 Maxillary, V3 Mandibular (also contains motor fibers for temporalis, masseter, and pterygoid muscles of mastication).',
            '3. Vagus Nerve (CN X): "The Wanderer" - only cranial nerve extending into thoracic and abdominopelvic cavities, providing parasympathetic innervation to heart (decreases HR), lungs (bronchoconstriction), and GI tract (increases motility and secretions).',
            '4. Clinical Testing Pearls: Bell Palsy (unilateral CN VII facial paralysis), Trigeminal neuralgia (excruciating lightning-like pain along V2/V3), Strabismus/Diplopia (CN III, IV, VI palsy).'
          ],
          diagramDescription: 'Anatomical diagram of ventral brainstem showing emergence points: Forebrain (I, II), Midbrain (III, IV), Pons (V), Pontomedullary junction (VI, VII, VIII), Medulla oblongata (IX, X, XI, XII).',
          scoringKeywordsSummary: 'Sensory vs Motor vs Mixed, Trigeminal 3 branches, Bell Palsy CN VII, Vagus parasympathetic heart/GI, Vestibulocochlear hearing/balance, Mastication.',
          topperPearls: 'Present the cranial nerves in a clean 5-column table: [Roman Numeral | Name | Type (S/M/B) | Foramen of Exit | Primary Function] to get an effortless 10/10.',
          expectedQuestions: {
            tenMarker: 'List the 12 pairs of cranial nerves. Tabulate their number, name, type (sensory/motor/mixed), origin, and physiological functions.',
            fiveMarker: 'Write a short note on the Trigeminal nerve (CN V) detailing its three branches and distribution. What is Trigeminal Neuralgia?',
            twoMarker: 'Name the cranial nerves responsible for taste sensation and ocular movement.'
          }
        },
        {
          id: 'hap_u4_c2',
          topic: 'Structure of the Eye & Physiology of Vision',
          weightage: '10 MARKS ESSAY',
          frequency: 'Repeated 7/10 Exams',
          definition: 'The eyeball is a specialized spherical organ of vision housed within the bony orbit, composed of three concentric tunics (fibrous, vascular, and neural) and refractory media that focus light rays onto photoreceptor cells of the retina.',
          highlightKeywords: [
            'Fibrous Tunic (Sclera & transparent Cornea)', 'Vascular Tunic / Uvea (Choroid, Ciliary body, Iris)',
            'Neural Tunic / Retina (Pigmented layer & Neural layer)', 'Photoreceptors: Rods (Rhodopsin, Scotopic)',
            'Cones (Photopsin/Iodopsin, Photopic, Color vision)', 'Fovea Centralis (Only Cones, Maximum Acuity)',
            'Optic Disc (Blind spot, no photoreceptors)', 'Aqueous humor (Ciliary processes to Canal of Schlemm)',
            'Vitreous humor', 'Visual Pathway (Optic nerve -> Chiasma -> Tract -> LGN -> Visual Cortex Occipital)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  LIGHT REFRACTION & VISUAL CONDUCTION PATHWAY           |
+-------------------------------------------------------------------------+
       [LIGHT RAYS] (Enter anterior eye)
             |
             v
       [CORNEA] (Provides 75% of refractive optical power)
             |
             v
       [AQUEOUS HUMOR] (In Anterior Chamber)
             |
             v
       [PUPIL / LENS] (Ciliary muscle alters curvature for Accommodation)
             |
             v
       [VITREOUS BODY] (Clear gelatinous mass maintains retinal pressure)
             |
             v
       [RETINA PHOTORECEPTORS] (Rods: Scotopic/Dark; Cones: Photopic/Color)
             |
             v  [PHOTOCHEMICAL TRANSDUCTION] (11-cis-retinal to all-trans-retinal)
             |
       [BIPOLAR CELLS] ----> [GANGLION CELLS] (Axons form Optic Nerve)
                                  |
                                  v
                            [OPTIC NERVE (CN II)]
                                  |
                            [OPTIC CHIASM] (Medial nasal fibers decussate)
                                  |
                            [OPTIC TRACT]
                                  |
                            [LATERAL GENICULATE NUCLEUS (LGN - Thalamus)]
                                  |
                            [OPTIC RADIATIONS]
                                  |
                            [PRIMARY VISUAL CORTEX (Broadmann Area 17, Occipital Lobe)]
`,
          explanation: [
            '1. Three Tunics: Fibrous outer coat (posterior opaque white Sclera + anterior avascular Cornea); Vascular middle uvea (Choroid rich in blood vessels and melanin absorbing stray light, Ciliary body with ciliary processes producing aqueous humor and ciliary muscles controlling lens accommodation, and Iris controlling pupillary diameter via sphincter/dilator pupillae); Sensory inner retina.',
            '2. Retinal Cell Layers (Pathway of Light): Light passes through ganglion cells -> bipolar cells -> reaches Rods and Cones at the back of retina.',
            '3. Rods vs Cones: Rods (120 million, contains Rhodopsin = Scotopsin + 11-cis-retinal, highly sensitive to low light, night vision/scotopic, non-color); Cones (6 million, 3 opsins for Red, Green, Blue, bright daylight/photopic vision, high visual acuity concentrated at Fovea Centralis).',
            '4. Wald Visual Cycle: Light strikes Rhodopsin -> 11-cis-retinal isomerizes to all-trans-retinal -> activates transducin G-protein -> activates phosphodiesterase (PDE) -> breaks down cGMP -> closes Na+ channels -> hyperpolarization of photoreceptor -> decreases glutamate release -> depolarizes on-center bipolar cells.',
            '5. Intraocular Fluid Dynamics: Aqueous humor is secreted by ciliary epithelium into posterior chamber -> flows through pupil into anterior chamber -> drains through trabecular meshwork into Canal of Schlemm. Blockage leads to elevated intraocular pressure (>21 mmHg) causing Glaucoma.'
          ],
          diagramDescription: 'Sagittal section of eyeball showing Cornea, Anterior Chamber, Iris, Ciliary body with suspensory zonules, biconvex Lens, Vitreous chamber, Sclera, Choroid, Retina with Fovea Centralis dip and Optic Disc exit point.',
          scoringKeywordsSummary: 'Sclera/Cornea, Canal of Schlemm, Glaucoma >21 mmHg, Rhodopsin 11-cis to all-trans, Hyperpolarization, Fovea centralis cones only, Optic chiasm nasal decussation, Area 17 Occipital.',
          topperPearls: 'Draw the Visual Pathway showing decussation of nasal fibers at the Optic Chiasm and uncrossed temporal fibers to explain Bitemporal Hemianopsia.',
          expectedQuestions: {
            tenMarker: 'Explain the internal anatomy of the human eye with a neat labeled diagram. Discuss the physiology of vision and the visual conduction pathway.',
            fiveMarker: 'Differentiate between Rods and Cones. Explain the formation, circulation, and drainage of Aqueous Humor.',
            twoMarker: 'What is Fovea Centralis and Blind Spot? What is the normal intraocular pressure?'
          }
        }
      ]
    },
    {
      unitNumber: 5,
      title: 'Cardiovascular System',
      examImportance: 'Maximum High (15-20 Marks: Cardiac Cycle, ECG, or Internal Heart Anatomy is asked in EVERY exam)',
      concepts: [
        {
          id: 'hap_u5_c1',
          topic: 'Cardiac Conduction System & Phases of Cardiac Cycle',
          weightage: '10 MARKS ESSAY',
          frequency: 'Guaranteed 10-Marker in 98% Exams',
          definition: 'The cardiac cycle consists of all the physiological mechanical and electrical events that occur from the beginning of one heartbeat to the beginning of the next, comprising alternating periods of systole (contraction/emptying) and diastole (relaxation/filling), lasting 0.8 seconds at a resting heart rate of 75 bpm.',
          highlightKeywords: [
            'Sinoatrial (SA) Node (Pacemaker, 70-80 bpm)', 'Atrioventricular (AV) Node (AV delay 0.1s)',
            'Bundle of His', 'Purkinje fibers (Rapid conduction 4 m/s)', '0.8 second cardiac cycle',
            'Ventricular Systole (0.3s): Isovolumetric contraction & Rapid ejection',
            'Ventricular Diastole (0.5s): Isovolumetric relaxation, Rapid filling, Diastasis, Atrial systole (0.1s)',
            'Heart sounds: Lub (S1 - AV valves close) & Dub (S2 - Semilunar valves close)',
            'Stroke Volume (70 mL)', 'Cardiac Output (CO = HR x SV = 5 L/min)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  CARDIAC ELECTRICAL CONDUCTION SEQUENCE                 |
+-------------------------------------------------------------------------+
   [SA NODE] (Superior posterolateral wall of Right Atrium - Natural Pacemaker)
       |  (Internodal pathways: Anterior, Middle, Posterior - 1 m/s)
       v
   [AV NODE] (Interatrial septum near tricuspid orifice - AV Delay 0.1 sec)
       |
       v
   [BUNDLE OF HIS] (Atrioventricular Bundle crosses fibrous cardiac skeleton)
       |
       v
   [RIGHT & LEFT BUNDLE BRANCHES] (Run along interventricular septum)
       |
       v
   [PURKINJE FIBER NETWORK] (Spreads rapidly 4 m/s through ventricular myocardium)
       |
       v
   [COORDINATED VENTRICULAR CONTRACTION] (From apex upward toward base)
`,
          explanation: [
            '1. Why SA Node is the Natural Pacemaker: Highest intrinsic rate of autorhythmic discharge (70-80 action potentials/min) due to unstable resting membrane potential caused by "funny" hyperpolarization-activated sodium channels (If).',
            '2. Significance of AV Nodal Delay (0.1 sec): Slow conduction through small-diameter nodal fibers ensures that atria completely empty their blood volume into ventricles before ventricular systole begins.',
            '3. Cardiac Cycle Time Partition (0.8s at 75 bpm):',
            '   - Atrial Systole (0.1s) + Atrial Diastole (0.7s) = 0.8s',
            '   - Ventricular Systole (0.3s) + Ventricular Diastole (0.5s) = 0.8s',
            '4. Detailed Mechanical Phases:',
            '   a) Isovolumetric Contraction (0.05s): Ventricles contract with all 4 valves CLOSED. Pressure rises sharply without change in volume.',
            '   b) Rapid Ejection (0.15s) & Reduced Ejection (0.10s): Ventricular pressure exceeds aortic/pulmonary pressure -> semilunar valves open -> 70 mL ejected (Stroke Volume). Remaining 60 mL is End-Systolic Volume (ESV).',
            '   c) Isovolumetric Relaxation (0.08s): Ventricles relax with all 4 valves CLOSED. Pressure plunges without volume change.',
            '   d) Ventricular Filling (Rapid filling + Diastasis + Atrial kick 0.1s): AV valves open -> ventricles fill up to End-Diastolic Volume (EDV = 130 mL).',
            '5. Heart Sounds: S1 ("Lub" - closure of Tricuspid & Bicuspid/Mitral valves at start of ventricular systole); S2 ("Dub" - closure of Aortic & Pulmonary semilunar valves at start of ventricular diastole).'
          ],
          diagramDescription: 'Wiggers diagram or circular clock diagram divided into 8 sectors of 0.1s each, showing atrial systole (0.1), ventricular systole (0.3), and general joint diastole (0.4), with S1 and S2 sound markers.',
          scoringKeywordsSummary: 'SA Node pacemaker 70-80, AV delay 0.1s, Purkinje 4 m/s, 0.8s total, Isovolumetric contraction, Stroke volume 70 mL, EDV 130 mL, ESV 60 mL, Lub S1 / Dub S2, CO = HR x SV.',
          topperPearls: 'Draw the circular clock diagram of 0.8 seconds and define Cardiac Output with the formula: CO = HR (75 bpm) × SV (70 mL) = 5,250 mL/min (approx 5 L/min).',
          expectedQuestions: {
            tenMarker: 'Explain the conducting system of the heart with a neat diagram. Describe the various mechanical events of the Cardiac Cycle with timing and pressure changes.',
            fiveMarker: 'Write a short note on Heart Sounds (S1 and S2) and define Cardiac Output with factors affecting Stroke Volume.',
            twoMarker: 'What is the physiological importance of AV nodal delay? What is Stroke Volume?'
          }
        },
        {
          id: 'hap_u5_c2',
          topic: 'Electrocardiogram (ECG): Waves, Intervals & Clinical Significance',
          weightage: '5 MARKS / 10 MARKS',
          frequency: 'Repeated 9/10 Exams',
          definition: 'An Electrocardiogram (ECG/EKG) is a graphic recording of the electrical voltage potentials generated by the muscle cells of the heart during each cardiac cycle, detected on the surface of the body using standardized lead electrodes.',
          highlightKeywords: [
            'Einthoven Triangle (Willem Einthoven)', 'P wave (Atrial Depolarization, 0.08-0.10s)',
            'PR Interval (AV conduction time, 0.12-0.20s)', 'QRS Complex (Ventricular Depolarization, 0.08-0.12s)',
            'ST Segment (Isoelectric, Ventricular plateau)', 'T wave (Ventricular Repolarization, 0.16s)',
            'QT Interval (Total electrical systole, 0.38-0.42s)', 'ST Elevation (Myocardial Infarction / STEMI)',
            'PR prolongation (Heart block)', 'Arrhythmias (Tachycardia, Bradycardia, Fibrillation)'
          ],
          flowchart: `
+-------------------------------------------------------------------------+
|                  STANDARD NORMAL ECG WAVEFORM & INTERVALS               |
+-------------------------------------------------------------------------+
             R
            / \\
           /   \\                     T
          /     \\                   / \\
    P    /       \\                 /   \\
   / \\  /         \\               /     \\
--/   \\/           \\-------------/       \\---- (Isoelectric line)
       Q            S     ST
     [ P-R ]            Segment
    Interval
   |<----->|
   |<---------- Q - T ---------->|
                Interval
`,
          explanation: [
            '1. P Wave: Small upward deflection caused by Atrial Depolarization originating from SA node. Normal duration: 0.08-0.10 s. Amplitude: 0.1-0.2 mV.',
            '2. P-R Interval: Measured from start of P wave to start of Q wave. Represents conduction transit time from SA node through AV node into Purkinje fibers. Normal: 0.12-0.20 s. Prolongation (>0.20s) indicates First-Degree AV Heart Block.',
            '3. QRS Complex: Large multi-wave deflection representing rapid Ventricular Depolarization (Atrial repolarization is masked inside QRS). Normal duration: 0.08-0.12 s. Widening (>0.12s) indicates Bundle Branch Block.',
            '4. S-T Segment: Flat isoelectric line from end of S wave to start of T wave, corresponding to phase 2 plateau of ventricular action potential. Clinical Marker: ST-elevation indicates acute Myocardial Infarction (STEMI / heart attack); ST-depression indicates myocardial ischemia.',
            '5. T Wave: Dome-shaped upward deflection representing Ventricular Repolarization. Inverted T wave indicates ischemia; Hyperacute tall tented T waves indicate Hyperkalemia.',
            '6. Q-T Interval: From beginning of Q wave to end of T wave (0.38-0.42 s). Represents total electrical ventricular depolarization and repolarization (electrical systole).'
          ],
          diagramDescription: 'Single normal lead II ECG wave trace on grid paper showing P wave, PR segment, sharp Q dip, tall R spike, deep S dip, horizontal ST segment, smooth T wave, and time brackets below for PR and QT intervals.',
          scoringKeywordsSummary: 'P wave atrial depolarization, QRS ventricular depolarization, T wave ventricular repolarization, PR interval AV delay 0.12-0.20s, ST elevation Myocardial Infarction, Einthoven.',
          topperPearls: 'Always draw the ECG waveform on a miniature grid indicating voltage (0.1 mV / small square vertically) and speed (25 mm/sec, 0.04 sec / small square horizontally).',
          expectedQuestions: {
            tenMarker: 'What is an Electrocardiogram? Draw a neat normal Lead II ECG tracing, label all waves and intervals, and explain the physiological and clinical significance of each component.',
            fiveMarker: 'Write a short note on P-R interval and S-T segment abnormalities. What is the clinical significance of ST elevation?',
            twoMarker: 'What does the QRS complex represent and what is its normal duration?'
          }
        }
      ]
    }
  ]
};

export default bp101tNotes;
