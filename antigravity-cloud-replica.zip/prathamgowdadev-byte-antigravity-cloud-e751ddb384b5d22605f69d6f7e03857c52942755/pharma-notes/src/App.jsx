import React, { useState } from 'react';
import { HashRouter, Routes, Route } from 'react-router-dom';
import YearsPage from './pages/YearsPage';
import BPharmYearsPage from './pages/BPharmYearsPage';
import SemestersPage from './pages/SemestersPage';
import SubjectsPage from './pages/SubjectsPage';
import UnitsPage from './pages/UnitsPage';
import UnitTopicsPage from './pages/UnitTopicsPage';
import Home from './pages/Home';
import NoteView from './pages/NoteView';
import { Smartphone, Monitor } from 'lucide-react';

function AppLayout({ children }) {
  const [deviceView, setDeviceView] = useState('phone'); // 'phone' or 'full'

  return (
    <div className="min-h-screen bg-white md:bg-[#0F172A] flex flex-col items-center justify-start sm:p-4 md:p-8">
      {/* Desktop View Switcher Bar (Hidden on Mobile) */}
      <aside aria-label="Desktop Preview Controls" className="hidden md:flex items-center justify-between w-full max-w-[440px] mb-3 px-3 py-1.5 rounded-full bg-slate-900 border border-slate-800 text-xs text-slate-400">
        <span className="font-bold text-white flex items-center gap-1.5 font-sans">
          <span className="w-2 h-2 rounded-full bg-[#3B82F6]" />
          Study Portal &amp; B.Pharm Notes
        </span>
        <div className="flex items-center gap-1 bg-slate-800 p-0.5 rounded-full">
          <button
            onClick={() => setDeviceView('phone')}
            className={`px-2.5 py-1 rounded-full flex items-center gap-1 text-[11px] font-semibold transition-all ${
              deviceView === 'phone' ? 'bg-[#1B2B65] text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3 h-3" />
            Phone View
          </button>
          <button
            onClick={() => setDeviceView('full')}
            className={`px-2.5 py-1 rounded-full flex items-center gap-1 text-[11px] font-semibold transition-all ${
              deviceView === 'full' ? 'bg-[#1B2B65] text-white shadow-xs' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Monitor className="w-3 h-3" />
            Full
          </button>
        </div>
      </aside>

      {/* Main Container: Native full-width on mobile (<768px), or stylized phone frame on desktop */}
      <div
        className={`w-full transition-all duration-300 ${
          deviceView === 'phone'
            ? 'max-w-[440px] md:rounded-[2.75rem] md:shadow-[0_25px_70px_rgba(0,0,0,0.55)] md:border-[10px] md:border-slate-800/90 overflow-hidden relative'
            : 'max-w-2xl rounded-3xl overflow-hidden'
        } bg-white min-h-screen md:min-h-[860px]`}
      >
        {children}
      </div>
    </div>
  );
}

export default function App() {
  return (
    <HashRouter>
      <AppLayout>
        <Routes>
          {/* Main Homepage Landing UI */}
          <Route path="/" element={<YearsPage />} />

          {/* Official 5-Screen B.Pharm Workflow */}
          <Route path="/bpharm" element={<BPharmYearsPage />} />
          <Route path="/year/:yearId" element={<SemestersPage />} />
          <Route path="/semester/:semId" element={<SubjectsPage />} />
          <Route path="/subject/:subjectId" element={<UnitsPage />} />
          <Route path="/subject/:subjectId/unit/:unitNumber" element={<UnitTopicsPage />} />
          
          {/* Legacy & Note Detail Routes */}
          <Route path="/legacy-home" element={<Home />} />
          <Route path="/note/:id" element={<NoteView />} />
        </Routes>
      </AppLayout>
    </HashRouter>
  );
}
