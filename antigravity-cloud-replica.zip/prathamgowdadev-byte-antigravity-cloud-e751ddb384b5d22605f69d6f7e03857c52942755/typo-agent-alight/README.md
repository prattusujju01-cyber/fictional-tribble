# VidCraft Typography AI Studio (Cloudflare Pages + Supabase)

Specialized Personal AI Kinetic Typography Video Generator that generates high-impact typography edits and exports **100% compliant Alight Motion XML project packages (.xml)**.

## Key Features
1. **Switchable Frontier AI Engines:**
   - 👑 **Gemini 2.0 Flash (Project Astra):** 1,000,000 Token context, native raw MP4 video ingestion, 100% free tier.
   - 🌟 **Gemini 1.5 Pro:** 2,000,000 Token context for complex, long-form scripts.
   - 🧠 **Claude 3.7 Sonnet / Fable 5.1:** Precision XML syntax and complex math curves.
   - ⚡ **OpenAI GPT-4o:** Snappy rhythmic copy and hooks.
2. **Video Self-Training Pipeline:**
   - Upload any reference video (MP4). Gemini Astra watches the video, reverse-engineers its easing curves and typography hierarchy, and saves the motion signature to Supabase.
3. **Alight Motion XML Engine:**
   - One-click export of genuine `.xml` project files.
   - Import directly into Alight Motion on Android and iOS to edit every text layer, font, color, keyframe, and bezier easing curve.

## 🚀 How to Deploy to Cloudflare Pages (Always Active 24/7)
1. Go to [Cloudflare Dashboard](https://dash.cloudflare.com/) > **Workers & Pages**.
2. Click **Create Application** > **Pages** > **Direct Upload** (or connect your GitHub repository).
3. Select this project folder (`typo-agent-alight`).
4. Build Output Directory: `.` (Root).
5. Deploy! Your specialized AI studio is now live on a global CDN, 100% free and always active 24/7.

## 📱 How to Import the XML into Alight Motion
### On Android:
1. Download the `.xml` file onto your phone.
2. Tap the file in your file manager and select **Share** > **Alight Motion**.
3. Alight Motion will show a notification: *"Project imported successfully"*. Open Alight Motion > **Projects** tab to edit every layer!

### On iOS:
1. Share the downloaded `.xml` file via AirDrop or the iOS Files app into Alight Motion.
