﻿-- ==============================================================================
-- Supabase Schema: Specialized Personal AI Typography Video Generator
-- Tables for: Projects, Learned Video Styles (Self-Training Memory), and XML Exports
-- ==============================================================================

CREATE TABLE IF NOT EXISTS typography_projects (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID,
    title TEXT NOT NULL DEFAULT 'Untitled Typography Edit',
    prompt TEXT NOT NULL,
    script TEXT NOT NULL,
    duration_seconds NUMERIC NOT NULL DEFAULT 45,
    aspect_ratio TEXT NOT NULL DEFAULT '9:16',
    model_used TEXT NOT NULL DEFAULT 'gemini-2.0-flash',
    palette JSONB NOT NULL DEFAULT '{bg: #F6F1E7, primary: #21130D, accent: #FF5400, pill: #EDE4D4}',
    choreography JSONB NOT NULL,
    alight_motion_xml TEXT NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

CREATE TABLE IF NOT EXISTS learned_video_styles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name TEXT NOT NULL,
    description TEXT,
    reference_video_url TEXT,
    extracted_motion_signature JSONB NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT timezone('utc'::text, now()) NOT NULL
);

ALTER TABLE typography_projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE learned_video_styles ENABLE ROW LEVEL SECURITY;

CREATE POLICY Allow anonymous read/write for personal tool ON typography_projects
    FOR ALL USING (true) WITH CHECK (true);

CREATE POLICY Allow anonymous read/write for learned styles ON learned_video_styles
    FOR ALL USING (true) WITH CHECK (true);

INSERT INTO learned_video_styles (name, description, extracted_motion_signature)
VALUES (
    'Hera 2026 Viral Editorial',
    'High-contrast kinetic typography with elastic overshoot, rapid micro-pauses, and modular box layouts.',
    '{
        easing_curves: {
            elastic_drop: 0.175, 0.885, 0.32, 1.275,
            snap_lock: 0.16, 1, 0.3, 1,
            squash_anticipation: 0.4, 0, 0.2, 1
        },
        pacing: {
            wpm: 175,
            micro_pause_ms: 350,
            max_words_per_beat: 3
        },
        typography_rules: {
            display_font: CabinetGrotesk-Black,
            body_font: PlusJakartaSans-ExtraBold,
            mono_tag_font: SpaceMono-Bold,
            size_contrast: 110pt / 24pt
        },
        color_palette: {
            bg: 0xfff6f1e7,
            primary: 0xff21130d,
            accent: 0xffff5400,
            pill: 0xffede4d4
        }
    }'::jsonb
) ON CONFLICT DO NOTHING;
